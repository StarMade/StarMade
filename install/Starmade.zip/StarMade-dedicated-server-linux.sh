#!/bin/bash
cd "$(dirname "$0")"
java -Xms128m -Xmx1024m -jar StarMade.jar -server