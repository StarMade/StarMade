import java.util.ArrayList;

public final class class_464 extends class_456 {

   public class_464(class_1001 var1, class_1001 var2, class_1001 var3, class_371 var4) {
      super(var1, var2, var3, var4);
   }

   protected final class_1001 a(class_1001 var1) {
      ArrayList var2;
      (var2 = new ArrayList()).add(new class_300(super.field_a.a8(), this.field_a, "Let\'s start with basic movement\n", 5000));
      var2.add(new class_300(super.field_a.a8(), this.field_a, "currently there is no time\nconstraint on how long your\ncharacter can survive in space,\nbut this \"feature\" is planned", 8000));
      var2.add(new class_300(super.field_a.a8(), this.field_a, "Your player\'s health\nis indicated by the bar in the \nbottom of your screen,\n(if you die, you lose half \nof your credits)", 12000));
      var2.add(new class_401(super.field_a.a8(), this.field_a, "Use the mouse to look around,\nand \'" + class_367.field_c.b1() + class_367.field_a.b1() + class_367.field_d.b1() + class_367.field_b.b1() + "\' to move your character,\nand \'" + class_367.field_e.b1() + "\'/\'" + class_367.field_f.b1() + "\' to float Up/Down\n", 20000));
      var2.add(new class_300(super.field_a.a8(), this.field_a, "Keybord assignments can be\nchanged in the options (ESC)", 20000));
      var2.add(new class_300(super.field_a.a8(), this.field_a, "Here are a few things about\nthe interface.", 10000));
      var2.add(new class_300(super.field_a.a8(), this.field_a, "Every indicator on screen\nstands for another Entity.", 10000));
      var2.add(new class_300(super.field_a.a8(), this.field_a, "Red indicators are Enemies,\n\nGreen indicators are Friends.", 9000));
      var2.add(new class_300(super.field_a.a8(), this.field_a, "Light Blue indicators are\nempty ships,\n\nPurple indicators are shops.\n", 9000));
      var2.add(new class_300(super.field_a.a8(), this.field_a, "On the top right is a small\nmap of your surroundings\nseen from the top of the camera", 10000));
      var2.add(new class_300(super.field_a.a8(), this.field_a, "Use \'" + class_367.field_O.b1() + "\' to switch to the \ntarget you are looking at.\nThe target\'s indicator has to be in the.\ncenter of the screen.\n", 12000));
      var2.add(new class_401(super.field_a.a8(), this.field_a, "You can select an object\nby looking at it,\nand pressing \'" + class_367.field_O.b1() + "\'.", 16000));
      var2.add(new class_300(super.field_a.a8(), this.field_a, "The object will be highlighted,\nwhich can be vital in battle\nto help you keep track of an enemy", 6000));
      var2.add(new class_300(super.field_a.a8(), this.field_a, "There are also a lot more other\ntechniques to select an object.\nYou can for example also select\nan object from a list by pressing \'" + class_367.field_J.b1() + "\'", 15000));
      this.a2(var1, (class_1001)var2.get(0));

      for(int var3 = 0; var3 < var2.size() - 1; ++var3) {
         this.a2((class_1001)var2.get(var3), (class_1001)var2.get(var3 + 1));
      }

      return (class_1001)var2.get(var2.size() - 1);
   }

   public final void a1() {
      super.field_b = new class_300(super.field_a.a8(), this.field_a, "This tutorial will guide\nyou through the basic\nfunctions of the game\n", 3000);
      super.field_c = new class_401(super.field_a.a8(), this.field_a, "take some time to get \naccustomed to the controls\n", 20000);
   }
}
