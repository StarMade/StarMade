
public interface class_68 {

   String getUniqueIdentifier();

   boolean isVolatile();
}
