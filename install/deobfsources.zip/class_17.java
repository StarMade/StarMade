import java.util.Iterator;
import org.lwjgl.input.Keyboard;
import org.schema.game.client.view.SegmentDrawer;
import org.schema.game.common.controller.CannotImmediateRequestOnClientException;

public final class class_17 extends class_15 {

   public class_17(class_371 var1) {
      super(var1);
   }

   public final void handleKeyEvent() {
      super.handleKeyEvent();
      this.a6().a27().f();
      if(Keyboard.getEventKeyState()) {
         switch(Keyboard.getEventKey()) {
         case 23:
            class_943.field_Q.d();
            System.err.println("info: " + class_943.field_Q.b1());
            return;
         case 24:
         case 25:
         case 26:
         case 27:
         case 29:
         case 30:
         case 31:
         case 32:
         case 33:
         case 35:
         case 36:
         case 37:
         case 39:
         case 40:
         case 41:
         case 42:
         case 43:
         case 44:
         case 46:
         case 47:
         case 48:
         case 49:
         case 50:
         case 51:
         case 52:
         case 53:
         case 54:
         case 55:
         case 56:
         case 57:
         case 58:
         case 59:
         case 69:
         case 70:
         case 71:
         case 72:
         case 73:
         case 74:
         case 75:
         case 76:
         case 77:
         case 78:
         case 79:
         case 80:
         case 81:
         case 82:
         case 83:
         case 84:
         case 85:
         case 86:
         default:
            break;
         case 28:
            if(class_943.field_o.b1()) {
               class_227.field_b = true;
            }
            break;
         case 34:
            class_943.field_K.d();
            return;
         case 38:
            if(class_943.field_o.b1()) {
               class_227.field_b = true;
               return;
            }
            break;
         case 45:
            class_943.field_v.d();
            System.err.println("SYNC");
            return;
         case 60:
            class_943.field_u.d();
            System.err.println("RELOADING SHADERS");
            return;
         case 61:
            class_943.field_x.d();
            System.err.println("fbo: " + class_943.field_x.b1());
            return;
         case 62:
            class_943.field_V.d();
            System.err.println("bloom: " + class_943.field_V.b1());
            return;
         case 63:
            SegmentDrawer.field_a = true;
            System.err.println("force contextSwitch: " + SegmentDrawer.field_a);
            return;
         case 64:
            if(Keyboard.isKeyDown(42)) {
               SegmentDrawer.field_b = true;
            }

            this.a6().a4().a();
            return;
         case 65:
            this.a6().a33(true);
            return;
         case 66:
            class_801 var1;
            class_800 var4;
            if((var1 = this.a6().a14().field_a.field_a.field_a.a43()) != null && var1 instanceof class_743 && (var4 = ((class_743)var1).getSegmentBuffer().a9(class_743.field_a, false)) != null) {
               this.a6().a14().field_a.field_a.field_a.a51().a16(var4);
               this.a6().a4().a14(this.a6().a3(), (class_365)var4.a7().a15(), new class_47(), var4.a2(new class_47()), true);
               return;
            }

            Iterator var5 = this.a6().a7().values().iterator();

            while(var5.hasNext()) {
               class_801 var2 = (class_801)var5.next();

               try {
                  class_800 var6;
                  if(var2 instanceof class_743 && ((class_743)var2).getSectorId() == this.a6().a8() && (var6 = ((class_743)var2).getSegmentBuffer().a9(class_743.field_a, true)) != null) {
                     this.a6().a14().field_a.field_a.field_a.a51().a16(var6);
                     this.a6().a4().a14(this.a6().a3(), (class_365)var6.a7().a15(), new class_47(), var6.a2(new class_47()), true);
                     return;
                  }
               } catch (CannotImmediateRequestOnClientException var3) {
                  System.err.println("CANNOT IMMEDIATE REQUEST");
               }
            }

            return;
         case 67:
            class_943.field_o.d();
            return;
         case 68:
            class_943.field_F.d();
            System.err.println("physics: " + class_943.field_F.b1());
            return;
         case 87:
            this.a6().a();
            return;
         case 88:
            System.err.println("REQUESTING TEST");
            this.a6().a4().a29().a8().a(new class_47(0, 0, 0));
            return;
         }
      }

   }

   public final void a12(class_941 var1) {
      super.a12(var1);
   }

   public final void a15(class_935 var1) {}
}
