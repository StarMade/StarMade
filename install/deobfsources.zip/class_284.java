
final class class_284 extends class_13 {

   // $FF: synthetic field
   private class_286 field_a;


   class_284(class_286 var1, class_371 var2, Object var3, Object var4, String var5) {
      this.field_a = var1;
      super(var2, 3, var3, var4, var5);
   }

   public final boolean a1() {
      return false;
   }

   public final void onFailedTextCheck(String var1) {}

   public final String handleAutoComplete(String var1, class_1077 var2, String var3) {
      return null;
   }

   public final String[] getCommandPrefixes() {
      return null;
   }

   public final boolean a7(String var1) {
      class_785 var2;
      (var2 = new class_785(class_286.a112(this.field_a))).field_c = var1;
      if(class_286.a113(this.field_a) && ((Boolean)super.field_a.a20().a117().isAdminClient.get()).booleanValue()) {
         var2.field_a = true;
         super.field_a.a53().a181(var2);
      } else {
         var2.field_b = super.field_a.a20().getName();
         super.field_a.a53().a181(var2);
      }

      return true;
   }

   public final void a2() {
      this.field_a.a14().e2(false);
   }
}
