import java.util.Iterator;
import org.schema.schine.network.client.ClientState;

public final class class_262 extends class_114 {

   public class_262(ClientState var1) {
      super(420.0F, var1);
   }

   public final boolean equals(Object var1) {
      return var1 instanceof class_262;
   }

   protected final void a27(class_963 var1) {
      int var2 = 0;
      var1.clear();
      System.err.println("[GUI] UPDATING LIST: " + ((class_371)this.a24()).a20().a132().a78().size());

      for(Iterator var3 = ((class_371)this.a24()).a20().a132().a78().iterator(); var3.hasNext(); ++var2) {
         class_765 var4 = (class_765)var3.next();
         var1.a144(new class_264(this.a24(), var4, var2));
      }

   }
}
