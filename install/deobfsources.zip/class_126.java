import java.util.ArrayList;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.graphicsengine.core.settings.StateParameterNotFoundException;
import org.schema.schine.network.client.ClientState;

public final class class_126 extends class_932 implements class_1410 {

   private class_940 field_a;
   private class_970 field_a;
   private class_970 field_b;
   private class_776 field_a;
   private boolean field_a;


   public class_126(ClientState var1, class_776 var2) {
      super(var1);
      super.field_g = true;
      this.a143(this);
      this.field_a = var2;
      this.field_a = new class_970(class_967.a2().a5("tools-16x16-gui-"), this.a24());
      this.field_b = new class_970(class_967.a2().a5("tools-16x16-gui-"), this.a24());
      this.field_a = new class_940(140, 30, class_28.d(), this.a24());
   }

   public final void a1(class_964 var1, class_941 var2) {
      var1 = null;
      if(var2.field_a && var2.field_a == 0) {
         try {
            this.field_a.a13();
            return;
         } catch (StateParameterNotFoundException var3) {
            var3.printStackTrace();
            class_927.a2(var3);
         }
      }

   }

   public final void a2() {}

   protected final void d() {}

   public final void b() {
      if(!this.field_a) {
         this.c();
      }

      GlUtil.d1();
      this.r();
      this.field_a.b();
      this.field_a.b();
      this.field_b.b();
      GlUtil.c2();
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1() + this.field_a.b1() + this.field_b.b1();
   }

   public final boolean a4() {
      return false;
   }

   public final void c() {
      this.field_a.field_b = new ArrayList();
      this.field_a.field_b.add(this.field_a.a162().toString());
      this.field_a.a165(0.0F, 5.0F, 0.0F);
      this.field_a.c();
      this.field_a.field_g = true;
      this.field_b.field_g = true;
      this.field_a.a143(new class_124(this));
      this.field_b.a143(new class_83(this));
      this.field_a.a_2(21);
      this.field_b.a_2(20);
      this.field_a.a83().field_x = this.field_a.b1();
      this.field_b.a83().field_x = this.field_a.b1() + this.field_a.b1();
      this.field_a = true;
   }

   // $FF: synthetic method
   static class_776 a34(class_126 var0) {
      return var0.field_a;
   }

   // $FF: synthetic method
   static void a35(class_126 var0) {
      var0.field_a.field_b.set(0, var0.field_a.a162().toString());
   }
}
