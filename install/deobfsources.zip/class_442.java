import org.schema.schine.graphicsengine.shader.ErrorDialogException;

public final class class_442 extends class_454 {

   private static final long serialVersionUID = 438885771406304916L;


   public class_442(class_983 var1, String var2, class_371 var3) {
      super(var1, var2, var3);
      this.field_b = true;
   }

   protected final boolean a() {
      return super.field_a.a14().a18().a79().a58().c();
   }

   public final boolean c() {
      class_445 var1;
      if((var1 = super.field_a.a14().a18().a79()).a58().c()) {
         try {
            var1.a58().c2(false);
            var1.a60().c2(true);
         } catch (ErrorDialogException var2) {
            var2.printStackTrace();
         }
      }

      return super.c();
   }
}
