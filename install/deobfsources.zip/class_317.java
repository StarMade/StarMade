import javax.vecmath.Vector3f;

public final class class_317 extends class_937 {

   private static float field_a;


   public final float a() {
      return field_a;
   }

   public final void a1() {
      field_a = (new Vector3f((float)(a2() << 4), (float)(a2() << 4), (float)(a2() << 4))).length();
      class_880.a();
   }
}
