import com.bulletphysics.linearmath.Transform;

public final class class_297 extends class_251 {

   public class_297(Transform var1, String var2) {
      super(var1, var2);
   }

   public final Transform a() {
      return this.field_a;
   }

   public final boolean a2() {
      return true;
   }
}
