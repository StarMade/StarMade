import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.schema.schine.graphicsengine.core.ResourceException;
import org.schema.schine.graphicsengine.forms.Mesh;
import org.schema.schine.graphicsengine.meshimporter.XMLOgreParser;

public final class class_72 {

   private final Map field_a = new HashMap();
   private class_38 field_a;
   private static boolean field_a = true;


   public class_72(class_38 var1) {
      this.field_a = var1;
   }

   public final boolean a(String var1, String var2, String var3) {
      return this.b(var1, var2, var3);
   }

   private boolean b(String var1, String var2, String var3) {
      class_986 var4;
      try {
         var4 = null;
         if(this.field_a.containsKey(var1)) {
            return true;
         } else {
            class_957 var7;
            (var7 = (new XMLOgreParser()).a11("data/" + var3 + "/", var2)).c11(var1);
            this.a1(var7, var3);
            if(field_a) {
               Iterator var8 = var7.a156().iterator();

               while(var8.hasNext()) {
                  if((var4 = (class_986)var8.next()) instanceof Mesh) {
                     try {
                        while(!var4.i1()) {
                           Mesh.a174((Mesh)var4);
                        }
                     } catch (Exception var5) {
                        System.err.println("error in " + var1);
                        var5.printStackTrace();
                     }
                  }
               }
            }

            this.field_a.put(var1, var7);
            return true;
         }
      } catch (ResourceException var6) {
         var4 = null;
         var6.printStackTrace();
         return false;
      }
   }

   private void a1(Mesh var1, String var2) {
      if(var1.a157().a9() && var1.a157().b1() != null) {
         try {
            var1.a157().c2(class_967.a3().a6("data/" + var2 + var1.a157().b1(), true));
            String var3 = var1.a157().b1().replace(".", "_normal.");
            String var4 = var1.a157().b1().replace(".", "_specular.");
            this.field_a.a2("data/" + var2 + var3);
            this.field_a.a2("data/" + var2 + var4);
            var1.a157().a13(class_967.a3().a6("data/" + var2 + var3, true));
            var1.a157().e();
            var1.a157().b3(class_967.a3().a6("data/" + var2 + var4, true));
            var1.a157().g();
         } catch (ResourceException var5) {
            ;
         } catch (IOException var6) {
            System.err.println("ERROR LOADING: data/" + var2 + var1.a157().b1());
            var6.printStackTrace();
         }
      }

      Iterator var7 = var1.a156().iterator();

      while(var7.hasNext()) {
         class_986 var8;
         if((var8 = (class_986)var7.next()) instanceof Mesh) {
            var1 = (Mesh)var8;
            this.a1(var1, var2);
         }
      }

   }

   public final Map a2() {
      return this.field_a;
   }

}
