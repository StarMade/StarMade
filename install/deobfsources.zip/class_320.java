import org.schema.game.common.data.element.ElementInformation;

public final class class_320 {

   private ElementInformation field_a;
   private class_739 field_a;
   public int field_a;


   public class_320(ElementInformation var1, class_739 var2) {
      this.field_a = var1;
      this.field_a = var2;
   }

   public final String toString() {
      return "how many " + this.field_a.getName() + " you want to buy?\nIf you enter too many, the maximal amount you can affort\nwill be displayed.\nCurrent Buying Value: " + this.field_a.a89(this.field_a, this.field_a) + "c (base " + (long)this.field_a * this.field_a.getPrice() + "c)";
   }
}
