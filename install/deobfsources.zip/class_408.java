import java.io.IOException;
import org.schema.game.common.data.UploadInProgressException;

final class class_408 extends class_14 {

   // $FF: synthetic field
   private class_303 field_a;


   class_408(class_303 var1, class_371 var2, Object var3, Object var4, String var5) {
      this.field_a = var1;
      super(var2, 50, var3, var4, var5);
   }

   public final String[] getCommandPrefixes() {
      return null;
   }

   public final String handleAutoComplete(String var1, class_1077 var2, String var3) {
      return var1;
   }

   public final boolean a1() {
      return super.field_a.b().indexOf(this) != super.field_a.b().size() - 1;
   }

   public final void a2() {
      this.field_a.e2(false);
   }

   public final void onFailedTextCheck(String var1) {
      this.a9("SHIPNAME INVALID: " + var1);
   }

   public final boolean a7(String var1) {
      try {
         super.field_a.a20().a129().a4(var1);
         return true;
      } catch (IOException var2) {
         var2.printStackTrace();
         class_927.a2(var2);
      } catch (UploadInProgressException var3) {
         super.field_a.a4().b1("Cannot Upload!\nThere is already\nan Upload in progress");
      }

      return false;
   }
}
