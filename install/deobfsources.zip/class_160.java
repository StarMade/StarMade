import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import javax.vecmath.Vector4f;
import org.schema.schine.network.client.ClientState;

public abstract class class_160 extends class_964 implements Observer {

   private class_966 field_a;
   private class_1412 field_a;
   private class_963 field_a;
   boolean field_a;
   private boolean field_b;
   private class_928 field_a;
   private class_928 field_b;
   private class_928 field_c;
   private class_180 field_a;
   private class_928 field_d;


   public class_160(ClientState var1, boolean var2) {
      this(var1, 340, var2);
   }

   public class_160(ClientState var1, int var2, boolean var3) {
      super(var1);
      this.field_a = true;
      this.field_b = var3;
      this.field_a = new class_966(542.0F, (float)(var2 - 30), var1);
      this.field_a = new class_1412(var1, 542.0F, 30.0F);
      this.field_a = new class_963(this.a24());
   }

   public final void a2() {}

   public abstract Collection a50();

   public final void b() {
      if(this.field_a) {
         class_963 var2 = this.field_a;
         class_160 var1 = this;
         Collection var3 = this.a50();
         HashSet var4 = new HashSet();
         Iterator var5 = var2.iterator();

         while(var5.hasNext()) {
            class_972 var6;
            class_248 var7;
            if((var6 = (class_972)var5.next()) instanceof class_248 && (var7 = (class_248)var6).a149() instanceof class_959 && ((class_959)var7.a149()).c1()) {
               var4.add(var7.a108().field_a);
            }
         }

         var2.clear();
         int var9 = 0;

         for(Iterator var10 = var3.iterator(); var10.hasNext(); ++var9) {
            class_785 var11 = (class_785)var10.next();
            class_274 var8 = new class_274(var1.a24(), var1, var11, var1.field_b, var9);
            var2.a144(new class_248(var8, var8, var11, var1.a24()));
            var8.a29(var4.contains(var11.field_a));
         }

         if(var1.field_a == null) {
            var1.a51(class_180.field_a);
         } else {
            var1.b8(var1.field_a);
         }

         var1.b2(var1.field_a);
         if(var2.size() > 0) {
            var1.a9(var1.field_a);
         }

         this.field_a = false;
      }

      this.k();
   }

   public final void a51(class_180 var1) {
      var1.field_a = Collections.reverseOrder(var1.field_a);
      this.b8(var1);
   }

   private void b8(class_180 var1) {
      Collections.sort(this.field_a, var1.field_a);
      this.field_a = var1;
      this.field_a.field_a.set(0.7F, 0.7F, 0.7F, 0.7F);
      this.field_b.field_a.set(0.7F, 0.7F, 0.7F, 0.7F);
      this.field_c.field_a.set(0.7F, 0.7F, 0.7F, 0.7F);
      this.field_d.field_a.set(0.7F, 0.7F, 0.7F, 0.7F);
      switch(class_182.field_a[var1.ordinal()]) {
      case 1:
         this.field_a.field_a.set(1.0F, 1.0F, 1.0F, 1.0F);
         break;
      case 2:
         this.field_b.field_a.set(1.0F, 1.0F, 1.0F, 1.0F);
         break;
      case 3:
         this.field_c.field_a.set(1.0F, 1.0F, 1.0F, 1.0F);
         break;
      case 4:
         this.field_d.field_a.set(1.0F, 1.0F, 1.0F, 1.0F);
      }

      for(int var2 = 0; var2 < this.field_a.size(); ++var2) {
         ((class_274)this.field_a.a145(var2).a149()).a72(var2);
      }

   }

   public final void c() {
      this.field_a.c6(this.field_a);
      this.field_a.a83().field_y = this.field_a.a3();
      this.field_a = new class_928(this.a24(), 217, 20, new Vector4f(0.4F, 0.4F, 0.4F, 0.5F), new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), class_28.o(), "Name", new class_158(this));
      this.field_b = new class_928(this.a24(), 140, 20, new Vector4f(0.4F, 0.4F, 0.4F, 0.5F), new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), class_28.o(), "Owner", new class_188(this));
      this.field_c = new class_928(this.a24(), 90, 20, new Vector4f(0.4F, 0.4F, 0.4F, 0.5F), new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), class_28.o(), "Price", new class_186(this));
      this.field_d = new class_928(this.a24(), 50, 20, new Vector4f(0.4F, 0.4F, 0.4F, 0.5F), new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), class_28.o(), "Rating", new class_184(this));
      this.field_b.a83().field_x = this.field_a.a83().field_x + 217.0F;
      this.field_c.a83().field_x = this.field_b.a83().field_x + 140.0F;
      this.field_d.a83().field_x = this.field_c.a83().field_x + 90.0F;
      this.field_a.a9(this.field_a);
      this.field_a.a9(this.field_b);
      this.field_a.a9(this.field_c);
      this.field_a.a9(this.field_d);
      this.a9(this.field_a);
      this.a9(this.field_a);
   }

   public final float a3() {
      return this.field_a.a3() + this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public void update(Observable var1, Object var2) {
      if(var1 instanceof class_959) {
         this.field_a.f();
      }

   }
}
