
public abstract class class_438 implements class_74 {

   public class_47 field_a;
   public class_347[] field_a;


   public void fromTagStructure(class_79 var1) {
      class_79[] var2 = (class_79[])var1.a4();
      this.field_a = (class_47)var2[0].a4();
   }

   public boolean isVolatile() {
      return false;
   }

   public class_79 toTagStructure() {
      class_79 var1 = new class_79(class_81.field_k, (String)null, this.field_a);
      class_79 var2 = null.toTagStructure();
      class_79[] var3 = new class_79[this.field_a.length + 1];

      for(int var4 = 0; var4 < var3.length; ++var4) {
         var3[var4] = this.field_a[var4].toTagStructure();
      }

      var3[var3.length - 1] = new class_79(class_81.field_a, (String)null, (class_79[])null);
      class_79 var5 = new class_79(class_81.field_n, (String)null, var3);
      return new class_79(class_81.field_n, (String)null, new class_79[]{var1, var2, var5, new class_79(class_81.field_a, (String)null, (class_79[])null)});
   }
}
