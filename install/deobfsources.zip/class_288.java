import javax.vecmath.Vector3f;
import javax.vecmath.Vector4f;
import org.schema.schine.network.client.ClientState;

public final class class_288 extends class_1361 {

   private class_785 field_a;
   private String field_b;
   private boolean field_b;


   public class_288(ClientState var1, class_785 var2, String var3, int var4) {
      super(var1, 510.0F, 30.0F, new Vector4f());
      this.field_a = var2;
      this.field_b = var3;
      this.a72(var4);
   }

   public final void a72(int var1) {
      super.field_a = var1 % 2 == 0?new Vector4f(0.0F, 0.0F, 0.0F, 0.0F):new Vector4f(0.1F, 0.1F, 0.1F, 0.5F);
   }

   public final void b() {
      super.b();
   }

   public final void c() {
      if(!this.field_b) {
         super.c();
         class_940 var1;
         (var1 = new class_940(10, 10, this.a24())).a137(this.field_b);
         class_940 var2;
         (var2 = new class_940(10, 10, this.a24())).a137(this.field_a.field_a);
         class_940 var3;
         (var3 = new class_940(10, 10, this.a24())).a137(this.field_a.field_b);
         class_940 var4;
         (var4 = new class_940(10, 10, this.a24())).a137(String.valueOf(this.field_a.field_b));
         class_940 var5 = new class_940(10, 10, this.a24());
         if(this.field_a.field_a > 0.0F) {
            var5.a137(class_40.a2(this.field_a.field_a) + "/" + class_785.field_d);
         } else {
            var5.a137("n/a");
         }

         this.a24();
         Vector3f var10000 = var2.a83();
         var10000.field_x += 7.0F;
         var3.a83().field_x = var2.a83().field_x + 210.0F;
         var4.a83().field_x = var3.a83().field_x + 140.0F;
         var5.a83().field_x = var4.a83().field_x + 100.0F;
         var1.a83().field_y = 5.0F;
         var2.a83().field_y = 5.0F;
         var3.a83().field_y = 5.0F;
         var4.a83().field_y = 5.0F;
         var5.a83().field_y = 5.0F;
         this.a9(var1);
         this.a9(var2);
         this.a9(var3);
         this.a9(var4);
         this.a9(var5);
         this.field_b = true;
      }

   }
}
