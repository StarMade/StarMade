import org.schema.schine.network.client.ClientState;

public final class class_194 extends class_970 {

   private final class_319 field_a;


   public class_194(class_1382 var1, ClientState var2, class_319 var3, String var4, class_1410 var5) {
      super(var1, var2);
      this.field_a = var3;
      super.field_g = true;
      super.field_a = var4;
      this.a143(var5);
   }

   public final void b() {
      if(!super.field_a) {
         this.a_2(this.field_a.a(this.a_()));
         super.b();
      }
   }
}
