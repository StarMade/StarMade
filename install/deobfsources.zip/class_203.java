
final class class_203 implements class_1410 {

   // $FF: synthetic field
   private class_82 field_a;


   class_203(class_82 var1) {
      this.field_a = var1;
      super();
   }

   public final void a(class_964 var1, class_941 var2) {
      var1 = null;
      if(var2.field_a && var2.field_a == 0) {
         class_461 var3;
         (var3 = class_82.a5(this.field_a)).field_a = Math.max(1, var3.field_a - 1);
         class_82.a6(this.field_a);
      }

   }

   public final boolean a1() {
      return false;
   }
}
