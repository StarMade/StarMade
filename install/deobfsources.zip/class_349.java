import java.io.DataInputStream;
import java.io.DataOutputStream;

public final class class_349 extends class_337 {

   public class_799 field_a;


   public final int a9(class_1382 var1) {
      switch(class_351.field_a[this.field_a.ordinal()]) {
      case 1:
         return 1;
      case 2:
         return 2;
      case 3:
         return 0;
      case 4:
         return 5;
      case 5:
         return 3;
      default:
         return super.a9(var1);
      }
   }

   protected final void a1(DataInputStream var1) {
      super.a1(var1);
      this.field_a = class_799.values()[var1.readByte()];
   }

   public final void a2(DataOutputStream var1) {
      super.a2(var1);
      var1.writeByte(this.field_a.ordinal());
   }
}
