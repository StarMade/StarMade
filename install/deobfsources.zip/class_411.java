
final class class_411 extends class_13 {

   // $FF: synthetic field
   private class_777 field_a;
   // $FF: synthetic field
   private class_777 field_b;
   // $FF: synthetic field
   private class_423 field_a;


   class_411(class_423 var1, class_371 var2, Object var3, Object var4, class_777 var5, class_777 var6) {
      this.field_a = var1;
      this.field_a = var5;
      this.field_b = var6;
      super(var2, 5, var3, var4);
   }

   public final boolean a1() {
      return false;
   }

   public final void onFailedTextCheck(String var1) {}

   public final String handleAutoComplete(String var1, class_1077 var2, String var3) {
      return null;
   }

   public final String[] getCommandPrefixes() {
      return null;
   }

   public final boolean a7(String var1) {
      super.field_a.a45().a27(super.field_a.getPlayerName(), this.field_a.a3(), this.field_b.a3(), (byte)1, var1);
      return true;
   }

   public final void a2() {
      this.field_a.e2(false);
   }
}
