
public final class class_448 extends class_454 {

   private static final long serialVersionUID = 438885771406304916L;


   public class_448(class_983 var1, String var2, class_371 var3) {
      super(var1, var2, var3);
      this.field_b = true;
   }

   protected final boolean a() {
      return !super.field_a.a14().a18().a79().a61().c();
   }
}
