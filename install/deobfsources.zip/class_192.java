import com.bulletphysics.linearmath.Transform;
import java.nio.FloatBuffer;
import java.util.Iterator;
import javax.vecmath.Matrix3f;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.util.vector.Matrix4f;
import org.schema.game.common.data.element.ElementKeyMap;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public final class class_192 extends class_964 {

   private Transform field_b = new Transform();
   private Transform field_c = new Transform();
   private Matrix3f field_a = new Matrix3f();
   private static Transform field_d = new Transform();
   private static FloatBuffer field_b = BufferUtils.createFloatBuffer(16);
   private static float[] field_a = new float[16];
   private static Transform field_e = new Transform();
   private static FloatBuffer field_c = BufferUtils.createFloatBuffer(16);
   private static float[] field_b = new float[16];
   private short field_a = 1;
   private int field_a = 0;
   private int field_b = 0;
   private boolean field_a;
   public static class_1433 field_a = new class_1433();


   public class_192(ClientState var1) {
      super(var1);
      this.field_b.setIdentity();
      this.field_c.setIdentity();
   }

   public static void e() {
      Matrix4f var0 = class_967.field_a;
      field_b.rewind();
      var0.store(field_b);
      field_b.rewind();
      field_b.get(field_a);
      field_d.setFromOpenGLMatrix(field_a);
      field_d.origin.set(0.0F, 0.0F, 0.0F);
   }

   public final void a2() {}

   public final void b() {
      if(!this.h3()) {
         if(!this.field_a) {
            this.field_a = true;
         }

         GlUtil.d1();
         super.field_f = false;
         this.r();
         if(super.field_g) {
            this.l();
         }

         short var2 = this.field_a;
         if(var2 != 0) {
            Matrix4f var3 = class_967.field_a;
            field_c.rewind();
            var3.store(field_c);
            field_c.rewind();
            field_c.get(field_b);
            field_e.setFromOpenGLMatrix(field_b);
            GL11.glClear(256);
            class_964.j();
            GL11.glDisable(2929);
            GL15.glBindBuffer('\u8892', 0);
            GlUtil.b3(field_e);
            ElementKeyMap.getInfo(var2).getBuildIconNum();
            GlUtil.d1();
            GlUtil.c4(0.0F, 0.0F, 0.0F);
            GlUtil.b5(32.0F, -32.0F, 32.0F);
            if(ElementKeyMap.getInfo(var2).getBlockStyle() == 3) {
               this.field_c.basis.set(field_d.basis);
               field_d.basis.setIdentity();
            } else {
               this.field_a.set(this.field_b.basis);
               field_d.basis.mul(this.field_a);
            }

            GlUtil.b3(field_d);
            Transform var4;
            (var4 = new Transform()).setIdentity();
            var4.basis.set(((class_371)this.a24()).a6().getWorldTransform().basis);
            GlUtil.b3(var4);
            if(ElementKeyMap.getInfo(var2).getBlockStyle() == 3) {
               field_d.basis.set(this.field_c.basis);
            }

            class_863 var5;
            (var5 = new class_863()).a50(ElementKeyMap.getInfo(var2).getIndividualSides() < 4 && ElementKeyMap.getInfo(var2).isOrientatable());
            var5.a49((byte)this.field_a);
            var5.b6((byte)this.field_b);
            var5.a48(var2);
            GlUtil.c2();
            class_964.h1();
            GL11.glEnable(2896);
            GL11.glDisable(2977);
            GL11.glEnable(2929);
         }

         Iterator var1 = super.field_a.iterator();

         while(var1.hasNext()) {
            ((class_986)var1.next()).b();
         }

         GlUtil.c2();
      }
   }

   public final void c() {
      this.field_a = true;
   }

   public final float a3() {
      return 32.0F;
   }

   public final float b1() {
      return 32.0F;
   }

   public final void a74(short var1) {
      this.field_a = var1;
   }

   public final void a72(int var1) {
      this.field_a = var1;
   }

   public final void b13(int var1) {
      this.field_b = var1;
   }

}
