import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public final class class_122 extends class_964 {

   private class_970 field_a = new class_970(class_967.a2().a5("ai-panel-gui-"), this.a24());
   private class_966 field_a;
   private boolean field_a = true;
   private class_963 field_a;


   public class_122(ClientState var1) {
      super(var1);
   }

   public final void a9(class_964 var1) {
      this.field_a.a9(var1);
   }

   public final void a2() {
      this.field_a.a2();
   }

   public final void b2(class_964 var1) {
      this.field_a.b2(var1);
   }

   public final void b() {
      if(this.field_a) {
         this.c();
      }

      GlUtil.d1();
      this.r();
      this.field_a.b();
      GlUtil.c2();
   }

   private class_18 a32() {
      return ((class_371)this.a24()).a14().field_a.field_a.field_a;
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public final void c() {
      this.field_a = new class_966(533.0F, 316.0F, this.a24());
      this.field_a.a83().set(251.0F, 107.0F, 0.0F);
      this.field_a = new class_963(this.a24());
      this.field_a.a143(this.a32());
      this.field_a.c6(this.field_a);
      this.field_a.c();
      super.a9(this.field_a);
      this.field_a.a9(this.field_a);
      this.d();
      this.field_a = false;
   }

   private void a33(class_778 var1) {
      this.field_a.clear();
      if(var1 != null) {
         class_776[] var6;
         int var2 = (var6 = var1.a176()).length;

         for(int var3 = 0; var3 < var2; ++var3) {
            class_776 var4;
            if((var4 = var6[var3]).a162() instanceof Boolean) {
               class_120 var5 = new class_120(this.a24(), var4);
               this.field_a.a144(new class_934(this.a24(), var4.a(), var5, true));
            } else {
               class_126 var7 = new class_126(this.a24(), var4);
               this.field_a.a144(new class_934(this.a24(), var4.a(), var7, true));
            }
         }
      }

   }

   public final void a12(class_935 var1) {
      super.a12(var1);
      if(this.a32().field_d) {
         if(this.a32().field_a != null) {
            if(!(this.a32().field_a.a7().a15() instanceof class_993)) {
               ((class_371)this.a24()).a4().b1("this structure has no AI");
               return;
            }

            this.a33((class_778)((class_993)this.a32().field_a.a7().a15()).a());
         } else {
            this.a33((class_778)null);
         }

         this.a32().field_d = false;
      }

   }
}
