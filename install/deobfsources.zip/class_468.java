import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import org.schema.schine.ai.stateMachines.FSMException;

public final class class_468 extends class_456 implements Observer {

   private class_452 field_a;
   private class_450 field_a;
   private class_300 field_a;
   private class_452 field_b;
   private class_450 field_b;
   private class_466 field_a;
   private class_300 field_b;


   public class_468(class_1001 var1, class_1001 var2, class_1001 var3, class_371 var4) {
      super(var1, var2, var3, var4);
      var4.a14().a18().a79().a60().a51().a45().a36().addObserver(this);
      var4.a14().a18().a79().a60().a51().a45().a38().addObserver(this);
      var4.a14().a18().a79().a60().a52().addObserver(this);
   }

   protected final class_1001 a(class_1001 var1) {
      ArrayList var3;
      (var3 = new ArrayList()).add(new class_300(super.field_a.a8(), this.field_a, "Please wait until the new ship is!\nloaded. In multiplayer, it might take\na short moment.", 6000));
      var3.add(new class_300(super.field_a.a8(), this.field_a, "Congratulations!\nThis is your first Ship!\n", 4000));
      var3.add(new class_300(super.field_a.a8(), this.field_a, "The block you see is the core\nmodule.\nIt\'s the most important part of a ship", 8000));
      var3.add(new class_300(super.field_a.a8(), this.field_a, "If your core takes too much damage,\nyou will die, and the core will overheat.\nYou can stop any core from overheating,\nif you enter it.\n", 8000));
      var3.add(new class_300(super.field_a.a8(), this.field_a, "The bigger your ship is,\nthe longer the overheating will take.\nShould the counter reach zero,\nyour ship will be destroyed!", 8000));
      var3.add((new class_446(super.field_a.a8(), "You can enter your ship this way:\nAim at the core element, and\npress \'" + class_367.field_v.b1() + "\'. You have to be near\nenough to the core, to enter a ship.", this.field_a)).a9(new class_389(), this.field_a));
      var3.add(this.f(new class_300(super.field_a.a8(), this.field_a, "Good job!\nYou are now in the special build mode\nof this ship. You can of course add blocks\nfrom outside the ship, but this mode\noffers a lot of advantages.", 4000)));
      var3.add(this.f(new class_401(super.field_a.a8(), this.field_a, "You can move around the same way\n you do outside the ship.\nNote, that in this build mode, you will always\nbe orientated to the ship.", 12000)));
      var3.add(this.f(new class_300(super.field_a.a8(), this.field_a, "With \'" + class_367.field_t.b1() + "\' you can reset the\nview to the ship\n", 8000)));
      var3.add(this.f(new class_401(super.field_a.a8(), this.field_a, "The left mouse button builds,\nand the right removes blocks.\nSelect the block you want to place\nwith the mouse wheel, or number key\n(\'" + class_367.field_t.b1() + "\' to reset camera)", 25000)));
      var3.add(this.f(new class_300(super.field_a.a8(), this.field_a, "You can switch the mouse\nbuttons in the options\n", 8000)));
      var3.add(this.f(new class_401(super.field_a.a8(), this.field_a, "Holding down " + class_367.field_U.b1() + "\nwill let you place blocks\nfrom a fixed camera angle.\n", 20000)));
      var3.add(this.f(new class_300(super.field_a.a8(), this.field_a, "Holding down " + class_367.field_U.b1() + "\nalso lets you use advanced\nbuilding tools like symmetry.\n", 20000)));
      var3.add(this.f(new class_300(super.field_a.a8(), this.field_a, "The arrow on top of the screen\nindicates, where the front of\nthe ship is.\nBe careful not to build sideways!", 6000)));
      var3.add(this.f(new class_300(super.field_a.a8(), this.field_a, "You can switch between build mode and\nflight mode with \'" + class_367.field_r.b1() + "\'.\n", 8000)));
      this.field_a = new class_452(super.field_a.a8(), "You are not in build mode.\nPlease press \'" + class_367.field_r.b1() + "\'\nto switch back to build mode.\n", this.field_a);
      var3.add(this.f(this.field_a));
      var3.add(this.f(this.b(new class_300(super.field_a.a8(), this.field_a, "To build a functional ship,\nyou must add some thrust to your ship\n", 5000))));
      var3.add(this.f(this.b(new class_440(super.field_a.a8(), this.field_a, (short)8))));
      var3.add(this.f(this.b(new class_300(super.field_a.a8(), this.field_a, "Great!\nBut the thrusters need power\nso we have to place a\npower generator", 5000))));
      var3.add(this.f(this.b(new class_440(super.field_a.a8(), this.field_a, (short)2))));
      var3.add(this.f(this.b(new class_300(super.field_a.a8(), this.field_a, "Great work!\nPower Blocks will supply\nyour ship with energy\n", 7000))));
      var3.add(this.f(this.b(new class_300(super.field_a.a8(), this.field_a, "The more usable blocks you have\n(Thrusters, Weapons, Shield, etc...),\nthe more power you will need.\n", 7000))));
      var3.add(this.f(this.b(new class_300(super.field_a.a8(), this.field_a, "As you can see,\nyour ship\'s power bar\nat the bottom of the screen\nwill now fill up.\n", 7000))));
      var3.add(this.f(this.b(new class_300(super.field_a.a8(), this.field_a, "Blocks like Thrusters and Weapons\nwill consume that power,\nbut don\'t worry: \npower automatically regenerates.\n", 7000))));
      var3.add(this.f(this.b(new class_300(super.field_a.a8(), this.field_a, "You can also achieve a higher\ncapacity and regeneration rate of \npower blocks by grouping\nthem together.\n", 7000))));
      var3.add(this.f(this.b(new class_300(super.field_a.a8(), this.field_a, "Note, that thrusters are\nconnected by default.\nConnections can be customized\nin star-made, but that will be part\nof the advanced Tutorial", 5000))));
      var3.add(this.f(this.b(new class_300(super.field_a.a8(), this.field_a, "The more thruster elements\nyou have,\nthe faster your space ship \naccelerates", 10000))));
      var3.add(this.f(this.b(new class_300(super.field_a.a8(), this.field_a, "Group thruster elements\ntogether to get an even \nbetter efficiency\n", 10000))));
      this.field_a = new class_450(super.field_a.a8(), "You are now ready to fly\nyour first space ship!\nPlease use the \'" + class_367.field_r.b1() + "\'\nto switch into flight mode.\n", this.field_a);
      var3.add(this.f(this.field_a));
      var3.add(this.f(this.d(new class_401(super.field_a.a8(), this.field_a, "You are now in Flight mode!\nMove your ship with \'" + class_367.field_c.b1() + class_367.field_a.b1() + class_367.field_d.b1() + class_367.field_b.b1() + "\'.\nRoll with the mouse while holding \nthe \'" + class_367.field_q.b1() + "\' key.\nPress \'" + class_367.field_p.b1() + "\' to break", '\u9c40'))));
      var3.add(this.f(this.d(new class_300(super.field_a.a8(), this.field_a, "Now let\'s add some weapons!\n", 8000))));
      this.field_b = new class_452(super.field_a.a8(), "Please use the \'" + class_367.field_r.b1() + "\'\nto switch back into build mode.\n", this.field_a);
      var3.add(this.f(this.field_b));
      var3.add(this.f(this.c(new class_300(super.field_a.a8(), this.field_a, "First you have to place a\n\"weapon controller\".\nNote that Weapon controllers can\nalso be entered by other players.", 12000))));
      var3.add(this.f(this.c(new class_440(super.field_a.a8(), this.field_a, (short)6))));
      var3.add(this.f(this.c(new class_300(super.field_a.a8(), this.field_a, "Well done!\nThe wobbling boxes mean, that the weapon\ncontroller is connected to the core.", 12000))));
      var3.add(this.f(this.c(new class_300(super.field_a.a8(), this.field_a, "Now you need a weapon to \nconnect to this weapon controller.\n", 7000))));
      var3.add(this.f(this.c(new class_440(super.field_a.a8(), this.field_a, (short)16))));
      var3.add(this.f(this.c(new class_300(super.field_a.a8(), this.field_a, "Awesome!\nArranging Weapons into larger groups\nwill increase that weapon\'s \nspeed, range, damage, and\ndecreases its reload time.\n", 14000))));
      var3.add(this.f(this.c(new class_300(super.field_a.a8(), this.field_a, "Yay!\nYou can now obliterate \nyour enemies.\n", 7000))));
      this.field_b = new class_450(super.field_a.a8(), "You are now ready to test\nyour spaceship\'s weapons\nPlease use the \'" + class_367.field_r.b1() + "\'\nto switch to flight mode.\n", this.field_a);
      var3.add(this.f(this.field_b));
      var3.add(this.f(this.e(new class_401(super.field_a.a8(), this.field_a, "Press the left mouse button to fire\n", 12000))));
      var3.add(this.f(this.c(new class_300(super.field_a.a8(), this.field_a, "In StarMade, there is a connection system for each ship!\n\nIn order to use a block (e.g. weapon) from where you\nhave entered the ship, it has to be directly,\nor indirectly connected to the ship.\n", 7000))));
      var3.add(this.f(this.c(new class_300(super.field_a.a8(), this.field_a, "Thrusters have to be connected to the core!\nHowever, if you place down a thruster, it will be connected\nby default, so you don\'t have to worry about that.\n", 7000))));
      var3.add(this.f(this.c(new class_300(super.field_a.a8(), this.field_a, "If you place down any controller (like the weapon computer),\nit will automatically connected to the core, and selected,\nso every following weapon will be connected to that weapon controller.\nThe connection chain for weapons is: weapon -> weapon computer -> core", 7000))));
      var3.add(this.f(this.c(new class_300(super.field_a.a8(), this.field_a, "All controllers connected to the core will be\navailable to use for the player that entered the core", 7000))));
      var3.add(this.f(this.c(new class_300(super.field_a.a8(), this.field_a, "Note, that this chain goes for every\nusable module in the game:\nmodule -> controller -> core \n", 7000))));
      var3.add(this.f(this.c(new class_300(super.field_a.a8(), this.field_a, "If you connect two modules to one\ncontroller, they will fire\nat the same time. Grouping them \nwill make the weapon stronger", 7000))));
      var3.add(this.f(this.c(new class_300(super.field_a.a8(), this.field_a, "Every controller will give you\nan action, that can be\nreassigned to a slot\nin your bottom bar\n", 8000))));
      var3.add(this.f(this.e(new class_300(super.field_a.a8(), this.field_a, "In the bottom action bar you see\nwhich controllers are currently\nassigned to which key\n", 12000))));
      var3.add(this.f(this.e(new class_401(super.field_a.a8(), this.field_a, "You can press \'" + class_367.field_I.b1() + "\' to assign a number\nkey to a controller action by selecting\nit from the list and pressing a number.\n", 25000))));
      this.a2(this.field_a, (class_1001)var3.get(0));

      for(int var2 = 0; var2 < var3.size() - 1; ++var2) {
         this.a2((class_1001)var3.get(var2), (class_1001)var3.get(var2 + 1));
      }

      return (class_1001)var3.get(var3.size() - 1);
   }

   public final void a1() {
      this.field_a = new class_300(super.field_a.a8(), this.field_a, "You have exited the ship.\nThe ship tutorial will now restar\n(skip \'ship build and use\' tutorial\nwith \'END\')", 4000);
      this.field_b = new class_300(super.field_a.a8(), this.field_a, "Time to build your first ship!\nNote, that you have to have a core\nmodule to create a new ship.\n\nShip Cores are very valuable so don\'t lose it", 8000);
      this.field_a = new class_466(super.field_a.a8(), "To create a ship, \npress \'" + class_367.field_x.b1() + "\' to open the ship \ncreation dialog. Then\nchose a name for your ship.", this.field_a);
      this.a2(this.field_b, this.field_a);
      this.a4(this.field_a, this.field_a, this.field_b);
      super.field_b = this.field_b;
      super.field_c = new class_300(super.field_a.a8(), this.field_a, "Congratulations!\nyou now know how to \nbuild and fly ships", 5000);
   }

   private class_1001 b(class_1001 var1) {
      var1.a9(new class_397(), this.field_a);
      return var1;
   }

   private class_1001 c(class_1001 var1) {
      var1.a9(new class_397(), this.field_b);
      return var1;
   }

   private class_1001 d(class_1001 var1) {
      var1.a9(new class_387(), this.field_a);
      return var1;
   }

   private class_1001 e(class_1001 var1) {
      var1.a9(new class_387(), this.field_b);
      return var1;
   }

   private class_1001 f(class_1001 var1) {
      var1.a9(new class_379(), this.field_a);
      var1.a9(new class_389(), this.field_a);
      return var1;
   }

   public final void update(Observable var1, Object var2) {
      System.err.println("UPDATED TUTORIAL STATE " + var1);
      if(var1 instanceof class_15 && ((class_15)var1).c()) {
         if(var1 instanceof class_453) {
            try {
               super.field_a.a8().a8().a2().a1(new class_387());
            } catch (FSMException var4) {
               ;
            }
         }

         if(var1 instanceof class_332) {
            try {
               super.field_a.a8().a8().a2().a1(new class_397());
            } catch (FSMException var3) {
               ;
            }
         }

         if(var1 instanceof class_431) {
            try {
               super.field_a.a8().a8().a2().a1(new class_379());
               return;
            } catch (FSMException var5) {
               ;
            }
         }
      }

   }
}
