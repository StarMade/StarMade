import com.bulletphysics.collision.dispatch.CollisionObject;
import com.bulletphysics.linearmath.Transform;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import javax.vecmath.Vector3f;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.schema.game.client.view.SegmentDrawer;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.data.element.ElementClassNotFoundException;
import org.schema.game.common.data.element.ElementKeyMap;
import org.schema.game.common.data.physics.CubeRayCastResult;
import org.schema.game.common.data.physics.PhysicsExt;
import org.schema.game.common.data.world.Universe;
import org.schema.schine.graphicsengine.core.GLException;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.graphicsengine.forms.Mesh;
import org.schema.schine.graphicsengine.shader.ErrorDialogException;

public final class class_227 extends class_986 {

   public static boolean field_a;
   private class_371 field_a;
   private class_842 field_a;
   private class_824 field_a;
   private class_293 field_a;
   private class_224 field_a;
   private class_254 field_a;
   private final class_247 field_a;
   private ArrayList field_a;
   private final class_218 field_a;
   private class_1431 field_a = new class_1431(9.0F);
   private class_834 field_a;
   private class_237 field_a;
   private class_826 field_a;
   private class_283 field_a;
   private final class_261 field_a;
   private final class_331 field_a;
   private final class_228 field_a;
   private boolean field_f;
   private SegmentDrawer field_a;
   private class_402 field_a;
   public static SegmentController field_a;
   public static long field_a;
   private final class_233 field_a;
   private final class_220 field_a;
   private final class_249 field_a;
   private final class_398 field_a = new class_398();
   private Vector3f field_b = new Vector3f();
   public static boolean field_b = false;
   public static boolean field_c = false;
   public static boolean field_d = false;
   private class_820 field_a;
   private class_245 field_a;
   private Integer[] field_a;
   private Integer[] field_b = new Integer[0];
   private int field_a = -2;
   private float field_a;
   private class_47 field_a = new class_47();
   private class_47 field_b = new class_47();
   private Transform field_b = new Transform();
   private boolean field_g;
   private boolean field_h;
   private boolean field_i;


   public class_227(class_371 var1) {
      this.field_a = var1;
      this.field_a = new ArrayList();
      this.field_a = new class_233();
      this.field_a = new SegmentDrawer(var1);
      this.field_a = new class_220();
      this.field_a = new class_249();
      this.field_a = new class_331(var1);
      this.field_a = new class_228(var1);
      this.field_a = new class_247();
      this.field_a = new class_261(var1.a15());
      this.field_a = new class_834();
      this.field_a = new class_237();
      this.field_a = new class_826();
      this.field_a = new class_824();
      this.field_a = new class_402(var1);
      this.field_a = new class_218();
   }

   public final void a2() {}

   public final void d() {
      this.field_a.d();
      this.field_a.d();
      this.field_a.e();
      this.field_a.d();
      class_402 var1 = this.field_a;

      while(var1.field_a.size() > 0) {
         ((class_404)var1.field_a.remove(0)).e();
      }

   }

   private void s() {
      StringBuffer var1;
      (var1 = new StringBuffer()).append("Physics Data (!!warning slow): ");
      Iterator var2 = this.field_a.a19().getDynamicsWorld().getCollisionObjectArray().iterator();

      while(var2.hasNext()) {
         CollisionObject var3 = (CollisionObject)var2.next();
         var1.append(var3.getCollisionShape().getClass().getSimpleName() + ": ");
         Iterator var4 = this.field_a.a7().values().iterator();

         while(var4.hasNext()) {
            class_801 var5;
            if((var5 = (class_801)var4.next()) instanceof class_1419 && ((class_1419)var5).getPhysicsDataContainer().getObject() == var3) {
               var1.append(var5);
            }
         }

         var1.append("; \n");
      }

      class_969.field_a.add(var1.toString());
   }

   private void a87(long var1, class_47 var3, class_47 var4, Transform var5) {
      float var6 = (float)((System.currentTimeMillis() - var1) % 1200000L) / 1200000.0F;
      var3.a5(16);
      var3.a(8, 8, 8);
      var3.c1(this.field_a.a20().a44());
      this.field_a = var6;
      Vector3f var7 = new Vector3f((float)(var4.field_a * Universe.getSectorSizeWithMargin()), (float)(var4.field_b * Universe.getSectorSizeWithMargin()), (float)(var4.field_c * Universe.getSectorSizeWithMargin()));
      new Vector3f((float)(var3.field_a * Universe.getSectorSizeWithMargin()), (float)(var3.field_b * Universe.getSectorSizeWithMargin()), (float)(var3.field_c * Universe.getSectorSizeWithMargin()));
      var5.setIdentity();
      if(class_795.a19(this.field_a.a20().a44())) {
         var5.basis.rotX(6.2831855F * this.field_a);
      }

      var5.transform(var7);
      class_969.field_a.c12(var7);
   }

   private void a73(long var1) {
      class_663 var3 = this.field_a.a20().a128();
      int var4 = -1;
      class_47 var5 = new class_47();

      class_47 var10001;
      for(int var6 = 0; var6 < 27; ++var6) {
         byte var7 = var3.a6(var6);
         class_797 var8 = class_797.values()[var7];
         var3.a(var6, this.field_a);
         this.field_b.b((this.field_a.field_a << 4) + 8, (this.field_a.field_b << 4) + 8, (this.field_a.field_c << 4) + 8);
         class_47 var10;
         (var10 = new class_47(this.field_b)).c1(this.field_a.a20().a44());
         if(var4 < 0 || var10.a4() < var5.a4()) {
            var4 = var6;
            var5.b1(var10);
         }

         this.field_b.setIdentity();
         if(var8 == class_797.field_e) {
            var10001 = this.field_b;
            this.a87(var1, this.field_a, var10, this.field_b);
         } else if(var8 == class_797.field_f) {
            var10001 = this.field_b;
            this.a87(var1, this.field_a, var10, this.field_b);
            class_237 var10000 = this.field_a;
            this.field_a.b();
         }
      }

      class_793.a192(this.field_a.a20().a44(), this.field_a);
      if(!var3.a1().equals(this.field_a)) {
         System.err.println("[CLIENT] WARNING: System not yet right: " + this.field_a + " / " + var3.a1());
      } else {
         byte var9 = var3.a6(var3.a5(this.field_a));
         class_797 var11 = class_797.values()[var9];
         this.field_b.b((this.field_a.field_a << 4) + 8, (this.field_a.field_b << 4) + 8, (this.field_a.field_c << 4) + 8);
         class_47 var12;
         (var12 = new class_47(this.field_b)).c1(this.field_a.a20().a44());
         var10001 = this.field_b;
         this.a87(var1, this.field_a, var12, this.field_b);
         GL11.glDepthRange(0.0D, 1.0D);
         this.field_a.field_a.b1(var12);
         if(!class_943.field_V.b1() && var11 == class_797.field_e) {
            this.field_a.b();
         }

         class_969.field_a.add("#####SECTORSYSTEM " + this.field_a + " CENTER: " + this.field_b + ": " + var11);
      }
   }

   public final void b() {
      if(class_943.field_m.b1()) {
         this.field_a.a14().b3(0);
      }

      class_799 var1 = null;
      boolean var2 = false;
      class_826 var7 = this.field_a;
      if(this.field_a.field_a.field_a == 0 && var7.field_a.field_b == 0 && var7.field_a.field_c == 0) {
         GL11.glDisable(2929);
         GL11.glDisable(2884);
         GlUtil.d1();
         GlUtil.a31(class_967.a1().a83());
         GlUtil.b5(3.0F, 3.0F, 3.0F);
         GL11.glEnable(3042);
         GL11.glBlendFunc(770, 771);
         class_1379.field_e.c();
         GlUtil.a33(class_1379.field_e, "time", var7.field_a * 10.0F);
         var7.field_a.b();
         class_1376 var10000 = class_1379.field_e;
         class_1376.e();
         GL11.glDisable(3042);
         GlUtil.c2();
         GL11.glEnable(2929);
         GL11.glEnable(2884);
         GL11.glClear(256);
      }

      if(this.field_a.a20().a127().a2() != this.field_a) {
         synchronized(this.field_a.a20().a127()) {
            this.field_a = this.field_a.a20().a127().a2();
            class_225 var8 = new class_225(this);
            this.field_a.getThreadPool().execute(var8);
         }
      }

      if(this.field_a != null) {
         this.field_b = this.field_a;
         this.field_a = null;
      }

      this.field_b.setIdentity();
      class_47 var3 = new class_47();
      long var4 = this.field_a.a4().calculateStartTime();

      int var6;
      for(var6 = 0; var6 < this.field_b.length; ++var6) {
         int var15 = this.field_b[var6].intValue();
         this.field_a.a20().a127().a(var15, var3);
         class_797 var18 = class_797.values()[this.field_a.a20().a127().b(var15)];
         class_799.values();
         this.field_a.a20().a127().a1(var15);
         if(var18 == class_797.field_c) {
            if(this.field_a.a20().a44().equals(var3)) {
               var1 = class_799.values()[this.field_a.a20().a127().a1(var15)];
               this.field_a.field_a = var1;
               if(this.field_a.a5()) {
                  var2 = true;
               } else {
                  this.field_a.b();
               }
            } else {
               class_47 var17;
               (var17 = new class_47(var3)).c1(this.field_a.a20().a44());
               this.field_b.basis.setIdentity();
               class_47 var9 = class_793.a192(var3, new class_47());
               if(class_795.a19(var3)) {
                  float var10 = (float)((System.currentTimeMillis() - var4) % 1200000L) / 1200000.0F;
                  if(class_795.a19(this.field_a.a20().a44())) {
                     this.field_a.field_a = var10;
                  } else {
                     this.field_a.field_a = 0.0F;
                  }

                  var9.a5(16);
                  var9.a(8, 8, 8);
                  var9.c1(this.field_a.a20().a44());
                  this.field_a.field_a.b1(var9);
               } else {
                  this.field_a.field_a = 0.0F;
               }

               this.field_a.a42(var17);
               this.field_a.a43(class_799.values()[this.field_a.a20().a127().a1(var15)]);
               this.field_a.b();
            }
         }
      }

      GL11.glDepthRange(0.0D, 1.0D);
      this.field_a.b();
      this.field_a.b();
      this.field_a.b();

      for(var6 = 0; var6 < this.field_a.size(); ++var6) {
         ((class_305)this.field_a.get(var6)).b();
      }

      this.field_a.f();
      class_39.a("SEGMENTS");
      this.field_a.b();
      class_39.b("SEGMENTS");
      this.field_a.b();
      class_443 var20;
      if(Keyboard.isKeyDown(class_367.field_U.a5()) && ((var20 = this.field_a.a14().field_a.field_a.field_a).a51().a45().field_a.field_c || var20.a53().a36().field_c) && field_a) {
         this.field_b = class_969.a54(this.field_b);
      }

      this.field_a.b();
      this.field_a.b();

      try {
         if(field_a != null && System.currentTimeMillis() - field_a < 8000L && this.field_a.a14() != null && this.field_a.a14().field_a.field_a.field_a.a51().a45().field_a.field_c) {
            System.currentTimeMillis();
            long var14 = field_a;
            GlUtil.d1();
            Mesh var16 = (Mesh)class_967.a2().a4("Arrow").field_a.get(0);
            Transform var19 = new Transform(field_a.getWorldTransform());
            Vector3f var13;
            (var13 = new Vector3f(0.0F, 0.0F, 1.0F)).scale(this.field_a.a1());
            var19.basis.transform(var13);
            var19.origin.add(var13);
            GlUtil.b3(var19);
            GlUtil.b5(0.3F, 0.3F, 0.3F);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GL11.glEnable(2903);
            GlUtil.a38(1.0F, 1.0F, 1.0F, this.field_a.a1());
            var16.b();
            GlUtil.c2();
            GL11.glDisable(2903);
            GL11.glDisable(3042);
            GlUtil.a38(1.0F, 1.0F, 1.0F, 1.0F);
         } else {
            field_a = null;
            field_a = 0L;
         }
      } catch (NullPointerException var12) {
         var12.printStackTrace();
      }

      if(var2) {
         this.field_a.b();
      }

      this.field_a.b();
      this.field_a.field_a = this.field_a.a5();
      this.field_a.b();
      this.field_a.a2();
      this.field_a.b();
      this.field_a.b();
      this.field_a.b();
      if(var1 != null && !var2) {
         this.field_a.a42(new class_47(0, 0, 0));
         this.field_a.a43(var1);
         this.field_a.b();
      }

      this.a73(var4);
      this.field_a.b();
      if(class_943.field_G.b1()) {
         this.s();
      }

      SegmentDrawer.field_a = false;
   }

   public final void e() {
      if(field_d) {
         t();
         field_d = false;
      }

      class_39.a("GUI");
      this.field_a.b();
      class_39.b("GUI");
      if(field_c) {
         t();
         field_c = false;
      }

      class_192.e();
      class_820 var1;
      if(class_943.field_o.b1()) {
         if(this.field_a == null) {
            this.field_a = new class_820();
         }

         var1 = this.field_a;
         this.field_a.field_b = this.field_a.field_d;
         var1.field_c = var1.field_e;
         var1.a();
      }

      if(field_b) {
         var1 = new class_820();
         if(this.field_a == null) {
            this.field_a = new class_820();
         }

         var1.field_a = this.field_a.field_a;

         try {
            class_919 var2;
            (var2 = new class_919(1024, 1024)).e();
            var2.d();
            GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
            GL11.glClear(16640);
            var1.field_b = 32;
            var1.field_c = 32;
            GL11.glViewport(0, 0, 1024, 1024);
            var1.field_a = true;
            var1.a();
            var1.field_a = false;
            System.err.println("SHEET: " + var1.field_a + " WRITING SCREEN TO DISK: ./data/image-resource/build-icons-" + class_40.b(var1.field_a) + "-16x16-gui-");
            GlUtil.a43("./data/image-resource/build-icons-" + class_40.b(var1.field_a) + "-16x16-gui-", "png", 1024, 1024);
            GL11.glViewport(0, 0, class_927.b(), class_927.a());
            var2.b1();
            var2.a();
         } catch (GLException var3) {
            var3.printStackTrace();
         }

         field_b = false;
      }

   }

   private static void t() {
      File[] var0 = (new File("./")).listFiles();
      int var1 = 0;
      boolean var2 = true;

      while(var2) {
         var2 = false;
         File[] var3 = var0;
         int var4 = var0.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            if(var3[var5].getName().startsWith("starmade-screenshot-" + class_40.a1(var1) + ".png")) {
               System.err.println("Screen Already Exists: ./starmade-screenshot-" + class_40.a1(var1) + ".png");
               ++var1;
               var2 = true;
               break;
            }
         }
      }

      GlUtil.a43("./starmade-screenshot-" + class_40.a1(var1), "png", class_927.b(), class_927.a());
   }

   public final void f() {
      Keyboard.enableRepeatEvents(true);
      if(class_943.field_o.b1() && this.field_a != null) {
         class_820 var1 = this.field_a;
         if(Keyboard.getEventKeyState()) {
            int var2;
            switch(Keyboard.getEventKey()) {
            case 17:
               var1.field_e += 8;
               break;
            case 30:
               var1.field_d -= 8;
               break;
            case 31:
               var1.field_e -= 8;
               break;
            case 32:
               var1.field_d += 8;
               break;
            case 203:
               var2 = ElementKeyMap.highestType / 256 + 1;
               if(var1.field_a - 1 < 0) {
                  var1.field_a = var2 - 1;
               } else {
                  --var1.field_a;
               }
               break;
            case 205:
               var2 = ElementKeyMap.highestType / 256 + 1;
               var1.field_a = (var1.field_a + 1) % var2;
            }
         }
      }

      Keyboard.enableRepeatEvents(false);
   }

   public final void g() {
      this.field_a.a23();
      class_307.b7().b();
      Vector3f var1 = class_969.field_a.a83();
      GlUtil.d1();
      GlUtil.c4(var1.field_x, var1.field_y, var1.field_z);
      float var2 = 4.0F;
      float var3;
      if((var3 = (float)Math.pow((double)var1.length(), 1.2999999523162842D)) < 30000.0F) {
         var2 = var3 / 30000.0F;
         var2 = 4.0F * var2;
      }

      class_967.a2().a4("Sphere").b29(var2, var2, var2);
      class_967.a2().a4("Sphere").b();
      GlUtil.c2();
   }

   public static void a88(SegmentController var0) {
      field_a = var0;
      field_a = System.currentTimeMillis();
   }

   public final Vector3f b9() {
      return this.field_b;
   }

   public final class_233 a89() {
      return this.field_a;
   }

   public final class_331 a90() {
      return this.field_a;
   }

   public final class_293 a91() {
      return this.field_a;
   }

   public final class_261 a92() {
      return this.field_a;
   }

   public final class_247 a93() {
      return this.field_a;
   }

   public final SegmentDrawer a94() {
      return this.field_a;
   }

   public final class_220 a95() {
      return this.field_a;
   }

   public final class_824 a96() {
      return this.field_a;
   }

   public final class_254 a97() {
      return this.field_a;
   }

   public final void h1() {
      class_39.a("CONTEXT");
      this.field_a.e();
      class_39.b("CONTEXT");
   }

   public final void c() {
      this.field_a = new class_842();
      this.field_a.c();
      this.field_a.c();
      this.field_a.c();
      this.field_a.c();
      this.field_a.c();
      this.field_a.c();
      this.field_a.c();
      this.field_a.c();
      this.field_a.c();
      this.field_a.c1();
      this.field_a.c();
      this.field_a = new class_293();
      this.field_a.c();
      this.field_a.c();
      this.field_a = new class_224();
      this.field_a.c();
      this.field_a = new class_254(this.field_a);
      this.field_a.c();
      this.field_a = new class_245(this.field_a);
      this.field_a.c();
      this.field_a = new class_283(this.field_a);
      this.field_a.c();
      class_305 var1 = new class_305(this.field_a.getParticleController());
      this.field_a.a27().field_a.add(var1);
      var1.c();
      this.field_f = true;
   }

   public final void i() {
      long var1 = System.currentTimeMillis();
      this.field_a.d();
      long var3;
      if((var3 = System.currentTimeMillis() - var1) > 10L) {
         System.err.println("[WORLDDRAWER] WARNING: SECTOR CHANGE UPDATE FOR DRAWER TOOK " + var3);
      }

   }

   public final void j() {
      if(this.field_a != null) {
         class_826 var1 = this.field_a;
         if(this.field_a.field_c > 5) {
            var1.field_b = GL15.glGetQueryObjectui(var1.field_a, '\u8866');
            var1.field_c = 0;
         }
      }

   }

   public final void a12(class_935 var1) {
      if(this.field_f) {
         class_39.a("update");
         long var2 = System.currentTimeMillis();
         long var4;
         if((var4 = System.currentTimeMillis() - var2) > 10L) {
            System.err.println("[DRAWER][WARNING] synUPDATE took " + var4 + " ms");
         }

         var2 = System.currentTimeMillis();
         if(this.field_h) {
            this.field_a.f();
            this.field_h = false;
         }

         long var6;
         if((var6 = System.currentTimeMillis() - var2) > 10L) {
            System.err.println("[DRAWER][WARNING] seg controller set update took " + var6 + " ms");
         }

         var2 = System.currentTimeMillis();
         if(this.field_g) {
            this.u();
            this.field_g = false;
         }

         long var8;
         if((var8 = System.currentTimeMillis() - var2) > 10L) {
            System.err.println("[DRAWER][WARNING] segManControllerUpdate took " + var8 + " ms");
         }

         if(this.field_i) {
            this.field_a.d();
            this.field_i = false;
         }

         this.field_a.a(var1);
         Vector3f var5 = null;
         class_824 var12 = this.field_a;
         if(this.field_a.field_a != null) {
            var12.field_a.field_a.a(var1);
         }

         this.field_a.a1(var1);
         this.field_a.a1(var1);
         class_237 var14;
         (var14 = this.field_a).field_a = this.field_a.field_a + var1.a() * 0.07F;
         if(var14.field_a > 1.0F) {
            var14.field_a = (float)((double)var14.field_a - Math.floor((double)var14.field_a));
         }

         this.field_a.field_a += var1.a() * 0.07F;
         this.field_a.a15(var1);
         this.field_a.a1(var1);
         this.field_a.field_a.a6(var1);
         class_224 var15 = this.field_a;
         if(!this.field_a.field_a) {
            var15.field_a.set(class_967.a1().a83());
            var15.field_a.sub(var15.field_b);
            float var19 = var15.field_a.length();
            var15.field_b += var19;
            if(var15.field_b > 0.05F) {
               var15.field_a.a12(Math.min(var15.field_b, var15.field_a), var15.field_a);
               var15.field_b = 0.0F;
            }
         }

         var15.field_a.a6(var1);
         var15.field_b.set(class_967.a1().a83());
         this.field_a.a1(var1);
         class_249 var10000 = this.field_a;
         class_249.b();
         this.field_a.a1(var1);
         this.field_a.a1(var1);
         this.field_a.a1(var1);
         class_331 var17 = this.field_a;
         class_883.field_a.remove(var17.field_a);
         if((var17.a34().a36().field_c || var17.a35().field_a.field_c || var17.a33().field_b) && var17.field_a.a3() != null) {
            if(var17.field_d) {
               var17.field_b = null;
               var17.field_a = null;
               var17.field_a = null;
               var17.field_a = null;
               var17.field_d = false;
            }

            var17.field_a.a(var1);
            var17.field_b.a(var1);

            try {
               class_453 var20 = var17.a32();
               Vector3f var3 = new Vector3f(class_967.a1().a83());
               if(var20 == null && var17.field_a.a3() != null) {
                  var3.set(var17.field_a.a3().a136().origin);
               }

               var5 = new Vector3f(var3);
               Vector3f var22;
               if(!Float.isNaN((var22 = new Vector3f(class_967.a1().c10())).field_x)) {
                  if(Keyboard.isKeyDown(class_367.field_U.a5())) {
                     var5 = new Vector3f(var17.field_a.a27().field_b);
                     var22.sub(var5, var3);
                     var22.normalize();
                  }

                  var22.scale(var20 != null?160.0F:6.0F);
                  var5.add(var22);
                  var17.field_a = ((PhysicsExt)var17.field_a.a19()).testRayCollisionPoint(var3, var5, false, (SegmentController)null, var20 != null?var20.a68():null, false, var17.field_a, true);
                  CubeRayCastResult var13;
                  if(var17.field_a != null && var17.field_a.hasHit() && var17.field_a instanceof CubeRayCastResult && (var13 = (CubeRayCastResult)var17.field_a).getSegment() != null) {
                     var17.field_a = var13.getSegment();
                     if(var13.getSegment() != null && var17.field_b != null && !var13.getSegment().equals(var17.field_b) || !var13.cubePos.equals(var17.field_a) || var17.field_a == null) {
                        var17.field_a.b1(var13.cubePos);
                        var17.field_b = var13.getSegment();
                        var17.field_a = new class_800(var17.field_b, var17.field_a);
                        var17.field_a = ElementKeyMap.getInfo(var17.field_a.a9());
                     }
                  } else {
                     var17.field_a = null;
                     var17.field_a = null;
                     var17.field_a = null;
                  }

                  String var16;
                  if(var17.field_a != null) {
                     if(var17.field_a.isEnterable()) {
                        var17.field_a.field_a = "Enter " + var17.field_a.getName() + " [" + class_367.field_v.b1() + "]";
                        var17.field_a.a8(var17.field_a.field_a);
                        class_883.field_a.add(var17.field_a);
                     } else if(var17.field_a.getFactory() != null) {
                        var16 = "[" + class_367.field_z.b1() + "]: Enter Connection Mode";
                        class_800 var23;
                        if((var23 = var17.a33().field_a) != null) {
                           if(!var23.equals(var17.field_a)) {
                              boolean var18 = var23.a7().a15().getControlElementMap().isControlling(var23.a2(var17.field_a), var17.field_a.a2(new class_47(var17.field_b)), var17.field_a.a9());
                              var16 = "[" + class_367.field_A.b1() + "]: " + (!var18?"Connect":"Disconnect") + " this Block to " + ElementKeyMap.getInfo(var23.a9()).getName() + "\n[" + class_367.field_z.b1() + "]: Switch Connection Mode";
                           } else {
                              var16 = "[" + class_367.field_z.b1() + "]: Exit Connection Mode";
                           }
                        }

                        var17.field_a.field_a = "[" + class_367.field_w.b1() + "]: Open Block Inventory\n" + var16;
                        var17.field_a.a8(var17.field_a.field_a);
                        class_883.field_a.add(var17.field_a);
                     } else if(var17.field_a.canActivate()) {
                        if(var17.field_a.getId() == 16) {
                           var17.field_a.field_a = "Make Output [" + class_367.field_w.b1() + "] " + (var17.field_a.a10()?"ON":"OFF");
                        } else {
                           var17.field_a.field_a = "Activate " + var17.field_a.getName() + " [" + class_367.field_w.b1() + "]";
                        }

                        var17.field_a.a8(var17.field_a.field_a);
                        class_883.field_a.add(var17.field_a);
                     }
                  }

                  if(var20 != null) {
                     label176: {
                        if(var20.a40() != null) {
                           var20.a40().a12();
                           if(var17.field_b != var20.a40() && var20.a40().a9() != 0) {
                              var17.field_b = var20.a40();
                              var17.field_b = ElementKeyMap.getInfo(var17.field_b.a9());
                              break label176;
                           }

                           if(var20.a40().a9() != 0) {
                              break label176;
                           }
                        }

                        var17.field_b = null;
                        var17.field_b = null;
                     }

                     var17.field_a = false;
                     var17.field_b = false;
                     var17.field_c = false;
                     short var21;
                     if(var17.field_b != null && (var21 = var17.field_b.a9()) != 0 && var17.field_a != null) {
                        if(var17.field_b != null) {
                           try {
                              if(var17.field_a.getControlledBy().contains(Short.valueOf(var21))) {
                                 var17.field_a = true;
                              }
                           } catch (ElementClassNotFoundException var10) {
                              var10.printStackTrace();
                           }
                        }

                        if(!var17.field_a.getControlling().isEmpty()) {
                           var17.field_b = true;
                        }
                     }

                     if(var17.field_b != null && var17.field_a == var17.field_b) {
                        var17.field_c = true;
                        var17.field_b = false;
                     }

                     if(var17.field_b != null) {
                        var16 = "SELECTED:\n" + var17.field_b.getName() + (var17.field_c?"\ndeselect with " + class_367.field_z.b1():"");
                        var17.field_a.a4().b2(var16);
                     } else {
                        var17.field_a.a4().c();
                     }

                     if(var17.field_a != null) {
                        var16 = var17.field_a.getName() + (var17.field_a?"\n\n(dis)connect to " + var17.field_b.getName() + "\nwith " + class_367.field_A.b1():"") + (var17.field_b?"\nselect with " + class_367.field_A.b1():"");
                        var17.field_a.a4().a12(var16);
                     } else {
                        var17.field_a.a4().b();
                     }
                  }
               }
            } catch (Exception var11) {
               var11.printStackTrace();
               System.err.println("[BUILDMODEDRAWER] " + var11.getClass().getSimpleName() + ": " + var11.getMessage());
            }
         }

         this.field_a.a5(var1);
         class_39.b("update");
         if(class_39.a1("update") > 15L) {
            System.err.println("[DRAWER][WARNING] update took " + class_39.a1("update") + " ms");
         }

      }
   }

   private void u() {
      long var1 = System.currentTimeMillis();
      this.field_a.d();
      this.field_a.d();
      long var3;
      if((var3 = System.currentTimeMillis() - var1) > 5L) {
         System.err.println("[WORLDDRAWER] WARNING: CLEAR TOOK " + var3);
      }

      this.field_a.a7(this.field_a.a7());
      var1 = System.currentTimeMillis();
      this.field_a.a1(this.field_a.a7());
      Iterator var5 = this.field_a.a7().values().iterator();

      long var7;
      while(var5.hasNext()) {
         class_801 var6 = (class_801)var5.next();
         var7 = System.currentTimeMillis();
         long var9;
         if(var6 instanceof class_743) {
            var9 = System.currentTimeMillis();
            long var13 = System.currentTimeMillis();
            class_218 var10000 = this.field_a;
            class_295 var4 = new class_295((class_743)var6);
            var10000.field_a.add(var4);
            long var11;
            if((var11 = System.currentTimeMillis() - var13) > 3L) {
               System.err.println("[BEAMDRAWER] WARNING SHIP PLUM ADD of " + var6 + " took " + var11 + " ms");
            }

            var13 = System.currentTimeMillis();
            var10000 = this.field_a;
            class_356 var18 = new class_356((class_743)var6);
            var10000.field_b.add(var18);
            if((var11 = System.currentTimeMillis() - var13) > 3L) {
               System.err.println("[BEAMDRAWER] WARNING SHIP MUZZLE ADD of " + var6 + " took " + var11 + " ms");
            }

            var13 = System.currentTimeMillis();
            this.field_a.a2((class_743)var6);
            if((var11 = System.currentTimeMillis() - var13) > 3L) {
               System.err.println("[BEAMDRAWER] WARNING SHIP SHIELD ADD of " + var6 + " took " + var11 + " ms");
            }

            long var15;
            if((var15 = System.currentTimeMillis() - var9) > 5L) {
               System.err.println("[BEAMDRAWER] WARNING SHIP NORMAL ADD of " + var6 + " took " + var15 + " ms");
            }
         }

         if(var6 instanceof class_780 || var6 instanceof class_598) {
            this.field_a.a2((class_802)var6);
            this.field_a.a((class_802)var6);
         }

         if((var9 = System.currentTimeMillis() - var7) > 5L) {
            System.err.println("[WORLDDRAWER] WARNING: DRAWER UPDATE OF " + var6 + " took " + var9);
         }
      }

      long var19;
      if((var19 = System.currentTimeMillis() - var1) > 5L) {
         System.err.println("[WORLDDRAWER] WARNING: ADD TOOK " + var19);
      }

      var1 = System.currentTimeMillis();

      try {
         this.field_a.d();
      } catch (ErrorDialogException var17) {
         var17.printStackTrace();
         class_927.a2(var17);
      }

      if((var7 = System.currentTimeMillis() - var1) > 5L) {
         System.err.println("[WORLDDRAWER] WARNING: CONNECTION UPDATE TOOK " + var7);
      }

   }

   public final class_283 a98() {
      return this.field_a;
   }

   public final class_398 a99() {
      return this.field_a;
   }

   public final void k() {
      this.field_h = true;
   }

   public final class_218 a100() {
      return this.field_a;
   }

   public final class_228 a101() {
      return this.field_a;
   }

   public final class_249 a102() {
      return this.field_a;
   }

   public final void l() {
      this.field_i = true;
   }

   public final void m1() {
      this.field_g = true;
   }

   // $FF: synthetic method
   static class_371 a103(class_227 var0) {
      return var0.field_a;
   }

   // $FF: synthetic method
   static Integer[] a104(class_227 var0, Integer[] var1) {
      return var0.field_a = var1;
   }

}
