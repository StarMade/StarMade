import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import org.schema.game.common.controller.EditableSendableSegmentController;
import org.schema.game.common.data.player.inventory.NoSlotFreeException;

final class class_439 implements class_481 {

   // $FF: synthetic field
   private EditableSendableSegmentController field_a;
   // $FF: synthetic field
   private IntOpenHashSet field_a;
   // $FF: synthetic field
   private class_443 field_a;


   class_439(class_443 var1, EditableSendableSegmentController var2, IntOpenHashSet var3) {
      this.field_a = var1;
      this.field_a = var2;
      this.field_a = var3;
      super();
   }

   public final void a(short var1) {
      if(var1 != 0 && var1 != 1) {
         class_635 var2 = ((class_371)this.field_a.getState()).a20().getInventory((class_47)null);

         try {
            int var4 = var2.b7(var1, 1);
            this.field_a.add(var4);
            return;
         } catch (NoSlotFreeException var3) {
            this.field_a.a6().a4().b1("ERROR\nno free slot in inventory\nthe element is lost");
         }
      }

   }
}
