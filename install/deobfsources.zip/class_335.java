import org.schema.schine.graphicsengine.core.GLException;

final class class_335 extends class_73 {

   public final void a(class_66 var1) {
      System.err.println("Init Shop FrameBuffer");

      try {
         if(class_943.field_x.b1()) {
            (class_333.field_a = new class_919(512, 512)).e();
         }

      } catch (GLException var2) {
         class_333.field_a = null;
         var2.printStackTrace();
      }
   }
}
