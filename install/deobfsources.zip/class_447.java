import java.util.ConcurrentModificationException;
import java.util.Iterator;
import org.lwjgl.input.Keyboard;
import org.schema.game.common.controller.CannotImmediateRequestOnClientException;
import org.schema.game.common.controller.EditableSendableSegmentController;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.data.element.ElementCollection;

public class class_447 extends class_15 implements class_457 {

   private Object field_a = new Object();
   private class_800 field_a;
   private class_434 field_a = new class_434(this.a6());
   private class_453 field_a = new class_453(this.a6(), this);
   // $FF: synthetic field
   private static boolean field_d = !ax.class.desiredAssertionStatus();


   public class_447(class_371 var1) {
      super(var1);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
   }

   private void b() {
      Object var1 = this.field_a;
      synchronized(this.field_a) {
         class_47 var3 = null;
         if(this.field_a != null) {
            SegmentController var2 = this.field_a.a7().a15();
            var3 = this.field_a.a2(new class_47());
            System.err.println("EXIT SHIP FROM EXTRYPOINT " + var3);
            this.a6().a4().a14((class_365)var2, this.a6().a3(), var3, new class_47(), true);
         }

      }
   }

   public final class_47 a35() {
      return this.field_a.a2(new class_47());
   }

   public final class_800 a40() {
      return this.field_a;
   }

   public final class_453 a36() {
      return this.field_a;
   }

   public final EditableSendableSegmentController a37() {
      return (EditableSendableSegmentController)this.field_a.a7().a15();
   }

   public final class_434 a67() {
      return this.field_a;
   }

   public void handleKeyEvent() {
      super.handleKeyEvent();
      if(Keyboard.getEventKeyState() && Keyboard.getEventKey() == class_367.field_v.a5()) {
         this.b();
      }

   }

   public final void b2(boolean var1) {
      if(var1) {
         if(this.field_a.a7() == null) {
            System.err.println("Exception: entered has been null");
            if(!field_d && this.field_a == null) {
               throw new AssertionError();
            }

            return;
         }

         SegmentController var2;
         class_858 var3 = (var2 = this.field_a.a7().a15()).getControlElementMap().getControlledElements((short)32767, this.field_a.a2(new class_47()));
         if(!this.a6().a20().a121(var2)) {
            class_359 var4 = new class_359(this.a6().a20(), var2.getUniqueIdentifier());
            int var5 = 0;

            class_47 var6;
            try {
               var6 = new class_47();

               for(Iterator var10 = var2.getControlElementMap().getControllingMap().keySet().iterator(); var10.hasNext(); ++var5) {
                  long var7 = ((Long)var10.next()).longValue();
                  if(var3.field_a.contains(ElementCollection.getPosFromIndex(var7, var6))) {
                     var4.a20(var5, new class_47(var6), true);
                  }

                  if(var5 > 10) {
                     break;
                  }
               }
            } catch (ConcurrentModificationException var9) {
               var6 = null;
               var9.printStackTrace();
            }

            this.a6().a20().a78().add(var4);
         }

         if(this.field_a.a9() == 123) {
            this.field_a.c2(true);
         } else {
            this.field_a.c2(true);
         }

         this.field_a.a7().a15();
         this.field_a.a2(new class_47());
      } else {
         if(this.field_a != null && this.field_a.a7().a15() == this.a6().a6()) {
            this.a6().a32((class_801)null);
         }

         this.field_a.c2(false);
         this.field_a.c2(false);
      }

      if(!field_d && var1 && this.field_a == null) {
         throw new AssertionError(": Entered: " + this.field_a.a7().a15() + " -> " + this.field_a.a2(new class_47()));
      } else {
         super.b2(var1);
      }
   }

   public final void a16(class_800 var1) {
      Object var2 = this.field_a;
      synchronized(this.field_a) {
         this.field_a = var1;
      }
   }

   public final void a15(class_935 var1) {
      super.a15(var1);
      if(!this.a6().getLocalAndRemoteObjectContainer().getLocalObjects().containsKey(this.field_a.a7().a15().getId())) {
         this.b();
      }

      Object var5 = this.field_a;
      synchronized(this.field_a) {
         if(this.field_a != null) {
            this.field_a.a12();
            if(this.field_a.a9() == 0) {
               class_47 var2 = this.field_a.a2(new class_47());

               try {
                  class_800 var6;
                  if((var6 = this.field_a.a7().a15().getSegmentBuffer().a9(var2, true)).a9() == 0) {
                     this.b();
                  } else {
                     this.field_a = var6;
                  }
               } catch (CannotImmediateRequestOnClientException var3) {
                  ;
               }
            }

            if(!this.a6().getLocalAndRemoteObjectContainer().getLocalObjects().containsKey(this.field_a.a7().a15().getId())) {
               this.b();
            }
         }

      }
   }

}
