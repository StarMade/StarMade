
public final class class_350 extends class_15 implements class_1410 {

   public class_350(class_371 var1) {
      super(var1);
   }

   public final void a(class_964 var1, class_941 var2) {}

   public final boolean a1() {
      return false;
   }
}
