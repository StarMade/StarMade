import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;
import java.util.ArrayList;
import java.util.HashMap;
import org.schema.game.network.objects.NetworkClientChannel;
import org.schema.game.network.objects.remote.RemoteMapEntryAnswer;

public final class class_343 {

   public final HashMap field_a = new HashMap();
   public final ArrayList field_a = new ArrayList();
   public final ArrayList field_b = new ArrayList();
   public class_44 field_a;
   public final Object2LongOpenHashMap field_a = new Object2LongOpenHashMap();


   public class_343(class_44 var1) {
      this.field_a = var1;
   }

   public final void a(class_47 var1) {
      System.err.println("[CLIENT][MAPREQUESTMANAGER] requesting system map for " + var1);
      ArrayList var2 = this.field_a;
      synchronized(this.field_a) {
         this.field_a.add(new class_341((byte)2, var1));
      }
   }

   public final void a1(NetworkClientChannel var1) {
      for(int var2 = 0; var2 < var1.mapAnswers.getReceiveBuffer().size(); ++var2) {
         class_339 var3 = (class_339)((RemoteMapEntryAnswer)var1.mapAnswers.getReceiveBuffer().get(var2)).get();
         ArrayList var4 = this.field_b;
         synchronized(this.field_b) {
            this.field_b.add(var3);
         }
      }

   }
}
