import java.util.ArrayList;

final class class_225 implements Runnable {

   // $FF: synthetic field
   private class_227 field_a;


   class_225(class_227 var1) {
      this.field_a = var1;
      super();
   }

   public final void run() {
      ArrayList var1 = new ArrayList();

      for(int var2 = 0; var2 < 2744; ++var2) {
         if(class_797.values()[class_227.a103(this.field_a).a20().a127().b(var2)] == class_797.field_c) {
            var1.add(Integer.valueOf(var2));
         }
      }

      class_227.a104(this.field_a, (Integer[])var1.toArray(new Integer[var1.size()]));
   }
}
