import java.util.ArrayList;
import org.schema.schine.network.Identifiable;
import org.schema.schine.network.objects.Sendable;

public interface class_365 extends Identifiable {

   boolean isClientOwnObject();

   ArrayList a26();

   void a27(class_935 var1, class_752 var2);

   boolean isHidden();

   void a28(class_744 var1, Sendable var2, class_47 var3);

   void a29(class_744 var1, boolean var2);
}
