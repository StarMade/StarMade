import com.bulletphysics.linearmath.Transform;
import javax.vecmath.Vector4f;

public abstract class class_251 {

   public Transform field_a;
   private float field_a;
   public String field_a;
   public Vector4f field_a = null;


   public class_251(Transform var1, String var2) {
      this.field_a = var1;
      this.field_a = var2;
   }

   public boolean equals(Object var1) {
      return ((class_251)var1).field_a.equals(this.field_a);
   }

   public abstract Transform a();

   public int hashCode() {
      return this.field_a.hashCode();
   }

   public boolean a2() {
      return this.field_a < 0.3F;
   }

   public void a1(class_935 var1) {
      this.field_a += var1.a();
   }
}
