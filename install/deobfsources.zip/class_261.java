import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Observable;
import java.util.Observer;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.UnicodeFont;
import org.newdawn.slick.font.effects.ColorEffect;
import org.newdawn.slick.font.effects.OutlineEffect;
import org.schema.game.common.controller.elements.ElementCollectionManager;
import org.schema.game.common.controller.elements.ShieldContainerInterface;
import org.schema.schine.network.objects.Sendable;

public final class class_261 implements Observer, class_923, class_947 {

   private class_113 field_a;
   private class_371 field_a;
   private class_43 field_a;
   private class_1406 field_a;
   private class_116 field_a;
   private class_970 field_a;
   private class_940 field_a;
   private class_936 field_a;
   private float field_a = 1.0F;
   private float field_b = 0.2F;
   private float field_c = 0.3F;
   private float field_d = -1.0F;
   public final LinkedList field_a = new LinkedList();
   public final LinkedList field_b = new LinkedList();
   public final LinkedList field_c = new LinkedList();
   public class_108 field_a;
   public class_108 field_b;
   private class_134 field_a;
   private int field_a = 1;
   private class_881 field_a;
   private class_115 field_a;
   private class_914 field_a;
   private class_242 field_a;


   public class_261(class_43 var1) {
      this.field_a = var1.a();
      this.field_a = var1;
      this.field_a.addObserver(this);
   }

   public final void a() {}

   private void e() {
      this.field_a.h2(48);
      this.field_a.h2(48);
      this.field_a.h2(48);
      this.field_a.h2(9);
      this.field_a.h2(6);
      this.field_a.h2(48);
   }

   public final void b() {
      if(class_927.b1()) {
         this.e();
      }

      GL11.glClear(256);
      if(!class_943.field_K.b1()) {
         if(class_943.field_J.b1()) {
            if(this.c1()) {
               this.field_a.b();
            }

            if(!this.field_a.a14().a18().a76().c()) {
               this.field_a.b();
            }

            boolean var1 = !this.field_a.a14().a18().a79().a61().g() && !this.field_a.a14().a18().a79().a58().g() && !this.field_a.a14().a18().a79().a57().g() && !this.field_a.a14().a18().a79().a62().c() && !this.field_a.a14().a18().a79().a59().g() && !this.field_a.a14().a18().a79().a64().g() && !this.field_a.a14().a18().a79().a65().g() && !this.b1();
            class_964.i();
            if(var1) {
               class_39.a("HUD");
               this.field_a.b();
               class_39.b("HUD");
            } else if(this.b1()) {
               this.field_a.a127().e();
            }

            if(this.field_a.d2()) {
               this.field_a.b();
            }

            class_964.h1();
         }

         class_964.i();
         int var2;
         synchronized(this.field_a.b()) {
            for(var2 = 0; var2 < this.field_a.b().size(); ++var2) {
               ((class_11)this.field_a.b().get(var2)).a3().b();
            }
         }

         class_964.field_h = true;

         for(int var7 = 0; var7 < this.field_a.a10().size(); ++var7) {
            class_11 var9;
            (var9 = (class_11)this.field_a.a10().get(var7)).f();
            var9.a3().b();
            if(System.currentTimeMillis() - var9.a5() > 200L) {
               this.field_a.a10().remove(var7);
               --var7;
            }
         }

         class_964.field_h = false;
         if(!this.field_a.a14().a18().a77().c() && Keyboard.isKeyDown(class_367.field_Q.a5())) {
            this.field_a.b();
         }

         if(!this.field_a.a14().a18().a77().c() && Keyboard.isKeyDown(61)) {
            this.field_a.b();
         }

         this.field_a.b();
         class_964.h1();
         if(class_943.field_ac.b1()) {
            if(this.field_b != null) {
               class_964.i();
               this.field_b.b();
               class_964.h1();
            }

            if(this.field_a != null) {
               class_964.i();
               this.field_a.a83().field_y = this.field_a.a3() + 5.0F;
               this.field_a.b();
               class_964.h1();
            }

            LinkedList var8 = this.field_a;
            synchronized(this.field_a) {
               for(var2 = 0; var2 < this.field_a.size(); ++var2) {
                  class_964.i();
                  ((class_110)this.field_a.get(var2)).b();
                  class_964.h1();
               }
            }

            var8 = this.field_b;
            synchronized(this.field_b) {
               for(var2 = 0; var2 < this.field_b.size(); ++var2) {
                  class_964.i();
                  ((class_132)this.field_b.get(var2)).b();
                  class_964.h1();
               }
            }

            var8 = this.field_c;
            synchronized(this.field_c) {
               for(var2 = 0; var2 < this.field_c.size(); ++var2) {
                  class_964.i();
                  ((class_238)this.field_c.get(var2)).b();
                  class_964.h1();
               }
            }
         }

         if(class_943.field_O.b1() && this.field_a.a14().a19().c() && this.field_a.a4().a5() != null && this.field_a.a4().a6()) {
            class_964.i();
            this.field_a.b();
            class_964.h1();
         }

         class_964.i();
         this.field_a.a29(this.field_a.a14().a17().g());
         this.field_a.b();
         class_964.h1();
         if(this.field_d < this.field_b) {
            this.field_a.a135().field_w = this.field_d / this.field_b * this.field_c;
            class_964.i();
            this.field_a.b();
            class_964.h1();
         }

         if(class_1008.field_b) {
            class_964.i();
            this.field_a.b();
            class_964.h1();
         }

         this.field_a.e();
      }
   }

   private boolean b1() {
      return this.field_a.a14().a18().a79().a66().g();
   }

   private void a15(int var1, class_15 var2) {
      int var3 = var1;
      if((this.field_a & var1) == var1) {
         var3 = 0;
      }

      this.field_a += var2.g()?var3:-var1;
   }

   public final boolean a5() {
      return this.field_a.a4();
   }

   public final void c() {
      this.field_a = new class_113(this.field_a);
      this.field_a.c();
      this.field_a = new class_936(this.field_a);
      this.field_a.a135().set(1.0F, 0.0F, 0.0F, 0.0F);
      this.field_a.c();
      this.field_a = new class_116(this.field_a);
      this.field_a = new class_242(this.field_a);
      this.field_a.c();
      this.field_a.c();
      this.field_a = new class_115(this.field_a);
      this.field_a.c();
      this.field_a = new class_881(this.field_a);
      this.field_a.c();
      this.field_a = new class_1406(this.field_a);
      this.field_a.a17("use \"/pm playername msg\" for PMs, and \"/f msg\" for faction chat");
      this.field_a.a172(this.field_a.getChat());
      this.field_a.c();
      this.field_a = new class_970(class_967.a2().a5("shopinrange-gui-"), this.field_a);
      this.field_a.c();
      this.field_a = new class_914(this.field_a);
      this.field_a.h2(10);
      this.field_a = new class_134(this.field_a);
      this.field_a.c();
      Font var1 = new Font("Arial", 1, 26);
      UnicodeFont var3;
      (var3 = new UnicodeFont(var1)).getEffects().add(new OutlineEffect(4, Color.black));
      var3.getEffects().add(new ColorEffect(Color.white));
      var3.addAsciiGlyphs();

      try {
         var3.loadGlyphs();
      } catch (SlickException var2) {
         var2.printStackTrace();
      }

      this.field_a = new class_940(500, 50, var3, this.field_a);
      this.field_a.b17(new ArrayList());
      this.field_a.b16().add("Detached Mouse From Game. Click to reattach");
      this.e();
   }

   public final void d() {
      this.field_a.e();
   }

   private boolean c1() {
      return this.field_a.a14().a18().a79().a60().a51().a45().a36().g();
   }

   public final void a16(Sendable var1) {
      if(this.field_d < 0.0F) {
         this.field_d = 0.0F;
         this.field_a = 1.0F;
         if(var1 != null && var1 instanceof class_802 && (class_802)var1 instanceof ShieldContainerInterface && ((ShieldContainerInterface)((class_802)var1)).getShieldManager().getShields() > 0.0D) {
            this.field_a.a135().field_x = 0.0F;
            this.field_a.a135().field_y = 0.0F;
            this.field_a.a135().field_z = 1.0F;
            return;
         }

         this.field_a.a135().field_x = 1.0F;
         this.field_a.a135().field_y = 0.0F;
         this.field_a.a135().field_z = 0.0F;
      }

   }

   public final void update(Observable var1, Object var2) {
      if("ON_SWITCH".equals(var2)) {
         if(var1 instanceof class_455) {
            this.a15(8, (class_15)var1);
            if(this.field_a != null) {
               this.field_a.a29(((class_455)var1).c());
            }
         }

         if(var1 instanceof class_469) {
            this.a15(2, (class_15)var1);
         }

         if(var1 instanceof class_332) {
            this.a15(64, (class_15)var1);
         }

         if(var1 instanceof class_303) {
            this.a15(4, (class_15)var1);
         }

         if(var1 instanceof class_330) {
            this.a15(16, (class_15)var1);
         }

         if(var1 instanceof class_23) {
            this.a15(32, (class_15)var1);
         }
      }

   }

   public final void a1(class_935 var1) {
      if(this.field_d >= 0.0F) {
         this.field_d += this.field_a * var1.a() * 2.0F;
         if(this.field_d > this.field_b) {
            this.field_a = -1.0F;
         }
      } else {
         this.field_a = 1.0F;
      }

      this.field_a.a12(var1);
      if(!this.c1()) {
         if(this.field_b != null) {
            this.field_b.e();
         }

         if(this.field_a != null) {
            this.field_a.e();
         }
      }

      if(this.field_b != null) {
         this.field_b.a12(var1);
      }

      if(this.field_a != null) {
         this.field_a.a12(var1);
      }

      if(!this.field_a.a14().a18().a77().c() && Keyboard.isKeyDown(class_367.field_Q.a5())) {
         this.field_a.a12(var1);
      }

      if(!this.field_a.a14().a18().a77().c() && Keyboard.isKeyDown(61)) {
         this.field_a.a12(var1);
      }

      this.field_a.a12(var1);
      this.field_a.a12(var1);
      class_192.field_a.a(var1);
      LinkedList var2 = this.field_a;
      int var3;
      synchronized(this.field_a) {
         var3 = 0;

         while(true) {
            if(var3 >= this.field_a.size()) {
               break;
            }

            ((class_110)this.field_a.get(var3)).a12(var1);
            if(!((class_110)this.field_a.get(var3)).a4()) {
               this.field_a.remove(var3);
               --var3;
            } else {
               ((class_110)this.field_a.get(var3)).field_a = (float)var3;
            }

            ++var3;
         }
      }

      var2 = this.field_b;
      synchronized(this.field_b) {
         var3 = 0;

         while(true) {
            if(var3 >= this.field_b.size()) {
               break;
            }

            ((class_132)this.field_b.get(var3)).a12(var1);
            if(!((class_132)this.field_b.get(var3)).a4()) {
               this.field_b.remove(var3);
               --var3;
            } else {
               ((class_132)this.field_b.get(var3)).field_a = (float)var3;
            }

            ++var3;
         }
      }

      var2 = this.field_c;
      synchronized(this.field_c) {
         for(var3 = 0; var3 < this.field_c.size(); ++var3) {
            ((class_238)this.field_c.get(var3)).a12(var1);
            if(!((class_238)this.field_c.get(var3)).a4()) {
               this.field_c.remove(var3);
               --var3;
            } else {
               ((class_238)this.field_c.get(var3)).field_a = (float)var3;
            }
         }

      }
   }

   public final void a17(ElementCollectionManager var1) {
      this.field_a.a21(var1);
   }

   public final class_113 a18() {
      return this.field_a;
   }
}
