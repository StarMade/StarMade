import java.io.InvalidObjectException;
import java.util.logging.Level;

public final class class_27 extends Level {

   private static final long serialVersionUID = 4998223571342726511L;
   public static Level field_a = new class_27("STDOUT", Level.INFO.intValue() + 53);
   public static Level field_b = new class_27("STDERR", Level.INFO.intValue() + 54);


   private class_27(String var1, int var2) {
      super(var1, var2);
   }

   protected final Object readResolve() {
      if(this.intValue() == field_a.intValue()) {
         return field_a;
      } else if(this.intValue() == field_b.intValue()) {
         return field_b;
      } else {
         throw new InvalidObjectException("Unknown instance :" + this);
      }
   }

}
