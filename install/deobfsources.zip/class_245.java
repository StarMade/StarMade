
public final class class_245 implements class_923 {

   private class_371 field_a;
   private boolean field_a;
   private class_1382[] field_a;


   public class_245(class_371 var1) {
      this.field_a = var1;
   }

   public final void a() {}

   public final void b() {
      if(!this.field_a) {
         this.c();
      }

      class_670 var1;
      if((var1 = this.field_a.a9()) != null && !var1.a40().isEmpty()) {
         for(int var2 = 0; var2 < this.field_a.length; ++var2) {
            class_1382 var3;
            (var3 = this.field_a[var2]).b29(0.01F, 0.01F, 0.01F);
            var3.c15(true);
            var3.a29(true);
            class_1382.a171(var3, var1.a40().values(), class_967.a1());
            var3.a29(false);
            var3.c15(false);
            var3.b29(1.0F, 1.0F, 1.0F);
         }

      }
   }

   public final void c() {
      this.field_a = new class_1382[3];
      this.field_a[0] = class_967.a2().a5("build-icons-00-16x16-gui-");
      this.field_a[1] = class_967.a2().a5("build-icons-01-16x16-gui-");
      this.field_a[2] = class_967.a2().a5("build-icons-extra-gui-");
      this.field_a = true;
   }
}
