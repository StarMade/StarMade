import java.io.DataInputStream;
import java.io.DataOutputStream;

public abstract class class_345 implements class_347 {

   // $FF: synthetic field
   private static boolean field_a = !cC.class.desiredAssertionStatus();


   public static class_347[] a15(DataInputStream var0) {
      int var1;
      class_347[] var2 = new class_347[var1 = var0.readInt()];

      for(int var3 = 0; var3 < var1; ++var3) {
         Object var5 = null;
         byte var6;
         switch(var6 = var0.readByte()) {
         case 1:
            var5 = new class_337();
            break;
         case 2:
            var5 = new class_337();
            break;
         case 3:
            var5 = new class_337();
            break;
         case 4:
            var5 = new class_349();
            break;
         case 5:
            var5 = new class_337();
            break;
         case 6:
         case 7:
         case 8:
         case 9:
         default:
            if(!field_a) {
               throw new AssertionError(var6);
            }
         case 10:
         }

         ((class_345)var5).a4(var6);
         ((class_345)var5).a1(var0);
         var2[var3] = (class_347)var5;
      }

      return var2;
   }

   public static void a16(DataOutputStream var0, class_347[] var1) {
      var0.writeInt(var1.length);

      for(int var2 = 0; var2 < var1.length; ++var2) {
         var0.writeByte(var1[var2].a3());
         var1[var2].a2(var0);
      }

   }

   protected abstract void a1(DataInputStream var1);

}
