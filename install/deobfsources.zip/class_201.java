import com.bulletphysics.linearmath.Transform;
import javax.vecmath.Vector3f;
import org.schema.game.common.controller.SegmentController;

public class class_201 extends class_958 {

   protected class_47 field_a = new class_47();
   private Vector3f field_a = new Vector3f();
   protected SegmentController field_a;
   protected class_457 field_a;
   private Transform field_b = new Transform();
   private float field_a = 13.0F;
   private Vector3f field_b = new Vector3f();


   public class_201(class_457 var1) {
      super(var1.a1());
      new Vector3f();
      new Vector3f();
      new class_47();
      new class_34();
      this.field_a = var1.a1();
      this.field_a = var1;
   }

   public final synchronized Vector3f a83() {
      Vector3f var1 = super.a83();
      Vector3f var2 = new Vector3f(this.field_a.field_x + (float)this.field_a.a().field_a - 8.0F, this.field_a.field_y + (float)this.field_a.a().field_b - 8.0F, this.field_a.field_z + (float)this.field_a.a().field_c - 8.0F);
      this.field_b.set(super.field_a.getWorldTransform());
      this.field_b.basis.transform(var2);
      var1.add(var2);
      return var1;
   }

   public final class_47 a85() {
      return this.field_a;
   }

   public final void a2() {
      this.field_a = 50.0F;
   }

   public final void a12(class_935 var1) {
      this.field_b.set((float)this.field_a.field_a, (float)this.field_a.field_b, (float)this.field_a.field_c);
      this.field_b.sub(this.field_a);
      float var2;
      if((var2 = this.field_b.length()) > 0.0F) {
         float var3 = this.field_b.length();
         this.field_b.normalize();
         this.field_b.scale(var1.a() * Math.max(var3 * 3.0F, this.field_a));
         if(this.field_b.length() < var2) {
            this.field_a.add(this.field_b);
         } else {
            this.field_a.set((float)this.field_a.field_a, (float)this.field_a.field_b, (float)this.field_a.field_c);
         }
      }
   }
}
