import java.util.Iterator;
import java.util.Set;
import java.util.Map.Entry;
import javax.vecmath.Vector3f;
import org.lwjgl.BufferUtils;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import org.schema.common.util.ByteUtil;
import org.schema.schine.graphicsengine.core.GlUtil;

public final class class_228 implements class_952, class_923 {

   private final class_241 field_a;
   private final class_232 field_a;
   private final class_371 field_a;
   private class_1431 field_a = new class_1431();
   public static int field_a;
   public static final class_47 field_a;
   private class_1381 field_a;
   private class_953[] field_a = new class_953[]{new class_234(this)};
   private final class_47 field_b = new class_47();


   public class_228(class_371 var1) {
      this.field_a = var1;
      this.field_a = new class_232(this);
      this.field_a = new class_241(this.field_a);
      this.field_a.a(4530.0F);
   }

   public final void a2() {}

   private static void a22(float var0, float var1) {
      GL11.glBegin(7);
      GlUtil.a38(0.3F, 0.0F, 0.0F, var1);
      GL11.glNormal3f(0.0F, 0.0F, 1.0F);
      GL11.glVertex3f(var0, var0, -var0);
      GL11.glVertex3f(var0, -var0, -var0);
      GL11.glVertex3f(-var0, -var0, -var0);
      GL11.glVertex3f(-var0, var0, -var0);
      GlUtil.a38(0.3F, 0.0F, 0.0F, var1);
      GL11.glNormal3f(0.0F, 0.0F, -1.0F);
      GL11.glVertex3f(var0, -var0, var0);
      GL11.glVertex3f(var0, var0, var0);
      GL11.glVertex3f(-var0, var0, var0);
      GL11.glVertex3f(-var0, -var0, var0);
      GlUtil.a38(0.0F, 0.3F, 0.0F, var1);
      GL11.glNormal3f(-1.0F, 0.0F, 0.0F);
      GL11.glVertex3f(var0, -var0, -var0);
      GL11.glVertex3f(var0, var0, -var0);
      GL11.glVertex3f(var0, var0, var0);
      GL11.glVertex3f(var0, -var0, var0);
      GlUtil.a38(0.0F, 0.3F, 0.0F, var1);
      GL11.glNormal3f(1.0F, 0.0F, 0.0F);
      GL11.glVertex3f(-var0, -var0, var0);
      GL11.glVertex3f(-var0, var0, var0);
      GL11.glVertex3f(-var0, var0, -var0);
      GL11.glVertex3f(-var0, -var0, -var0);
      GlUtil.a38(0.0F, 0.0F, 0.3F, var1);
      GL11.glNormal3f(0.0F, -1.0F, 0.0F);
      GL11.glVertex3f(var0, var0, var0);
      GL11.glVertex3f(var0, var0, -var0);
      GL11.glVertex3f(-var0, var0, -var0);
      GL11.glVertex3f(-var0, var0, var0);
      GlUtil.a38(0.0F, 0.0F, 0.3F, var1);
      GL11.glNormal3f(0.0F, 1.0F, 0.0F);
      GL11.glVertex3f(var0, -var0, -var0);
      GL11.glVertex3f(var0, -var0, var0);
      GL11.glVertex3f(-var0, -var0, var0);
      GL11.glVertex3f(-var0, -var0, -var0);
      GL11.glEnd();
   }

   public final void a15(class_935 var1) {
      if(this.a1()) {
         class_232 var2;
         label19: {
            var2 = this.field_a;
            if(!this.field_a.field_a.epsilonEquals(var2.field_b, 0.001F)) {
               var2.field_c.sub(var2.field_b, var2.field_a);
               float var4 = var2.field_c.length();
               var2.field_c.normalize();
               var2.field_c.scale(var1.a() * 10.0F);
               if(var4 > 1.0F) {
                  var2.field_c.scale(var4);
               }

               if(var4 >= var2.field_c.length()) {
                  var2.field_a.add(var2.field_c);
                  break label19;
               }
            }

            var2.field_a.set(var2.field_b);
         }

         var2.getWorldTransform().origin.set(var2.field_a);
         this.field_a.a(var1);
      }
   }

   public final void b() {
      if(this.a1()) {
         if(this.field_a.a4().a29() != null && this.field_a.a4().a29().a8() != null) {
            GlUtil.d1();
            GlUtil.b2();
            this.field_a.c();
            class_343 var10000 = this.field_a.a4().a29().a8();
            Object var7 = null;
            Set var1 = var10000.field_a.entrySet();
            class_969.field_a.b();
            GL11.glEnable(2884);
            GL11.glEnable(3042);
            GL11.glEnable(2903);
            GL11.glBlendFunc(770, 771);
            GlUtil.d1();
            this.field_a.a4();
            GlUtil.c2();
            Iterator var10 = var1.iterator();

            while(var10.hasNext()) {
               Entry var2 = (Entry)var10.next();
               class_232 var14 = this.field_a;
               class_47 var5 = (class_47)var2.getKey();
               boolean var3;
               if(var3 = var14.field_b.equals(var5)) {
                  class_883.field_a.add(var2.getValue());
                  GlUtil.d1();
                  GlUtil.c4((float)((class_47)var2.getKey()).field_a * 100.0F, (float)((class_47)var2.getKey()).field_b * 100.0F, (float)((class_47)var2.getKey()).field_c * 100.0F);
                  GL11.glCullFace(1028);
                  a22(50.0F, 0.15F);
                  GL11.glCullFace(1029);
                  GlUtil.c4(-50.0F, -50.0F, -50.0F);
                  GL11.glDisable(2896);
                  GL11.glEnable(2903);
                  GL11.glEnable(3042);
                  GL11.glBlendFunc(770, 771);
                  class_47 var15;
                  if(var3) {
                     float var4 = -100.0F;
                     var15 = var5 = new class_47();
                     var15.field_a = ByteUtil.d(var15.field_a);
                     var5.field_b = ByteUtil.d(var5.field_b);
                     var5.field_c = ByteUtil.d(var5.field_c);
                     GL11.glBegin(1);
                     float var6 = 0.0F;
                     float var12 = 0.0F;
                     float var8 = 0.0F;

                     for(float var9 = 0.0F; var9 < 3.0F; ++var9) {
                        var8 = 1.0F;
                        var12 = 1.0F;
                        if(var9 == 0.0F) {
                           var12 = 0.0F;
                           var8 = 0.6F;
                        } else if(var9 == 2.0F) {
                           var12 = 0.6F;
                           var8 = 0.0F;
                        }

                        GlUtil.a38(1.0F, 1.0F, 1.0F, var12);
                        GL11.glVertex3f((float)var5.field_a * 100.0F, (float)var5.field_b * 100.0F, var4);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var8);
                        GL11.glVertex3f((float)var5.field_a * 100.0F, (float)var5.field_b * 100.0F, var6);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var12);
                        GL11.glVertex3f(var4, (float)var5.field_b * 100.0F, (float)var5.field_c * 100.0F);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var8);
                        GL11.glVertex3f(var6, (float)var5.field_b * 100.0F, (float)var5.field_c * 100.0F);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var12);
                        GL11.glVertex3f((float)var5.field_a * 100.0F, var4, (float)var5.field_c * 100.0F);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var8);
                        GL11.glVertex3f((float)var5.field_a * 100.0F, var6, (float)var5.field_c * 100.0F);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var12);
                        GL11.glVertex3f((float)var5.field_a * 100.0F, (float)(var5.field_b + 1) * 100.0F, var4);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var8);
                        GL11.glVertex3f((float)var5.field_a * 100.0F, (float)(var5.field_b + 1) * 100.0F, var6);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var12);
                        GL11.glVertex3f(var4, (float)var5.field_b * 100.0F, (float)(var5.field_c + 1) * 100.0F);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var8);
                        GL11.glVertex3f(var6, (float)var5.field_b * 100.0F, (float)(var5.field_c + 1) * 100.0F);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var12);
                        GL11.glVertex3f((float)var5.field_a * 100.0F, var4, (float)(var5.field_c + 1) * 100.0F);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var8);
                        GL11.glVertex3f((float)var5.field_a * 100.0F, var6, (float)(var5.field_c + 1) * 100.0F);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var12);
                        GL11.glVertex3f((float)(var5.field_a + 1) * 100.0F, (float)var5.field_b * 100.0F, var4);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var8);
                        GL11.glVertex3f((float)(var5.field_a + 1) * 100.0F, (float)var5.field_b * 100.0F, var6);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var12);
                        GL11.glVertex3f(var4, (float)(var5.field_b + 1) * 100.0F, (float)var5.field_c * 100.0F);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var8);
                        GL11.glVertex3f(var6, (float)(var5.field_b + 1) * 100.0F, (float)var5.field_c * 100.0F);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var12);
                        GL11.glVertex3f((float)(var5.field_a + 1) * 100.0F, var4, (float)var5.field_c * 100.0F);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var8);
                        GL11.glVertex3f((float)(var5.field_a + 1) * 100.0F, var6, (float)var5.field_c * 100.0F);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var12);
                        GL11.glVertex3f((float)(var5.field_a + 1) * 100.0F, (float)(var5.field_b + 1) * 100.0F, var4);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var8);
                        GL11.glVertex3f((float)(var5.field_a + 1) * 100.0F, (float)(var5.field_b + 1) * 100.0F, var6);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var12);
                        GL11.glVertex3f(var4, (float)(var5.field_b + 1) * 100.0F, (float)(var5.field_c + 1) * 100.0F);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var8);
                        GL11.glVertex3f(var6, (float)(var5.field_b + 1) * 100.0F, (float)(var5.field_c + 1) * 100.0F);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var12);
                        GL11.glVertex3f((float)(var5.field_a + 1) * 100.0F, var4, (float)(var5.field_c + 1) * 100.0F);
                        GlUtil.a38(1.0F, 1.0F, 1.0F, var8);
                        GL11.glVertex3f((float)(var5.field_a + 1) * 100.0F, var6, (float)(var5.field_c + 1) * 100.0F);
                        var6 += 100.0F;
                        var4 += 100.0F;
                     }

                     GL11.glEnd();
                  }

                  if(var3) {
                     var15 = var5 = this.field_a.a(new class_47());
                     var15.field_a = ByteUtil.d(var15.field_a);
                     var5.field_b = ByteUtil.d(var5.field_b);
                     var5.field_c = ByteUtil.d(var5.field_c);
                     GL11.glBegin(1);
                     GlUtil.a38(1.0F, 1.0F, 1.0F, 0.05F);
                     GlUtil.a38(1.0F, 1.0F, 1.0F, 0.2F);
                     GL11.glVertex3f((float)var5.field_a * 6.25F, (float)var5.field_b * 6.25F, 0.0F);
                     GL11.glVertex3f((float)var5.field_a * 6.25F, (float)var5.field_b * 6.25F, 100.0F);
                     GL11.glVertex3f(0.0F, (float)var5.field_b * 6.25F, (float)var5.field_c * 6.25F);
                     GL11.glVertex3f(100.0F, (float)var5.field_b * 6.25F, (float)var5.field_c * 6.25F);
                     GL11.glVertex3f((float)var5.field_a * 6.25F, 0.0F, (float)var5.field_c * 6.25F);
                     GL11.glVertex3f((float)var5.field_a * 6.25F, 100.0F, (float)var5.field_c * 6.25F);
                     GL11.glVertex3f((float)var5.field_a * 6.25F, (float)(var5.field_b + 1) * 6.25F, 0.0F);
                     GL11.glVertex3f((float)var5.field_a * 6.25F, (float)(var5.field_b + 1) * 6.25F, 100.0F);
                     GL11.glVertex3f(0.0F, (float)var5.field_b * 6.25F, (float)(var5.field_c + 1) * 6.25F);
                     GL11.glVertex3f(100.0F, (float)var5.field_b * 6.25F, (float)(var5.field_c + 1) * 6.25F);
                     GL11.glVertex3f((float)var5.field_a * 6.25F, 0.0F, (float)(var5.field_c + 1) * 6.25F);
                     GL11.glVertex3f((float)var5.field_a * 6.25F, 100.0F, (float)(var5.field_c + 1) * 6.25F);
                     GL11.glVertex3f((float)(var5.field_a + 1) * 6.25F, (float)var5.field_b * 6.25F, 0.0F);
                     GL11.glVertex3f((float)(var5.field_a + 1) * 6.25F, (float)var5.field_b * 6.25F, 100.0F);
                     GL11.glVertex3f(0.0F, (float)(var5.field_b + 1) * 6.25F, (float)var5.field_c * 6.25F);
                     GL11.glVertex3f(100.0F, (float)(var5.field_b + 1) * 6.25F, (float)var5.field_c * 6.25F);
                     GL11.glVertex3f((float)(var5.field_a + 1) * 6.25F, 0.0F, (float)var5.field_c * 6.25F);
                     GL11.glVertex3f((float)(var5.field_a + 1) * 6.25F, 100.0F, (float)var5.field_c * 6.25F);
                     GL11.glVertex3f((float)(var5.field_a + 1) * 6.25F, (float)(var5.field_b + 1) * 6.25F, 0.0F);
                     GL11.glVertex3f((float)(var5.field_a + 1) * 6.25F, (float)(var5.field_b + 1) * 6.25F, 100.0F);
                     GL11.glVertex3f(0.0F, (float)(var5.field_b + 1) * 6.25F, (float)(var5.field_c + 1) * 6.25F);
                     GL11.glVertex3f(100.0F, (float)(var5.field_b + 1) * 6.25F, (float)(var5.field_c + 1) * 6.25F);
                     GL11.glVertex3f((float)(var5.field_a + 1) * 6.25F, 0.0F, (float)(var5.field_c + 1) * 6.25F);
                     GL11.glVertex3f((float)(var5.field_a + 1) * 6.25F, 100.0F, (float)(var5.field_c + 1) * 6.25F);
                     GL11.glEnd();
                  }

                  class_475.field_b.clear();
                  class_1382 var11;
                  (var11 = class_967.a2().a5("map-sprites-8x2-c-gui-")).a29(true);
                  var11.d();
                  var11.c15(true);
                  this.field_a.d();
                  this.field_a.a(field_a);
                  class_438 var10001 = (class_438)var2.getValue();
                  var7 = null;
                  class_1382.a170(var11, var10001.field_a, this.field_a);
                  var15 = this.field_a.a20().a44();
                  Object var13 = null;
                  class_793.a192(var15, this.field_b);
                  if(this.field_b.equals(var2.getKey())) {
                     class_1382.a170(var11, this.field_a, this.field_a);
                  }

                  var11.a29(false);
                  var11.c15(false);
                  GL11.glEnable(2896);
                  GL11.glEnable(2884);
                  GL11.glEnable(3042);
                  GL11.glEnable(2903);
                  GL11.glBlendFunc(770, 771);
                  if(var3) {
                     GlUtil.d1();
                     GlUtil.c4((float)(-((class_47)var2.getKey()).field_a) * 100.0F, (float)(-((class_47)var2.getKey()).field_b) * 100.0F, (float)(-((class_47)var2.getKey()).field_c) * 100.0F);
                     GlUtil.d1();
                     GlUtil.c4(50.0F, 50.0F, 50.0F);
                     this.field_a.a(new class_47());
                     GlUtil.c4(this.field_a.getWorldTransform().origin.field_x, this.field_a.getWorldTransform().origin.field_y, this.field_a.getWorldTransform().origin.field_z);
                     a22(3.125F, 0.4F);
                     GlUtil.c2();
                     GlUtil.c2();
                  }

                  GlUtil.c4(50.0F, 50.0F, 50.0F);
                  a22(50.0F, 0.15F);
                  GlUtil.c2();
               }
            }

            GL11.glDisable(2903);
            GL11.glEnable(2884);
            GL11.glDisable(3042);
            GlUtil.c2();
            GlUtil.a38(1.0F, 1.0F, 1.0F, 1.0F);
         }
      }
   }

   public final void c1() {
      this.field_a = new class_1381();
   }

   public final void a23(class_371 var1, class_935 var2) {
      if(this.a1()) {
         this.field_a.a77(var1, var2);
      }

   }

   private boolean a1() {
      return this.field_a.a14().a18().a79().a66().g() && this.field_a.a14().a18().a79().a66().c();
   }

   public final boolean a24(class_935 var1) {
      if(this.a1()) {
         this.field_a.a12(var1);
         return true;
      } else {
         return false;
      }
   }

   public final void handleKeyEvent() {
      if(Keyboard.getEventKeyState()) {
         if(Keyboard.getEventKey() == class_367.field_c.a5()) {
            this.a25(0, 0, 1);
         }

         if(Keyboard.getEventKey() == class_367.field_d.a5()) {
            this.a25(0, 0, -1);
         }

         if(Keyboard.getEventKey() == class_367.field_b.a5()) {
            this.a25(-1, 0, 0);
         }

         if(Keyboard.getEventKey() == class_367.field_a.a5()) {
            this.a25(1, 0, 0);
         }

         if(Keyboard.getEventKey() == class_367.field_e.a5()) {
            this.a25(0, 1, 0);
         }

         if(Keyboard.getEventKey() == class_367.field_f.a5()) {
            this.a25(0, -1, 0);
         }

         if(Keyboard.getEventKey() == 2) {
            a13(1);
         }

         if(Keyboard.getEventKey() == 3) {
            a13(2);
         }

         if(Keyboard.getEventKey() == 4) {
            a13(4);
         }

         if(Keyboard.getEventKey() == 5) {
            field_a = 0;
         }
      }

   }

   private static void a13(int var0) {
      boolean var1 = (field_a & var0) == var0;
      if(var1) {
         field_a &= ~var0;
      } else {
         field_a |= var0;
      }
   }

   private void a25(int var1, int var2, int var3) {
      Vector3f var4 = new Vector3f();
      int var5 = 0;
      if(var3 != 0) {
         var5 = var3;
         var3 = 0;
         GlUtil.c(var4, this.field_a.getWorldTransform());
      }

      if(var2 != 0) {
         var5 = var2;
         var2 = 0;
         GlUtil.f(var4, this.field_a.getWorldTransform());
      }

      if(var1 != 0) {
         var5 = var1;
         var1 = 0;
         GlUtil.e(var4, this.field_a.getWorldTransform());
      }

      if(Math.abs(var4.field_x) >= Math.abs(var4.field_y) && Math.abs(var4.field_x) >= Math.abs(var4.field_z)) {
         if(var4.field_x >= 0.0F) {
            var1 = var5;
         } else {
            var1 = -var5;
         }
      } else if(Math.abs(var4.field_y) >= Math.abs(var4.field_x) && Math.abs(var4.field_y) >= Math.abs(var4.field_z)) {
         if(var4.field_y >= 0.0F) {
            var2 = var5;
         } else {
            var2 = -var5;
         }
      } else if(Math.abs(var4.field_z) >= Math.abs(var4.field_y) && Math.abs(var4.field_z) >= Math.abs(var4.field_x)) {
         if(var4.field_z >= 0.0F) {
            var3 = var5;
         } else {
            var3 = -var5;
         }
      }

      int var7 = var3;
      var3 = var2;
      var2 = var1;
      class_232 var6 = this.field_a;
      this.field_a.field_a.a(var2, var3, var7);
      var6.a2(false);
   }

   public final void d() {
      this.field_a.a1(this.field_a.a20().a44().field_a, this.field_a.a20().a44().field_b, this.field_a.a20().a44().field_c, true);
   }

   public final class_241 a26() {
      return this.field_a;
   }

   public final class_1381 a27() {
      return this.field_a;
   }

   public static int a28() {
      return field_a;
   }

   public final class_232 a29() {
      return this.field_a;
   }

   public final void a30(class_47 var1) {
      class_343 var10000 = this.field_a.a4().a29().a8();
      class_47 var2 = var1;
      class_343 var3 = var10000;
      var2 = class_793.a192(var2, new class_47());
      if(!var3.field_a.containsKey(var2)) {
         if(!var3.field_a.containsKey(var2) || System.currentTimeMillis() - var3.field_a.get(var2).longValue() > 300000L) {
            var3.a(var2);
            var3.field_a.put(var2, System.currentTimeMillis());
            return;
         }
      } else if(!var3.field_a.containsKey(var2) || System.currentTimeMillis() - var3.field_a.get(var2).longValue() > 300000L) {
         var3.a(var2);
         var3.field_a.put(var2, System.currentTimeMillis());
      }

   }

   // $FF: synthetic method
   static class_1431 a31(class_228 var0) {
      return var0.field_a;
   }

   // $FF: synthetic method
   static class_371 a32(class_228 var0) {
      return var0.field_a;
   }

   static {
      BufferUtils.createIntBuffer(2048);
      field_a = 0;
      field_a = new class_47();
   }
}
