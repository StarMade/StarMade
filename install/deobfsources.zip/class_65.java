import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import org.schema.common.ParseException;

public final class class_65 implements Serializable {

   private ArrayList field_a = new ArrayList();
   private static final long serialVersionUID = 592607324358471017L;


   private static class_54 a(String var0) {
      class_54[] var1;
      int var2 = (var1 = class_54.values()).length;

      for(int var3 = 0; var3 < var2; ++var3) {
         class_54 var4 = var1[var3];
         if(var0.equals(var4.toString())) {
            return var4;
         }
      }

      throw new ParseException("-- PARSING ERROR: Type not known: " + var0);
   }

   public final void a1(String var1, String var2) {
      try {
         ArrayList var10000 = this.field_a;
         class_54 var5 = a(var2);
         Object var3 = null;
         switch(class_64.field_a[var5.ordinal()]) {
         case 1:
            var3 = new class_56(var1, var5);
            break;
         case 2:
            var3 = new class_59(var1, var5);
            break;
         case 3:
            var3 = new class_62(var1, var5);
            break;
         case 4:
            var3 = new class_57(Boolean.valueOf(Boolean.parseBoolean(var1)), var5);
            break;
         case 5:
            var3 = new class_63(Boolean.valueOf(Boolean.parseBoolean(var1)), var5);
         }

         if(var3 == null) {
            throw new ParseException("Type " + var5.name() + " not found");
         } else {
            var10000.add(var3);
         }
      } catch (ParseException var4) {
         var4.printStackTrace();
      }
   }

   public final class_58 a2(String var1) {
      class_54 var2 = a(var1);
      Iterator var3 = this.field_a.iterator();

      class_58 var4;
      do {
         if(!var3.hasNext()) {
            throw new ParseException("could not find Type \"" + var2 + "\" in Parsed XML! Existing Types: " + this.field_a);
         }
      } while(!(var4 = (class_58)var3.next()).field_a.equals(var2));

      return var4;
   }
}
