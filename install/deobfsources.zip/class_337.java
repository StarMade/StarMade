import com.bulletphysics.linearmath.Transform;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import javax.vecmath.Vector3f;
import javax.vecmath.Vector4f;

public class class_337 extends class_345 implements class_1390 {

   public Vector3f field_a;
   public byte field_a;
   public String field_a;
   private boolean field_a = true;
   private class_251 field_a;
   private Vector4f field_a = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);
   private float field_a;


   public boolean equals(Object var1) {
      class_337 var2;
      return (var2 = (class_337)var1).field_a.equals(this.field_a) && var2.field_a == this.field_a && var2.field_a.equals(this.field_a);
   }

   public int hashCode() {
      return this.field_a.hashCode() + this.field_a + this.field_a.hashCode();
   }

   public void fromTagStructure(class_79 var1) {}

   public String getUniqueIdentifier() {
      return null;
   }

   public boolean isVolatile() {
      return false;
   }

   public class_79 toTagStructure() {
      return null;
   }

   protected void a1(DataInputStream var1) {
      this.field_a = new Vector3f(var1.readFloat(), var1.readFloat(), var1.readFloat());
      this.field_a = var1.readUTF();
   }

   public void a2(DataOutputStream var1) {
      var1.writeFloat(this.field_a.field_x);
      var1.writeFloat(this.field_a.field_y);
      var1.writeFloat(this.field_a.field_z);
      var1.writeUTF(this.field_a);
   }

   public final int a3() {
      return this.field_a;
   }

   public final void a4(byte var1) {
      this.field_a = var1;
   }

   public String toString() {
      return "TEME[pos=" + this.field_a + ", type=" + this.field_a + ", name=" + this.field_a + "]";
   }

   public final boolean a5(int var1, class_47 var2) {
      return (var1 & 1) == 1 && (this.field_a.field_x / 100.0F * 16.0F < (float)var2.field_a || this.field_a.field_x / 100.0F * 16.0F > (float)(var2.field_a + 1))?false:((var1 & 2) == 2 && (this.field_a.field_y / 100.0F * 16.0F < (float)var2.field_b || this.field_a.field_y / 100.0F * 16.0F > (float)(var2.field_b + 1))?false:(var1 & 4) != 4 || this.field_a.field_z / 100.0F * 16.0F >= (float)var2.field_c && this.field_a.field_z / 100.0F * 16.0F <= (float)(var2.field_c + 1));
   }

   public final class_251 a6(class_47 var1) {
      if(this.field_a == null) {
         Transform var2;
         (var2 = new Transform()).setIdentity();
         var2.origin.set((float)(var1.field_a * 100) + this.field_a.field_x - 50.0F, (float)(var1.field_b * 100) + this.field_a.field_y - 50.0F, (float)(var1.field_c * 100) + this.field_a.field_z - 50.0F);
         this.field_a = new class_297(var2, this.field_a);
         return this.field_a;
      } else {
         float var10001 = (float)(var1.field_a * 100) + this.field_a.field_x - 50.0F;
         float var10002 = (float)(var1.field_b * 100) + this.field_a.field_y - 50.0F;
         float var10003 = (float)(var1.field_c * 100) + this.field_a.field_z;
         this.field_a.a().origin.set(var10001, var10002, var10003 - 50.0F);
         return this.field_a;
      }
   }

   public final boolean a7() {
      return this.field_a;
   }

   public final Vector3f a8() {
      return this.field_a;
   }

   public int a9(class_1382 var1) {
      return this.field_a == 4?0:(this.field_a == 1?8:(this.field_a == 2?9:(this.field_a == 5?10:0)));
   }

   public final float a10(long var1) {
      return 0.1F;
   }

   public final Vector4f a11() {
      this.field_a.field_w = 1.0F;
      if((class_228.field_a & 1) == 1 && (this.field_a.field_x / 100.0F * 16.0F < (float)class_228.field_a.field_a || this.field_a.field_x / 100.0F * 16.0F > (float)(class_228.field_a.field_a + 1))) {
         this.field_a.field_w = 0.1F;
      }

      if((class_228.field_a & 2) == 2 && (this.field_a.field_y / 100.0F * 16.0F < (float)class_228.field_a.field_b || this.field_a.field_y / 100.0F * 16.0F > (float)(class_228.field_a.field_b + 1))) {
         this.field_a.field_w = 0.1F;
      }

      if((class_228.field_a & 4) == 4 && (this.field_a.field_z / 100.0F * 16.0F < (float)class_228.field_a.field_c || this.field_a.field_z / 100.0F * 16.0F > (float)(class_228.field_a.field_c + 1))) {
         this.field_a.field_w = 0.1F;
      }

      return this.field_a;
   }

   public final void a12(float var1) {
      this.field_a = true;
      this.field_a = var1;
      class_475.field_b.add(this);
   }

   public final void a13() {
      this.field_a = false;
      class_475.field_b.remove(this);
   }

   public final boolean b2() {
      return (class_228.field_a & 1) == 1 && (this.field_a.field_x / 100.0F * 16.0F < (float)class_228.field_a.field_a || this.field_a.field_x / 100.0F * 16.0F > (float)(class_228.field_a.field_a + 1))?false:((class_228.field_a & 2) == 2 && (this.field_a.field_y / 100.0F * 16.0F < (float)class_228.field_a.field_b || this.field_a.field_y / 100.0F * 16.0F > (float)(class_228.field_a.field_b + 1))?false:(class_228.field_a & 4) != 4 || this.field_a.field_z / 100.0F * 16.0F >= (float)class_228.field_a.field_c && this.field_a.field_z / 100.0F * 16.0F <= (float)(class_228.field_a.field_c + 1));
   }

   public final float a14() {
      return this.field_a;
   }
}
