import java.io.IOException;
import org.schema.schine.graphicsengine.core.ResourceException;

final class class_325 extends class_73 {

   public final void a(class_66 var1) {
      try {
         System.err.println("Loading cube textures");
         (class_333.field_a = new class_1389[10])[0] = class_967.a3().a7("data/./textures/block/overlays.png");
         class_333.field_a[1] = class_967.a3().a7("data/./textures/block/t000.png");
         class_333.field_a[2] = class_967.a3().a7("data/./textures/block/t001.png");
         class_333.field_a[3] = class_967.a3().a7("data/./textures/block/t002.png");
         System.err.println("Loading cube textures DONE");
      } catch (IOException var2) {
         var2.printStackTrace();
         throw new ResourceException("data/./textures/block/");
      }
   }
}
