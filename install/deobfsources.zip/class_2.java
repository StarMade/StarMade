import org.schema.schine.graphicsengine.shader.ErrorDialogException;

final class class_2 extends class_12 {

   class_2(class_371 var1, Object var2, Object var3) {
      super(var1, var2, var3);
   }

   public final boolean a1() {
      return false;
   }

   public final void b() {
      class_967.b("0022_action - buttons push medium");
      if(super.field_a.a4().b4()) {
         this.d();

         try {
            super.field_a.a14().field_a.c2(false);
         } catch (ErrorDialogException var2) {
            var2.printStackTrace();
         }

         super.field_a.a14().field_a.d2(true);
         super.field_a.a14().field_a.a13(500);
      } else {
         String var1 = "Those who don\'t exist cannot be killed!.";
         super.field_a.a17(var1);
      }

      this.d();
   }

   public final void a2() {
      super.field_a.a14().field_a.field_a.a13(400);
   }
}
