import com.bulletphysics.linearmath.Transform;
import java.nio.FloatBuffer;
import javax.vecmath.Matrix3f;
import javax.vecmath.Vector3f;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.util.vector.Matrix4f;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.graphicsengine.forms.Mesh;

public final class class_134 implements class_923 {

   private class_371 field_a;
   private float field_a;
   private Matrix3f field_a;
   private Transform field_a;
   private FloatBuffer field_a;
   private float[] field_a;
   private boolean field_a;
   private Mesh field_a;


   public class_134(class_371 var1) {
      new Transform();
      new Vector3f();
      this.field_a = 0.0F;
      this.field_a = new Matrix3f();
      this.field_a = new Transform();
      this.field_a = BufferUtils.createFloatBuffer(16);
      this.field_a = new float[16];
      this.field_a = var1;
   }

   public final void a() {}

   public final void b() {
      if(!this.field_a) {
         this.c();
      }

      try {
         class_743 var1;
         if((var1 = this.field_a.a25()) != null) {
            Matrix4f var2 = class_967.field_a;
            this.field_a.rewind();
            var2.store(this.field_a);
            this.field_a.rewind();
            this.field_a.get(this.field_a);
            this.field_a.setFromOpenGLMatrix(this.field_a);
            this.field_a.origin.set(0.0F, 0.0F, 0.0F);
            class_964.j();
            GlUtil.d1();
            GlUtil.c4((float)(class_927.b() / 2), 105.0F, 0.0F);
            GlUtil.b5(10.0F, -10.0F, 10.0F);
            this.field_a.set(var1.getWorldTransform().basis);
            this.field_a.basis.mul(this.field_a);
            GlUtil.b3(this.field_a);
            GL11.glDisable(2896);
            GL11.glDisable(2929);
            GL11.glEnable(2977);
            GL11.glDisable(2884);
            GL11.glEnable(2929);
            this.field_a.a157().a2();
            this.field_a.e();
            this.field_a.a157().c();
            GlUtil.c2();
            class_964.h1();
            this.field_a += 0.15F;
            GL11.glEnable(2896);
            GL11.glDisable(2977);
            GL11.glEnable(2929);
            GL15.glBindBuffer('\u8892', 0);
         }

      } catch (NullPointerException var3) {
         System.err.println("EXCPETION HAS BEEN HANDLED");
         var3.printStackTrace();
      }
   }

   public final void c() {
      this.field_a = (Mesh)class_967.a2().a4("Arrow").a156().get(0);
      this.field_a = true;
   }
}
