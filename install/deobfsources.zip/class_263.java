import org.schema.schine.network.client.ClientState;

public final class class_263 extends class_196 {

   private class_930 field_a;
   private class_1080 field_a;


   public class_263(ClientState var1, class_1410 var2, Object var3, Object var4, class_1080 var5) {
      super(var1, var2, var3, var4);
      this.field_a = new class_930(var1, true);
      this.field_a.field_b = "";
      this.field_a.field_a = var5;
      this.field_a = var5;
   }

   public final void a2() {
      super.a2();
      this.field_a.a2();
   }

   public final void c() {
      super.c();
      this.field_a.c();
      this.field_a.a9(this.field_a);
      this.field_a.c12(this.field_a.a83());
      this.field_a.a165(2.0F, 110.0F, 0.0F);
      this.field_a.field_b.add(new class_265(this));
   }

   // $FF: synthetic method
   static class_1080 a109(class_263 var0) {
      return var0.field_a;
   }
}
