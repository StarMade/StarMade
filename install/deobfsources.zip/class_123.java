import java.util.Date;
import javax.vecmath.Vector4f;
import org.schema.schine.network.client.ClientState;

final class class_123 extends class_972 implements class_1410 {

   private class_1361 field_a;
   private class_765 field_a;


   public class_123(ClientState var1, class_765 var2, int var3) {
      super(var1);
      this.field_a = var2;
      this.field_a = new class_1361(this.a24(), 410.0F, 45.0F, var3 % 2 == 0?new Vector4f(0.1F, 0.1F, 0.1F, 1.0F):new Vector4f(0.2F, 0.2F, 0.2F, 2.0F));
      super.field_a = this.field_a;
      super.field_b = this.field_a;
   }

   public final void c() {
      class_940 var1;
      (var1 = new class_940(200, 30, this.a24())).a137((new Date(this.field_a.a25())).toString());
      class_777 var2 = ((class_371)this.a24()).a45().a146(this.field_a.a3());
      var1.field_b.add("to: " + this.field_a.a());
      var1.field_b.add(var2 != null?var2.a():"(ERROR)unknown");
      class_928 var3;
      (var3 = new class_928(this.a24(), 50, 20, "Revoke", this)).field_a = "REVOKE";
      this.field_a.a9(var1);
      this.field_a.a9(var3);
      var3.a83().field_x = 300.0F;
      super.c();
   }

   public final void a1(class_964 var1, class_941 var2) {
      if(var2.a() && "REVOKE".equals(var1.field_a)) {
         ((class_371)this.a24()).a45().b25(this.field_a);
      }

   }

   public final boolean a4() {
      return false;
   }
}
