import com.bulletphysics.linearmath.Transform;
import javax.vecmath.Vector3f;
import org.lwjgl.input.Keyboard;
import org.schema.game.common.controller.SegmentController;

public final class class_199 extends class_958 implements class_952 {

   private Vector3f field_a = new Vector3f();
   private SegmentController field_a;
   private class_457 field_a;
   private Transform field_b = new Transform();
   private float field_a;
   private float field_b;


   public class_199(class_457 var1) {
      super(var1.a1());
      new Vector3f();
      new Vector3f();
      new Vector3f();
      this.field_a = 25.0F;
      this.field_b = 5.0F;
      new class_47();
      new class_34();
      this.field_a = var1.a1();
      this.field_a = var1;
   }

   public final synchronized Vector3f a83() {
      Vector3f var1 = super.a83();
      Vector3f var2 = this.b9();
      this.field_b.set(super.field_a.getWorldTransform());
      this.field_b.basis.transform(var2);
      var1.add(var2);
      return var1;
   }

   public final Vector3f b9() {
      return new Vector3f(this.field_a.field_x + (float)this.field_a.a().field_a - 8.0F, this.field_a.field_y + (float)this.field_a.a().field_b - 8.0F, this.field_a.field_z + (float)this.field_a.a().field_c - 10.0F);
   }

   public final void handleKeyEvent() {}

   public final void a84(class_47 var1) {
      var1.c1(this.field_a.a());
      this.field_a.set((float)var1.field_a, (float)var1.field_b, (float)var1.field_c);
   }

   public final void a12(class_935 var1) {
      if(((class_371)this.field_a.getState()).a14().a18().a79().a60().a51().a45().a36().g() || ((class_371)this.field_a.getState()).a14().a18().a79().a60().a53().g()) {
         if(!((class_371)this.field_a.getState()).a14().a18().a77().c()) {
            Vector3f var2 = new Vector3f(this.field_a.getCamForwLocal());
            Vector3f var3 = new Vector3f(this.field_a.getCamUpLocal());
            Vector3f var4 = new Vector3f(this.field_a.getCamLeftLocal());
            float var5 = Keyboard.isKeyDown(42)?this.field_a:this.field_b;
            var2.scale(var5 * var1.a());
            var3.scale(var5 * var1.a());
            var4.scale(var5 * var1.a());
            if(!class_367.field_c.a6() || !class_367.field_d.a6()) {
               if(class_367.field_c.a6()) {
                  this.field_a.add(var2);
               }

               if(class_367.field_d.a6()) {
                  var2.scale(-1.0F);
                  this.field_a.add(var2);
               }
            }

            if(!class_367.field_a.a6() || !class_367.field_b.a6()) {
               if(class_367.field_a.a6()) {
                  var4.scale(-1.0F);
                  this.field_a.add(var4);
               }

               if(class_367.field_b.a6()) {
                  this.field_a.add(var4);
               }
            }

            if(!class_367.field_f.a6() || !class_367.field_e.a6()) {
               if(class_367.field_f.a6()) {
                  var3.scale(-1.0F);
                  this.field_a.add(var3);
               }

               if(class_367.field_e.a6()) {
                  this.field_a.add(var3);
               }
            }

         }
      }
   }
}
