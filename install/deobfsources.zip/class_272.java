import org.schema.game.common.data.element.Element;
import org.schema.game.common.data.element.ElementInformation;
import org.schema.game.common.data.element.ElementKeyMap;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public final class class_272 extends class_932 {

   private final class_192 field_a;
   private final class_940 field_a;
   private final class_970 field_a;
   private final class_970 field_b;
   private boolean field_a;
   private int field_a = -1;


   public class_272(ClientState var1) {
      super(var1);
      super.field_g = true;
      this.field_a = new class_970(class_967.a2().a5("tools-16x16-gui-"), this.a24());
      this.field_b = new class_970(class_967.a2().a5("tools-16x16-gui-"), this.a24());
      this.field_a = new class_192(var1);
      this.field_a = new class_940(10, 10, this.a24());
      this.field_a.a137("N/A for this block");
   }

   public final void a2() {}

   public final void b() {
      if(!this.field_a) {
         this.c();
      }

      if(this.field_a != this.a28().b6()) {
         this.e();
         this.field_a = this.a28().b6();
      }

      short var1;
      if((var1 = this.a28().a54()) != 0 && (ElementKeyMap.getInfo(var1).getBlockStyle() != 0 || ElementKeyMap.getInfo(var1).individualSides >= 4 || ElementKeyMap.getInfo(var1).isOrientatable()) && ElementKeyMap.getInfo(var1).getBlockStyle() != 3) {
         GlUtil.d1();
         this.r();
         this.field_a.b();
         this.field_a.b();
         this.field_b.b();
         GlUtil.c2();
      } else {
         GlUtil.d1();
         this.r();
         this.field_a.b();
         GlUtil.c2();
      }
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1() + this.field_a.b1() + this.field_b.b1();
   }

   public final void c() {
      this.field_a.c();
      this.field_a.field_g = true;
      this.field_b.field_g = true;
      this.field_a.a143(new class_270(this));
      this.field_b.a143(new class_268(this));
      this.field_a.a_2(21);
      this.field_b.a_2(20);
      this.field_a.a83().field_x = 6.0F;
      this.field_a.a83().field_y = 9.0F;
      this.field_a.a83().field_x = this.field_a.b1() + 29.0F;
      this.field_a.a83().field_y = 24.0F;
      this.field_b.a83().field_x = this.field_a.b1() + 60.0F;
      this.field_a = true;
   }

   private void e() {
      int var1 = this.a28().a28();
      short var2;
      if((var2 = this.a28().a54()) != 0) {
         int var3;
         if((var3 = ElementKeyMap.getInfo(var2).getBlockStyle()) > 0 && var3 < 3) {
            this.field_a.a74(var2);
            this.field_a.b13(0);
            this.field_a.a72(Element.orientationMapping[var1]);
         } else if(ElementKeyMap.getInfo(var2).getIndividualSides() > 3) {
            this.field_a.a74(var2);
            this.field_a.a72(0);
            this.field_a.b13(Element.orientationMapping[var1]);
         } else if(ElementKeyMap.getInfo(var2).orientatable) {
            this.field_a.a74(var2);
            this.field_a.a72(0);
            this.field_a.b13(Element.orientationMapping[var1]);
         } else {
            this.field_a.a74((short)0);
            this.field_a.a72(0);
            this.field_a.b13(0);
         }
      } else {
         this.field_a.a74((short)0);
         this.field_a.a72(0);
         this.field_a.b13(0);
      }
   }

   public final class_443 a28() {
      return ((class_371)this.a24()).a14().field_a.field_a.field_a;
   }

   // $FF: synthetic method
   static int a110(class_272 var0) {
      short var1;
      if((var1 = var0.a28().a54()) != 0) {
         ElementInformation var2;
         if((var2 = ElementKeyMap.getInfo(var1)).getIndividualSides() > 3) {
            return 6;
         }

         if(var2.getBlockStyle() == 1) {
            return 16;
         }

         if(var2.getBlockStyle() == 2) {
            return 16;
         }
      }

      return 8;
   }

   // $FF: synthetic method
   static void a111(class_272 var0) {
      var0.e();
   }
}
