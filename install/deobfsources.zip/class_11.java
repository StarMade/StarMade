import java.util.Observable;

public abstract class class_11 extends Observable implements class_952, class_1410 {

   public static long field_a = 0L;
   public class_371 field_a;
   boolean field_a = true;
   private long field_b;
   // $FF: synthetic field
   private static boolean field_b = !H.class.desiredAssertionStatus();


   public static boolean b1() {
      return System.currentTimeMillis() - field_a < 300L;
   }

   public class_11(class_371 var1) {
      this.field_a = var1;
      this.e();
   }

   public final void c1() {
      if(!field_b && this.a3() == null) {
         throw new AssertionError();
      } else {
         synchronized(this.field_a.b()) {
            this.field_b = 0L;
            this.field_a.b().remove(this);
            this.field_a.b().add(this);
         }
      }
   }

   public boolean c() {
      return false;
   }

   public final void d() {
      synchronized(this.field_a.b()) {
         boolean var2;
         if((var2 = this.field_a.b().remove(this)) && this.a3() instanceof class_42) {
            this.field_a.a10().add(this);
         }

         if(!var2) {
            System.err.println("[CLIENT][PlayerInput] not found: " + this + " to deactivate: " + this.field_a.b());
         } else {
            System.err.println("[CLIENT][PlayerInput] successfully deactivated " + this);
         }

         this.a2();
         this.field_b = System.currentTimeMillis();
         if(var2) {
            this.field_a.setLastDeactivatedMenu(System.currentTimeMillis());
         }

      }
   }

   public final long a5() {
      return this.field_b;
   }

   public abstract class_964 a3();

   public final class_371 a6() {
      return this.field_a;
   }

   protected void e() {}

   public abstract void a2();

   public final void f() {
      if(this.a3() instanceof class_42) {
         float var1 = 0.0F;
         if(this.field_b > 0L) {
            if((var1 = (float)(System.currentTimeMillis() - this.field_b)) > 200.0F) {
               var1 = 1.0F;
            } else {
               var1 /= 200.0F;
            }
         }

         ((class_42)this.a3()).a(var1);
      }

   }

}
