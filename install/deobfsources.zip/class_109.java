import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import org.schema.schine.network.client.ClientState;

public final class class_109 extends class_196 implements Observer {

   private class_966 field_a;
   private class_963 field_a;
   private boolean field_b = true;


   public class_109(ClientState var1, class_1410 var2) {
      super(var1, var2, "Faction Relationship Offers", "");
      ((class_371)this.a24()).a20().a132().deleteObserver(this);
      ((class_371)this.a24()).a20().a132().addObserver(this);
   }

   public final void c() {
      super.c();
      this.field_a = new class_966(410.0F, 110.0F, this.a24());
      this.field_a = new class_963(this.a24());
      this.field_a.c6(this.field_a);
      this.field_a.a9(this.field_a);
   }

   public final void b() {
      super.b();
      if(this.field_b) {
         class_109 var1 = this;
         this.field_a.clear();
         int var2 = 0;
         System.err.println("[GUI] UPDATING FACTION OFFER LIST: " + ((class_371)this.a24()).a20().a132().c23().size());

         for(Iterator var3 = ((class_371)this.a24()).a20().a132().c23().iterator(); var3.hasNext(); ++var2) {
            class_625 var4 = (class_625)var3.next();
            class_131 var5;
            (var5 = new class_131(var1.a24(), var4, var2)).c();
            var1.field_a.a144(var5);
         }

         this.field_b = false;
      }

   }

   public final boolean equals(Object var1) {
      return var1 instanceof class_86;
   }

   public final void update(Observable var1, Object var2) {
      this.field_b = true;
   }
}
