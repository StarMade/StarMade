
public final class class_340 {

   public long field_a = 117L;


   public class_340(class_340 var1) {
      this.field_a = var1.field_a;
   }

   public class_340() {}

   public final void a(boolean var1, long var2) {
      if(var1) {
         this.field_a |= var2;
      } else {
         this.field_a &= ~var2;
      }
   }
}
