import com.bulletphysics.linearmath.Transform;
import java.util.Locale;
import javax.vecmath.Vector3f;
import org.schema.schine.graphicsengine.shader.ErrorDialogException;

final class class_418 extends class_14 {

   // $FF: synthetic field
   private class_431 field_a;


   class_418(class_431 var1, class_371 var2, Object var3, Object var4, String var5) {
      this.field_a = var1;
      super(var2, 50, var3, var4, var5);
   }

   public final String[] getCommandPrefixes() {
      return null;
   }

   public final String handleAutoComplete(String var1, class_1077 var2, String var3) {
      return var1;
   }

   public final boolean a1() {
      return super.field_a.b().indexOf(this) != super.field_a.b().size() - 1;
   }

   public final void a2() {
      System.err.println("deactivate");
      this.field_a.e2(false);
   }

   public final void onFailedTextCheck(String var1) {
      this.a9("SHIPNAME INVALID: " + var1);
   }

   public final boolean a7(String var1) {
      if(super.field_a.a3() != null && super.field_a.a3().getPhysicsDataContainer() != null && super.field_a.a3().getPhysicsDataContainer().isInitialized()) {
         Transform var2 = new Transform();
         Vector3f var3 = new Vector3f(class_967.a1().c10());
         var2.set(super.field_a.a3().getPhysicsDataContainer().getCurrentPhysicsTransform());
         var3.scale(2.0F);
         var2.origin.add(var3);
         var2.basis.rotY(-1.5707964F);

         try {
            if(super.field_a.a20().getInventory((class_47)null).b2()) {
               if(!var1.toLowerCase(Locale.ENGLISH).contains("vehicle")) {
                  this.field_a.field_a = class_1039.a(var1.trim());
                  super.field_a.a4().a19(var2, new class_47(-2, -2, -2), new class_47(2, 2, 2), super.field_a.a20(), this.field_a.field_a, var1.trim());
                  System.err.println("SENDING LAST NAME: " + this.field_a.field_a + "; obs: " + this.countObservers());
                  this.field_a.a9(this.field_a.field_a);
               }
            } else {
               super.field_a.a4().b1("ERROR\nYou need a Core Element\nto create a ship");
            }

            return true;
         } catch (Exception var4) {
            var4.printStackTrace();
            throw new ErrorDialogException(var4.getMessage());
         }
      } else {
         System.err.println("[ERROR] Character might not have been initialized");
         return false;
      }
   }
}
