import java.net.URL;

public final class class_60 {

   public String field_a;
   public URL field_a;


   public class_60(String var1, URL var2) {
      this.field_a = var1;
      this.field_a = var2;
   }
}
