import java.util.HashSet;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;

public abstract class class_15 extends Observable implements class_952, class_948 {

   private final class_371 field_a;
   public boolean field_a = false;
   public boolean field_b;
   public HashSet field_a;
   private int field_a = -1;
   public boolean field_c;
   public long field_a;
   private int field_b;
   private long field_b;


   public class_15(class_371 var1) {
      this.field_a = var1;
      this.field_a = new HashSet();
      this.addObserver(var1.a27().a92());
   }

   public final void a11(class_15 var1) {
      Iterator var2 = this.field_a.iterator();

      while(var2.hasNext()) {
         class_15 var3;
         if((var3 = (class_15)var2.next()) != var1) {
            var3.c2(false);
         }
      }

      if(!var1.field_b) {
         var1.c2(true);
      }

   }

   public final void a2() {
      if(this.field_a >= 0) {
         this.c2(this.field_a == 1);
      }

      this.field_a = -1;
      Iterator var1 = this.field_a.iterator();

      while(var1.hasNext()) {
         ((class_15)var1.next()).a2();
      }

   }

   public class_371 a6() {
      return this.field_a;
   }

   public final long a5() {
      return this.field_a;
   }

   protected final boolean b1() {
      synchronized(this.a6().b()) {
         int var2;
         if((var2 = this.a6().b().size()) > 0) {
            ((class_11)this.a6().b().get(var2 - 1)).handleKeyEvent();
            return true;
         }
      }

      return false;
   }

   public void handleKeyEvent() {
      if(!this.field_a && !this.e1()) {
         Iterator var1 = this.field_a.iterator();

         while(var1.hasNext()) {
            class_15 var2;
            if(!(var2 = (class_15)var1.next()).field_a && var2.field_b) {
               var2.handleKeyEvent();
            }
         }
      }

   }

   public void a12(class_941 var1) {
      if(!this.field_a && !this.e1()) {
         Iterator var2 = this.field_a.iterator();

         while(var2.hasNext()) {
            class_15 var3;
            if(!(var3 = (class_15)var2.next()).field_a && var3.field_b) {
               var3.a12(var1);
            }
         }
      }

   }

   public final void a13(int var1) {
      this.field_b = var1;
      this.field_b = System.currentTimeMillis();
   }

   public final boolean c() {
      return this.field_b;
   }

   public final boolean d1() {
      return this.field_a >= 0;
   }

   public final boolean e1() {
      return System.currentTimeMillis() - this.field_b < (long)this.field_b;
   }

   public final boolean f1() {
      return this.field_a;
   }

   public final boolean g() {
      return this.field_c;
   }

   public void a14(boolean var1) {
      this.a6().a20().a114().a9(var1);
   }

   public void b2(boolean var1) {
      this.field_c = var1;
      class_15 var3 = null;
      Iterator var2 = this.field_a.iterator();

      while(var2.hasNext()) {
         (var3 = (class_15)var2.next()).b2(var1 && var3.field_b);
      }

   }

   public final void b3(int var1) {
      if(this.field_b) {
         String var2 = "";

         for(int var3 = 0; var3 < var1; ++var3) {
            var2 = var2 + "->";
         }

         var2 = var2 + this.getClass().getSimpleName();
         class_969.field_a.add("|-- " + var2);
         Iterator var4 = this.field_a.iterator();

         while(var4.hasNext()) {
            ((class_15)var4.next()).b3(var1 + 1);
         }
      }

   }

   public void c2(boolean var1) {
      boolean var10000 = this.field_b;
      boolean var2 = var1 != this.field_b;
      this.field_b = var1;
      if(var2) {
         this.b2(var1);
         this.setChanged();
         this.notifyObservers("ON_SWITCH");
      }

   }

   public synchronized void deleteObserver(Observer var1) {
      super.deleteObserver(var1);
   }

   public synchronized void deleteObservers() {
      super.deleteObservers();
   }

   public final void d2(boolean var1) {
      this.field_a = var1?1:0;
   }

   public final void e2(boolean var1) {
      if(var1 != this.field_a) {
         this.a14(var1);
         this.field_a = var1;
      }

      if(!var1) {
         this.field_a = System.currentTimeMillis();
      }

   }

   public void a15(class_935 var1) {
      if(!this.field_a) {
         Iterator var2 = this.field_a.iterator();

         while(var2.hasNext()) {
            class_15 var3;
            if(!(var3 = (class_15)var2.next()).field_a && var3.field_b) {
               var3.a15(var1);
            }
         }
      }

   }
}
