import java.util.List;

public final class class_333 extends class_66 {

   public static class_1389[] field_a;
   public static class_1389[] field_b;
   public static class_1389 field_a;
   public static class_1389 field_b;
   public static class_1385 field_a;
   public static class_919 field_a;


   public final List a() {
      List var1 = super.a();
      class_1385 var10000 = field_a;
      var1.add(new class_335());
      var1.add(new class_321());
      var1.add(new class_323());
      var1.add(new class_325());
      var1.add(new class_327());
      var1.add(new class_315());
      var1.add(new class_313());
      return var1;
   }
}
