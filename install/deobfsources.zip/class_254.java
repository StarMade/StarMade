import com.bulletphysics.linearmath.Transform;
import java.util.ArrayList;
import javax.vecmath.Vector3f;

public final class class_254 implements class_923 {

   private class_253[] field_a;
   private class_1352 field_a;
   private class_214 field_a;
   private class_1359 field_a;
   private boolean field_a = true;
   private class_371 field_a;
   public final ArrayList field_a = new ArrayList();
   private Vector3f field_a = new Vector3f();


   public class_254(class_371 var1) {
      this.field_a = var1;
      this.field_a = new class_253[32];

      for(int var2 = 0; var2 < 32; ++var2) {
         this.field_a[var2] = new class_253(class_967.a1().getWorldTransform());
      }

      this.field_a = new class_1352();
      this.field_a = new class_214(this.field_a);
      this.field_a = new class_1359(this.field_a, 16.0F);
   }

   public final void a() {}

   public final void b() {
      if(this.field_a) {
         this.c();
      }

      this.field_a.b();

      for(int var1 = 0; var1 < 32; ++var1) {
         if(this.field_a[var1].field_a) {
            this.field_a.a60(this.field_a[var1]);
            this.field_a.b();
         }
      }

   }

   public final void c() {
      this.field_a.c();
      this.field_a = false;
   }

   private void a14(Transform var1) {
      for(int var2 = 0; var2 < 32; ++var2) {
         if(this.field_a[var2].field_a == var1) {
            this.field_a[var2].field_b = true;
            this.field_a.a27().a91().a23(this.field_a[var2].field_a.origin, 50.0F);
            class_214 var3 = this.field_a;
            this.field_a.field_a[var2].field_a = (var3.field_a[var2].field_a + 1) % 100000;
            return;
         }
      }

   }

   public final void a1(class_935 var1) {
      ArrayList var2 = this.field_a;
      int var9;
      synchronized(this.field_a) {
         while(!this.field_a.isEmpty()) {
            class_358 var3;
            if((var3 = (class_358)this.field_a.remove(0)).field_a) {
               Transform var4 = var3.field_a;
               class_254 var8 = this;

               for(int var5 = 0; var5 < 32; ++var5) {
                  if(!var8.field_a[var5].field_a) {
                     System.err.println("[MISSILE] STARTING NEW TRAIL " + var4.origin);
                     class_253 var10;
                     (var10 = var8.field_a[var5]).b2();
                     var10.field_a = var4;
                     var10.field_b = null;
                     var10.field_b = false;
                     var10.field_a = true;
                     class_214 var11;
                     var9 = var8.field_a.a14((var11 = var8.field_a).field_a[var5].field_a.origin, var11.field_a);
                     var11.field_a[var5].field_a = var9;
                     var11.field_a.c1(var9, (float)var5, (float)var9, 0.0F);
                     break;
                  }
               }
            } else {
               this.a14(var3.field_a);
            }
         }
      }

      for(var9 = 0; var9 < 32; ++var9) {
         if(this.field_a[var9].field_a) {
            this.field_a[var9].a6(var1);
         }
      }

      this.field_a.set(class_967.a1().a83());
      if(this.field_a != null) {
         this.field_a.a1(var1);
      }

      this.field_a.a6(var1);
   }
}
