
public interface class_481 {

   void a(short var1);
}
