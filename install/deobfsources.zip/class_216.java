import com.bulletphysics.linearmath.Transform;
import javax.vecmath.Vector3f;
import javax.vecmath.Vector4f;

public final class class_216 extends class_251 {

   private Transform field_b;
   private static Vector3f field_a = new Vector3f();


   private class_216(Transform var1, String var2) {
      super(var1, var2);
      this.field_b = new Transform();
      this.field_b.set(var1);
   }

   public class_216(Transform var1, String var2, float var3, float var4, float var5) {
      this(var1, var2);
      super.field_a = new Vector4f(var3, var4, var5, 1.0F);
   }

   public final Transform a() {
      return this.field_b;
   }

   public final void a1(class_935 var1) {
      super.a1(var1);
      field_a.set(class_967.a1().f5());
      field_a.scale(var1.a());
      this.field_b.origin.add(field_a);
   }

}
