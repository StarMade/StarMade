
public final class class_344 extends class_11 {

   private class_777 field_a;
   private class_777 field_b;
   private class_86 field_a;


   public class_344(class_371 var1, class_777 var2, class_777 var3) {
      super(var1);
      this.field_a = var2;
      this.field_b = var3;
      this.field_a = new class_86(var1, var2, var3, this);
      this.field_a.e();
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.a()) {
         if(var1.b19().equals("OK")) {
            this.d();
            return;
         }

         if(var1.b19().equals("CANCEL") || var1.b19().equals("X")) {
            System.err.println("CANCEL");
            this.d();
            return;
         }

         class_777 var3;
         class_423 var4;
         class_777 var5;
         class_423 var10000;
         if(var1.b19().equals("WAR")) {
            var10000 = super.field_a.a14().field_a.field_a.field_a;
            var3 = this.field_b;
            var5 = this.field_a;
            var4 = var10000;
            var10000.e2(true);
            (new class_411(var4, var4.a6(), "Declare war", "Enter a message for your declaration", var5, var3)).c1();
            this.d();
            return;
         }

         if(var1.b19().equals("PEACE")) {
            var10000 = super.field_a.a14().field_a.field_a.field_a;
            var3 = this.field_b;
            var5 = this.field_a;
            var4 = var10000;
            var10000.e2(true);
            (new class_414(var4, var4.a6(), "Peace Treaty Offer", "Enter a message for the offer", var5, var3)).c1();
            this.d();
            return;
         }

         if(var1.b19().equals("ALLY")) {
            var10000 = super.field_a.a14().field_a.field_a.field_a;
            var3 = this.field_b;
            var5 = this.field_a;
            var4 = var10000;
            var10000.e2(true);
            (new class_416(var4, var4.a6(), "Alliance Offer", "Enter a message for the offer", var5, var3)).c1();
            this.d();
         }
      }

   }

   public final boolean a1() {
      return false;
   }

   public final void handleKeyEvent() {}

   public final class_964 a3() {
      return this.field_a;
   }

   public final void a2() {
      super.field_a.a14().field_a.field_a.field_a.a13(500);
      super.field_a.a14().field_a.field_a.field_a.e2(false);
   }
}
