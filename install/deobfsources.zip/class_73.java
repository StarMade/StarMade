import org.schema.schine.graphicsengine.core.ResourceException;

public class class_73 {

   public int field_a = -1;
   public String field_a;
   public String field_b;
   public String field_c;
   public String field_d;


   public void a(class_66 var1) {
      switch(this.field_a) {
      case 0:
         var1.c1(this);
         return;
      case 1:
         var1.b1(this);
         return;
      case 2:
         var1.a8(this);
         return;
      case 3:
         var1.a2().add(0, "loading FONTS...");
         class_28.m();
         class_28.a16();
         class_28.b2();
         class_28.h();
         class_28.e();
         class_28.d();
         class_28.j();
         class_28.i();
         class_28.g();
         class_28.n();
         class_28.o();
         class_28.c();
         class_28.f();
         return;
      default:
         throw new ResourceException("Unspecified resource type: " + this.field_a);
      }
   }

   public String toString() {
      return "RESOURCE(" + this.field_a + "; " + this.field_a + "; " + this.field_b + "; " + this.field_c + "; 0)";
   }
}
