
public final class class_8 extends class_11 {

   private class_128 field_a;
   private long field_b;
   private long field_c = 20000L;
   private final class_777 field_a;
   private final class_777 field_b;
   private String field_a;
   private String field_b;


   public class_8(class_371 var1, int var2, int var3) {
      super(var1);
      this.field_a = var1.a45().a146(var2);
      this.field_b = var1.a45().a146(var3);
      this.field_a = this.field_a != null?this.field_a.a():"(UNKNOWN)" + var2;
      this.field_b = this.field_b != null?this.field_b.a():"(UNKNOWN)" + var3;
      this.field_a = new class_128(var1, this.a4());
      this.field_b = System.currentTimeMillis();
      super.field_a = false;
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.field_a && var2.field_a == 0 && !super.field_a.a14().field_a.field_b && !b1()) {
         class_11.field_a = System.currentTimeMillis();
      }

   }

   public final boolean c() {
      this.field_a.a17(this.a4());
      return System.currentTimeMillis() - this.field_b > this.field_c;
   }

   private String a4() {
      long var1 = (this.field_c - (System.currentTimeMillis() - this.field_b)) / 1000L;
      return "Round has ended! \nTeam \"" + this.field_a + "\" has won\nby destroying the base of \nthe pathetic team \n\"" + this.field_b + "\"\n\n\nThe Round Will \nRestart in " + var1 + " seconds";
   }

   public final void handleKeyEvent() {}

   public final boolean a1() {
      return super.field_a.b().indexOf(this) != super.field_a.b().size() - 1;
   }

   public final void a2() {}
}
