
public interface class_377 {

   void a(String var1);
}
