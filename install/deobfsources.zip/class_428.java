
public final class class_428 extends class_11 {

   private final class_244 field_a;
   private boolean field_b;


   public class_428(class_371 var1, class_785 var2, boolean var3) {
      super(var1);
      this.field_a = new class_244(super.field_a, var2, this, var3);
      this.field_b = var3;
      this.field_a.c();
   }

   public final boolean a1() {
      return false;
   }

   public final void handleKeyEvent() {}

   public final class_964 a3() {
      return this.field_a;
   }

   public final void a2() {
      super.field_a.a14().field_a.field_a.field_a.a13(500);
      super.field_a.a14().field_a.field_a.field_a.e2(false);
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.a()) {
         if(var1.b19().equals("OK")) {
            if(this.field_b && ((Boolean)super.field_a.a20().a117().isAdminClient.get()).booleanValue()) {
               this.field_a.a108().field_a = true;
               super.field_a.a53().a181(this.field_a.a108());
            } else {
               this.field_a.a108().field_b = super.field_a.a20().getName();
               super.field_a.a53().a181(this.field_a.a108());
            }

            this.d();
            return;
         }

         if(var1.b19().equals("CANCEL") || var1.b19().equals("X")) {
            this.d();
         }
      }

   }
}
