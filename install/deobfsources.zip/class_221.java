import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.schema.schine.graphicsengine.core.GlUtil;

public final class class_221 implements class_1368 {

   private int field_a;


   public class_221(int var1) {
      this.field_a = var1;
   }

   public final void d() {
      GL11.glBindTexture(3553, 0);
   }

   public final void a(class_1376 var1) {
      GlUtil.a41(var1, "selectionColor", 0.7F, 0.7F, 0.7F, 1.0F);
      GL13.glActiveTexture('\u84c0');
      GL11.glBindTexture(3553, this.field_a);
      GlUtil.a35(var1, "mainTexA", 0);
   }
}
