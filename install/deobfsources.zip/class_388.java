
public final class class_388 {

   float[] field_a = new float[6];
   public byte[] field_a;
   public float[] field_b;
   int field_a;


   public class_388(int var1) {
      this.field_a = var1;
   }
}
