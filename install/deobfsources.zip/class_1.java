
public class class_1 extends class_11 {

   private class_200 field_a;
   // $FF: synthetic field
   private static boolean field_b = !E.class.desiredAssertionStatus();


   public class_1(class_371 var1) {
      super(var1);
      this.field_a = new class_200(var1, this, "Main Menu");
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var1.b19() != null && !var1.l1() && var1.a_()) {
         class_967.b("0022_action - buttons push small");
      }

      if(var2.field_a && var2.field_a == 0) {
         if(var1.b19().equals("RESUME") || var1.b19().equals("X")) {
            class_967.b("0022_menu_ui - enter");
            this.d();
            super.field_a.a14().field_a.c2(false);
            super.field_a.a14().field_a.d2(true);
            super.field_a.a14().field_a.a13(500);
            return;
         }

         if(var1.b19().equals("EXIT")) {
            class_967.b("0022_menu_ui - back");
            String var4 = "Sorry! there is no menu to go back to. Plase choose \'exit game\'.";
            this.field_a.a17(var4);
            return;
         }

         if(var1.b19().equals("SUICIDE")) {
            class_967.b("0022_menu_ui - enter");
            String var3 = "Are you sure you want to commit suicide?\nYou will spawn at the last activated\n\"Undeathinator\" module.";
            (new F(super.field_a, "Commit suicide?", var3)).c1();
            return;
         }

         if(var1.b19().equals("EXIT_TO_WINDOWS")) {
            System.err.println("MAIN MENU EXIT");
            class_967.b("0022_menu_ui - back");
            class_927.a3();
            return;
         }

         if(var1.b19().equals("OPTIONS")) {
            class_967.b("0022_menu_ui - enter");
            super.field_a.a14().field_a.c2(false);
            super.field_a.a14().field_a.c2(true);
            return;
         }

         if(!field_b) {
            throw new AssertionError("not known command: " + var1.b19());
         }
      }

   }

   public void handleKeyEvent() {}

   public final boolean a1() {
      return false;
   }

   public final void a2() {}

}
