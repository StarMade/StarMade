
final class class_256 extends class_12 {

   // $FF: synthetic field
   private int field_a;


   class_256(class_371 var1, Object var2, Object var3, int var4) {
      this.field_a = var4;
      super(var1, var2, var3);
   }

   public final boolean a1() {
      return false;
   }

   public final void b() {
      super.field_a.a20().a132().b5(this.field_a);
      this.d();
   }

   public final void a2() {}
}
