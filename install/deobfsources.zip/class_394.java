import it.unimi.dsi.fastutil.objects.ObjectArrayList;

public class class_394 {

   public int field_a;
   private final ObjectArrayList field_a;
   private final ObjectArrayList field_b;
   private int field_b;
   // $FF: synthetic field
   private static boolean field_a = !dH.class.desiredAssertionStatus();


   public class_394() {
      this.field_a = ((Integer)class_943.field_ad.a4()).intValue() + 10;
      this.field_a = new ObjectArrayList(((Integer)class_943.field_ad.a4()).intValue());
      this.field_b = new ObjectArrayList(((Integer)class_943.field_ad.a4()).intValue());
      this.field_b = this.field_a;
   }

   public static void a() {}

   public final void a1(int var1) {
      ObjectArrayList var2 = this.field_a;
      synchronized(this.field_a) {
         for(int var3 = 0; var3 < this.field_b.size(); ++var3) {
            class_661 var4;
            if((var4 = ((class_400)this.field_b.get(var3)).field_a) != null && var4.a4() < var1 - 5000 && !var4.c()) {
               if(!this.field_a.contains(this.field_b.get(var3))) {
                  var4.c1();
                  var4.b3();
                  var4.b7(false);
                  System.err.println("WARNING: Exception: cleaned up stuck mesh! " + var4 + "; " + var4.a15() + "; SegSector: " + var4.a15().getSectorId() + "; CurrentSector " + ((class_371)var4.a15().getState()).a8());
                  --var3;
               }
            } else if(var4 == null) {
               System.err.println("WARNING: Exception: null mesh! ");
            }
         }

      }
   }

   public final void b() {
      ObjectArrayList var1 = this.field_a;
      synchronized(this.field_a) {
         this.field_a.clear();
      }
   }

   private class_400 a2() {
      ObjectArrayList var1 = this.field_a;
      synchronized(this.field_a) {
         class_400 var2;
         if(this.field_a.isEmpty() && this.field_b > 0) {
            var2 = new class_400();
            --this.field_b;
            this.field_b.add(var2);
            return var2;
         } else {
            do {
               if(!this.field_a.isEmpty()) {
                  var2 = (class_400)this.field_a.remove(0);
                  this.field_b.add(var2);
                  var2.field_a = false;
                  if(!field_a && this.field_a.size() > this.field_a) {
                     throw new AssertionError();
                  }

                  return var2;
               }

               this.field_a.wait(5000L);
            } while(!this.field_a.isEmpty());

            System.err.println("[CUBEMESH] WARNING: overquota " + this.field_a);
            ++this.field_a;
            var2 = new class_400();
            this.field_b.add(var2);
            return var2;
         }
      }
   }

   public final class_400 a3(class_661 var1) {
      ObjectArrayList var2 = this.field_a;
      synchronized(this.field_a) {
         class_400 var3;
         (var3 = this.a2()).field_a = var1;
         if(!field_a && var3.field_a == null) {
            throw new AssertionError();
         } else {
            return var3;
         }
      }
   }

   public final void a4(class_400 var1) {
      ObjectArrayList var2 = this.field_a;
      synchronized(this.field_a) {
         if(var1 != null && !this.field_a.contains(var1)) {
            this.field_a.add(var1);
            this.field_b.remove(var1);
            this.field_a.notify();
         }

      }
   }

}
