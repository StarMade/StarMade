
final class class_282 extends class_12 {

   // $FF: synthetic field
   private class_286 field_a;


   class_282(class_286 var1, class_371 var2, Object var3, Object var4) {
      this.field_a = var1;
      super(var2, var3, var4);
   }

   public final boolean a1() {
      return false;
   }

   public final void b() {
      class_785 var1;
      if(class_286.a113(this.field_a) && ((Boolean)super.field_a.a20().a117().isAdminClient.get()).booleanValue()) {
         (var1 = new class_785(class_286.a112(this.field_a))).field_a = true;
         super.field_a.a53().b36(var1);
      } else {
         (var1 = new class_785(class_286.a112(this.field_a))).field_b = super.field_a.a20().getName();
         super.field_a.a53().b36(var1);
      }

      this.d();
   }

   public final void a2() {
      this.field_a.a14().e2(false);
   }
}
