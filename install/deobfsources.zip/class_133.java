import java.util.Iterator;
import org.schema.schine.network.client.ClientState;

public final class class_133 extends class_114 {

   public class_133(ClientState var1) {
      super(410.0F, var1);
   }

   public final boolean equals(Object var1) {
      return var1 instanceof class_133;
   }

   protected final void a27(class_963 var1) {
      int var2 = 0;
      var1.clear();

      for(Iterator var3 = ((class_371)this.a24()).a20().a132().b40().iterator(); var3.hasNext(); ++var2) {
         class_765 var4 = (class_765)var3.next();
         var1.a144(new class_123(this.a24(), var4, var2));
      }

   }
}
