import java.util.List;
import org.schema.game.common.data.element.ElementKeyMap;
import org.schema.game.server.data.blueprintnw.BlueprintEntry;

public final class class_303 extends class_15 implements class_1410 {

   public short field_a = -1;
   public class_972 field_a;
   private long field_b;
   private class_972 field_b;


   public class_303(class_371 var1) {
      super(var1);
   }

   public final void a(class_964 var1, class_941 var2) {
      String var3 = null;
      if(var2.field_a && var2.field_a == 0) {
         if(var1 instanceof class_972) {
            class_972 var12 = (class_972)var1;
            if(!"CATEGORY".equals(var12.a149().b19())) {
               if(this.field_b != null) {
                  this.field_b.a142().e();
                  this.field_b.a29(false);
               }

               var12.a29(true);
               this.field_a = ((Short)var12.a149().b19()).shortValue();
               this.field_b = var12;
            }
         }

         if("upload".equals(var1.b19())) {
            if(System.currentTimeMillis() - this.field_b < 5000L) {
               this.a6().a4().b1("Cannot upload now!\nplease wait " + (System.currentTimeMillis() - this.field_b) / 1000L + " seconds");
               return;
            }

            this.field_b = System.currentTimeMillis();
            List var14 = class_1214.field_a.a7();
            var3 = "Please enter in a name for your blue print!\n\nAvailable:\n" + var14;
            class_408 var15;
            (var15 = new class_408(this, this.a6(), "BluePrint", var3, var14.isEmpty()?"":((BlueprintEntry)var14.get(0)).toString())).a10(new class_476());
            synchronized(this.a6().b()) {
               this.a6().b().add(var15);
               this.e2(true);
            }
         }

         String var16;
         if("save_local".equals(var1.b19())) {
            if(System.currentTimeMillis() - this.field_b < 5000L) {
               this.a6().a4().b1("Cannot save now!\nplease wait " + (System.currentTimeMillis() - this.field_b) / 1000L + " seconds");
               return;
            }

            this.field_b = System.currentTimeMillis();
            var16 = "Please enter in a name for your blue print!";
            class_478 var17;
            (var17 = new class_478(this, this.a6(), "BluePrint", var16, "BLUEPRINT_" + System.currentTimeMillis())).a10(new class_472());
            synchronized(this.a6().b()) {
               this.a6().b().add(var17);
               this.e2(true);
            }
         }

         if("save_catalog".equals(var1.b19())) {
            if(System.currentTimeMillis() - this.field_b < 5000L) {
               this.a6().a4().b1("Cannot save now!\nplease wait " + (System.currentTimeMillis() - this.field_b) / 1000L + " seconds");
               return;
            }

            this.field_b = System.currentTimeMillis();
            var16 = "Please enter in a name for your blue print!";
            class_474 var18;
            (var18 = new class_474(this, this.a6(), "BluePrint", var16, "BLUEPRINT_" + System.currentTimeMillis())).a10(new class_484());
            synchronized(this.a6().b()) {
               this.a6().b().add(var18);
               this.e2(true);
            }
         }

         if("buy_catalog".equals(var1.b19()) && this.a33() != null) {
            if(System.currentTimeMillis() - this.field_b < 5000L) {
               this.a6().a4().b1("Cannot buy now!\nplease wait " + (System.currentTimeMillis() - this.field_b) / 1000L + " seconds");
               return;
            }

            this.field_b = System.currentTimeMillis();
            var16 = "Please type in a name for your new Ship!";
            class_486 var19;
            (var19 = new class_486(this, this.a6(), "New Ship", var16, this.a33().field_a + "_" + System.currentTimeMillis())).a10(new class_480());
            synchronized(this.a6().b()) {
               this.a6().b().add(var19);
               this.e2(true);
            }
         }

         if(var1 instanceof class_970 && this.field_a >= 0) {
            boolean var10000;
            short var22;
            if("buy".equals(var1.b19())) {
               var22 = this.field_a;
               class_739 var5;
               if((var5 = this.a6().a5()) == null) {
                  this.a6().a4().b1("ERROR: no shop available");
                  var10000 = false;
               } else {
                  int var6 = var5.a90().a42(var22);
                  int var4 = var5.a90().a41(var6);
                  if(var6 >= 0 && var4 > 0) {
                     if(this.a6().a20().b4() < var5.a89(ElementKeyMap.getInfo(var22), 1)) {
                        this.a6().a4().b1("ERROR: not enough credits");
                        var10000 = false;
                     } else {
                        var10000 = true;
                     }
                  } else {
                     this.a6().a4().b1("ERROR: shop out of item");
                     var10000 = false;
                  }
               }

               if(var10000) {
                  class_967.b("0022_action - purchase with credits");
                  this.a6().a20().a115().a(this.field_a, 1);
               }
            }

            if("sell".equals(var1.b19())) {
               label128: {
                  var22 = this.field_a;
                  if(this.a6().a20().getInventory((class_47)null).a42(var22) >= 0) {
                     class_739 var20;
                     if((var20 = this.a6().a5()) != null) {
                        label166: {
                           int var23;
                           if((var23 = var20.a90().a42(var22)) >= 0) {
                              int var13 = var20.a90().a41(var23);
                              var20.a90();
                              if(var13 >= class_653.e()) {
                                 this.a6().a4().b1("ERROR: shop has reached the max\nstock for the item\n" + ElementKeyMap.getInfo(var22).getName());
                                 break label166;
                              }
                           }

                           var10000 = true;
                           break label128;
                        }
                     } else {
                        this.a6().a4().b1("ERROR: no shop in distance");
                     }
                  } else {
                     this.a6().a4().b1("ERROR: you don\'t own that item\n" + ElementKeyMap.getInfo(var22).getName());
                  }

                  var10000 = false;
               }

               if(var10000) {
                  class_967.b("0022_action - receive credits");
                  this.a6().a20().a115().b(this.field_a, 1);
               }
            }

            class_739 var21;
            if("sell_more".equals(var1.b19())) {
               if((var21 = this.a6().a5()) != null) {
                  this.a34(this.field_a, 1, var21);
               } else {
                  this.a6().a4().b1("ERROR: shop no more in distance");
               }
            }

            if("buy_more".equals(var1.b19()) && (var21 = this.a6().a5()) != null) {
               synchronized(this.a6().b()) {
                  this.a6().b().add(new class_322(this.a6(), this.field_a, var21));
                  this.e2(true);
                  return;
               }
            }
         }
      }

   }

   public final class_785 a33() {
      return this.field_a != null?(class_785)this.field_a.b19():null;
   }

   public final void handleKeyEvent() {}

   public final void a12(class_941 var1) {
      super.a12(var1);
   }

   public final boolean a1() {
      return !this.a6().b().isEmpty();
   }

   public final void b2(boolean var1) {
      class_1008.field_a = !var1;
      if(var1) {
         class_967.b("0022_menu_ui - swoosh scroll large");
      } else {
         class_967.b("0022_menu_ui - swoosh scroll small");
      }

      this.a6().a14().field_a.field_a.field_a.a51().a45().field_a.e2(var1);
      this.a6().a14().field_a.field_a.field_a.a51().a45().field_a.e2(var1);
      super.b2(var1);
   }

   public final void a34(short var1, int var2, class_739 var3) {
      synchronized(this.a6().b()) {
         this.a6().b().add(new class_304(this.a6(), var1, var2, var3));
         this.e2(true);
      }
   }

   public final void a15(class_935 var1) {
      class_1008.field_a = false;
      if(!this.a6().d2()) {
         this.a6().a4().b1("no shop in range");
         this.d2(false);
         this.a6().a14().field_a.field_a.field_a.d2(true);
      }

      this.a6().a14().field_a.field_a.field_a.e2(true);
   }
}
