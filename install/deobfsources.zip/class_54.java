import java.io.Serializable;

public enum class_54 implements Serializable {

   field_a("SPRITEPATH", 0, "path"),
   field_b("SPRITENAME", 1, "filename"),
   field_c("SPAWNABLE", 2, "spawnable"),
   field_d("SOUNDPATH", 3, "soundpath"),
   field_e("CULLING", 4, "culling");
   private String field_a;
   // $FF: synthetic field
   private static final class_54[] field_a = new class_54[]{field_a, field_b, field_c, field_d, field_e};


   private class_54(String var1, int var2, String var3) {
      this.field_a = var3;
   }

   public final String toString() {
      return this.field_a;
   }

}
