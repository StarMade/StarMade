
public abstract class class_456 {

   class_1001 field_a;
   class_1001 field_b;
   class_1001 field_c;
   private class_1001 field_d;
   private class_1001 field_e;
   private static class_956 field_a = new class_391();
   private static class_956 field_b = new class_385();
   private static class_956 field_c = new class_375();
   private static class_956 field_d = new class_383();
   private static class_956 field_e = new class_393();
   private static class_956 field_f = new class_395();
   protected class_371 field_a;
   // $FF: synthetic field
   private static boolean field_a = !bL.class.desiredAssertionStatus();


   public class_456(class_1001 var1, class_1001 var2, class_1001 var3, class_371 var4) {
      this.field_a = var1;
      this.field_d = var2;
      this.field_e = var3;
      this.field_a = var4;
   }

   public final class_1001 a3() {
      this.a1();
      if(!field_a && this.field_b == null) {
         throw new AssertionError();
      } else if(!field_a && this.field_c == null) {
         throw new AssertionError();
      } else {
         this.field_b.a9(field_f, this.field_a);
         this.field_a.a9(field_a, this.field_b);
         this.field_a.a9(field_b, this.field_d);
         this.field_a.a9(field_e, this.field_e);
         class_1001 var1 = this.a(this.field_b);
         this.a2(var1, this.field_c);
         if(!field_a && this.field_b.a10().a() <= 0) {
            throw new AssertionError();
         } else {
            return this.field_c;
         }
      }
   }

   protected abstract class_1001 a(class_1001 var1);

   protected abstract void a1();

   protected void a2(class_1001 var1, class_1001 var2) {
      var1.a9(field_a, var2);
      var1.a9(field_b, this.field_d);
      var1.a9(field_d, this.field_a);
      var1.a9(field_c, this.field_c);
      var1.a9(field_e, this.field_e);
      var2.a9(field_f, var1);
   }

   protected final void a4(class_1001 var1, class_1001 var2, class_1001 var3) {
      var1.a9(field_a, var2);
      var1.a9(field_b, this.field_d);
      var1.a9(field_d, this.field_a);
      var1.a9(field_c, this.field_c);
      var1.a9(field_e, this.field_e);
      var2.a9(field_f, var3);
   }

}
