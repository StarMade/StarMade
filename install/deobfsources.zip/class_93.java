import java.util.ArrayList;
import java.util.List;
import javax.vecmath.Vector4f;
import org.schema.game.server.data.blueprintnw.BlueprintEntry;
import org.schema.schine.network.client.ClientState;

public final class class_93 extends class_1412 implements class_1410 {

   private class_928 field_a;
   private class_928 field_b;
   private class_928 field_c;
   private class_940 field_a;


   public class_93(ClientState var1) {
      super(var1, 510.0F, 60.0F);
   }

   public final class_427 a14() {
      return ((class_371)this.a24()).a14().field_a.field_a.field_a;
   }

   public final void c() {
      super.c();
      class_371 var1 = (class_371)this.a24();
      this.field_a = new class_928(var1, 142, 25, new Vector4f(0.3F, 0.3F, 0.7F, 1.0F), new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), class_28.c(), "Create new entry", this, this.a14());
      this.field_a.field_a = "save";
      this.field_a.b14(4, 1);
      this.field_b = new class_928(var1, 140, 20, new Vector4f(0.3F, 0.7F, 0.5F, 1.0F), new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), class_28.o(), "Save in local catalog", this, this.a14());
      this.field_b.field_a = "save_local";
      this.field_c = new class_928(var1, 160, 20, new Vector4f(0.5F, 0.7F, 0.3F, 1.0F), new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), class_28.o(), "Upload entry from local", this, this.a14());
      this.field_c.field_a = "upload";
      this.field_b.a83().field_x = 220.0F;
      this.field_c.a83().field_x = 370.0F;
      class_940 var2 = new class_940(1, 1, var1);
      int var3;
      if((var3 = ((Integer)var1.a12().a52().saveSlotsAllowed.get()).intValue()) < 0) {
         var2.a137("Used: " + var1.a20().a112().a1().size());
      } else {
         var2.a137("Used: " + var1.a20().a112().a1().size() + "/" + var3);
      }

      var2.a83().field_x = 150.0F;
      var2.a83().field_y = 2.0F;
      this.field_a = new class_940(1, 1, var1);
      this.field_a.field_b = new ArrayList();
      this.field_a.field_b.add("\"Create new Entry\" will save the ship you are currently in into this catalog. You can also save ");
      this.field_a.field_b.add("a ship in your singleplayer (local) catalog, or upload an entry from it.");
      this.field_a.a83().field_y = this.field_a.a83().field_y + this.field_a.a3() + 4.0F;
      this.a9(this.field_a);
      this.a9(var2);
      this.a9(this.field_a);
      this.a9(this.field_b);
      this.a9(this.field_c);
   }

   public final void b() {
      ((class_371)this.a24()).a14().field_a.field_a.field_a.a43();
      super.b();
   }

   public final void a1(class_964 var1, class_941 var2) {
      if(var2.a()) {
         class_801 var4 = ((class_371)this.a24()).a14().field_a.field_a.field_a.a43();
         boolean var5 = ((class_371)this.a24()).a25() != null || var4 != null && var4 instanceof class_743;
         String var9;
         if("save".equals(var1.field_a)) {
            if(var5) {
               this.a14().e2(true);
               var9 = "Please enter in a name for your blue print!";
               class_168 var10;
               (var10 = new class_168(this, (class_371)this.a24(), "BluePrint", var9, "BLUEPRINT_" + System.currentTimeMillis())).a10(new class_166());
               var10.c1();
               return;
            }

            ((class_371)this.a24()).a4().b1("You must be in a\nship or have one\nselected to save it");
            return;
         }

         if("save_local".equals(var1.field_a)) {
            if(var5) {
               this.a14().e2(true);
               var9 = "Please enter in a name for your blue print!";
               class_95 var7;
               (var7 = new class_95(this, (class_371)this.a24(), "BluePrint", var9, "BLUEPRINT_" + System.currentTimeMillis())).a10(new class_97());
               var7.c1();
               return;
            }

            ((class_371)this.a24()).a4().b1("You must be in a\nship or have one\nselected to save it");
            return;
         }

         if("upload".equals(var1.field_a)) {
            this.a14().e2(true);
            List var6 = class_1214.field_a.a7();
            String var3 = "Please enter in a name for your blue print!\n\nAvailable:\n" + var6;
            class_172 var8;
            (var8 = new class_172(this, (class_371)this.a24(), "BluePrint", var3, var6.isEmpty()?"":((BlueprintEntry)var6.get(0)).toString())).a10(new class_170());
            var8.c1();
         }
      }

   }

   public final boolean a4() {
      return false;
   }
}
