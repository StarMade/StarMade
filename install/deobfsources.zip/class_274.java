import javax.vecmath.Vector4f;
import org.schema.schine.network.client.ClientState;

public final class class_274 extends class_959 {

   private class_1361 field_a;


   public class_274(ClientState var1, class_160 var2, class_785 var3, boolean var4, int var5) {
      super(var1);
      this.field_a = new class_1361(this.a24(), 510.0F, 80.0F, var5 % 2 == 0?new Vector4f(0.0F, 0.0F, 0.0F, 0.0F):new Vector4f(0.1F, 0.1F, 0.1F, 0.5F));
      class_286 var6;
      (var6 = new class_286(this.a24(), var3, var4)).c();
      this.field_a.a9(var6);
      this.field_a.a144(new class_972(this.field_a, this.field_a, this.a24()));
      this.field_a = new class_288(this.a24(), var3, "+", var5);
      this.field_b = new class_288(this.a24(), var3, "-", var5);
      this.field_a.c();
      this.field_b.c();
      this.c();
      this.addObserver(var2);
   }

   protected final boolean b3() {
      return ((class_371)this.a24()).b().isEmpty();
   }

   public final void a72(int var1) {
      this.field_a.a63().set(var1 % 2 == 0?new Vector4f(0.0F, 0.0F, 0.0F, 0.0F):new Vector4f(0.1F, 0.1F, 0.1F, 0.5F));
      ((class_288)this.field_a).a72(var1);
      ((class_288)this.field_b).a72(var1);
   }
}
