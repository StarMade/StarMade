import org.schema.game.client.view.cubes.CubeOptOptMesh;

final class class_321 extends class_73 {

   public final void a(class_66 var1) {
      System.err.println("Init Cube MESH");
      class_967.a2().a4("Box").a156().get(0);
      CubeOptOptMesh.d();
      System.err.println("Init Cube MESH DONE");
   }
}
