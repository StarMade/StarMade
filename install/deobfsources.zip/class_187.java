import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public final class class_187 extends class_964 {

   private class_966 field_a;
   private boolean field_a;
   private class_970 field_a;
   class_161 field_a;


   public class_187(ClientState var1) {
      super(var1);
      this.field_a = new class_966(536.0F, 360.0F, var1);
      this.a9(this.field_a);
   }

   public final void a2() {}

   public final void b() {
      if(!this.field_a) {
         this.c();
      }

      GlUtil.d1();
      this.r();
      this.field_a.b();
      GlUtil.c2();
   }

   public final float a3() {
      return 360.0F;
   }

   public final float b1() {
      return 536.0F;
   }

   public final void c() {
      this.field_a = new class_183(this.a24(), this.field_a);
      this.field_a.c6(this.field_a);
      this.field_a = new class_161((class_371)this.a24());
      this.field_a.a54(((class_371)this.a24()).a20().getInventory((class_47)null));
      this.field_a.c();
      this.field_a.a9(this.field_a);
      this.field_a = true;
   }
}
