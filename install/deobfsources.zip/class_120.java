import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.graphicsengine.core.settings.StateParameterNotFoundException;
import org.schema.schine.network.client.ClientState;

public class class_120 extends class_932 implements class_1410 {

   private class_970 field_a;
   private class_970 field_b;
   private class_776 field_a;
   // $FF: synthetic field
   private static boolean field_a = !fs.class.desiredAssertionStatus();


   public class_120(ClientState var1, class_776 var2) {
      super(var1);
      super.field_g = true;
      this.a143(this);
      this.field_a = var2;
      if(!field_a && !(var2.a162() instanceof Boolean)) {
         throw new AssertionError();
      } else {
         this.field_a = new class_970(class_967.a2().a5("tools-16x16-gui-"), this.a24());
         this.field_b = new class_970(class_967.a2().a5("tools-16x16-gui-"), this.a24());
      }
   }

   public final void a1(class_964 var1, class_941 var2) {
      var1 = null;
      if(var2.field_a && var2.field_a == 0) {
         try {
            this.field_a.a13();
            return;
         } catch (StateParameterNotFoundException var3) {
            var3.printStackTrace();
            class_927.a2(var3);
         }
      }

   }

   public final void a2() {}

   protected final void d() {}

   public final void b() {
      GlUtil.d1();
      this.r();
      this.l();
      this.field_a.b();
      if(this.field_a.a7()) {
         this.field_b.b();
      }

      GlUtil.c2();
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public final boolean a4() {
      return false;
   }

   public final void c() {
      this.field_a.a_2(18);
      this.field_b.a_2(19);
   }

}
