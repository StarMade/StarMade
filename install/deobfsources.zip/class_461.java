
public final class class_461 {

   public int field_a = 1;


   public final String toString() {
      return String.valueOf(this.field_a);
   }
}
