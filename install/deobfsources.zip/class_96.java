
final class class_96 {

   // $FF: synthetic field
   private class_777 field_a;
   // $FF: synthetic field
   private class_101 field_a;


   class_96(class_101 var1, class_777 var2) {
      this.field_a = var1;
      this.field_a = var2;
      super();
   }

   public final String toString() {
      return this.field_a.a3() >= 0 && this.field_a.a3() != ((class_371)this.field_a.a24()).a20().a132().a3()?(this.field_a.c()?"join":"private"):"        -";
   }
}
