
final class class_441 implements class_481 {

   public final void a(short var1) {}
}
