import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.graphicsengine.forms.Mesh;

public final class class_237 implements class_923, class_1368 {

   public float field_a;
   private int field_a;
   private int field_b;
   private float field_b;
   private float field_c;
   private Mesh field_a;


   public final void a() {}

   public final void b() {
      GlUtil.d1();
      GlUtil.a31(class_969.field_a.a83());
      GlUtil.b5(10.0F, 10.0F, 10.0F);
      GL11.glEnable(2884);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      class_1379.field_l.field_a = this;
      class_1379.field_l.b();
      this.field_a.b();
      class_1379.field_l.d();
      GL11.glDisable(3042);
      GlUtil.c2();
   }

   public final void c() {
      this.field_a = (Mesh)class_967.a2().a4("BlackHole").a156().iterator().next();
      this.field_b = 5.0E-7F;
      this.field_c = 0.7F;
      this.field_a = class_967.a2().a5("detail").a157().a1().field_c;
      this.field_b = class_967.a2().a5("detail_normal").a157().a1().field_c;
   }

   public final void d() {
      GL13.glActiveTexture('\u84c0');
      GL11.glDisable(3553);
      GL11.glBindTexture(3553, 0);
      GL13.glActiveTexture('\u84c1');
      GL11.glDisable(3553);
      GL11.glBindTexture(3553, 0);
      GL13.glActiveTexture('\u84c0');
   }

   public final void a13(class_1376 var1) {
      GlUtil.a33(var1, "cSharp", this.field_b);
      GlUtil.a33(var1, "cCover", this.field_c);
      GlUtil.a33(var1, "cMove", this.field_a);
      GlUtil.a41(var1, "lightPos", class_969.field_a.a83().field_x, class_969.field_a.a83().field_y, class_969.field_a.a83().field_z, 1.0F);
      GL13.glActiveTexture('\u84c0');
      GL11.glEnable(3553);
      GL11.glBindTexture(3553, this.field_a);
      GL13.glActiveTexture('\u84c1');
      GL11.glEnable(3553);
      GL11.glBindTexture(3553, this.field_b);
      GL13.glActiveTexture('\u84c2');
      GlUtil.a35(var1, "tex", 0);
      GlUtil.a35(var1, "nmap", 1);
   }
}
