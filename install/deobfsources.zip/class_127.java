import org.schema.schine.network.client.ClientState;

final class class_127 extends class_196 implements class_1410 {

   // $FF: synthetic field
   private class_121 field_a;


   public class_127(class_121 var1, ClientState var2, class_1410 var3, Object var4, Object var5) {
      this.field_a = var1;
      super(var2, var3, var4, var5);
      super.field_a = false;
   }

   public final void c() {
      super.c();
      class_133 var1;
      (var1 = new class_133(this.a24())).c();
      this.field_a.a9(var1);
      class_940 var2;
      (var2 = new class_940(100, 100, this.a24())).a137("No Permission to invite");
      class_125 var3;
      (var3 = new class_125(this.a24(), "Invite Player", this, var2)).field_a = "INVITE";
      var3.a165(235.0F, 213.0F, 0.0F);
      this.field_a.a9(var3);
   }

   public final void a1(class_964 var1, class_941 var2) {
      if(var2.a()) {
         class_423 var3;
         if((var3 = ((class_371)this.a24()).a14().field_a.field_a.field_a).a6().a20().a132().b40().size() >= 5) {
            var3.a6().a4().b1("You can only have five\ninvitations pending\nat the same time");
         } else {
            var3.e2(true);
            (new class_412(var3, var3.a6(), "Create Invitation", "Enter Name of the player you want to invite")).c1();
         }

         this.field_a.d();
      }

   }

   public final boolean a4() {
      return false;
   }
}
