import org.schema.schine.network.client.ClientState;

public final class class_90 extends class_196 {

   private class_777 field_a;
   private class_156[] field_a;


   public class_90(ClientState var1, class_346 var2, class_777 var3) {
      super(var1, var2, "Edit Roles", "");
      this.field_a = var3;
   }

   public final void c() {
      super.c();
      class_966 var1 = new class_966(406.0F, 139.0F, this.a24());
      class_963 var2 = new class_963(this.a24());
      this.field_a = new class_156[5];

      for(int var3 = 0; var3 < 5; ++var3) {
         this.field_a[var3] = new class_156((class_371)this.a24(), this.field_a, var3);
         this.field_a[var3].c();
         var2.a144(new class_972(this.field_a[var3], this.field_a[var3], this.a24()));
      }

      var1.c6(var2);
      this.field_a.a9(var1);
   }

   public final class_156[] a13() {
      return this.field_a;
   }
}
