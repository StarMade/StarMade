
public final class class_9 {

   final class_744 field_a;
   long field_a = -1L;
   long field_b = -1L;
   boolean field_a = false;
   boolean field_b;
   public boolean field_c;


   public class_9(class_744 var1) {
      this.field_a = var1;
      var1.a131();
      this.field_a = class_740.a4();
   }
}
