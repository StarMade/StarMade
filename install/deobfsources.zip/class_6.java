import com.bulletphysics.collision.dispatch.CollisionWorld;
import com.bulletphysics.linearmath.Transform;

public interface class_6 {

   void handleHit(CollisionWorld.ClosestRayResultCallback var1, class_798 var2, float var3);

   void handleHitMissile(class_609 var1, Transform var2);
}
