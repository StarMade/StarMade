import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

final class class_125 extends class_928 {

   // $FF: synthetic field
   private class_940 field_a;


   class_125(ClientState var1, Object var2, class_1410 var3, class_940 var4) {
      this.field_a = var4;
      super(var1, 120, 30, var2, var3);
   }

   public final void b() {
      int var1 = ((class_371)this.a24()).a20().h1();
      class_777 var3;
      if((var3 = ((class_371)this.a24()).a45().a146(var1)) != null) {
         class_762 var2;
         if((var2 = (class_762)var3.a154().get(((class_371)this.a24()).a20().getName())) != null && var2.c15(var3)) {
            super.b();
         } else {
            GlUtil.d1();
            this.r();
            this.field_a.b();
            GlUtil.c2();
         }
      } else {
         GlUtil.d1();
         this.r();
         this.field_a.b();
         GlUtil.c2();
      }
   }
}
