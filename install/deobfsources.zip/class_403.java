
public abstract class class_403 extends class_454 {

   private static final long serialVersionUID = 4508994008546152897L;
   protected long field_a;


   public class_403(class_983 var1, String var2, class_371 var3) {
      super(var1, var2, var3);
   }

   protected boolean a() {
      super.field_a.a4().a5();
      class_460.a2();
      return this.field_a;
   }

   public boolean c() {
      this.field_a = System.currentTimeMillis();
      return super.c();
   }
}
