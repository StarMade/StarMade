import java.io.DataOutputStream;

public interface class_69 {

   void writeToTag(DataOutputStream var1);

   byte getFactoryId();
}
