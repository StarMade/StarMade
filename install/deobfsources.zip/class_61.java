import java.io.File;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class class_61 {

   private Map field_a = new HashMap();
   private List field_a = new ArrayList();
   private int field_a = 0;
   public boolean field_a = true;


   public final class_60 a(String var1, File var2) {
      try {
         String var3 = var2.getName();
         if(var1.indexOf(".") > 0) {
            var1 = var1.substring(0, var1.indexOf("."));
         }

         if(this.field_a) {
            while(Character.isDigit(var1.charAt(var1.length() - 1))) {
               var1 = var1.substring(0, var1.length() - 1);
            }
         }

         var1 = var1.replaceAll("/", ".");
         if(!this.field_a.containsKey(var1)) {
            this.field_a.put(var1, new ArrayList());
         }

         class_60 var5 = new class_60(var3, var2.toURI().toURL());
         ((ArrayList)this.field_a.get(var1)).add(var5);
         this.field_a.add(var5);
         ++this.field_a;
         return var5;
      } catch (MalformedURLException var4) {
         var4.printStackTrace();
         throw new RuntimeException(var4);
      }
   }

   public final class_60 a1(String var1) {
      List var2;
      return (var2 = (List)this.field_a.get(var1)) == null?null:(class_60)var2.get(0);
   }
}
