import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Observer;
import java.util.Set;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import javax.vecmath.Vector3f;
import javax.vecmath.Vector4f;
import org.lwjgl.BufferUtils;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.controller.elements.ParticleHandler;
import org.schema.game.common.crashreporter.CrashReporter;
import org.schema.game.server.data.PlayerNotFountException;
import org.schema.schine.network.ChatSystem;
import org.schema.schine.network.client.ClientState;
import org.schema.schine.network.objects.Sendable;
import org.schema.schine.network.server.ServerMessage;

public class class_371 extends ClientState implements class_361, class_706, class_672, ParticleHandler, class_1070, class_1041, class_1405 {

   public static final String field_a = "." + File.separator + "client-database" + File.separator;
   public static final String field_b = field_a + File.separator + "DATA" + File.separator;
   private float field_a;
   private class_1417 field_a;
   private class_227 field_a;
   private class_51 field_a;
   private class_927 field_a;
   private class_307 field_a;
   private class_43 field_a;
   private class_24 field_a;
   private Map field_a = new HashMap();
   private final ArrayList field_a = new ArrayList();
   private final ArrayList field_b = new ArrayList();
   private final ArrayList field_c = new ArrayList();
   private final ArrayList field_d = new ArrayList();
   private final ArrayList field_e = new ArrayList();
   private final class_725 field_a = new class_725("CLIENT");
   private byte[] field_b = new byte[1048576];
   private ByteBuffer field_a = BufferUtils.createByteBuffer(1048576);
   private class_788 field_a;
   private long field_d;
   public static long field_a;
   public static long field_b;
   public static long field_c;
   public static int field_a;
   public static int field_b;
   public static int field_c;
   public static int field_d;
   public static int field_e;
   private final ArrayList field_f = new ArrayList();
   public static int field_f;
   public static int field_g;
   private class_743 field_a;
   private class_744 field_a;
   private class_801 field_a;
   private class_746 field_a;
   private ChatSystem field_a;
   private class_880 field_a = new class_880(this);
   private String field_e;
   private boolean field_a;
   private class_904 field_a = null;
   private final HashSet field_a = new HashSet();
   private final HashSet field_b = new HashSet();
   private final HashSet field_c = new HashSet();
   private final HashSet field_d = new HashSet();
   private static final String[] field_a = new String[]{"//", "/"};
   public static final byte[] field_a = new byte[1048576];
   public static Deflater field_a;
   public static Inflater field_a;
   public static int field_h;
   public static class_371 field_a;
   private static byte[] field_c;
   public static int field_i;
   public static int field_j;
   public static int field_k;
   private boolean field_b = false;
   private boolean field_c;
   private boolean field_d;
   private Integer field_a = Integer.valueOf(-2);
   private class_47 field_a = new class_47(-1, -1, -1);
   private int field_l = -1;
   private class_7 field_a;
   private class_739 field_a;
   private boolean field_e;
   private boolean field_f;
   private final ArrayList field_g = new ArrayList();
   private final class_991 field_a = new class_991("tutorialAIState", this);
   private final Int2ObjectOpenHashMap field_a = new Int2ObjectOpenHashMap();
   private final ObjectArrayList field_a = new ObjectArrayList();
   private String field_f;
   private String field_g;
   public String field_c;
   public String field_d;
   // $FF: synthetic field
   private static boolean field_g = !ct.class.desiredAssertionStatus();


   public class_371() {
      field_a = this;
   }

   public synchronized void addObserver(Observer var1) {
      super.addObserver(var1);
   }

   public void chat(ChatSystem var1, String var2, String var3, boolean var4) {
      Vector4f var5 = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);
      System.err.println("[CLINT][CHAT] Prefix: " + var3 + "; Msg: " + var2);
      if(var3.startsWith("[PM]")) {
         var5.set(0.5F, 0.5F, 1.0F, 1.0F);
      }

      if(var3.startsWith("[FACTION]")) {
         var5.set(0.5F, 1.0F, 0.5F, 1.0F);
      }

      if(var3.startsWith("[SERVER]") || var3.startsWith("[message]")) {
         var5.set(1.0F, 0.5F, 0.5F, 1.0F);
      }

      String var9;
      try {
         StringBuilder var6 = new StringBuilder();
         if(var3.length() > 0) {
            var6.append(var3).append(" ");
         }

         if(var4) {
            var6.append(this.a21((long)var1.getOwnerStateId()).getName()).append(": ");
         }

         var6.append(var2);
         var9 = var6.toString();
      } catch (PlayerNotFountException var7) {
         var9 = var3 + " unknown(" + var1.getOwnerStateId() + "): " + var2;
      }

      boolean var10 = false;
      var9 = class_40.a6(var9, 56);

      for(int var8 = 0; var8 < this.field_a.size(); ++var8) {
         ((class_377)this.field_a.get(var8)).a(var9);
      }

      this.field_c.add(0, var9);
      this.field_b.add(0, new class_1418(var9, var5));

      while(this.field_b.size() > 8) {
         this.field_b.remove(this.field_b.size() - 1);
      }

   }

   public void exit() {
      try {
         CrashReporter.a();
         return;
      } catch (IOException var4) {
         var4.printStackTrace();
      } finally {
         System.exit(0);
      }

   }

   public final void a() {
      this.field_c = true;
   }

   public final class_675 a1(short var1) {
      Map var2 = this.field_a;
      synchronized(this.field_a) {
         return (class_675)this.field_a.remove(Short.valueOf(var1));
      }
   }

   public final class_775 a2() {
      return this.field_a.a112();
   }

   public final class_746 a3() {
      return this.field_a;
   }

   public ChatSystem getChat() {
      return this.field_a;
   }

   public String[] getCommandPrefixes() {
      return field_a;
   }

   public final class_51 a4() {
      return this.field_a;
   }

   public final class_739 a5() {
      return this.field_a;
   }

   public final class_801 a6() {
      return this.field_a;
   }

   public final Int2ObjectOpenHashMap a7() {
      return this.field_a;
   }

   public final int a8() {
      if(this.field_a == null) {
         if(!field_g && this.field_a.intValue() == -2) {
            throw new AssertionError();
         } else {
            return this.field_a.intValue();
         }
      } else if(!field_g && this.field_a.c2() == -2) {
         throw new AssertionError();
      } else {
         return this.field_a.c2();
      }
   }

   public final class_670 a9() {
      Sendable var1;
      return (var1 = (Sendable)this.getLocalAndRemoteObjectContainer().getLocalObjects().get(this.field_a.c2())) != null && var1 instanceof class_670?(class_670)var1:null;
   }

   public byte[] getDataBuffer() {
      return this.field_b;
   }

   public final ArrayList a10() {
      return this.field_e;
   }

   public final class_904 a11() {
      return this.field_a;
   }

   public final class_788 a12() {
      return this.field_a;
   }

   public final class_927 a13() {
      return this.field_a;
   }

   public final class_24 a14() {
      return this.field_a;
   }

   public final class_43 a15() {
      return this.field_a;
   }

   public final float a16() {
      return this.field_a;
   }

   public final class_47 a17() {
      return this.field_a;
   }

   public final long a18() {
      return this.field_d;
   }

   public final float getMaxMsBetweenUpdates() {
      return 100.0F;
   }

   public class_7 getParticleController() {
      return this.field_a;
   }

   public final class_1417 a19() {
      return this.field_a;
   }

   public final class_744 a20() {
      return this.field_a;
   }

   private class_744 a21(long var1) {
      synchronized(this.getLocalAndRemoteObjectContainer().getLocalObjects()) {
         Iterator var4 = this.getLocalAndRemoteObjectContainer().getLocalObjects().values().iterator();

         while(var4.hasNext()) {
            Sendable var5;
            class_744 var7;
            if((var5 = (Sendable)var4.next()) instanceof class_744 && (long)(var7 = (class_744)var5).a3() == var1) {
               return var7;
            }
         }
      }

      throw new PlayerNotFountException("clientID: " + var1);
   }

   public final ArrayList b() {
      return this.field_d;
   }

   public String getPlayerName() {
      return this.field_e;
   }

   public final Map a22() {
      return this.field_a;
   }

   public final class_307 a23() {
      return this.field_a;
   }

   public final class_880 a24() {
      return this.field_a;
   }

   public final ArrayList c() {
      return this.field_f;
   }

   public final class_743 a25() {
      return this.field_a;
   }

   public final class_725 a26() {
      return this.field_a;
   }

   public float getVersion() {
      return class_1264.field_a;
   }

   public final ArrayList d() {
      return this.field_b;
   }

   public final class_227 a27() {
      return this.field_a;
   }

   public final void b1() {
      HashSet var1;
      HashSet var2;
      Sendable var5;
      Iterator var6;
      class_51 var10000;
      if(!this.field_a.isEmpty()) {
         var1 = new HashSet(this.field_a.size());
         var2 = this.field_a;
         synchronized(this.field_a) {
            var1.addAll(this.field_a);
         }

         var6 = var1.iterator();

         while(var6.hasNext()) {
            var5 = (Sendable)var6.next();
            if(this.getPrivateLocalAndRemoteObjectContainer().getLocalObjects().containsKey(var5.getId())) {
               var10000 = this.field_a;
               class_51.h();
            } else {
               this.field_a.b6(var5);
            }

            this.setChanged();
            this.notifyObservers(var5);
         }

         this.field_a.clear();
      }

      if(!this.field_b.isEmpty()) {
         var1 = new HashSet(this.field_b.size());
         var2 = this.field_b;
         synchronized(this.field_b) {
            var1.addAll(this.field_b);
         }

         var6 = var1.iterator();

         while(var6.hasNext()) {
            var5 = (Sendable)var6.next();
            if(this.getPrivateLocalAndRemoteObjectContainer().getLocalObjects().containsKey(var5.getId())) {
               var10000 = this.field_a;
               class_51.h();
            } else {
               this.field_a.a34(var5);
            }

            this.setChanged();
            this.notifyObservers(var5);
         }

         this.field_b.clear();
      }

   }

   public final void c1() {
      if(!this.field_c.isEmpty()) {
         HashSet var1 = new HashSet();
         HashSet var2 = this.field_c;
         synchronized(this.field_c) {
            var1.addAll(this.field_c);
         }

         Iterator var5 = var1.iterator();

         while(var5.hasNext()) {
            Sendable var4 = (Sendable)var5.next();
            this.setChanged();
            this.notifyObservers(var4);
         }

         this.field_c.clear();
      }

   }

   public final void d1() {
      this.field_a = Math.max(this.field_a, 0.0F);
   }

   public final boolean a28() {
      return this.field_a != null && this.field_a.field_d;
   }

   public final boolean b2() {
      return this.field_d;
   }

   public final boolean c2() {
      return this.field_c;
   }

   public final int b3() {
      return this.field_l;
   }

   public final boolean d2() {
      Set var2 = null;
      if(!this.field_e) {
         return false;
      } else {
         try {
            boolean var1;
            if((var1 = this.field_a != null && this.field_a instanceof class_735 && ((class_735)this.field_a).a().size() > 0) != this.field_b && this.field_a.a5() != null) {
               this.field_a.a5().a3(var1);
               this.field_b = var1;
            }

            if(var1) {
               var2 = ((class_735)this.field_a).a();
               this.field_a = null;
               Iterator var5 = var2.iterator();

               while(var5.hasNext()) {
                  class_739 var3;
                  if((var3 = (class_739)var5.next()).getSectorId() == this.field_a.getSectorId()) {
                     (new Vector3f(var3.getWorldTransform().origin)).sub(this.field_a.getWorldTransform().origin);
                     this.field_a = var3;
                  }
               }
            }

            return var1;
         } catch (NullPointerException var4) {
            System.err.println("EXCEPTION HAS BEEN CATCHED. CURRENT OBJECT PROBABLY BECAME NULL: " + this.field_a);
            var4.printStackTrace();
            return false;
         }
      }
   }

   public final boolean e() {
      return this.field_e;
   }

   public final boolean f() {
      return this.field_a;
   }

   public void message(String var1, Integer var2) {
      ServerMessage var4 = new ServerMessage(var1, var2.intValue());
      ArrayList var5 = this.field_f;
      synchronized(this.field_f) {
         this.field_f.add(var4);
      }
   }

   public void notifyOfAddedObject(Sendable var1) {
      SegmentController var2;
      if(var1 instanceof SegmentController && (var2 = (SegmentController)var1).getCreatorThread() == null) {
         var2.startCreatorThread();
      }

      HashSet var4 = this.field_a;
      synchronized(this.field_a) {
         this.field_a.add(var1);
      }
   }

   public void notifyOfRemovedObject(Sendable var1) {
      HashSet var2 = this.field_b;
      synchronized(this.field_b) {
         this.field_b.add(var1);
      }
   }

   public void needsNotify(Sendable var1) {
      HashSet var2 = this.field_c;
      synchronized(this.field_c) {
         this.field_c.add(var1);
      }
   }

   public final void e1() {
      this.setChanged();
      this.notifyObservers("CATALOG_UPDATE");
   }

   public String onAutoComplete(String var1, class_1077 var2, String var3) {
      return this.field_a.a7(var1, var2, var3);
   }

   public void onStringCommand(String var1, class_1077 var2, String var3) {
      this.field_a.a11(var1, var2, var3);
   }

   public final void f1() {
      this.field_c = false;
   }

   public final void a29(class_746 var1) {
      this.field_a = var1;
   }

   public final void a30(ChatSystem var1) {
      this.field_a = var1;
   }

   public final void a31(class_51 var1) {
      this.field_a = var1;
   }

   public final void a32(class_801 var1) {
      this.field_a = var1;
   }

   public final void a33(boolean var1) {
      this.field_d = var1;
   }

   public final void a34(int var1) {
      this.field_l = var1;
   }

   public final void a35(class_904 var1) {
      this.field_a = var1;
   }

   public final void a36(class_788 var1) {
      this.field_a = var1;
   }

   public final void a37(class_927 var1) {
      this.field_a = var1;
   }

   public final void a38(class_24 var1) {
      this.field_a = var1;
   }

   public final void a39(class_43 var1) {
      this.field_a = var1;
   }

   public final void g() {
      this.field_a = 0.0F;
   }

   public final void a40(Integer var1) {
      System.err.println("SET INITIAL SECTOR ID TO " + var1);
      if(!field_g && var1.intValue() == -2) {
         throw new AssertionError();
      } else {
         this.field_a = var1;
      }
   }

   public final void a41(long var1) {
      this.field_d = var1;
   }

   public final void a42(class_7 var1) {
      this.field_a = var1;
   }

   public final void a43(class_1417 var1) {
      this.field_a = var1;
   }

   public final void a44(class_744 var1) {
      this.field_a = var1;
      this.field_f = true;
   }

   public void setPlayerName(String var1) {
      this.field_e = var1;
   }

   public final void b4(boolean var1) {
      if(this.field_e && !var1 && this.field_a.a5() != null) {
         this.field_a.a5().d();
      }

      this.field_e = var1;
   }

   public final class_769 a45() {
      return this.field_a.a51();
   }

   public final void a46(class_307 var1) {
      this.field_a = var1;
   }

   public final void a47(class_743 var1) {
      this.field_a = var1;
   }

   public final void c3(boolean var1) {
      this.field_a = var1;
   }

   public final void a48(class_227 var1) {
      this.field_a = var1;
   }

   public final void a49(class_704 var1, Object var2, Object var3) {
      ArrayList var5 = this.field_g;
      synchronized(this.field_g) {
         this.field_g.add(var1);
      }
   }

   public List getGeneralChatLog() {
      return this.field_c;
   }

   public final boolean g1() {
      return this.field_f;
   }

   public final void h() {
      this.field_f = false;
   }

   public final void i() {
      if(!this.field_g.isEmpty()) {
         while(!this.field_g.isEmpty()) {
            ArrayList var1 = this.field_g;
            synchronized(this.field_g) {
               class_704 var2 = (class_704)this.field_g.remove(0);
               this.notifyObservers(var2);
            }
         }
      }

   }

   public boolean onChatTextEnterHook(ChatSystem var1, String var2, boolean var3) {
      class_777 var5;
      if(var2.startsWith("/f ") && (var5 = this.field_a.a51().a146(this.field_a.h1())) != null) {
         var2 = var2.substring(3);
         Iterator var6 = var5.a154().keySet().iterator();

         while(var6.hasNext()) {
            String var4;
            if(!(var4 = (String)var6.next()).equals(this.field_a.getName())) {
               var1.wisper(var4, var2, false, (byte)1);
            }
         }

         var1.addToVisibleChat(var2, "[FACTION][" + this.field_a.getName() + "] ", false);
         return true;
      } else {
         return false;
      }
   }

   public final class_777 a50() {
      return this.field_a.a51().a146(this.field_a.h1());
   }

   public final String a51() {
      class_777 var1;
      return (var1 = this.a50()) == null?"neutral":var1.a();
   }

   public final class_991 a52() {
      return this.field_a;
   }

   public final String b5() {
      return "[PHYSICS][CLIENT] WARNING: PHYSICS SYNC IN DANGER";
   }

   public final class_781 a53() {
      return this.field_a.a53();
   }

   public final HashSet a54() {
      return this.field_d;
   }

   public ByteBuffer getDataByteBuffer() {
      return this.field_a;
   }

   public final ArrayList e2() {
      return this.field_a;
   }

   public static byte[] a55(int var0) {
      if(field_c.length < var0) {
         int var1;
         for(var1 = field_c.length; var1 < var0; var1 <<= 1) {
            ;
         }

         field_c = new byte[var1];
      }

      return field_c;
   }

   public final ObjectArrayList a56() {
      return this.field_a;
   }

   public final String c4() {
      return "CLIENT: " + this.toString();
   }

   public final float b6() {
      return this.field_a != null?this.field_a.b11():0.09F;
   }

   public final float c5() {
      return this.field_a != null?this.field_a.c3():0.09F;
   }

   public final void a57(String var1) {
      this.field_g = var1;
   }

   public final void b7(String var1) {
      this.field_f = var1;
   }

   public final String d3() {
      return this.field_g;
   }

   public final String e3() {
      return this.field_f;
   }

   static {
      new ByteArrayOutputStream(102400);
      field_a = new Deflater();
      field_a = new Inflater();
      field_c = new byte[16384];
   }
}
