import javax.vecmath.Vector3f;
import org.lwjgl.input.Keyboard;

public final class class_202 extends class_201 implements class_952 {

   public final void handleKeyEvent() {
      class_47 var1;
      (var1 = new class_47(this.field_a)).a1(this.field_a.a());
      if(!this.field_a.getSegmentBuffer().b1(var1)) {
         while(this.field_a.a4() > 0.0F && !this.field_a.getSegmentBuffer().b1(var1)) {
            this.field_a.field_a /= 2;
            this.field_a.field_b /= 2;
            this.field_a.field_c /= 2;
            var1.b1(this.field_a);
            var1.a1(this.field_a.a());
            System.err.println("[CAM] SEARCHING anchor");
         }
      } else {
         boolean var2 = true;
         Vector3f var3 = new Vector3f((float)var1.field_a, (float)var1.field_b, (float)var1.field_c);
         if(Keyboard.getEventKeyState()) {
            if(!Keyboard.isKeyDown(42)) {
               if(Keyboard.getEventKey() == class_367.field_a.a5()) {
                  var3.sub(this.field_a.getCamLeftLocal());
               } else if(Keyboard.getEventKey() == class_367.field_b.a5()) {
                  var3.add(this.field_a.getCamLeftLocal());
               } else if(Keyboard.getEventKey() == class_367.field_c.a5()) {
                  var3.add(this.field_a.getCamForwLocal());
               } else if(Keyboard.getEventKey() == class_367.field_d.a5()) {
                  var3.sub(this.field_a.getCamForwLocal());
               } else if(Keyboard.getEventKey() == class_367.field_e.a5()) {
                  var3.add(this.field_a.getCamUpLocal());
               } else if(Keyboard.getEventKey() == class_367.field_f.a5()) {
                  var3.sub(this.field_a.getCamUpLocal());
               } else {
                  var2 = false;
               }
            } else {
               var2 = false;
            }

            var1.b(Math.round(var3.field_x), Math.round(var3.field_y), Math.round(var3.field_z));
            if(var2) {
               if(this.field_a.getSegmentBuffer().b1(var1)) {
                  var1.c1(this.field_a.a());
                  System.err.println("EXISTS!. pos mod set to " + var1);
                  this.field_a.b1(var1);
                  return;
               }

               System.err.println("NOT EXISTS!. pos mod NOT set to " + var1);
            }
         }
      }

   }
}
