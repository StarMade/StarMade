import org.schema.schine.network.client.ClientState;

public final class class_259 extends class_196 {

   private class_930 field_a;


   public class_259(ClientState var1, class_1410 var2, Object var3, Object var4, class_1075 var5) {
      super(var1, var2, var3, var4);
      this.field_a = new class_930(var1);
      this.field_a.field_b = "";
      this.field_a.field_a = var5;
   }

   public final void a2() {
      super.a2();
      this.field_a.a2();
   }

   public final void c() {
      super.c();
      this.field_a.c();
      this.field_a.a9(this.field_a);
      this.field_a.a165(55.0F, 181.0F, 0.0F);
   }
}
