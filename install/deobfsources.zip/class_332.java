import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import javax.vecmath.Vector3f;
import org.lwjgl.input.Keyboard;
import org.schema.common.FastMath;
import org.schema.game.common.data.element.ElementDocking;
import org.schema.schine.graphicsengine.camera.Camera;
import org.schema.schine.network.objects.Sendable;

public class class_332 extends class_15 {

   private Camera field_a;
   private float field_a = 0.0F;
   private float field_b = 0.0F;
   private class_801 field_a;
   private boolean field_d = false;
   private int field_a = -1;
   private boolean field_e;
   private class_47 field_a;
   // $FF: synthetic field
   private static boolean field_f = !bl.class.desiredAssertionStatus();


   public class_332(class_328 var1) {
      super(var1.a6());
      new class_752();
      new Vector3f();
      this.field_e = true;
      this.field_a = new class_47();
   }

   public static float a39() {
      return 5.0F;
   }

   private class_800 a40() {
      return this.a6().a14().field_a.field_a.field_a.a51().a40();
   }

   public final class_47 a41(class_47 var1) {
      return this.a6().a14().field_a.field_a.field_a.a51().a40().a2(var1);
   }

   public final class_743 a42() {
      return this.a6().a25();
   }

   public final class_801 a43() {
      return this.field_a;
   }

   public final float b4() {
      return this.field_a;
   }

   public void handleKeyEvent() {
      if(Keyboard.getEventKeyState()) {
         if(Keyboard.getEventKey() >= 2 && Keyboard.getEventKey() <= 11 && !Keyboard.isKeyDown(29)) {
            int var2 = Keyboard.getEventKey() - 2;
            this.a6().a20().d6(var2);
            this.field_e = true;
         }

         int var1;
         class_47 var7;
         class_800 var14;
         if(Keyboard.isKeyDown(29) && !this.a6().a25().getDockingController().a5().isEmpty() && (var1 = Keyboard.getEventKey() - 2) < this.a6().a25().getDockingController().a5().size()) {
            Iterator var9 = this.a6().a25().getDockingController().a5().iterator();
            ElementDocking var3 = null;

            for(int var4 = 0; var4 <= var1; ++var4) {
               var3 = (ElementDocking)var9.next();
            }

            (var14 = this.a40()).a7().a15();
            var7 = this.a40().a2(new class_47());
            System.err.println("EXIT SHIP FROM EXTRYPOINT " + var7);
            this.a6().a14().field_a.field_a.field_a.a51().a16(var3.from);
            this.a6().a4().a14((class_365)var14.a7().a15(), (class_365)this.a40().a7().a15(), var14.a2(new class_47()), this.a40().a2(new class_47()), true);
            this.field_a = -1;
         }

         if(Keyboard.getEventKey() == class_367.field_C.a5() && this.a6().a25().getDockingController().a4() != null) {
            var7 = null;
            class_443 var10 = this.a6().a14().field_a.field_a.field_a;

            try {
               (var14 = this.a40()).a7().a15();
               var7 = this.a40().a2(new class_47());
               System.err.println("EXIT SHIP FROM EXTRYPOINT " + var7);
               class_800 var12 = this.a6().a25().getDockingController().a4().field_to.a7().a15().getSegmentBuffer().a9(class_743.field_a, false);
               var10.a51().a16(var12);
               this.a6().a4().a14((class_365)var14.a7().a15(), (class_365)this.a40().a7().a15(), var14.a2(new class_47()), this.a40().a2(new class_47()), true);
               this.field_a = -1;
            } catch (IOException var5) {
               var5.printStackTrace();
            } catch (InterruptedException var6) {
               var6.printStackTrace();
            }
         }

         ArrayList var8;
         if(!(var8 = this.a6().a25().a96().getCockpits()).isEmpty() && this.a40().a9() == 1) {
            class_47 var11;
            class_47 var13;
            if(Keyboard.getEventKey() == class_367.field_E.a5()) {
               if(this.field_a == 0) {
                  this.field_a = -1;
                  (var13 = this.a6().a14().field_a.field_a.field_a.a51().a40().a2(new class_47())).c1(class_743.field_a);
                  ((class_201)this.field_a.a184()).a85().b1(var13);
                  return;
               }

               if(this.field_a < 0) {
                  this.field_a = var8.size() - 1;
               } else {
                  this.field_a = FastMath.b1(this.field_a - 1, var8.size());
               }

               (var11 = new class_47((class_47)var8.get(this.field_a))).c1(class_743.field_a);
               ((class_201)this.field_a.a184()).a85().b1(var11);
               return;
            }

            if(Keyboard.getEventKey() == class_367.field_D.a5()) {
               if(this.field_a + 1 >= var8.size()) {
                  this.field_a = -1;
                  (var13 = this.a6().a14().field_a.field_a.field_a.a51().a40().a2(new class_47())).c1(class_743.field_a);
                  ((class_201)this.field_a.a184()).a85().b1(var13);
                  return;
               }

               if(this.field_a < 0) {
                  this.field_a = 0;
               } else {
                  this.field_a = FastMath.b1(this.field_a + 1, var8.size());
               }

               (var11 = new class_47((class_47)var8.get(this.field_a))).c1(class_743.field_a);
               ((class_201)this.field_a.a184()).a85().b1(var11);
            }
         }
      }

   }

   public final void a12(class_941 var1) {
      if(class_943.field_X.a4().equals("SLOTS") && !Keyboard.isKeyDown(42)) {
         int var2 = FastMath.b1(this.a6().a20().d() + (var1.field_f > 0?1:(var1.field_f < 0?-1:0)), 10);
         this.a6().a20().d6(var2);
      }

   }

   public final boolean a1() {
      return this.field_d;
   }

   public final void b2(boolean var1) {
      class_342 var2 = this.a6().a14().field_a.field_a.field_a.a51();
      if(this.a6().a20() != null) {
         this.a6().a20().a55((class_801)null);
      }

      if(var1) {
         this.field_e = true;
         if(this.field_a != null && ((class_958)this.field_a.a184()).a140() == this.a6().a25()) {
            if(this.field_a != null) {
               ((class_191)this.field_a).a78(class_967.a1());
            }
         } else {
            if(!field_f && this.a6().a25() == null) {
               throw new AssertionError("SHIP NOT FOUND ");
            }

            this.field_a = new class_191(var2.a45(), class_967.a1(), this.a40());
            this.field_a.a(0.0F);
            if(!this.a41(new class_47()).equals(class_743.field_a)) {
               ((class_191)this.field_a).field_b = true;
            } else {
               ((class_191)this.field_a).field_b = false;
            }
         }

         class_47 var3;
         if(this.field_a >= 0 && this.field_a < this.a6().a25().a96().getCockpits().size()) {
            (var3 = new class_47((class_47)this.a6().a25().a96().getCockpits().get(this.field_a))).c1(class_743.field_a);
            ((class_201)this.field_a.a184()).a85().b1(var3);
         } else {
            this.field_a = -1;
            (var3 = var2.a40().a2(new class_47())).c1(class_743.field_a);
            ((class_201)this.field_a.a184()).a85().b1(var3);
         }

         this.a6().a4().c2("BuildMode");
         this.a6().a4().a26("FlightMode", "Flight Mode", "(press " + class_367.field_r.b1() + " to switch to BUILD MODE; press " + class_367.field_v.b1() + " to exit structure)");
         class_967.a9(this.field_a);
      } else {
         this.field_a = null;
      }

      super.b2(var1);
   }

   private class_801 b5() {
      if(this.a6().a23() != null && this.a6().a23().a26() != null) {
         class_1381 var1 = this.a6().a23().a26();
         Vector3f var2 = new Vector3f();
         float var3 = 0.0F;
         float var4 = -1.0F;
         class_801 var5 = null;
         Vector3f var6 = var1.a1(new Vector3f());
         synchronized(this.a6().getLocalAndRemoteObjectContainer().getLocalObjects()) {
            Iterator var8 = this.a6().getLocalAndRemoteObjectContainer().getLocalObjects().values().iterator();

            while(var8.hasNext()) {
               Sendable var9;
               class_801 var14;
               if((var9 = (Sendable)var8.next()) instanceof class_801 && (var14 = (class_801)var9) != this.a6().a6()) {
                  var2.set(var14.getWorldTransform().origin);
                  if(this.a6().a6() != null) {
                     var2.sub(this.a6().a6().getWorldTransform().origin);
                  } else {
                     var2.sub(class_967.a1().a83());
                  }

                  Vector3f var10 = var1.a2(var14.getWorldTransformClient().origin, new Vector3f(), true);
                  Vector3f var11 = new Vector3f();
                  Vector3f var12 = new Vector3f();
                  var11.sub(var10, var6);
                  var12.sub(this.a6().a25().getWorldTransform().origin, var14.getWorldTransformClient().origin);
                  if(var11.length() < 90.0F && (var5 == null || var11.length() < var3 && var12.length() < var4)) {
                     var5 = var14;
                     var3 = var11.length();
                     var4 = var12.length();
                  }
               }
            }

            return var5;
         }
      } else {
         return null;
      }
   }

   public final void a15(class_935 var1) {
      super.a15(var1);
      class_332 var2 = this;
      if(this.field_e) {
         try {
            class_359 var3;
            if((var3 = var2.a6().a20().a118(var2.a6().a25())) != null) {
               class_47 var7;
               if((var7 = var3.a17(var2.a6().a20().d())) != null) {
                  class_800 var8;
                  if((var8 = var2.a6().a25().getSegmentBuffer().a9(var7, true)) != null) {
                     var2.field_d = var8.a9() == 54;
                  }
               } else {
                  var2.field_d = false;
               }

               var2.field_e = false;
            }
         } catch (Exception var4) {
            ;
         }
      }

      if(class_367.field_V.a6() && class_967.a1() instanceof class_191) {
         ((class_191)class_967.a1()).b();
      }

      class_1008.field_a = true;
      if(this.field_a >= 0) {
         this.field_a.b1(((class_201)this.field_a.a184()).a85());
         this.field_a.a1(class_743.field_a);
         if(!this.a6().a25().a96().getCockpits().contains(this.field_a)) {
            this.field_a = -1;
            class_47 var5;
            (var5 = this.a6().a14().field_a.field_a.field_a.a51().a40().a2(new class_47())).c1(class_743.field_a);
            ((class_201)this.field_a.a184()).a85().b1(var5);
         }

         if(this.field_a >= 0) {
            if(!this.a6().a20().a117().cockpit.getVector().equals(this.field_a)) {
               this.a6().a20().a117().cockpit.forceClientUpdates();
               this.a6().a20().a117().cockpit.set(this.field_a);
            }
         } else if(!this.a6().a20().a117().cockpit.getVector().equals(class_743.field_a)) {
            this.a6().a20().a117().cockpit.forceClientUpdates();
            this.a6().a20().a117().cockpit.set(class_743.field_a);
         }
      }

      if(this.field_d) {
         if(this.a6().a20().a110() != null) {
            this.field_b += var1.a();
         }

         if(this.field_b <= 0.0F || this.field_b >= 3.0F) {
            this.field_b = 0.0F;
            class_801 var6 = this.b5();
            if(this.field_a != var6) {
               this.field_a = var6;
               this.field_a = 0.0F;
               this.a6().a20().a55((class_801)null);
               return;
            }

            if(this.field_a != null) {
               this.field_a += var1.a();
               if(this.field_a > 5.0F) {
                  this.a6().a20().a55(this.field_a);
               }
            }

            return;
         }

         if(this.b5() == this.a6().a20().a110()) {
            this.field_b = 0.0F;
            return;
         }
      } else {
         this.a6().a20().a55((class_801)null);
         this.field_a = 0.0F;
         this.field_b = 0.0F;
      }

   }

}
