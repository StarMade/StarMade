import org.schema.game.common.controller.EditableSendableSegmentController;

final class class_239 {

   class_229 field_a;
   EditableSendableSegmentController field_a;


   public class_239(class_229 var1, EditableSendableSegmentController var2) {
      this.field_a = var1;
      this.field_a = var2;
   }
}
