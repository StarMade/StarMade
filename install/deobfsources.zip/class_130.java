import javax.vecmath.Vector4f;
import org.schema.schine.graphicsengine.core.GlUtil;

public final class class_130 extends class_964 {

   private class_970 field_a;
   private class_970 field_b;
   private class_970 field_c;
   private class_970 field_d;
   private class_1431 field_a = new class_1431();
   private float field_a = 32.0F;
   private boolean field_a;
   private class_970 field_e;
   private class_970 field_f;


   public class_130(class_371 var1) {
      super(var1);
      String var2 = "powerbar-1x4-gui-";
      this.field_b = new class_970(class_967.a2().a5(var2), this.a24());
      this.field_b.a_2(0);
      this.field_b.a165(66.0F, -11.0F, 0.0F);
      this.field_a = new class_970(class_967.a2().a5(var2), this.a24());
      this.field_a.a_2(2);
      this.field_a.a165(66.0F, -11.0F, 0.0F);
      this.field_e = new class_970(class_967.a2().a5(var2), this.a24());
      this.field_e.a_2(2);
      this.field_e.a165(66.0F, -11.0F, 0.0F);
      this.field_f = new class_970(class_967.a2().a5(var2), this.a24());
      this.field_f.a_2(2);
      this.field_f.a165(66.0F, -11.0F, 0.0F);
      this.field_d = new class_970(class_967.a2().a5(var2), this.a24());
      this.field_d.a_2(1);
      this.field_d.a165(549.0F, -11.0F, 0.0F);
      this.field_c = new class_970(class_967.a2().a5(var2), this.a24());
      this.field_c.a_2(3);
      this.field_c.a165(549.0F, -11.0F, 0.0F);
      if(class_967.a2().a5(var2).a63() == null) {
         class_967.a2().a5(var2).c7(new Vector4f(1.0F, 1.0F, 1.0F, 1.0F));
      }

   }

   public final void a2() {}

   public final void b() {
      GlUtil.d1();
      this.r();
      class_371 var1 = (class_371)this.a24();
      this.field_a.a151().a63().field_w = 0.0F;
      this.field_c.a151().a63().field_w = 0.0F;
      this.field_a.b();
      this.field_b.a151().a63().set(1.0F, 1.0F, 1.0F, 1.0F);
      float var2 = 1.0F - var1.a20().a14() / 300.0F;
      org.lwjgl.util.vector.Vector4f var3 = new org.lwjgl.util.vector.Vector4f(this.field_b.a83().field_x + var2 * 402.0F, this.field_b.a83().field_x + 402.0F, this.field_b.a83().field_y, this.field_b.a83().field_y + this.field_b.a3());
      this.field_b.a147(var3);
      if(var1.a25() != null) {
         class_743 var6 = var1.a25();
         this.field_e.a151().a63().set(1.0F, 1.0F, 1.0F, 1.0F);
         float var7 = (float)(1.0D - var6.a96().getShieldManager().getShields() / (double)var6.a96().getShieldManager().getShieldCapabilityHP());
         org.lwjgl.util.vector.Vector4f var4 = new org.lwjgl.util.vector.Vector4f(this.field_e.a83().field_x + var7 * 402.0F, this.field_e.a83().field_x + 402.0F, this.field_e.a83().field_y, this.field_e.a83().field_y + this.field_e.a3());
         this.field_e.a147(var4);
         this.field_c.a151().a63().field_w = 0.0F;
         if(this.field_a != var6.a96().getPowerAddOn().isInRecovery()) {
            this.field_a = var6.a96().getPowerAddOn().isInRecovery();
         }

         if(this.field_a || var6.a96().getPowerAddOn().getPower() <= 0.0D) {
            this.field_c.a151().a63().field_x = 1.0F;
            this.field_c.a151().a63().field_y = 0.0F;
            this.field_c.a151().a63().field_z = 0.0F;
            this.field_c.a151().a63().field_w = this.field_a.a1() * 0.3F;
         }

         this.field_c.b();
         this.field_d.a151().a63().set(1.0F, 1.0F, 1.0F, 1.0F);
         class_970 var10000 = this.field_d;
         float var10001 = (float)var6.a96().getPowerAddOn().getPower() * 0.785F;
         var7 = (float)var6.a96().getPowerAddOn().getMaxPower();
         var2 = var10001;
         class_970 var5 = var10000;
         var2 /= var7;
         var5.field_a.set(var5.a83().field_x, var5.a83().field_x + var2 * var5.b1(), var5.a83().field_y, var5.a83().field_y + 1.0F * var5.a3());
         var5.a147(var5.field_a);
      }

      GlUtil.c2();
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1() * 2.0F + this.field_a;
   }

   public final void c() {
      this.field_a.c();
      this.field_b.c();
      this.field_c.c();
      this.field_d.c();
   }

   public final void a12(class_935 var1) {
      this.field_a.a(var1);
   }
}
