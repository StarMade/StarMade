import java.util.Observable;
import java.util.Observer;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public final class class_278 extends class_964 implements Observer {

   private class_160 field_a;
   private boolean field_a;
   private class_940 field_a;


   public class_278(ClientState var1) {
      super(var1);
   }

   public final void a2() {}

   public final void b() {
      if(((Boolean)((class_371)this.a24()).a20().a117().isAdminClient.get()).booleanValue()) {
         if(this.field_a) {
            this.field_a.field_a = true;
            this.field_a = false;
         }

         this.k();
      } else {
         GlUtil.d1();
         this.r();
         this.field_a.b();
         GlUtil.c2();
      }
   }

   public final void c() {
      this.field_a = new class_276(this.a24());
      this.field_a.c();
      this.a9(this.field_a);
      this.field_a = new class_940(1, 1, this.a24());
      this.field_a.a137("Permission denied! You are not an admin");
      this.field_a.c();
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public final void update(Observable var1, Object var2) {
      this.field_a = true;
   }
}
