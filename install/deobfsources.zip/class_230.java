import java.util.Comparator;

public final class class_230 implements Comparator {

   private boolean field_a;


   public class_230(boolean var1) {
      this.field_a = var1;
   }
}
