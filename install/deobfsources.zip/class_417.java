import org.schema.game.common.data.element.ElementKeyMap;

final class class_417 implements class_479 {

   // $FF: synthetic field
   private class_431 field_a;


   class_417(class_431 var1) {
      this.field_a = var1;
      super();
   }

   public final void a(class_47 var1, class_47 var2, short var3) {
      if(var3 != 0 && ElementKeyMap.getInfo(var3).controlling.size() > 0) {
         this.field_a.a6().a4().b1("Warning:\nController blocks placed\nin astronaut-mode have\nto be connected manually\n(use \'" + class_367.field_z.b1() + "\'(select) and \'" + class_367.field_A.b1() + "\'(connect))");
      }

   }
}
