import com.bulletphysics.linearmath.Transform;
import java.util.Observable;
import javax.vecmath.Vector3f;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.controller.elements.ShieldContainerInterface;
import org.schema.game.common.controller.elements.shield.ShieldCollectionManager;

public final class class_222 extends Observable implements class_923 {

   SegmentController field_a;
   private ShieldCollectionManager field_a;
   private Vector3f field_a = new Vector3f();
   private class_838 field_a;
   private Transform field_a = new Transform();
   private Transform field_b = new Transform();
   private float field_a;


   public class_222(class_802 var1) {
      this.a2(var1);
      this.field_a = new class_838();
   }

   public final void a4(Vector3f var1) {
      if(class_943.field_s.b1()) {
         this.field_a.set(var1);
         this.field_a.getWorldTransformInverse().transform(this.field_a);
         this.field_a.a3(this.field_a);
         if(this.field_a.a4() > 0) {
            this.setChanged();
            this.notifyObservers(Boolean.valueOf(true));
         }

      }
   }

   public final void a() {}

   public final void b() {
      if(class_943.field_s.b1()) {
         ;
      }
   }

   public final void c() {
      if(class_943.field_s.b1()) {
         ;
      }
   }

   public final void a2(class_802 var1) {
      this.field_a = var1.a1();
      this.field_a = ((ShieldContainerInterface)var1.a()).getShieldManager();
   }

   public final void a1(class_935 var1) {
      if(class_943.field_s.b1()) {
         this.field_a.a5(var1);
         if(this.field_a.a4() <= 0) {
            this.setChanged();
            this.notifyObservers(Boolean.valueOf(false));
         }

         this.field_a = (float)this.field_a.getShields() / (float)this.field_a.getShieldCapabilityHP();
      }
   }

   public final boolean a5() {
      return this.field_a.a4() > 0;
   }

   public final class_838 a6() {
      return this.field_a;
   }

   public final float a7() {
      return this.field_a;
   }

   public final void d() {
      this.field_a = null;
      this.field_a = null;
      this.field_a.set(0.0F, 0.0F, 0.0F);
      this.field_a.setIdentity();
      this.field_b.setIdentity();
      this.field_a.a2();
   }
}
