import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.schema.schine.graphicsengine.core.GlUtil;

public final class class_305 extends class_950 implements class_1368 {

   private class_371 field_a;
   private class_1382 field_a;
   private class_1376 field_a;
   private boolean field_c;


   public class_305(class_7 var1) {
      super(var1, (byte)0);
      this.field_a = (class_371)var1.a3();
      super.field_b = false;
   }

   public final void b() {
      if(!this.field_c) {
         this.c();
      }

      field_a = Keyboard.isKeyDown(79);
      if(super.field_a.b1() > 0) {
         if(!field_a) {
            this.field_a.field_a = this;
            this.field_a.b();
         }

         super.b();
         if(!field_a) {
            this.field_a.d();
         }

      }
   }

   public final void d() {
      GL11.glBindTexture(3553, 0);
   }

   public final void c() {
      this.field_a = class_967.a2().a5("starSprite");
      this.field_a = class_1379.field_b;
      super.c();
      this.field_c = true;
   }

   public final String toString() {
      return "ProjectileDrawerVBO [state=" + this.field_a + ", count=" + super.field_a.b1() + "]";
   }

   public final void a13(class_1376 var1) {
      GL13.glActiveTexture('\u84c0');
      GL11.glBindTexture(3553, this.field_a.a157().a1().field_c);
      GlUtil.a35(var1, "noiseVolume", 0);
   }
}
