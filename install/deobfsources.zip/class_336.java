
public final class class_336 extends class_11 {

   private final class_181 field_a;


   public class_336(class_371 var1, class_340 var2) {
      super(var1);
      this.field_a = new class_181(super.field_a, var2, this);
      this.field_a.c();
   }

   public final boolean a1() {
      return false;
   }

   public final void handleKeyEvent() {}

   public final class_964 a3() {
      return this.field_a;
   }

   public final void a2() {
      super.field_a.a14().field_a.field_a.field_a.a13(500);
      super.field_a.a14().field_a.field_a.field_a.e2(false);
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.a()) {
         if(var1.b19().equals("OK")) {
            super.field_a.a14().field_a.field_a.field_a.field_a = this.field_a.field_a;
            super.field_a.a27().a92().a18().a23().e();
            this.d();
            return;
         }

         if(var1.b19().equals("CANCEL") || var1.b19().equals("X")) {
            this.d();
         }
      }

   }
}
