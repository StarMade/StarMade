import it.unimi.dsi.fastutil.io.FastByteArrayInputStream;
import it.unimi.dsi.fastutil.io.FastByteArrayOutputStream;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

public final class class_75 {

   private byte[] field_a = new byte[5242880];
   private byte[] field_b;


   public class_75() {
      new FastByteArrayInputStream(this.field_a);
      this.field_b = new byte[5242880];
      new FastByteArrayOutputStream(this.field_b);
      new Deflater();
      new Inflater();
   }
}
