
final class class_188 implements class_1410 {

   // $FF: synthetic field
   private class_160 field_a;


   class_188(class_160 var1) {
      this.field_a = var1;
      super();
   }

   public final boolean a1() {
      return false;
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.a()) {
         this.field_a.a51(class_180.field_d);
      }

   }
}
