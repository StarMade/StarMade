
public final class class_459 extends class_15 implements class_1410 {

   public class_461 field_a = new class_461();
   public class_461 field_b = new class_461();
   public class_461 field_c = new class_461();
   public boolean field_d;


   public class_459(class_371 var1) {
      super(var1);
      new class_461();
      this.field_d = true;
   }

   public final void a(class_964 var1, class_941 var2) {}

   public final int a28() {
      return this.field_c.field_a;
   }

   public final int b6() {
      return this.field_b.field_a;
   }

   public final class_47 a35() {
      return new class_47(this.field_a.field_a, this.field_b.field_a, this.field_c.field_a);
   }

   public final int c4() {
      return this.field_a.field_a;
   }

   public final boolean a1() {
      return false;
   }
}
