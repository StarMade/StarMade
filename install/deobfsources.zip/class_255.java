import org.schema.schine.network.client.ClientState;

public final class class_255 extends class_964 implements class_1410 {

   private class_860 field_a;


   public class_255(ClientState var1) {
      super(var1);
   }

   public final void a2() {}

   public final void b() {
      this.k();
   }

   public final void c() {
      this.field_a = new class_860(this.a24(), this);
      this.field_a.c();
      this.a9(this.field_a);
   }

   public final float a3() {
      return 0.0F;
   }

   public final float b1() {
      return 0.0F;
   }

   public final void a1(class_964 var1, class_941 var2) {
      class_777 var3 = null;
      if(var2.field_a && var2.field_a == 0) {
         System.err.println("Callback " + var1 + "; " + var1.field_a);
         int var6;
         if(var1.field_a != null && var1.field_a.toString().startsWith("JOIN_")) {
            var6 = Integer.parseInt(var1.field_a.toString().substring(5));
            if(((class_371)this.a24()).a20().h1() != 0) {
               (new class_256((class_371)this.a24(), "Confirm", "Do you really want to join this faction\nand leave your current faction?", var6)).c1();
            } else {
               ((class_371)this.a24()).a20().a132().b5(var6);
            }
         }

         if(var1.field_a != null && var1.field_a.toString().startsWith("REL_")) {
            var6 = Integer.parseInt(var1.field_a.toString().substring(4));
            class_423 var5;
            if((var5 = ((class_371)this.a24()).a14().field_a.field_a.field_a).a6().a20().h1() == 0) {
               var5.a6().a4().b1("Cannot modify:\nYou are not in any faction");
               return;
            }

            var3 = var5.a6().a45().a146(var5.a6().a20().h1());
            class_777 var7 = var5.a6().a45().a146(var6);
            if(var3 == null) {
               var5.a6().a4().b1("Your faction is corrupted\nand does not exist");
               return;
            }

            if(var7 == null) {
               var5.a6().a4().b1("Target faction is corrupted\nand does not exist");
               return;
            }

            if(var3 == var7) {
               var5.a6().a4().b1("Your faction can\'t have\nrelations with itself");
               return;
            }

            if(var7.a3() < 0) {
               var5.a6().a4().b1("Cannot modify relations\nto an NPC faction!");
               return;
            }

            class_762 var4;
            if((var4 = (class_762)var3.a154().get(var5.a6().a20().getName())) == null || !var4.a140(var3)) {
               var5.a6().a4().b1("Cannot change relation:\nPermission denied!");
               return;
            }

            var5.e2(true);
            (new class_344(var5.a6(), var3, var7)).c1();
         }
      }

   }

   public final boolean a4() {
      return false;
   }
}
