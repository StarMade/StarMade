import com.bulletphysics.linearmath.Transform;
import javax.vecmath.Vector3f;
import org.schema.game.common.data.element.ElementCollection;
import org.schema.game.common.data.element.PointDistributionCustomOutputUnit;

public final class class_287 implements Comparable {

   long field_a = -1L;
   private ElementCollection field_a;
   float field_a = 0.0F;
   private final class_212 field_a = new class_212();


   public class_287(class_743 var1, ElementCollection var2) {
      this.field_a = var2;
      if(var2 instanceof PointDistributionCustomOutputUnit) {
         this.field_a.a2(var1, ((PointDistributionCustomOutputUnit)var2).getOutput());
      } else {
         this.field_a.a2(var1, var2.getSignificator());
      }

      this.field_a = 0.0F;
      this.field_a = -1L;
   }

   public final boolean equals(Object var1) {
      return this.field_a.equals(((class_287)var1).field_a);
   }

   public final int hashCode() {
      return this.field_a.hashCode();
   }

   public final boolean a() {
      return this.field_a >= 0L && (float)(System.currentTimeMillis() - this.field_a) <= 200.0F;
   }

   public final void a1() {
      long var1;
      if((float)(var1 = System.currentTimeMillis() - this.field_a) > 160.0F && (float)var1 < 200.0F) {
         this.field_a = System.currentTimeMillis() + 160L;
      } else {
         if((float)var1 >= 200.0F) {
            this.field_a = System.currentTimeMillis();
         }

      }
   }

   public final void a2(class_935 var1) {
      this.field_a = (float)((double)this.field_a + (double)(var1.a() / 1000.0F) * ((Math.random() + 9.999999747378752E-5D) / 0.10000000149011612D));
      if(this.field_a > 1.0F) {
         this.field_a = 0.0F;
      }

   }

   public final void a3(Transform var1, Vector3f var2) {
      this.field_a.a1(var1, var2);
   }

   // $FF: synthetic method
   public final int compareTo(Object var1) {
      class_287 var2 = (class_287)var1;
      return this.field_a.a(var2.field_a);
   }
}
