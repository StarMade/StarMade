import com.bulletphysics.dynamics.RigidBody;
import javax.vecmath.Vector3f;
import org.lwjgl.input.Mouse;
import org.schema.game.common.controller.elements.ElementCollectionManager;
import org.schema.game.common.controller.elements.thrust.ThrusterCollectionManager;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public class class_113 extends class_964 {

   private class_250 field_a;
   private class_84 field_a;
   private class_877 field_a;
   private class_159 field_a;
   private class_122 field_a;
   private class_177 field_a;
   private class_154 field_a;
   private class_236 field_a;
   private class_146 field_a;
   private class_1412 field_a;
   private class_1412 field_b;
   private class_1412 field_c;
   private class_1412 field_d;
   private class_1412 field_e;
   private class_891 field_a;
   private class_1412 field_f;
   private class_1412 field_g;
   private class_85 field_a;
   private class_1412 field_h;


   public class_113(ClientState var1) {
      super(var1);
   }

   public final void e() {
      this.field_a.e();
   }

   private boolean b3() {
      return ((class_371)super.a24()).a14().field_a.field_a.field_a.field_c;
   }

   private boolean c1() {
      return (this.a18().a36().field_c?this.a18().a36():(this.a19().field_a.field_c?this.a19().field_a:null)) != null;
   }

   public final void a2() {}

   protected final void d() {
      this.field_a.h2(48);
      this.field_a.h2(48);
      this.field_a.h2(48);
      this.field_a.h2(48);
      this.field_a.h2(48);
      this.field_a.h2(40);
      this.field_a.h2(40);
   }

   public final void b() {
      if(this.k1()) {
         this.d();
      }

      class_964.i();
      this.field_a.b();
      class_236 var2;
      if(!this.e1() && !this.n()) {
         var2 = null;
         this.field_a.a29(false);
      } else {
         var2 = null;
         this.field_a.a29(true);
      }

      if(this.e1()) {
         this.field_a.b();
      }

      if(this.b3()) {
         this.field_a.b();
      }

      if(this.n()) {
         this.field_a.b();
      }

      if(this.f1()) {
         this.field_a.b();
      }

      if(this.o()) {
         this.field_a.b();
      }

      if(this.p()) {
         this.field_a.b();
      }

      if(this.m()) {
         this.field_a.b();
      }

      if(this.d1() && !((class_371)super.a24()).a14().field_a.field_a.field_a.field_c) {
         if((((class_371)super.a24()).a14().field_a.field_a.field_a.a51().a45().field_a.field_c || this.m()) && !this.n() && !this.e1()) {
            this.field_a.b();
         } else {
            this.field_a.b();
            if(!this.n() && !this.e1() && this.c1()) {
               this.field_a.b();
            }
         }
      }

      if(((class_371)super.a24()).getDragging() != null && ((class_371)super.a24()).getDragging() instanceof class_185) {
         class_185 var1;
         if((var1 = (class_185)((class_371)super.a24()).getDragging()).a70() != 0 && var1.a68(true) > 0) {
            this.field_a.a48(var1);
         } else {
            ((class_371)super.a24()).setDragging((class_1416)null);
         }
      }

      if(this.d1()) {
         class_964.i();
         var2 = this.field_a;
         if(!Mouse.isGrabbed()) {
            GlUtil.d1();

            for(int var3 = 0; var3 < var2.field_a.length; ++var3) {
               var2.field_a[var3].e();
            }

            GlUtil.c2();
         }

         class_964.h1();
      }

      if(this.e1()) {
         class_964.i();
         this.field_a.e();
         class_964.h1();
      }

      class_964.h1();
   }

   public final float a3() {
      return 0.0F;
   }

   private class_447 a18() {
      return ((class_371)super.a24()).a14().field_a.field_a.field_a.a53();
   }

   private class_328 a19() {
      return ((class_371)super.a24()).a14().field_a.field_a.field_a.a51().a45();
   }

   public final class_371 a20() {
      return (class_371)super.a24();
   }

   public final float b1() {
      return 0.0F;
   }

   private boolean d1() {
      return ((class_371)super.a24()).a14().field_a.field_c;
   }

   private boolean e1() {
      return ((class_371)super.a24()).a14().field_a.field_a.field_a.field_c;
   }

   public final boolean a4() {
      return this.c1() && class_367.field_U.a6() && this.field_a.a_();
   }

   private boolean f1() {
      return ((class_371)super.a24()).a14().field_a.field_a.field_a.field_c;
   }

   public final void c() {
      class_119 var1 = new class_119(this, (byte)0);
      this.field_d = new class_1412((class_371)super.a24(), 39.0F, 26.0F);
      this.field_d.field_a = "X";
      this.field_d.field_g = true;
      this.field_d.a143(var1);
      this.field_d.a83().set(804.0F, 4.0F, 0.0F);
      this.field_d.c();
      this.field_a = new class_1412((class_371)super.a24(), 147.0F, 40.0F);
      this.field_a.field_a = "INVENTORY";
      this.field_a.field_g = true;
      this.field_a.a143(var1);
      this.field_a.a83().set(216.0F, 26.0F, 0.0F);
      this.field_a.c();
      this.field_f = new class_1412((class_371)super.a24(), 147.0F, 40.0F);
      this.field_f.field_a = "AI";
      this.field_f.field_g = true;
      this.field_f.a143(var1);
      this.field_f.a83().set(662.0F, 472.0F, 0.0F);
      this.field_f.c();
      this.field_g = new class_1412((class_371)super.a24(), 147.0F, 40.0F);
      this.field_g.field_a = "FACTION";
      this.field_g.field_g = true;
      this.field_g.a143(var1);
      this.field_g.a83().set(517.0F, 472.0F, 0.0F);
      this.field_g.c();
      this.field_b = new class_1412((class_371)super.a24(), 147.0F, 40.0F);
      this.field_b.field_a = "WEAPON";
      this.field_b.field_g = true;
      this.field_b.a143(var1);
      this.field_b.a83().set(366.0F, 26.0F, 0.0F);
      this.field_b.c();
      this.field_h = new class_1412((class_371)super.a24(), 147.0F, 40.0F);
      this.field_h.field_a = "CATALOG";
      this.field_h.field_g = true;
      this.field_h.a143(var1);
      this.field_h.a83().set(366.0F, 472.0F, 0.0F);
      this.field_h.c();
      this.field_c = new class_1412((class_371)super.a24(), 147.0F, 40.0F);
      this.field_c.field_a = "SHOP";
      this.field_c.field_g = true;
      this.field_c.a143(var1);
      this.field_c.a83().set(514.0F, 26.0F, 0.0F);
      this.field_c.c();
      this.field_e = new class_1412((class_371)super.a24(), 147.0F, 40.0F);
      this.field_e.field_a = "NAVIGATION";
      this.field_e.field_g = true;
      this.field_e.a143(var1);
      this.field_e.a83().set(662.0F, 26.0F, 0.0F);
      this.field_e.c();
      this.field_a = new class_85((class_371)super.a24());
      this.field_a.c();
      this.field_a = new class_122((class_371)super.a24());
      this.field_a.c();
      this.field_a.a9(this.field_a);
      this.field_a.a9(this.field_c);
      this.field_a.a9(this.field_b);
      this.field_a.a9(this.field_d);
      this.field_a.a9(this.field_e);
      this.field_a.a9(this.field_f);
      this.field_a.a9(this.field_g);
      this.field_a.a9(this.field_h);
      this.field_a = new class_159((class_371)super.a24());
      this.field_a.c();
      this.field_a.a9(this.field_a);
      this.field_a.a9(this.field_c);
      this.field_a.a9(this.field_b);
      this.field_a.a9(this.field_d);
      this.field_a.a9(this.field_e);
      this.field_a.a9(this.field_f);
      this.field_a.a9(this.field_g);
      this.field_a.a9(this.field_h);
      this.field_a = new class_154((class_371)super.a24());
      this.field_a.c();
      this.field_a.a9(this.field_a);
      this.field_a.a9(this.field_c);
      this.field_a.a9(this.field_b);
      this.field_a.a9(this.field_d);
      this.field_a.a9(this.field_e);
      this.field_a.a9(this.field_f);
      this.field_a.a9(this.field_g);
      this.field_a.a9(this.field_h);
      this.field_a = new class_177((class_371)super.a24());
      this.field_a.c();
      this.field_a.a9(this.field_a);
      this.field_a.a9(this.field_c);
      this.field_a.a9(this.field_b);
      this.field_a.a9(this.field_d);
      this.field_a.a9(this.field_e);
      this.field_a.a9(this.field_f);
      this.field_a.a9(this.field_g);
      this.field_a.a9(this.field_h);
      this.field_a = new class_877((class_371)super.a24());
      this.field_a.c();
      this.field_a.a9(this.field_a);
      this.field_a.a9(this.field_c);
      this.field_a.a9(this.field_b);
      this.field_a.a9(this.field_d);
      this.field_a.a9(this.field_e);
      this.field_a.a9(this.field_f);
      this.field_a.a9(this.field_g);
      this.field_a.a9(this.field_h);
      this.field_a = new class_84((class_371)super.a24());
      this.field_a.c();
      this.field_a.a9(this.field_a);
      this.field_a.a9(this.field_c);
      this.field_a.a9(this.field_b);
      this.field_a.a9(this.field_d);
      this.field_a.a9(this.field_e);
      this.field_a.a9(this.field_f);
      this.field_a.a9(this.field_g);
      this.field_a.a9(this.field_h);
      this.field_a = new class_250((class_371)super.a24());
      this.field_a.c();
      this.field_a.a9(this.field_a);
      this.field_a.a9(this.field_c);
      this.field_a.a9(this.field_b);
      this.field_a.a9(this.field_d);
      this.field_a.a9(this.field_e);
      this.field_a.a9(this.field_f);
      this.field_a.a9(this.field_g);
      this.field_a.a9(this.field_h);
      this.field_a = new class_236(class_967.a2().a5("sidebar-gui-"), (class_371)super.a24());
      this.field_a.c();
      this.field_a = new class_146(class_967.a2().a5("sidebar-gui-"), (class_371)super.a24());
      this.field_a.c();
      this.field_a = new class_891((class_371)super.a24());
      this.field_a.c();
      this.d();
   }

   private boolean m() {
      return ((class_371)super.a24()).a14().field_a.field_a.field_a.field_b;
   }

   private boolean n() {
      return ((class_371)super.a24()).a14().field_a.field_a.field_a.field_c;
   }

   private boolean o() {
      return ((class_371)super.a24()).a14().field_a.field_a.field_a.field_c;
   }

   private boolean p() {
      return ((class_371)super.a24()).a14().field_a.field_a.field_a.field_c;
   }

   public final void a12(class_935 var1) {
      class_891 var2 = this.field_a;
      class_371 var3;
      long var4 = (long)(var3 = (class_371)this.field_a.a24()).a20().b4();
      var2.field_a.field_b.set(0, String.valueOf(var4));
      class_801 var11 = var3.a6();
      boolean var5 = false;

      try {
         if(var11 != null) {
            if(var11.getPhysicsDataContainer().isInitialized() && var11.getPhysicsDataContainer().getObject() instanceof RigidBody) {
               RigidBody var6 = (RigidBody)var11.getPhysicsDataContainer().getObject();
               Vector3f var7 = new Vector3f();
               var6.getLinearVelocity(var7);
               var5 = true;
               var2.field_c.field_b.set(0, class_40.a2(var7.length()));
            }

            if(var11 instanceof class_743) {
               class_743 var14 = (class_743)var11;
               if(((class_371)var2.a24()).a14().field_a.field_a.field_a.a51().a45().field_a.field_b) {
                  var2.field_b.field_b.set(0, var14.getRealName() + ", Sec: " + var3.a20().a44());
                  var2.field_b.field_b.set(1, "Thrust/Mass: " + class_40.a2(((ThrusterCollectionManager)var14.a96().getThrust().getCollectionManager()).getTotalThrust()) + " - " + class_40.a2(var14.getMass()) + " = " + class_40.a2(var14.a96().getThrusterElementManager().getActualThrust()));
               } else {
                  var2.field_b.field_b.set(0, var14.getRealName());
                  class_47 var15;
                  class_47 var9 = class_793.a192(var15 = var3.a9().a35().pos.getVector(), new class_47());
                  boolean var12 = class_795.a19(var15);
                  var2.field_b.field_b.set(1, (var12?"Star":"Void") + "Sys: " + var9 + "; Sec: " + var15);
               }
            } else {
               var2.field_b.field_b.set(0, var3.getPlayerName());
               class_47 var13;
               class_793.a192(var13 = var3.a9().a35().pos.getVector(), new class_47());
               boolean var10 = class_795.a19(var13);
               var2.field_b.field_b.set(1, (var10?"Star":"Void") + "System Sector: " + var13);
            }
         }
      } catch (Exception var8) {
         ;
      }

      if(!var5) {
         var2.field_c.field_b.set(0, "0");
      }

      this.field_a.a12(var1);
      this.field_a.a12(var1);
      this.field_a.a12(var1);
      this.field_a.a12(var1);
      this.field_a.a12(var1);
      super.a12(var1);
   }

   public final void a21(ElementCollectionManager var1) {
      this.field_a.a21(var1);
   }

   public final class_236 a22() {
      return this.field_a;
   }

   public final class_177 a23() {
      return this.field_a;
   }

   // $FF: synthetic method
   static boolean a25(class_113 var0) {
      return var0.e1();
   }

   // $FF: synthetic method
   static void a26(class_113 var0) {
      ((class_371)var0.a24()).a14().field_a.field_a.a63((class_635)null);
   }

   // $FF: synthetic method
   static boolean b4(class_113 var0) {
      return var0.m();
   }

   // $FF: synthetic method
   static void b5(class_113 var0) {
      if(((class_371)var0.a24()).a14().field_a.field_a.field_a.a51().field_b) {
         ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
         ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
         ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
         ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
         ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
         ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
         ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(true);
      } else {
         ((class_371)var0.a24()).a4().b1("ERROR: only available inside ship");
      }
   }

   // $FF: synthetic method
   static boolean c2(class_113 var0) {
      return var0.o();
   }

   // $FF: synthetic method
   static void c3(class_113 var0) {
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(true);
   }

   // $FF: synthetic method
   static boolean d2(class_113 var0) {
      return var0.p();
   }

   // $FF: synthetic method
   static void d3(class_113 var0) {
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(true);
   }

   // $FF: synthetic method
   static boolean e2(class_113 var0) {
      return var0.b3();
   }

   // $FF: synthetic method
   static void e3(class_113 var0) {
      if(((class_371)var0.a24()).a14().field_a.field_a.field_a.a51().field_b) {
         ((class_371)var0.a24()).a14().field_a.field_a.a16((class_800)null);
      } else {
         ((class_371)var0.a24()).a4().b1("No AI context available\nEither use this in a ship\nwith an AI Module, or\nactivate an AI Module externally (" + class_367.field_w.b1() + ")");
      }
   }

   // $FF: synthetic method
   static boolean f2(class_113 var0) {
      return var0.n();
   }

   // $FF: synthetic method
   static void f3(class_113 var0) {
      if(((class_371)var0.a24()).d2()) {
         ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
         ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
         ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
         ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
         ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
         ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
         ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(true);
      } else {
         ((class_371)var0.a24()).a4().b1("no shop in range");
      }
   }

   // $FF: synthetic method
   static boolean g1(class_113 var0) {
      return var0.f1();
   }

   // $FF: synthetic method
   static void g2(class_113 var0) {
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(false);
      ((class_371)var0.a24()).a14().field_a.field_a.field_a.c2(true);
   }

   // $FF: synthetic method
   static void h(class_113 var0) {
      ((class_371)var0.a24()).a14().field_a.field_a.b();
   }
}
