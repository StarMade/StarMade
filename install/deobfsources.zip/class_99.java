import org.schema.schine.network.client.ClientState;

final class class_99 extends class_959 {

   class_99(ClientState var1, class_963 var2, class_964 var3, class_964 var4) {
      super(var1, var2, var3, var4);
   }

   protected final boolean b3() {
      return ((class_371)this.a24()).b().isEmpty();
   }
}
