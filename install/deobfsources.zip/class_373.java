import org.schema.game.common.data.element.Element;

public final class class_373 {

   private final class_371 field_a;
   public class_47 field_a;
   public class_47 field_b;
   private class_47 field_c = new class_47();
   private class_47 field_d = new class_47();


   public class_373(class_371 var1) {
      this.field_a = var1;
   }

   public final void a(int var1) {
      if(this.field_a != null) {
         class_670 var3;
         if((var3 = (class_670)this.field_a.getLocalAndRemoteObjectContainer().getLocalObjects().get(var1)) == null) {
            this.field_a.a4().field_b = true;
            return;
         }

         class_47 var4 = var3.a34();
         System.err.println("UPDATE WAYPOINT: " + this.field_a);
         if(this.field_b == null) {
            this.field_b = new class_47();
         }

         if(var4.equals(this.field_a)) {
            this.a1((class_47)null);
            return;
         }

         this.field_d.b(0, 0, 0);

         for(int var2 = 0; var2 < Element.DIRECTIONSi.length; ++var2) {
            this.field_c.b2(var4, Element.DIRECTIONSi[var2]);
            if(this.field_c.equals(this.field_a)) {
               this.field_b.b2(var4, Element.DIRECTIONSi[var2]);
               break;
            }

            System.err.println("CHECKING WAYPOINT: " + var4 + ": " + this.field_c);
            this.field_c.c1(this.field_a);
            if(this.field_d.a4() != 0.0F && this.field_c.a4() >= this.field_d.a4()) {
               System.err.println("NOT TAKING: " + this.field_c.a4() + " / " + this.field_d.a4());
            } else {
               this.field_b.b2(var4, Element.DIRECTIONSi[var2]);
               this.field_d.b1(this.field_c);
            }
         }

         System.err.println("NEAREST WAYPOINT " + this.field_b);
      }

   }

   public final void a1(class_47 var1) {
      System.err.println("SETTING WAYPOINT: " + var1);
      this.field_a = var1;
      this.field_b = null;
      this.a(this.field_a.a8());
   }
}
