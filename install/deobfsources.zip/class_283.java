import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.controller.elements.FactoryAddOnInterface;
import org.schema.schine.graphicsengine.core.GlUtil;

public final class class_283 implements class_923 {

   private final HashMap field_a = new HashMap();
   private final class_371 field_a;


   public class_283(class_371 var1) {
      this.field_a = var1;
   }

   public final void a() {}

   public final void d() {
      Iterator var1 = this.field_a.a7().values().iterator();

      while(var1.hasNext()) {
         class_801 var2;
         if(((var2 = (class_801)var1.next()) instanceof class_848 || var2 instanceof class_780) && !this.field_a.containsKey(var2)) {
            class_285 var3 = new class_285((SegmentController)var2);
            this.field_a.put((SegmentController)var2, var3);
         }
      }

      ArrayList var4 = new ArrayList();
      Iterator var6 = this.field_a.keySet().iterator();

      SegmentController var7;
      while(var6.hasNext()) {
         if((var7 = (SegmentController)var6.next()).getSectorId() != this.field_a.a8()) {
            var4.add(var7);
         }
      }

      var6 = var4.iterator();

      while(var6.hasNext()) {
         var7 = (SegmentController)var6.next();
         class_285 var5;
         if((var5 = (class_285)this.field_a.remove(var7)) != null) {
            var5.a();
         }
      }

   }

   public final void b() {
      class_1379.field_C.c();
      Iterator var1 = this.field_a.values().iterator();

      while(var1.hasNext()) {
         class_285 var2;
         float var3 = ((FactoryAddOnInterface)((class_802)(var2 = (class_285)var1.next()).a21()).a()).getFactory().getAccumulated() / 5.0F;
         GlUtil.a33(class_1379.field_C, "time", var3);
         var2.b();
      }

      class_1376 var10000 = class_1379.field_C;
      class_1376.e();
   }

   public final void c() {}

   public final void a19(class_749 var1) {
      class_285 var2;
      if((var2 = (class_285)this.field_a.get(var1)) != null) {
         var2.d();
      } else {
         System.err.println("[CLIENT][ConnectionDrawer] WARNING segController to update not found!!!!!!!!!!! searching " + var1);
      }
   }
}
