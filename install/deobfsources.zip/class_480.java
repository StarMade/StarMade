
final class class_480 implements class_954 {

   public final boolean a(String var1, class_1077 var2) {
      if(class_1039.a4(var1)) {
         return true;
      } else {
         var2.onFailedTextCheck("Must only contain Letters or numbers or (_-)!");
         return false;
      }
   }
}
