import org.schema.game.common.data.element.ElementKeyMap;

final class class_465 implements class_954 {

   // $FF: synthetic field
   private short field_a;


   class_465(short var1) {
      this.field_a = var1;
      super();
   }

   public final boolean a(String var1, class_1077 var2) {
      try {
         if(var1.length() > 0) {
            ElementKeyMap.getInfo(this.field_a);
            Integer.parseInt(var1);
            return true;
         }
      } catch (NumberFormatException var3) {
         ;
      }

      var2.onFailedTextCheck("Amount must be a number!");
      return false;
   }
}
