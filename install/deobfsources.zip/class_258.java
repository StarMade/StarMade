
public final class class_258 extends class_11 {

   private class_260 field_a;
   private class_15 field_a;


   public class_258(class_371 var1, class_15 var2) {
      super(var1);
      this.field_a = var2;
      var2.e2(true);
      this.field_a = new class_260(super.field_a, this, "Incoming Invites", "");
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.a()) {
         if(var1.b19().equals("OK")) {
            this.d();
         }

         if(var1.b19().equals("CANCEL") || var1.b19().equals("X")) {
            System.err.println("CANCEL");
            this.d();
         }
      }

   }

   public final boolean a1() {
      return false;
   }

   public final void handleKeyEvent() {}

   public final class_964 a3() {
      return this.field_a;
   }

   public final void a2() {
      this.field_a.e2(false);
   }
}
