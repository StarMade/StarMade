import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.vecmath.Vector4f;
import org.schema.schine.network.client.ClientState;

public final class class_111 extends class_972 {

   private class_1361 field_a;
   private class_1361 field_b;
   private class_760 field_a;


   public class_111(ClientState var1, class_760 var2, int var3) {
      super(var1);
      this.field_a = new class_1361(this.a24(), 540.0F, 100.0F, var3 % 2 == 0?new Vector4f(0.1F, 0.1F, 0.1F, 1.0F):new Vector4f(0.2F, 0.2F, 0.2F, 1.0F));
      super.field_a = this.field_a;
      super.field_b = this.field_a;
      this.field_a = var2;
   }

   public final void c() {
      super.c();
      class_940 var1 = new class_940(200, 20, this.a24());
      class_940 var2 = new class_940(200, 20, this.a24());
      class_940 var3 = new class_940(200, 20, this.a24());
      this.field_b = new class_1361(this.a24(), 550.0F, 20.0F, new Vector4f(0.3F, 0.3F, 0.4F, 0.8F));
      var1.a137(this.field_a.a());
      GregorianCalendar var4;
      (var4 = new GregorianCalendar()).setTime(new Date(this.field_a.a25()));
      var2.a137(var4.getTime().toString());
      var3.field_b = new ArrayList();
      String[] var8;
      int var5 = (var8 = this.field_a.b().split("\\\\n")).length;

      for(int var6 = 0; var6 < var5; ++var6) {
         String var7 = var8[var6];
         var3.field_b.add(var7);
      }

      this.field_b.a9(var1);
      this.field_b.a9(var2);
      var2.a83().field_x = 300.0F;
      var3.a83().field_y = 20.0F;
      this.field_a.a9(this.field_b);
      this.field_a.a9(var3);
   }
}
