import java.util.Iterator;

public final class class_25 extends class_15 {

   public class_25(class_371 var1) {
      super(var1);
   }

   public final void handleKeyEvent() {
      super.handleKeyEvent();
   }

   public final void a12(class_941 var1) {
      super.a12(var1);
      class_11.field_a = System.currentTimeMillis();
   }

   public final void b2(boolean var1) {
      boolean var2 = false;
      if(var1) {
         synchronized(this.a6().b()) {
            Iterator var4 = this.a6().b().iterator();

            while(var4.hasNext()) {
               if((class_11)var4.next() instanceof class_1) {
                  var2 = true;
               }
            }
         }

         if(!var2) {
            class_1 var3 = new class_1(this.a6());
            this.a6().b().add(var3);
         }
      } else {
         class_11.field_a = System.currentTimeMillis();
         synchronized(this.a6().b()) {
            for(int var7 = 0; var7 < this.a6().b().size(); ++var7) {
               if((class_11)this.a6().b().get(var7) instanceof class_1) {
                  ((class_11)this.a6().b().get(var7)).d();
                  break;
               }
            }
         }
      }

      super.b2(var1);
   }

   public final void a15(class_935 var1) {
      class_1008.field_a = false;
      super.a15(var1);
   }
}
