import java.util.ArrayList;
import javax.vecmath.Vector4f;
import org.newdawn.slick.Color;
import org.schema.game.common.data.element.ElementKeyMap;
import org.schema.schine.graphicsengine.core.GlUtil;

public final class class_236 extends class_964 {

   class_185[] field_a = new class_185[256];
   private class_940[] field_a = new class_940[256];
   private class_1361 field_a;
   private class_970 field_a;
   private class_130 field_a;
   private int field_a;
   private long field_a;


   public class_236(class_1382 var1, class_371 var2) {
      super(var2);

      for(int var3 = 0; var3 < this.field_a.length; ++var3) {
         this.field_a[var3] = new class_185(var2, true, (class_964)null);
         this.field_a[var3] = new class_940(32, 32, class_28.c(), var2);
         this.field_a[var3].a136(Color.white);
         this.field_a[var3].field_b = new ArrayList();
         this.field_a[var3].field_b.add("i " + var3);
         this.field_a[var3].a165(2.0F, 2.0F, 0.0F);
         this.field_a[var3].a9(this.field_a[var3]);
      }

      this.field_a = new class_970(var1, var2);
      this.field_a = new class_1361(this.a24(), 64.0F, 64.0F, new Vector4f(1.0F, 1.0F, 1.0F, 0.18F));
   }

   public final void a29(boolean var1) {
      for(int var2 = 0; var2 < 10; ++var2) {
         this.field_a[var2].field_g = var1;
      }

   }

   public final void a2() {}

   protected final void d() {}

   public final void b() {
      GlUtil.d1();
      class_453 var1 = ((class_371)this.a24()).a14().field_a.field_a.field_a.a51().a45().field_a;
      class_443 var2 = ((class_371)this.a24()).a14().field_a.field_a.field_a;
      if(var1 != null) {
         int var11 = var2.b6();
         class_635 var3 = ((class_371)this.a24()).a20().getInventory((class_47)null);
         this.r();
         this.l();
         this.field_a.b();

         for(int var4 = 0; var4 < 10; ++var4) {
            short var5 = 0;
            int var6 = 511;
            int var7 = var2.a55(var4 + 2);
            if(var3.a18(var7)) {
               this.field_a[var4].field_b.set(0, "");
            } else {
               var6 = ElementKeyMap.getInfo(var5 = var3.a45(var7)).getBuildIconNum();
            }

            int var8 = var3.a41(var7);
            this.field_a[var4].f4(var7);
            this.field_a[var4].a74(var5);
            this.field_a[var4].a72(var8);
            int var12;
            if((var12 = this.field_a[var4].a68(false)) <= 0) {
               var6 = 511;
            }

            if(var12 > 0) {
               this.field_a[var4].field_b.set(0, String.valueOf(var12));
            } else {
               this.field_a[var4].field_b.set(0, "");
            }

            this.field_a[var4].b20(false);
            this.field_a[var4].a83().field_y = 21.0F;
            this.field_a[var4].a83().field_x = 159.0F + (float)var4 * 70.0F;
            var12 = var6 / 256;
            var6 %= 256;
            this.field_a[var4].e4(var12);
            this.field_a[var4].a151().b13(var6);
            this.field_a[var4].b();
            if(var7 == var11) {
               if(this.field_a != var7) {
                  this.field_a = System.currentTimeMillis();
                  this.field_a = var7;
               }

               this.field_a.a83().set(this.field_a[var4].a83());
               this.field_a.field_a.set(this.field_a[var4].field_a);
               this.field_a.b();
               long var9;
               if((var9 = System.currentTimeMillis() - this.field_a) < 1200L) {
                  GlUtil.d1();
                  this.field_a[var4].a((float)var9 / 1200.0F);
                  GlUtil.c2();
               }
            }
         }

         this.field_a[0].a151().b13(0);
         GlUtil.c2();
      }
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public final void c() {
      this.field_a.c();

      for(int var1 = 0; var1 < this.field_a.length; ++var1) {
         this.field_a[var1].c();
      }

      this.field_a.c();
      this.field_a = new class_130((class_371)this.a24());
      this.field_a.c();
      this.field_a.a9(this.field_a);
   }

   public final void a12(class_935 var1) {
      super.a12(var1);
      this.field_a.a12(var1);
   }
}
