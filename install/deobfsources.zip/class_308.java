
final class class_308 implements class_951 {

   // $FF: synthetic field
   private class_304 field_a;


   class_308(class_304 var1) {
      this.field_a = var1;
      super();
   }

   public final void a(String var1) {
      try {
         ((class_306)this.field_a.field_a).field_a = -Integer.parseInt(var1);
      } catch (Exception var2) {
         ;
      }
   }
}
