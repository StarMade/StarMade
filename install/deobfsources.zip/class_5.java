import com.bulletphysics.collision.dispatch.CollisionObject;
import com.bulletphysics.collision.narrowphase.ManifoldPoint;
import com.bulletphysics.collision.narrowphase.PersistentManifold;
import com.bulletphysics.dynamics.DynamicsWorld;
import com.bulletphysics.dynamics.InternalTickCallback;
import javax.vecmath.Vector3f;
import org.schema.schine.network.objects.Sendable;

final class class_5 extends InternalTickCallback {

   // $FF: synthetic field
   private class_51 field_a;


   private class_5(class_51 var1) {
      this.field_a = var1;
      super();
   }

   public final void internalTick(DynamicsWorld var1, float var2) {
      int var17 = class_51.a37(this.field_a).a19().getDynamicsWorld().getDispatcher().getNumManifolds();

      for(int var18 = 0; var18 < var17; ++var18) {
         PersistentManifold var3;
         CollisionObject var4 = (CollisionObject)(var3 = class_51.a37(this.field_a).a19().getDynamicsWorld().getDispatcher().getManifoldByIndexInternal(var18)).getBody0();
         CollisionObject var5 = (CollisionObject)var3.getBody1();
         int var6 = var3.getNumContacts();
         if(var4 != null && var5 != null && var4.getUserPointer() != null && var5.getUserPointer() != null) {
            int var7 = ((Integer)var4.getUserPointer()).intValue();
            int var8 = ((Integer)var5.getUserPointer()).intValue();
            Sendable var19 = (Sendable)class_51.a37(this.field_a).getLocalAndRemoteObjectContainer().getLocalObjects().get(var7);
            Sendable var20 = (Sendable)class_51.a37(this.field_a).getLocalAndRemoteObjectContainer().getLocalObjects().get(var8);
            Vector3f var9 = new Vector3f();
            Vector3f var10 = new Vector3f();
            if(var19 instanceof class_1274 && var20 instanceof class_1274) {
               class_1274 var11 = (class_1274)var19;
               class_1274 var12 = (class_1274)var20;
               boolean var13 = var11.needsManifoldCollision();
               boolean var14 = var12.needsManifoldCollision();
               if(var13 || var14) {
                  for(int var15 = 0; var15 < var6; ++var15) {
                     ManifoldPoint var16;
                     if((var16 = var3.getContactPoint(var15)).getDistance() < 0.0F && var4.getUserPointer() != null && var5.getUserPointer() != null) {
                        var16.getPositionWorldOnA(var9);
                        var16.getPositionWorldOnB(var10);
                        Vector3f var10000 = var16.normalWorldOnB;
                        if(var13) {
                           var11.onCollision(var16, var20);
                        }

                        if(var14) {
                           var12.onCollision(var16, var19);
                        }
                     }
                  }
               }
            }
         }
      }

   }

   // $FF: synthetic method
   class_5(class_51 var1, byte var2) {
      this(var1);
   }
}
