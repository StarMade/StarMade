import java.util.ArrayList;
import javax.vecmath.Vector4f;
import org.schema.schine.network.client.ClientState;

final class class_171 extends class_972 {

   private class_777 field_a;
   private class_762 field_a;
   private class_1361 field_a;
   private class_940 field_a;
   private class_928 field_a;
   private class_940 field_b;
   private Vector4f field_a;
   // $FF: synthetic field
   private class_173 field_a;


   public class_171(class_173 var1, ClientState var2, class_777 var3, class_762 var4, int var5) {
      this.field_a = var1;
      super(var2);
      this.field_a = var3;
      this.field_a = var4;
      this.field_a = var5 % 2 == 0?new Vector4f(0.1F, 0.1F, 0.1F, 1.0F):new Vector4f(0.3F, 0.3F, 0.3F, 1.0F);
      this.field_a = new class_1361(this.a24(), 400.0F, 20.0F, this.field_a);
      super.field_a = this.field_a;
      super.field_b = this.field_a;
      super.field_a = new Object[]{var3, var4};
   }

   public final void c() {
      this.field_a = new class_940(200, 20, this.a24());
      this.field_a.a137(this.field_a.field_a);
      class_169 var1 = new class_169(this);
      this.field_b = new class_940(200, 20, this.a24());
      this.field_b.field_b = new ArrayList();
      this.field_b.field_b.add(var1);
      Vector4f var2;
      (var2 = new Vector4f(this.field_a)).scale(1.1F);
      this.field_a = new class_928(this.a24(), 75, 20, var2, new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), class_28.l(), "Options", class_173.a58(this.field_a));
      this.field_a.b14(15, 1);
      this.field_a.a9(this.field_a);
      this.field_a.a9(this.field_b);
      if(class_173.a59(this.field_a)) {
         this.field_a.a9(this.field_a);
      }

      this.field_b.a83().field_x = 200.0F;
      this.field_a.a83().field_x = 300.0F;
      super.c();
   }

   public final void b() {
      if(this.field_a.d7(this.field_a)) {
         this.field_b.a138(0.7F, 0.7F);
      } else if(this.field_a.b23(this.field_a) || this.field_a.c15(this.field_a)) {
         this.field_b.a138(0.9F, 0.9F);
      }

      super.b();
      this.field_b.a138(1.0F, 1.0F);
   }

   // $FF: synthetic method
   static class_777 a55(class_171 var0) {
      return var0.field_a;
   }

   // $FF: synthetic method
   static class_762 a56(class_171 var0) {
      return var0.field_a;
   }
}
