import java.util.Observable;

final class class_4 extends Observable {

   private class_4() {}

   public final void a(String var1) {
      this.setChanged();
      this.notifyObservers(var1);
   }

   // $FF: synthetic method
   class_4(byte var1) {
      this();
   }
}
