import java.util.Comparator;
import javax.vecmath.Vector3f;
import org.schema.game.common.data.world.Segment;

public final class class_355 implements Comparator {

   private final Vector3f field_a = new Vector3f();
   private Vector3f field_b = new Vector3f();


   private synchronized int a(class_661 var1, class_661 var2) {
      return var1 != var2 && !var1.equals(var2)?Float.compare(this.a1(var1.field_a, var1), this.a1(var2.field_a, var2)):0;
   }

   private float a1(class_47 var1, Segment var2) {
      this.field_b.set((float)var1.field_a, (float)var1.field_b, (float)var1.field_c);
      var2.a15().getWorldTransformClient().basis.transform(this.field_b);
      this.field_b.add(var2.a15().getWorldTransformClient().origin);
      this.field_b.sub(this.field_a);
      return this.field_b.lengthSquared();
   }

   // $FF: synthetic method
   public final int compare(Object var1, Object var2) {
      return this.a((class_661)var1, (class_661)var2);
   }

   // $FF: synthetic method
   static Vector3f a2(class_355 var0) {
      return var0.field_a;
   }
}
