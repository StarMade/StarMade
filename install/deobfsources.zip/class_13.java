import org.lwjgl.input.Keyboard;

public abstract class class_13 extends class_11 implements class_1077, class_952 {

   private final class_1080 field_a;
   private final class_196 field_a;


   public class_13(class_371 var1, int var2, Object var3, Object var4) {
      super(var1);
      this.field_a = new class_1080(140, var2, this);
      this.field_a = new class_263(var1, this, var3, var4, this.field_a);
      this.field_a.a143(this);
   }

   public class_13(class_371 var1, int var2, Object var3, Object var4, String var5) {
      this(var1, var2, var3, var4);
      if(var5 != null && var5.length() > 0) {
         this.field_a.a9(var5);
         this.field_a.e();
         this.field_a.g1();
      }

   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.field_a && var2.field_a == 0) {
         if(var1.b19().equals("OK")) {
            System.err.println("OK");
            this.field_a.b();
         }

         if(var1.b19().equals("CANCEL") || var1.b19().equals("X")) {
            System.err.println("CANCEL");
            this.d();
         }
      }

   }

   public void handleKeyEvent() {
      if(Keyboard.getEventKeyState()) {
         if(super.field_a && Keyboard.getEventKey() == 1) {
            this.d();
            return;
         }

         this.field_a.handleKeyEvent();
      }

   }

   public abstract boolean a7(String var1);

   public void onTextEnter(String var1, boolean var2) {
      if(this.a7(var1)) {
         this.d();
      }

   }
}
