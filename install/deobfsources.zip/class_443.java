import com.bulletphysics.linearmath.Transform;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.HashMap;
import java.util.Iterator;
import javax.vecmath.Vector3f;
import org.lwjgl.input.Keyboard;
import org.schema.common.FastMath;
import org.schema.game.common.controller.BlockedByDockedElementException;
import org.schema.game.common.controller.EditableSendableSegmentController;
import org.schema.game.common.controller.ElementPositionBlockedException;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.data.element.Element;
import org.schema.game.common.data.element.ElementInformation;
import org.schema.game.common.data.element.ElementKeyMap;
import org.schema.game.common.data.player.inventory.NoSlotFreeException;
import org.schema.schine.network.objects.Sendable;
import org.schema.schine.network.objects.remote.RemoteInteger;
import org.schema.schine.network.objects.remote.Streamable;

public class class_443 extends class_15 {

   private int field_a;
   private HashMap field_a = new HashMap();
   private class_342 field_a;
   private class_447 field_a;
   private class_431 field_a;
   private class_801 field_a;
   private class_459 field_a;
   private int field_b = 4;
   // $FF: synthetic field
   private static boolean field_d = !ar.class.desiredAssertionStatus();


   public class_443(class_371 var1) {
      super(var1);
      this.field_a.put(Integer.valueOf(2), Integer.valueOf(0));
      this.field_a.put(Integer.valueOf(3), Integer.valueOf(1));
      this.field_a.put(Integer.valueOf(4), Integer.valueOf(2));
      this.field_a.put(Integer.valueOf(5), Integer.valueOf(3));
      this.field_a.put(Integer.valueOf(6), Integer.valueOf(4));
      this.field_a.put(Integer.valueOf(7), Integer.valueOf(5));
      this.field_a.put(Integer.valueOf(8), Integer.valueOf(6));
      this.field_a.put(Integer.valueOf(9), Integer.valueOf(7));
      this.field_a.put(Integer.valueOf(10), Integer.valueOf(8));
      this.field_a.put(Integer.valueOf(11), Integer.valueOf(9));
      this.field_a = new class_342(this.a6());
      this.field_a = new class_431(this.a6());
      this.field_a = new class_447(this.a6());
      this.field_a = new class_459(this.a6());
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
   }

   public final int a48(EditableSendableSegmentController var1, Vector3f var2, Vector3f var3, class_479 var4, class_709 var5, class_433 var6, float var7) {
      if(!this.a6().a4().c4(var1)) {
         return 0;
      } else {
         short var8;
         class_47 var10;
         if((var8 = this.a54()) == 0) {
            this.a6().a4().d1("No element available to build!\nSelected slot is empty!");
            if(var6.field_a != 0) {
               try {
                  class_800 var21 = var1.getNextToNearestPiece(var2, var3, new class_47(), var7, true, new class_47(), new class_47());
                  if(var6.field_a > 0 && var21 != null) {
                     var10 = var21.a2(new class_47());
                     switch(var6.field_a) {
                     case 1:
                        System.err.println("SYM XY PLANE SET");
                        var6.field_a.field_c = var10.field_c;
                        var6.field_a = true;
                        break;
                     case 2:
                        System.err.println("SYM XZ PLANE SET");
                        var6.field_b.field_b = var10.field_b;
                        var6.field_b = true;
                     case 3:
                     default:
                        break;
                     case 4:
                        System.err.println("SYM YZ PLANE SET");
                        var6.field_c.field_a = var10.field_a;
                        var6.field_c = true;
                     }

                     var6.field_a = 0;
                  }
               } catch (ElementPositionBlockedException var14) {
                  var14.printStackTrace();
               } catch (BlockedByDockedElementException var15) {
                  var15.printStackTrace();
               }
            }

            return 0;
         } else if(this.a6().a20().getInventory((class_47)null).a18(this.field_a)) {
            this.a6().a4().d1("No element available to build!\nSelected slot is empty!");
            return 0;
         } else if(!field_d && this.a6().a20().getInventory((class_47)null).a41(this.field_a) <= 0) {
            throw new AssertionError();
         } else {
            int var9 = this.a6().a20().getInventory((class_47)null).a41(this.field_a);

            try {
               var10 = new class_47(1, 1, 1);
               if(class_367.field_U.a6()) {
                  var10.b1(this.field_a.a35());
               }

               ElementInformation var22 = ElementKeyMap.getInfo(var8);
               boolean var12 = true;
               int var13 = this.field_b;
               if(this.field_b > 7) {
                  if(var22.getBlockStyle() == 1) {
                     var13 -= 8;
                     var12 = false;
                     System.err.println("[CLIENT][PLACEBLOCK] BLOCK ORIENTATION (1) EXTENSION: " + (var13 + 4) + " -> " + var13);
                  } else if(var22.getBlockStyle() == 2) {
                     var13 -= 8;
                     var12 = false;
                     System.err.println("[CLIENT][PLACEBLOCK] BLOCK ORIENTATION (2) EXTENSION: " + (var13 + 8) + " -> " + var13);
                  } else {
                     System.err.println("[CLIENT][PLACEBLOCK] Exception: Block orientation was set over 8 on block style " + var22 + ": " + var13);
                     var13 = 0;
                  }
               }

               int var19;
               if((var19 = var1.getNearestIntersection(var8, var2, var3, var4, var13, var12, var5, var10, var9, var7, var6)) > 0) {
                  class_635 var20 = ((class_371)var1.getState()).a20().getInventory((class_47)null);

                  try {
                     var20.a47(this.field_a, var8, -var19);
                     this.a6().a20().sendInventoryModification(this.field_a, (class_47)null);
                     class_967.b("0022_action - buttons push big");
                     if(var8 == 56) {
                        this.a6().a4().d1("INFO:\nUse gravity when you are\noutside the ship. Look at\ngravity module and press \'R\'");
                     }

                     var1.getNetworkObject().lastModifiedPlayerId.forceClientUpdates();
                     var1.getNetworkObject().lastModifiedPlayerId.set(this.a6().a20().getId());
                     return var19;
                  } catch (NoSlotFreeException var16) {
                     var16.printStackTrace();
                     System.err.println("[WARNING] ILLEGIT BLOCK WITH SLOT " + this.field_a);
                     var1.getNearestIntersectingElementPosition(var2, var3, new class_47(1, 1, 1), var7, new class_441(), var6);
                  }
               }
            } catch (ElementPositionBlockedException var17) {
               String var11 = "unknown";
               if(var17.field_a != null) {
                  if(var17.field_a instanceof SegmentController) {
                     var11 = ((SegmentController)var17.field_a).getRealName();
                  } else if(var17.field_a instanceof class_801) {
                     var11 = ((class_801)var17.field_a).toNiceString();
                  }
               }

               this.a6().a4().b1("Cannot build here!\nPosition is blocked by\n" + var11);
            } catch (BlockedByDockedElementException var18) {
               this.a6().a27().a90().a27(var18.field_a);
               this.a6().a4().b1("Cannot build here!\nPosition blocked\nby active docking area!");
            }

            return 0;
         }
      }
   }

   public final void a49(EditableSendableSegmentController var1, Vector3f var2, Vector3f var3, float var4, class_433 var5) {
      if(this.a6().a4().c4(var1)) {
         class_47 var6 = new class_47(1, 1, 1);
         if(class_367.field_U.a6()) {
            var6.b1(this.field_a.a35());
         }

         IntOpenHashSet var7 = new IntOpenHashSet(var6.field_a * var6.field_b * var6.field_c);
         var1.getNearestIntersectingElementPosition(var2, var3, var6, var4, new class_439(this, var1, var7), var5);
         class_967.b("0022_action - buttons push medium");
         this.a6().a20().sendInventoryModification(var7, (class_47)null);
         var1.getNetworkObject().lastModifiedPlayerId.forceClientUpdates();
         var1.getNetworkObject().lastModifiedPlayerId.set(this.a6().a20().getId());
      }
   }

   public final int a28() {
      return this.field_b;
   }

   public final class_459 a50() {
      return this.field_a;
   }

   public final class_342 a51() {
      return this.field_a;
   }

   public final class_431 a52() {
      return this.field_a;
   }

   public final class_447 a53() {
      return this.field_a;
   }

   public final class_801 a43() {
      return this.field_a;
   }

   public final int b6() {
      return this.field_a;
   }

   public final short a54() {
      return this.a6().a20().getInventory((class_47)null).a45(this.field_a);
   }

   public final int a55(int var1) {
      if(this.field_a.containsKey(Integer.valueOf(var1))) {
         return ((Integer)this.field_a.get(Integer.valueOf(var1))).intValue();
      } else {
         System.err.println("[WARNING] UNKNOWN SLOT KEY: " + var1 + ": " + this.field_a);
         return -1;
      }
   }

   public void handleKeyEvent() {
      if(!class_11.b1()) {
         synchronized(this.a6().b()) {
            int var2;
            if((var2 = this.a6().b().size()) > 0) {
               ((class_11)this.a6().b().get(var2 - 1)).handleKeyEvent();
               return;
            }
         }

         if(Keyboard.getEventKeyState()) {
            if(this.a6().b().isEmpty()) {
               if(Keyboard.getEventKey() == class_367.field_o.a5()) {
                  this.a6().a20().a117().dropOrPickupSlots.add((Streamable)(new RemoteInteger(Integer.valueOf(this.field_a), this.a6().a20().a117())));
               }

               if(Keyboard.getEventKey() == class_367.field_L.a5()) {
                  this.d3(1);
               } else if(Keyboard.getEventKey() == class_367.field_M.a5()) {
                  this.d3(-1);
               } else if(Keyboard.getEventKey() == class_367.field_N.a5()) {
                  class_443 var1 = this;
                  Vector3f var9 = new Vector3f();
                  Vector3f var3 = new Vector3f();
                  float var4 = 0.0F;
                  if(this.a6().a6() != null) {
                     var9.set(this.a6().a6().getWorldTransform().origin);
                  } else {
                     var9.set(class_967.a1().a83());
                  }

                  class_801 var5 = null;
                  Iterator var6 = this.a6().a7().values().iterator();

                  while(var6.hasNext()) {
                     class_801 var7 = (class_801)var6.next();
                     var3.sub(var7.getWorldTransformClient().origin, var9);
                     if(var7 != var1.a6().a6() && (var5 == null || var3.length() < var4)) {
                        System.err.println("!!!!!!!!!NEAREST IS NOW " + var7);
                        var5 = var7;
                        var4 = var3.length();
                     }
                  }

                  var1.field_a = var5;
               } else if(Keyboard.getEventKey() == class_367.field_O.a5()) {
                  this.c1();
               }
            }

            if(!super.field_a && super.field_b) {
               if(!field_d && !this.a6().b().isEmpty()) {
                  throw new AssertionError();
               }

               this.a6().a20().a117().handleKeyEvent(Keyboard.getEventKeyState(), Keyboard.getEventKey());
            }
         }

         if(this.a6().b().isEmpty()) {
            super.handleKeyEvent();
         }

      }
   }

   public final void b() {
      class_967.a1().getWorldTransform();
      if(this.a6().a25() != null) {
         this.a6().a25().getWorldTransform();
      } else {
         (new Transform()).setIdentity();
      }

      if(Keyboard.getEventKey() == 52) {
         this.c3((this.field_b + 1) % 8);
         short var1;
         ElementInformation var2;
         if((var1 = this.a54()) != 0 && (var2 = ElementKeyMap.getInfo(var1)).getBlockStyle() > 0) {
            System.err.println("BLOCK ORIENTATION: " + this.field_b + "; " + class_384.field_a[var2.getBlockStyle() - 1][Element.orientationMapping[this.field_b]].toString());
         }
      }

   }

   public final void a12(class_941 var1) {
      if(!this.a6().a27().a92().a5() && !class_11.b1() && this.a6().b().size() <= 0) {
         if(class_943.field_X.a4().equals("SLOTS") && !Keyboard.isKeyDown(42)) {
            this.field_a = FastMath.b1(this.field_a + (var1.field_f > 0?1:(var1.field_f < 0?-1:0)), 10);
         }

         super.a12(var1);
      }
   }

   public final boolean a1() {
      if(this.field_a.containsKey(Integer.valueOf(Keyboard.getEventKey()))) {
         short var1 = this.a54();
         this.field_a = ((Integer)this.field_a.get(Integer.valueOf(Keyboard.getEventKey()))).intValue();
         if(var1 != this.a54()) {
            this.c3(4);
         }

         System.err.println("Selected slot is now: " + this.field_a);
         return true;
      } else {
         return false;
      }
   }

   protected final void a14(boolean var1) {
      super.a14(var1);
      if(var1) {
         this.a6().a20().a117().keyboardOfController.set(Short.valueOf((short)0));
      }

   }

   public final void b2(boolean var1) {
      if(var1) {
         if(!this.field_a.field_b && !this.field_a.field_b && !this.field_a.d1() && !this.field_a.d1()) {
            if(!field_d && this.a6().a3() == null) {
               throw new AssertionError();
            }

            this.field_a.d2(true);
         }
      } else {
         this.a6().a20().a117().keyboardOfController.set(Short.valueOf((short)0));
      }

      super.b2(var1);
   }

   private void d3(int var1) {
      ObjectIterator var2 = this.a6().a7().values().iterator();
      int var3 = var1 > 0?Integer.MAX_VALUE:Integer.MIN_VALUE;
      int var4 = this.field_a != null?this.field_a.getId():-1;

      class_801 var5;
      while(var2.hasNext()) {
         var5 = (class_801)((Sendable)var2.next());
         if(this.field_a == null) {
            this.e3(-var1);
            return;
         }

         if(var1 > 0 && var5.getId() > var4 && var5.getId() < var3) {
            var3 = var5.getId();
         }

         if(var1 <= 0 && var5.getId() < var4 && var5.getId() > var3) {
            var3 = var5.getId();
         }
      }

      if(var3 != Integer.MAX_VALUE && var3 != Integer.MIN_VALUE) {
         if(this.a6().getLocalAndRemoteObjectContainer().getLocalObjects().containsKey(var3)) {
            var5 = (class_801)this.a6().getLocalAndRemoteObjectContainer().getLocalObjects().get(var3);
            this.field_a = var5;
         }

      } else {
         this.e3(var1);
      }
   }

   private void e3(int var1) {
      ObjectIterator var2 = this.a6().a7().values().iterator();
      int var3 = var1 > 0?Integer.MAX_VALUE:Integer.MIN_VALUE;

      class_801 var4;
      while(var2.hasNext()) {
         var4 = (class_801)((Sendable)var2.next());
         if(var1 > 0 && var4.getId() < var3) {
            var3 = var4.getId();
         }

         if(var1 <= 0 && var4.getId() > var3) {
            var3 = var4.getId();
         }
      }

      if(this.a6().getLocalAndRemoteObjectContainer().getLocalObjects().containsKey(var3)) {
         var4 = (class_801)this.a6().getLocalAndRemoteObjectContainer().getLocalObjects().get(var3);
         this.field_a = var4;
      }

   }

   private void c1() {
      if(this.a6().a23() != null && this.a6().a23().a26() != null) {
         class_1381 var1 = this.a6().a23().a26();
         Vector3f var2 = new Vector3f();
         float var3 = 0.0F;
         class_801 var4 = null;
         Vector3f var5 = var1.a1(new Vector3f());
         Iterator var6 = this.a6().a7().values().iterator();

         while(var6.hasNext()) {
            class_801 var7;
            if((var7 = (class_801)var6.next()) != this.a6().a6()) {
               var2.set(var7.getWorldTransform().origin);
               if(this.a6().a6() != null) {
                  var2.sub(this.a6().a6().getWorldTransform().origin);
               } else {
                  var2.sub(class_967.a1().a83());
               }

               Vector3f var8 = var1.a2(var7.getWorldTransformClient().origin, new Vector3f(), true);
               Vector3f var9;
               (var9 = new Vector3f()).sub(var8, var5);
               if(var9.length() < 250.0F && (var4 == null || var9.length() < var3)) {
                  var4 = var7;
                  var3 = var9.length();
               }
            }
         }

         this.field_a = var4;
      }
   }

   public final void c3(int var1) {
      System.err.println("SET ORIENTATION " + var1);
      this.field_b = var1;
   }

   public final void a56(class_801 var1) {
      this.field_a = var1;
   }

   public final void a15(class_935 var1) {
      super.a15(var1);
      if(this.a6().b().isEmpty()) {
         this.a6().a20().a13();
      }

   }

}
