import org.schema.schine.network.client.ClientState;

final class class_136 extends class_928 {

   // $FF: synthetic field
   private class_141 field_a;


   class_136(class_141 var1, ClientState var2, Object var3, class_1410 var4) {
      this.field_a = var1;
      super(var2, 200, 20, var3, var4);
   }

   public final void b() {
      if(((class_371)this.a24()).a50() != null && this.field_a.field_a.getFactionId() == ((class_371)this.a24()).a20().h1() && (this.field_a.field_a instanceof class_848 || this.field_a.field_a instanceof class_780)) {
         super.b();
      }

   }
}
