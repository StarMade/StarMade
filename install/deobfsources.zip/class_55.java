
public final class class_55 {

   public String field_a;
   public String field_b;


   public class_55(String var1, String var2) {
      this.field_a = var1;
      this.field_b = var2;
   }

   public final String toString() {
      return this.field_a;
   }
}
