import java.io.File;
import java.io.IOException;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.graphicsengine.core.ResourceException;

final class class_323 extends class_73 {

   public final void a(class_66 var1) {
      System.err.println("Init noise volume");
      GlUtil.f1();
      class_333.field_a = new class_1385();

      try {
         class_28.a18(new File("data//effects/thruster/NoiseVolume.dds"), class_333.field_a);
      } catch (IOException var2) {
         var2.printStackTrace();
         throw new ResourceException("noise volume");
      }

      GlUtil.f1();
      System.err.println("Init noise volume DONE");
   }
}
