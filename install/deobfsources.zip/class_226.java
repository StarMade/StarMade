import javax.vecmath.Vector3f;

public final class class_226 extends class_1358 {

   Vector3f field_a = new Vector3f();


   public final boolean a7(int var1, class_935 var2) {
      return true;
   }
}
