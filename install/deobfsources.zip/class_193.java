import org.lwjgl.input.Keyboard;
import org.schema.game.common.data.element.Element;
import org.schema.schine.graphicsengine.camera.Camera;

final class class_193 extends Camera {

   private class_298 field_a;
   private class_301 field_a;
   // $FF: synthetic field
   private class_191 field_a;


   public class_193(class_191 var1, class_960 var2) {
      this.field_a = var1;
      super(var2);
      this.field_a = new class_301(this, var1.field_a);
      super.field_a = this.field_a;
      super.field_c = 0.2F;
      super.field_b = 0.2F;
      this.field_a = new class_298(this, var1.field_a);
   }

   public final void a2() {
      super.a2();
      this.getWorldTransform().basis.set(this.field_a.field_a.getWorldTransform().basis);
   }

   public final void a12(class_935 var1) {
      if(this.field_a.field_a.getDockingController().a4() != null) {
         if(this.field_a.field_a != Element.orientationBackMapping[this.field_a.field_a.getDockingController().a4().field_to.b1()] || this.field_a.field_a != this.field_a.field_a.getDockingController().a4().field_to.a7().a15()) {
            System.err.println("NEW LOOKING ALGO " + this.field_a.field_a + " / " + Element.orientationBackMapping[this.field_a.field_a.getDockingController().a4().field_to.b1()] + "; " + this.field_a.field_a + " / " + this.field_a.field_a.getDockingController().a4().field_to.a7().a15());
            this.field_a = new class_298(this, this.field_a.field_a);
         }

         this.field_a.field_a = this.field_a.field_b;
         this.field_a.field_a.set(this.field_a.field_a.getWorldTransform());
         this.field_a.a4(this.field_a.field_a.getDockingController().a4().field_to.a7().a15());
         this.field_a.a5(Element.orientationBackMapping[this.field_a.field_a.getDockingController().a4().field_to.b1()]);
         super.field_a = this.field_a;
      } else {
         super.field_a = this.field_a;
         ((class_301)super.field_a).field_a = this.field_a.field_b;
         ((class_301)super.field_a).field_a.set(this.field_a.field_a.getWorldTransform());
         ((class_301)super.field_a).field_a = this.field_a.field_a;
         class_962 var10000 = super.field_a;
      }

      if(class_1008.a1()) {
         this.e();
         if(class_367.field_m.a6()) {
            super.field_a.a1(0.0F, 0.0F, -0.03F, 0.0F, this.b1(), this.a3());
         }

         if(class_367.field_n.a6()) {
            super.field_a.a1(0.0F, 0.0F, 0.03F, 0.0F, this.b1(), this.a3());
         }

         if(Keyboard.isKeyDown(29)) {
            super.field_a.a1(0.0F, (float)this.field_a.field_c / (float)(class_927.a() / 2), (float)this.field_a.field_b / (float)(class_927.b() / 2), 0.0F, this.b1(), this.a3());
         } else {
            super.field_a.a1((float)this.field_a.field_b / (float)(class_927.b() / 2), (!class_943.field_Y.b1() && !class_943.field_Z.b1()?(float)this.field_a.field_c:(float)(-this.field_a.field_c)) / (float)(class_927.a() / 2), 0.0F, this.a3(), this.b1(), 0.0F);
         }

         if(this.field_a.field_a) {
            this.field_a.field_a.getWorldTransform().basis.setIdentity();
            super.field_a.a6();
            this.field_a.field_a = false;
         }

         this.b32(var1);
      }

   }
}
