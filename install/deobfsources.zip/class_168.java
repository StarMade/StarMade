import org.schema.schine.network.objects.remote.RemoteArray;
import org.schema.schine.network.objects.remote.RemoteStringArray;

final class class_168 extends class_14 {

   // $FF: synthetic field
   private class_93 field_a;


   class_168(class_93 var1, class_371 var2, Object var3, Object var4, String var5) {
      this.field_a = var1;
      super(var2, 50, var3, var4, var5);
   }

   public final String[] getCommandPrefixes() {
      return null;
   }

   public final String handleAutoComplete(String var1, class_1077 var2, String var3) {
      return var1;
   }

   public final boolean a1() {
      return super.field_a.b().indexOf(this) != super.field_a.b().size() - 1;
   }

   public final void a2() {
      this.field_a.a14().e2(false);
   }

   public final void onFailedTextCheck(String var1) {
      this.a9("SHIPNAME INVALID: " + var1);
   }

   public final boolean a7(String var1) {
      class_801 var2;
      if((var2 = super.field_a.a6()) != null && var2 instanceof class_743) {
         RemoteStringArray var3;
         (var3 = new RemoteStringArray(2, super.field_a.a20().a117())).set(0, "#save;" + var2.getId());
         var3.set(1, var1);
         super.field_a.a20().a117().catalogSaveAndBuyBuffer.add((RemoteArray)var3);
         return true;
      } else {
         System.err.println("[ERROR] Player not int a ship");
         return false;
      }
   }
}
