import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;
import org.schema.game.common.controller.SegmentController;

public final class class_220 implements Observer, class_923 {

   private static ArrayList field_a = new ArrayList();
   public static float field_a;
   private final Map field_a = new HashMap();
   private int field_a;
   private final ArrayList field_b = new ArrayList();
   private class_222[] field_a = new class_222[128];


   public final void a2(class_802 var1) {
      ArrayList var10000 = this.field_b;
      class_222 var10001;
      if(field_a.isEmpty()) {
         var10001 = new class_222(var1);
      } else {
         class_222 var2;
         (var2 = (class_222)field_a.remove(0)).a2(var1);
         var10001 = var2;
      }

      var10000.add(var10001);
   }

   public final void a() {}

   public final void d() {
      Iterator var1 = this.field_a.values().iterator();

      while(var1.hasNext()) {
         class_222 var2;
         (var2 = (class_222)var1.next()).deleteObserver(this);
         var2.d();
         field_a.add(var2);
      }

      this.field_a = 0;
      this.field_a.clear();
   }

   public final void b() {
      if(class_943.field_s.b1()) {
         ;
      }
   }

   public final class_222 a3(SegmentController var1) {
      return (class_222)this.field_a.get(var1);
   }

   public final void c() {
      class_967.a2().a4("Sphere").a156().get(0);
   }

   public final void update(Observable var1, Object var2) {
      if(((Boolean)var2).booleanValue()) {
         boolean var5 = true;

         for(int var3 = 0; var3 < this.field_a.length && var3 < this.field_a; ++var3) {
            if(this.field_a[var3] == var1) {
               var5 = false;
               break;
            }
         }

         if(var5 && this.field_a < this.field_a.length) {
            this.field_a[this.field_a] = (class_222)var1;
            ++this.field_a;
         }

      } else {
         if(this.field_a < this.field_a.length) {
            for(int var4 = 0; var4 < this.field_a.length; ++var4) {
               if(this.field_a[var4] == (class_222)var1) {
                  this.field_a[var4] = this.field_a[this.field_a - 1];
                  --this.field_a;
                  return;
               }
            }
         }

      }
   }

   public final void a1(class_935 var1) {
      if((field_a += var1.a()) > 1.0F) {
         field_a -= (float)((int)field_a);
      }

      while(!this.field_b.isEmpty()) {
         class_222 var2;
         (var2 = (class_222)this.field_b.remove(0)).addObserver(this);
         this.field_a.put(var2.field_a, var2);
      }

      for(int var3 = 0; var3 < this.field_a; ++var3) {
         this.field_a[var3].a1(var1);
      }

   }

}
