import org.lwjgl.input.Keyboard;
import org.schema.game.client.controller.PlayerNotYetInitializedException;

public class class_0 extends class_11 {

   private class_198 field_a;
   // $FF: synthetic field
   private static boolean field_b = !D.class.desiredAssertionStatus();


   public class_0(class_371 var1) {
      super(var1);
      this.field_a = new class_198(var1, this, "Spawn Menu");
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var1.b19() != null && !var1.l1() && var1.a_()) {
         class_967.b("0022_action - buttons push small");
      }

      if(var2.field_a && var2.field_a == 0 && !super.field_a.a14().field_a.field_b && !b1()) {
         class_11.field_a = System.currentTimeMillis();

         try {
            if(var1.b19().equals("JOIN")) {
               if(!super.field_a.f()) {
                  class_967.b("0022_menu_ui - enter");
                  super.field_a.a4().e1();
                  this.d();
                  return;
               }
            } else {
               if(var1.b19().equals("EXIT")) {
                  System.err.println("EXIT: WAS: " + var1.l1() + " -> " + var1.a_() + ": " + var1.b19());
                  class_967.b("0022_menu_ui - cancel");
                  System.err.println("[GAMEMENU] MENU EXIT: SYSTEM WILL NOW EXIT");
                  class_927.a3();
                  return;
               }

               if(var1.b19().equals("X")) {
                  class_967.b("0022_menu_ui - cancel");
                  super.field_a.setLastDeactivatedMenu(System.currentTimeMillis());
                  super.field_a.a14().b();
                  return;
               }

               if(!field_b) {
                  throw new AssertionError("not known command: " + var1.b19());
               }
            }

            return;
         } catch (PlayerNotYetInitializedException var3) {
            var3.printStackTrace();
            super.field_a.a4().b1("Login Procedure not finished\n please try again");
         }
      }

   }

   public void handleKeyEvent() {
      if(Keyboard.getEventKeyState()) {
         switch(Keyboard.getEventKey()) {
         case 87:
            super.field_a.a14().field_a.field_a.c2(false);
            super.field_a.a14().field_a.field_a.c2(true);
            this.d();
         }
      }

   }

   public final boolean a1() {
      return super.field_a.b().indexOf(this) != super.field_a.b().size() - 1;
   }

   public final void a2() {}

}
