import javax.vecmath.Vector3f;
import org.schema.game.common.controller.SegmentController;
import org.schema.schine.graphicsengine.camera.Camera;

public final class class_243 extends Camera implements class_197, class_952 {

   private SegmentController field_a;
   private class_1006 field_a;
   private Camera field_a;


   public class_243(Camera var1, class_457 var2) {
      super(new class_199(var2));
      this.field_a = var2.a1();
      super.field_a = new class_1012(this);
      this.field_a = var1;
   }

   public final Vector3f b9() {
      return ((class_199)this.a184()).b9();
   }

   public final void handleKeyEvent() {
      ((class_199)this.a184()).handleKeyEvent();
   }

   public final void a84(class_47 var1) {
      ((class_199)this.a184()).a84(new class_47(var1));
   }

   public final void a12(class_935 var1) {
      if(!class_367.field_U.a6()) {
         ((class_1012)super.field_a).field_a.set(this.field_a.getWorldTransform());
         super.a12(var1);
      }

      if(this.field_a != null && this.field_a.a4()) {
         this.field_a.a12(var1);
         this.getWorldTransform().set(this.field_a.getWorldTransform());
      }

      if(this.field_a != null) {
         this.a78(this.field_a);
         this.field_a = null;
      }

   }

   public final void a78(Camera var1) {
      this.field_a = new class_1006(var1, this);
   }

   public final SegmentController a79() {
      return this.field_a;
   }
}
