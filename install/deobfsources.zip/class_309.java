import com.bulletphysics.linearmath.Transform;
import java.util.Comparator;
import javax.vecmath.Vector3f;

public final class class_309 implements Comparator {

   private Vector3f field_a = new Vector3f();
   private Vector3f field_b = new Vector3f();


   private synchronized int a(class_888 var1, class_888 var2) {
      return var1 != var2 && !var1.equals(var2)?(int)(this.a1(var1) - this.a1(var2)):0;
   }

   private float a1(class_888 var1) {
      Transform var2 = var1.a12().getWorldTransformClient();
      this.field_b.set((float)(var1.a11().field_a + 4 << 4) + var2.origin.field_x - 8.0F, (float)(var1.a11().field_b + 4 << 4) + var2.origin.field_y - 8.0F, (float)(var1.a11().field_c + 4 << 4) + var2.origin.field_z - 8.0F);
      this.field_b.sub(this.field_a);
      return this.field_b.lengthSquared();
   }

   // $FF: synthetic method
   public final int compare(Object var1, Object var2) {
      return this.a((class_888)var1, (class_888)var2);
   }

   // $FF: synthetic method
   static Vector3f a2(class_309 var0) {
      return var0.field_a;
   }
}
