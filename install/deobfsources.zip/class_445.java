import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Iterator;
import org.lwjgl.input.Keyboard;

public final class class_445 extends class_15 {

   public class_443 field_a = new class_443(this.a6());
   public class_469 field_a = new class_469(this.a6());
   public class_303 field_a = new class_303(this.a6());
   public class_334 field_a = new class_334(this.a6());
   public class_338 field_a = new class_338(this.a6());
   public class_475 field_a = new class_475(this.a6());
   public class_18 field_a = new V(this.a6());
   public class_423 field_a = new class_423(this.a6());
   public class_427 field_a = new class_427(this.a6());
   private final ObjectArrayList field_a = new ObjectArrayList();


   public class_445(class_371 var1) {
      super(var1);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      this.field_a.add(this.field_a);
      this.field_a.add(this.field_a);
      this.field_a.add(this.field_a);
      this.field_a.add(this.field_a);
      this.field_a.add(this.field_a);
      this.field_a.add(this.field_a);
      this.field_a.add(this.field_a);
      this.field_a.add(this.field_a);
   }

   public final void a16(class_800 var1) {
      if(this.a6().a25() != null) {
         if(this.a6().a25().a95().a175() == null) {
            this.field_a.a16((class_800)null);
            this.a6().a4().b1("No AI context available\nEither use this in a ship\nwith an AI Module or\nactivate an AI Module externally");
            return;
         }

         this.field_a.a16(this.a6().a25().a95().a175());
      } else {
         this.field_a.a16(var1);
      }

      if(this.field_a.field_b) {
         this.field_a.c2(false);
      }

      if(this.field_a.field_b) {
         this.field_a.c2(false);
      }

      if(this.field_a.field_b) {
         this.field_a.c2(false);
      }

      if(this.field_a.field_b) {
         this.field_a.c2(false);
      }

      if(this.field_a.field_b) {
         this.field_a.c2(false);
      }

      if(this.field_a.field_b) {
         this.field_a.c2(false);
      }

      boolean var2 = !this.field_a.field_b;
      this.field_a.d2(var2);
   }

   public final class_18 a57() {
      return this.field_a;
   }

   public final class_469 a58() {
      return this.field_a;
   }

   public final class_338 a59() {
      return this.field_a;
   }

   public final class_443 a60() {
      return this.field_a;
   }

   public final class_303 a61() {
      return this.field_a;
   }

   public final class_334 a62() {
      return this.field_a;
   }

   public final void b() {
      Iterator var1 = this.field_a.iterator();

      while(var1.hasNext()) {
         ((class_15)var1.next()).c2(false);
      }

      this.field_a.a13(600);
   }

   public final void handleKeyEvent() {
      boolean var1;
      if(Keyboard.getEventKeyState() && this.a6().b().isEmpty()) {
         if(this.field_a.field_b && Keyboard.getEventKey() == class_367.field_w.a5()) {
            this.a63((class_635)null);
         }

         if(Keyboard.getEventKey() == class_367.field_H.a5()) {
            this.a63((class_635)null);
         } else if(Keyboard.getEventKey() == class_367.field_G.a5()) {
            boolean var2 = !this.field_a.field_b;
            if(!this.a6().d2()) {
               this.a6().a4().d1("ERROR: You are not near any shop");
            } else {
               if(this.field_a.field_b) {
                  this.field_a.c2(false);
               }

               if(this.field_a.field_b) {
                  this.field_a.c2(false);
               }

               if(this.field_a.field_b) {
                  this.field_a.c2(false);
               }

               if(this.field_a.field_b) {
                  this.field_a.c2(false);
               }

               if(this.field_a.field_b) {
                  this.field_a.c2(false);
               }

               if(this.field_a.field_b) {
                  this.field_a.c2(false);
               }

               if(this.field_a.field_b) {
                  this.field_a.c2(false);
               }

               this.field_a.d2(var2);
            }
         } else if(Keyboard.getEventKey() == class_367.field_I.a5()) {
            if(!this.field_a.a51().field_b) {
               this.a6().a4().b1("ERROR: Weapon Menu only available\ninside ship");
               return;
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            var1 = !this.field_a.field_b;
            this.field_a.d2(var1);
         } else if(Keyboard.getEventKey() == class_367.field_J.a5()) {
            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            var1 = !this.field_a.field_b;
            this.field_a.d2(var1);
         } else if(Keyboard.getEventKey() == class_367.field_Z.a5()) {
            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            var1 = !this.field_a.field_b;
            System.err.println("ACTIVATE MAP " + var1);
            this.field_a.d2(var1);
         } else if(Keyboard.getEventKey() == class_367.field_K.a5()) {
            this.a16((class_800)null);
         } else if(Keyboard.getEventKey() == class_367.field_Y.a5()) {
            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            if(this.field_a.field_b) {
               this.field_a.c2(false);
            }

            var1 = !this.field_a.field_b;
            this.field_a.d2(var1);
         }
      }

      var1 = false;

      class_15 var3;
      for(Iterator var4 = this.field_a.iterator(); var4.hasNext(); var1 = var1 || var3.field_b) {
         var3 = (class_15)var4.next();
      }

      if(this.field_a.field_a != var1) {
         this.field_a.e2(var1);
      }

      if(this.a6().b().isEmpty()) {
         super.handleKeyEvent();
      }

   }

   public final void a63(class_635 var1) {
      if(this.field_a.field_b) {
         this.field_a.c2(false);
      }

      if(this.field_a.field_b) {
         this.field_a.c2(false);
      }

      if(this.field_a.field_b) {
         this.field_a.c2(false);
      }

      if(this.field_a.field_b) {
         this.field_a.c2(false);
      }

      if(this.field_a.field_b) {
         this.field_a.c2(false);
      }

      if(this.field_a.field_b) {
         this.field_a.c2(false);
      }

      if(this.field_a.field_b) {
         this.field_a.c2(false);
      }

      boolean var2;
      if(var2 = !this.field_a.field_b) {
         class_635 var3 = var1;
         class_469 var4 = this.field_a;
         System.err.println("SECOND INVENTORY SET TO " + var3);
         var4.field_a = var3;
      }

      this.field_a.d2(var2);
   }

   public final void b2(boolean var1) {
      if(var1) {
         this.field_a.c2(false);
         this.field_a.c2(false);
         this.field_a.c2(false);
         this.field_a.c2(false);
         this.field_a.c2(false);
         this.field_a.d2(true);
      } else {
         this.field_a.c2(false);
         this.field_a.c2(false);
         this.field_a.c2(false);
         this.field_a.c2(false);
         this.field_a.c2(false);
      }

      super.b2(var1);
   }

   public final void a15(class_935 var1) {
      boolean var2 = this.field_a.field_b || this.field_a.field_b || this.field_a.field_b || this.field_a.field_b || this.field_a.field_b || this.field_a.field_b;
      if(this.field_a.field_a != var2) {
         this.field_a.e2(var2);
      }

      super.a15(var1);
   }

   public final class_423 a64() {
      return this.field_a;
   }

   public final class_427 a65() {
      return this.field_a;
   }

   public final class_475 a66() {
      return this.field_a;
   }
}
