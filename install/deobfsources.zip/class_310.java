
final class class_310 implements class_954 {

   // $FF: synthetic field
   private short field_a;
   // $FF: synthetic field
   private class_304 field_a;


   class_310(class_304 var1, short var2) {
      this.field_a = var1;
      this.field_a = var2;
      super();
   }

   public final boolean a(String var1, class_1077 var2) {
      try {
         if(var1.length() > 0) {
            int var7 = Integer.parseInt(var1);
            int var3 = this.field_a.a6().a20().getInventory((class_47)null).b6(this.field_a);
            class_739 var4;
            if((var4 = this.field_a.a6().a5()) == null) {
               this.field_a.a6().a4().b1("ERROR: no shop available");
               return false;
            }

            if(var7 <= 0) {
               this.field_a.a6().a4().b1("ERROR: Invalid quantity");
               return false;
            }

            int var5;
            if((var5 = var4.a90().a42(this.field_a)) >= 0) {
               int var10000 = var4.a90().a41(var5) + var7;
               var4.a90();
               if(var10000 > class_653.e()) {
                  this.field_a.a6().a4().b1("ERROR: Shop cannot stock any\nmore of that item!");
                  class_1075 var8 = this.field_a.a8();
                  var4.a90();
                  var8.a9(String.valueOf(class_653.e() - var4.a90().a41(var5)));
                  this.field_a.a8().e();
                  return false;
               }
            }

            if(var7 <= var3) {
               class_967.b("0022_action - receive credits");
               return true;
            }

            this.field_a.a6().a4().b1("ERROR\nYou can\'t sell that many!\nYou can only sell " + var3 + "!");
            this.field_a.a8().a9(String.valueOf(var3));
            this.field_a.a8().e();
            this.field_a.a8().g1();
            return false;
         }
      } catch (NumberFormatException var6) {
         ;
      }

      var2.onFailedTextCheck("Please only enter numbers!");
      return false;
   }
}
