import com.bulletphysics.linearmath.Transform;
import javax.vecmath.Quat4f;
import javax.vecmath.Vector3f;
import org.schema.common.FastMath;
import org.schema.schine.graphicsengine.camera.Camera;
import org.schema.schine.graphicsengine.core.GlUtil;

public final class class_301 implements class_962 {

   private Camera field_a;
   private Vector3f field_a = new Vector3f();
   private Quat4f field_a = new Quat4f(0.0F, 0.0F, 0.0F, 1.0F);
   boolean field_a;
   int field_a = 4;
   private class_1432 field_a;
   private final Transform field_b = new Transform();
   final Transform field_a = new Transform();
   private final Transform field_c = new Transform();
   private final Transform field_d = new Transform();
   private float field_a = 0.7853982F;
   private int field_b = 0;
   private boolean field_b = true;


   public class_301(Camera var1, class_1432 var2) {
      this.field_a = var1;
      this.field_a = var2;
      this.field_a.setIdentity();
      this.field_c.setIdentity();
      this.field_b.set(var2.getWorldTransform());
   }

   public final void a6() {
      this.field_a.setIdentity();
      this.field_c.setIdentity();
      this.field_b.set(this.field_a.getWorldTransform());
   }

   private void a(Vector3f var1, Vector3f var2, Vector3f var3, Transform var4) {
      switch(this.field_a) {
      case 0:
         GlUtil.d(var1, var4);
         GlUtil.f(var2, var4);
         GlUtil.c(var3, var4);
         return;
      case 1:
         GlUtil.e(var1, var4);
         GlUtil.f(var2, var4);
         GlUtil.c(var3, var4);
         return;
      case 2:
         GlUtil.f(var1, var4);
         GlUtil.e(var2, var4);
         GlUtil.c(var3, var4);
         return;
      case 3:
         GlUtil.b(var1, var4);
         GlUtil.d(var2, var4);
         GlUtil.c(var3, var4);
      case 4:
         GlUtil.c(var1, var4);
         GlUtil.f(var2, var4);
         GlUtil.e(var3, var4);
         return;
      case 5:
         GlUtil.c(var1, var4);
         GlUtil.f(var2, var4);
         GlUtil.e(var3, var4);
         var1.negate();
         var3.negate();
         return;
      default:
      }
   }

   public final void a1(float var1, float var2, float var3, float var4, float var5, float var6) {
      this.field_d.set(this.field_a.getWorldTransform());
      this.field_b = 0;
      this.field_a.field_x = -var1 * var4;
      this.field_a.field_y = var2 * var5;
      this.field_a.field_z = var3 * var6;
      class_301 var10 = this;

      Vector3f var12;
      Vector3f var15;
      Vector3f var16;
      while(true) {
         var12 = new Vector3f();
         var15 = new Vector3f();
         var16 = new Vector3f();
         var10.a(var12, var15, var16, var10.field_a.getWorldTransform());
         if(var10.field_b) {
            var10.field_a.a163(var12);
            var10.field_a.c12(var15);
            var10.field_a.b25(var16);
            var10.field_b = false;
            var10.field_c.set(var10.field_a.getWorldTransform());
         }

         var10.field_a.getWorldTransform().set(var10.field_c);
         Vector3f var17;
         (var17 = new Vector3f()).cross(var12, var15);
         (var17 = new Vector3f(var17)).normalize();
         float var7 = var10.field_a.field_y;
         if(var10.field_a.field_y > 1.0F) {
            var7 = 1.0F;
         }

         if(var7 < -1.0F) {
            var7 = -1.0F;
         }

         Quat4f var19;
         if(var10.field_a.field_y == 0.0F) {
            var19 = new Quat4f(0.0F, 0.0F, 0.0F, 1.0F);
         } else {
            var19 = new Quat4f(var17.field_x * FastMath.h(var7), var17.field_y * FastMath.h(var7), var17.field_z * FastMath.h(var7), FastMath.d(var7));
         }

         (var17 = new Vector3f(var15)).normalize();
         float var8 = var10.field_a.field_x;
         if(var10.field_a.field_x > 1.0F) {
            var8 = 1.0F;
         }

         if(var8 < -1.0F) {
            var8 = -1.0F;
         }

         Quat4f var20;
         if(var10.field_a.field_x == 0.0F) {
            var20 = new Quat4f(0.0F, 0.0F, 0.0F, 1.0F);
         } else {
            var20 = new Quat4f(var17.field_x * FastMath.h(var8), var17.field_y * FastMath.h(var8), var17.field_z * FastMath.h(var8), FastMath.d(var8));
         }

         (var17 = new Vector3f(var12)).normalize();
         float var9 = var10.field_a.field_z;
         if(var10.field_a.field_z > 1.0F) {
            var9 = 1.0F;
         }

         if(var9 < -1.0F) {
            var9 = -1.0F;
         }

         Quat4f var18;
         if(var10.field_a.field_z == 0.0F) {
            var18 = new Quat4f(0.0F, 0.0F, 0.0F, 1.0F);
         } else {
            var18 = new Quat4f(var17.field_x * FastMath.h(var9), var17.field_y * FastMath.h(var9), var17.field_z * FastMath.h(var9), FastMath.d(var9));
         }

         var10.field_a.mul(var19, var20);
         var10.field_a.mul(var18);
         var10.field_a.normalize();
         (var18 = new Quat4f()).conjugate(var10.field_a);
         var19 = new Quat4f(var10.field_a.c10().field_x, var10.field_a.c10().field_y, var10.field_a.c10().field_z, 0.0F);
         (var20 = new Quat4f()).mul(var10.field_a, var19);
         var20.mul(var18);
         var12.field_x = var20.field_x;
         var12.field_y = var20.field_y;
         var12.field_z = var20.field_z;
         var12.normalize();
         var19 = new Quat4f(var10.field_a.f5().field_x, var10.field_a.f5().field_y, var10.field_a.f5().field_z, 0.0F);
         var20.mul(var10.field_a, var19);
         var20.mul(var18);
         var15.field_x = var20.field_x;
         var15.field_y = var20.field_y;
         var15.field_z = var20.field_z;
         var15.normalize();
         var19 = new Quat4f(var10.field_a.e7().field_x, var10.field_a.e7().field_y, var10.field_a.e7().field_z, 0.0F);
         var20.mul(var10.field_a, var19);
         var20.mul(var18);
         var16.field_x = var20.field_x;
         var16.field_y = var20.field_y;
         var16.field_z = var20.field_z;
         var16.normalize();
         Transform var24 = var10.field_a.getWorldTransform();
         var17 = var16;
         var16 = var15;
         var15 = var12;
         class_301 var14 = var10;
         Vector3f var22 = new Vector3f();
         Vector3f var23 = new Vector3f();
         Vector3f var11 = new Vector3f();
         var14.a(var22, var23, var11, var24);
         Vector3f var21 = new Vector3f(var22);
         var15.normalize();
         var17.normalize();
         if(var21.angle(var15) < var14.field_a) {
            var14.field_a.a163(var15);
            var14.field_a.b25(var17);
            var14.field_a.c12(var16);
            break;
         }

         var14.field_a.scale(0.5F);
         if(var14.field_b >= 10) {
            break;
         }

         ++var14.field_b;
         var10 = var14;
      }

      if(this.field_a) {
         Transform var13;
         (var13 = new Transform(this.field_a.getWorldTransform())).basis.sub(this.field_b.basis);
         var12 = new Vector3f();
         var15 = new Vector3f();
         var16 = new Vector3f();
         this.a(var12, var15, var16, var13);
         GlUtil.a30(var12, var13);
         GlUtil.d2(var15, var13);
         GlUtil.c3(var16, var13);
         this.field_a.getWorldTransform().basis.add(var13.basis);
         this.field_b.set(this.field_a.getWorldTransform());
      }

      this.field_c.set(this.field_a.getWorldTransform());
   }
}
