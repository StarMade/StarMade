
final class class_410 extends class_13 {

   // $FF: synthetic field
   private class_423 field_a;


   class_410(class_423 var1, class_371 var2, Object var3, Object var4, String var5) {
      this.field_a = var1;
      super(var2, 5, var3, var4, var5);
   }

   public final boolean a1() {
      return false;
   }

   public final void onFailedTextCheck(String var1) {}

   public final String handleAutoComplete(String var1, class_1077 var2, String var3) {
      return null;
   }

   public final String[] getCommandPrefixes() {
      return null;
   }

   public final boolean a7(String var1) {
      return super.field_a.a20().a132().b39(var1);
   }

   public final void a2() {
      this.field_a.e2(false);
   }
}
