
// $FF: synthetic class
final class class_80 {

   // $FF: synthetic field
   static final int[] field_a = new int[class_81.values().length];


   static {
      try {
         field_a[class_81.field_a.ordinal()] = 1;
      } catch (NoSuchFieldError var14) {
         ;
      }

      try {
         field_a[class_81.field_b.ordinal()] = 2;
      } catch (NoSuchFieldError var13) {
         ;
      }

      try {
         field_a[class_81.field_c.ordinal()] = 3;
      } catch (NoSuchFieldError var12) {
         ;
      }

      try {
         field_a[class_81.field_d.ordinal()] = 4;
      } catch (NoSuchFieldError var11) {
         ;
      }

      try {
         field_a[class_81.field_e.ordinal()] = 5;
      } catch (NoSuchFieldError var10) {
         ;
      }

      try {
         field_a[class_81.field_f.ordinal()] = 6;
      } catch (NoSuchFieldError var9) {
         ;
      }

      try {
         field_a[class_81.field_g.ordinal()] = 7;
      } catch (NoSuchFieldError var8) {
         ;
      }

      try {
         field_a[class_81.field_h.ordinal()] = 8;
      } catch (NoSuchFieldError var7) {
         ;
      }

      try {
         field_a[class_81.field_i.ordinal()] = 9;
      } catch (NoSuchFieldError var6) {
         ;
      }

      try {
         field_a[class_81.field_j.ordinal()] = 10;
      } catch (NoSuchFieldError var5) {
         ;
      }

      try {
         field_a[class_81.field_k.ordinal()] = 11;
      } catch (NoSuchFieldError var4) {
         ;
      }

      try {
         field_a[class_81.field_l.ordinal()] = 12;
      } catch (NoSuchFieldError var3) {
         ;
      }

      try {
         field_a[class_81.field_m.ordinal()] = 13;
      } catch (NoSuchFieldError var2) {
         ;
      }

      try {
         field_a[class_81.field_n.ordinal()] = 14;
      } catch (NoSuchFieldError var1) {
         ;
      }

      try {
         field_a[class_81.field_o.ordinal()] = 15;
      } catch (NoSuchFieldError var0) {
         ;
      }
   }
}
