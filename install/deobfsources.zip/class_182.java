
// $FF: synthetic class
final class class_182 {

   // $FF: synthetic field
   static final int[] field_a = new int[class_180.values().length];


   static {
      try {
         field_a[class_180.field_a.ordinal()] = 1;
      } catch (NoSuchFieldError var3) {
         ;
      }

      try {
         field_a[class_180.field_d.ordinal()] = 2;
      } catch (NoSuchFieldError var2) {
         ;
      }

      try {
         field_a[class_180.field_b.ordinal()] = 3;
      } catch (NoSuchFieldError var1) {
         ;
      }

      try {
         field_a[class_180.field_c.ordinal()] = 4;
      } catch (NoSuchFieldError var0) {
         ;
      }
   }
}
