import org.schema.schine.network.client.ClientState;

final class class_105 extends class_928 {

   public class_105(class_112 var1, ClientState var2, int var3) {
      super(var2, 120, 20, class_112.a20(var1).a171().a60()[var3], var1);
      super.field_a = new Integer(var3);
   }
}
