import javax.vecmath.Vector4f;
import org.schema.schine.network.client.ClientState;

public final class class_91 extends class_196 {

   private class_1410 field_b;


   public class_91(ClientState var1, class_1410 var2, class_785 var3) {
      super(var1, var2, "Rate", "Rate " + var3.field_a);
      super.field_a = false;
      this.field_b = var2;
   }

   public final void c() {
      super.c();

      for(int var1 = 0; var1 < 10; ++var1) {
         float var2 = (float)var1 / 10.0F;
         class_928 var4;
         (var4 = new class_928(this.a24(), 30, 30, new Vector4f(1.0F - var2, var2, 0.2F, 1.0F), new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), class_28.e(), String.valueOf(var1 + 1), this.field_b)).field_a = new Integer(var1);
         if(var1 < 9) {
            var4.b14(6, 0);
         }

         int var3 = var1 * 40;
         var4.a165((float)var3, 35.0F, 0.0F);
         this.field_a.a9(var4);
      }

   }
}
