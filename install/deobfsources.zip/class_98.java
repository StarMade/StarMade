
final class class_98 {

   // $FF: synthetic field
   private class_777 field_a;
   // $FF: synthetic field
   private class_101 field_a;


   class_98(class_101 var1, class_777 var2) {
      this.field_a = var1;
      this.field_a = var2;
      super();
   }

   public final String toString() {
      if(this.field_a.a3() == ((class_371)this.field_a.a24()).a20().a132().a3()) {
         return "*own*";
      } else {
         class_769 var1;
         boolean var2 = (var1 = ((class_371)this.field_a.a24()).a45()).a148(this.field_a.a3(), ((class_371)this.field_a.a24()).a20().a132().a3());
         boolean var3 = var1.b26(this.field_a.a3(), ((class_371)this.field_a.a24()).a20().a132().a3());
         return var2?"Enemy":(var3?"Ally":"Neutral");
      }
   }
}
