import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class class_71 {

   private static Pattern field_a = Pattern.compile("(.*)-([0-9]+x[0-9]+)(.*)");
   private final HashMap field_a;


   public class_71() {
      new HashMap();
      this.field_a = new HashMap();
   }

   public final HashMap a() {
      return this.field_a;
   }

   public final void a1(String var1, String var2) {
      long var4 = System.currentTimeMillis();
      class_1389 var3 = class_967.a3().a6(var1, !var2.contains("-gui-"));
      class_1382 var6;
      (var6 = new class_1382(var3)).c11(var2);
      var6.d10(var2.contains("-c-"));
      Matcher var7;
      if((var7 = field_a.matcher(var1)).matches()) {
         String[] var9;
         int var10 = Integer.parseInt((var9 = var7.group(2).split("x"))[0]);
         int var11 = Integer.parseInt(var9[1]);
         int var8 = var10 * var11;
         System.err.println("MULTITEXTURE: " + var10 + "x" + var11 + " : " + var8);
         var6.a146(var10, var11);
         var6.c4(var3.field_b / var10);
         var6.a72(var3.field_a / var11);
      }

      var6.c();
      this.field_a.put(var2, var6);
      long var12;
      if((var12 = System.currentTimeMillis() - var4) > 300L) {
         System.err.println("[WARNING] initializing Texture " + var1 + " took " + var12 + " ms");
      }

   }

}
