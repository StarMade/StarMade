import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import org.lwjgl.input.Keyboard;
import org.schema.common.ParseException;
import org.schema.schine.network.objects.remote.RemoteBuffer;
import org.schema.schine.network.objects.remote.RemoteShort;
import org.schema.schine.network.objects.remote.Streamable;

public enum class_367 {

   field_a("STRAFE_LEFT", 0, 30, "Strafe Left", class_369.field_a, (short)1),
   field_b("STRAFE_RIGHT", 1, 32, "Strafe right", class_369.field_a, (short)2),
   field_c("FORWARD", 2, 17, "Forward", class_369.field_a, (short)4),
   field_d("BACKWARDS", 3, 31, "Backwards", class_369.field_a, (short)8),
   field_e("UP", 4, 18, "Strafe Up", class_369.field_a, (short)16),
   field_f("DOWN", 5, 16, "Strafe Down", class_369.field_a, (short)32),
   field_g("STRAFE_LEFT_SHIP", 6, 30, "Strafe Left", class_369.field_d, (short)1),
   field_h("STRAFE_RIGHT_SHIP", 7, 32, "Strafe right", class_369.field_d, (short)2),
   field_i("FORWARD_SHIP", 8, 17, "Forward", class_369.field_d, (short)4),
   field_j("BACKWARDS_SHIP", 9, 31, "Backwards", class_369.field_d, (short)8),
   field_k("UP_SHIP", 10, 18, "Strafe Up", class_369.field_d, (short)16),
   field_l("DOWN_SHIP", 11, 16, "Strafe Down", class_369.field_d, (short)32),
   field_m("ROTATE_LEFT_SHIP", 12, 44, "Rotate Left", class_369.field_d, (short)512),
   field_n("ROTATE_RIGHT_SHIP", 13, 45, "Rotate Right", class_369.field_d, (short)1024),
   field_o("DROP_ITEM", 14, 14, "Drop Item", class_369.field_a, (short)-1),
   field_p("BREAK", 15, 42, "Break", class_369.field_d, (short)64),
   field_q("ROLL", 16, 29, "Roll Ship", class_369.field_d, (short)-1),
   field_r("CHANGE_SHIP_MODE", 17, 57, "Change Ship Mode", class_369.field_c, (short)128),
   field_s("JUMP", 18, 57, "Jump", class_369.field_b, (short)256),
   field_t("JUMP_TO_MODULE", 19, 45, "Jump to module", class_369.field_e, (short)-1),
   field_u("FREE_SHIP_CAM", 20, 54, "Free Ship Camera", class_369.field_d, (short)-1),
   field_v("ENTER_SHIP", 21, 19, "Exit Ship", class_369.field_c, (short)-1),
   field_w("ACTIVATE", 22, 19, "Activate Module", class_369.field_b, (short)-1),
   field_x("SPAWN_SHIP", 23, 45, "Spawn Ship", class_369.field_b, (short)-1),
   field_y("SPAWN_SPACE_STATION", 24, 50, "Spawn Space Station", class_369.field_b, (short)-1),
   field_z("SELECT_MODULE", 25, 46, "Select Module", class_369.field_e, (short)-1),
   field_A("CONNECT_MODULE", 26, 47, "Connect Module", class_369.field_e, (short)-1),
   field_B("HELP", 27, 87, "Help Screen", class_369.field_a, (short)-1),
   field_C("SWITCH_COCKPIT_SHIP_NEXT", 28, 200, "Docking Ship", class_369.field_d, (short)-1),
   field_D("SWITCH_COCKPIT_NEXT", 29, 205, "Next Cockpit", class_369.field_d, (short)-1),
   field_E("SWITCH_COCKPIT_PREVIOUS", 30, 203, "Previous Cockpit", class_369.field_d, (short)-1),
   field_aa("TEAM_CHANGE", 31, 36, "Change Team", class_369.field_a, (short)-1),
   field_F("CHAT", 32, 28, "Chat", class_369.field_a, (short)-1),
   field_G("SHOP_PANEL", 33, 48, "Shop Menu", class_369.field_a, (short)-1),
   field_H("INVENTORY_PANEL", 34, 23, "Inventory Menu", class_369.field_a, (short)-1),
   field_I("WEAPON_PANEL", 35, 20, "Weapon Menu", class_369.field_a, (short)-1),
   field_J("NAVIGATION_PANEL", 36, 49, "Navigation Menu", class_369.field_a, (short)-1),
   field_K("AI_CONFIG_PANEL", 37, 38, "AI Config Menu", class_369.field_a, (short)-1),
   field_L("SELECT_NEXT_ENTITY", 38, 22, "Select Next Entity", class_369.field_a, (short)-1),
   field_M("SELECT_PREV_ENTITY", 39, 21, "Select Previous Entity", class_369.field_a, (short)-1),
   field_N("SELECT_NEAR_ENTITY", 40, 34, "Select Nearest Entity", class_369.field_a, (short)-1),
   field_O("SELECT_LOOK_ENTITY", 41, 33, "Select Targeted Entity", class_369.field_a, (short)-1),
   field_P("RELEASE_MOUSE", 42, 60, "Release Mouse", class_369.field_a, (short)-1),
   field_Q("PLAYER_STATISTICS", 43, 15, "Player Statistics", class_369.field_a, (short)-1),
   field_R("NEXT_CONTROLLER", 44, 205, "Select next controller", class_369.field_e, (short)-1),
   field_S("PREVIOUS_CONTROLLER", 45, 203, "Select prev controller", class_369.field_e, (short)-1),
   field_T("SELECT_CORE", 46, 200, "Select core", class_369.field_e, (short)-1),
   field_U("BUILD_MODE_FIX_CAM", 47, class_1268.a() == class_1268.field_d?12:29, "Advanced Build Mode", class_369.field_e, (short)-1),
   field_V("ALIGN_SHIP", 48, 46, "Align Ship Cam", class_369.field_d, (short)-1),
   field_W("SCREENSHOT_WITH_GUI", 49, 63, "Screenshot (with GUI)", class_369.field_a, (short)-1),
   field_X("SCREENSHOT_WITHOUT_GUI", 50, 64, "Screenshot (without GUI)", class_369.field_a, (short)-1),
   field_Y("FACTION_MENU", 51, 35, "Open Faction Menu", class_369.field_a, (short)-1),
   field_Z("MAP_PANEL", 52, 25, "Map", class_369.field_a, (short)-1);
   private final int field_a;
   private final String field_a;
   private int field_b;
   public static final class_367[] field_a;
   private final class_369 field_a;
   private final short field_a;
   // $FF: synthetic field
   private static final class_367[] field_b = new class_367[]{field_a, field_b, field_c, field_d, field_e, field_f, field_g, field_h, field_i, field_j, field_k, field_l, field_m, field_n, field_o, field_p, field_q, field_r, field_s, field_t, field_u, field_v, field_w, field_x, field_y, field_z, field_A, field_B, field_C, field_D, field_E, field_aa, field_F, field_G, field_H, field_I, field_J, field_K, field_L, field_M, field_N, field_O, field_P, field_Q, field_R, field_S, field_T, field_U, field_V, field_W, field_X, field_Y, field_Z};
   // $FF: synthetic field
   private static boolean field_a = !cv.class.desiredAssertionStatus();


   public final boolean a(Short var1) {
      if(!field_a && this.field_a <= 0) {
         throw new AssertionError();
      } else {
         return (var1.shortValue() & this.field_a) == this.field_a;
      }
   }

   public final void a1(RemoteShort var1) {
      if(Keyboard.isCreated()) {
         if(Keyboard.isKeyDown(this.field_b)) {
            var1.set(Short.valueOf((short)(((Short)var1.get()).shortValue() | this.field_a)));
         } else {
            var1.set(Short.valueOf((short)(((Short)var1.get()).shortValue() & ~this.field_a)));
         }
      }
   }

   public static void a2() {
      try {
         String[] var0 = new String[values().length + 1];
         String[] var1 = new String[values().length + 1];
         File var2 = new File("./keyboard.cfg");
         BufferedReader var8 = new BufferedReader(new FileReader(var2));
         String var3 = null;

         int var4;
         for(var4 = 0; (var3 = var8.readLine()) != null; ++var4) {
            String[] var9 = var3.split(" = ", 2);
            var0[var4] = var9[0];
            var1[var4] = var9[1].trim();
            if(var4 == 0 && !var0[0].equals("#version")) {
               System.err.println("UNKNOWN VERSION!! RESETTING KEYS");
               return;
            }

            if(var4 == 0 && var0[0].equals("#version") && Integer.parseInt(var1[var4]) != 0) {
               System.err.println("OLD VERSION!! RESETTING KEYS");
            }

            System.err.println("KEY: " + var0[var4] + " = " + var1[var4]);
         }

         for(var4 = 1; var4 < var0.length; ++var4) {
            try {
               int var10;
               if((var10 = Keyboard.getKeyIndex(var1[var4])) == 0) {
                  throw new ParseException("Key not known: " + var1[var4]);
               }

               class_367 var10000 = valueOf(var0[var4]);
               var3 = null;
               var10000.field_b = var10;
            } catch (ParseException var6) {
               var3 = null;
               var6.printStackTrace();
            }
         }

         var8.close();
      } catch (Exception var7) {
         var7.printStackTrace();
         System.err.println("Could not read settings file: using defaults (" + var7.getMessage() + ")");
      }
   }

   public static void b() {
      File var0;
      (var0 = new File("./keyboard.cfg")).delete();
      var0.createNewFile();
      BufferedWriter var5;
      (var5 = new BufferedWriter(new FileWriter(var0))).write("#version = 0");
      var5.newLine();
      class_367[] var1;
      int var2 = (var1 = values()).length;

      for(int var3 = 0; var3 < var2; ++var3) {
         class_367 var4 = var1[var3];
         var5.write(var4.name() + " = " + Keyboard.getKeyName(var4.field_b));
         var5.newLine();
      }

      var5.flush();
      var5.close();
   }

   private class_367(String var1, int var2, int var3, String var4, class_369 var5, short var6) {
      this.field_a = var3;
      this.field_a = var4;
      this.field_b = this.field_a;
      this.field_a = var5;
      this.field_a = var6;
   }

   public final class_369 a3() {
      return this.field_a;
   }

   public final String a4() {
      return this.field_a;
   }

   public final String b1() {
      return Keyboard.getKeyName(this.field_b);
   }

   public final int a5() {
      return this.field_b;
   }

   public final boolean a6() {
      return Keyboard.isKeyDown(this.field_b);
   }

   public final void a7(int var1) {
      this.field_b = var1;
   }

   public final void a8(RemoteBuffer var1, boolean var2, boolean var3) {
      var1.add((Streamable)(new RemoteShort((short)(var2?this.field_a:-this.field_a), var3)));
   }

   public final boolean a9(int var1) {
      return this.field_a == var1;
   }

   static {
      ObjectArrayList var0 = new ObjectArrayList();
      class_367[] var1;
      int var2 = (var1 = values()).length;

      for(int var3 = 0; var3 < var2; ++var3) {
         class_367 var4;
         if((var4 = var1[var3]).field_a > 0) {
            var0.add(var4);
         }
      }

      field_a = new class_367[var0.size()];

      for(int var5 = 0; var5 < field_a.length; ++var5) {
         field_a[var5] = (class_367)var0.get(var5);
      }

   }
}
