import com.bulletphysics.collision.dispatch.CollisionWorld;
import com.bulletphysics.linearmath.Transform;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import javax.vecmath.Matrix4f;
import javax.vecmath.Vector3f;
import org.lwjgl.input.Keyboard;
import org.schema.common.FastMath;
import org.schema.game.common.controller.CannotBeControlledException;
import org.schema.game.common.controller.CannotImmediateRequestOnClientException;
import org.schema.game.common.controller.SegmentBufferManager;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.controller.elements.ElementCollectionManager;
import org.schema.game.common.controller.elements.ManagerModule;
import org.schema.game.common.controller.elements.UsableControllableElementManager;
import org.schema.game.common.controller.elements.UsableControllableSingleElementManager;
import org.schema.game.common.data.element.ElementCollection;
import org.schema.game.common.data.physics.CubeRayCastResult;
import org.schema.game.common.data.physics.PhysicsExt;
import org.schema.game.common.data.world.Segment;
import org.schema.schine.graphicsengine.core.GlUtil;

public class class_453 extends class_485 {

   private boolean field_d;
   private final class_433 field_a = new class_433();
   private class_243 field_a;
   private class_457 field_a;
   private class_800 field_a;
   private CollisionWorld.ClosestRayResultCallback field_a;
   private class_47 field_a;
   private boolean field_e;
   private ArrayList field_a;
   private int field_a;
   private Segment field_a;
   private boolean field_f;
   private SegmentController field_a;
   private long field_b;
   private class_709 field_a;
   private int field_b;
   private int field_c;
   private int field_d;
   private ElementCollectionManager field_a;
   private ArrayList field_b;
   // $FF: synthetic field
   private static boolean field_g = !au.class.desiredAssertionStatus();


   public class_453(class_371 var1, class_457 var2) {
      super(var1);
      new Matrix4f();
      new Matrix4f();
      this.field_a = new class_47();
      this.field_a = new ArrayList();
      this.field_b = 0;
      this.field_c = 0;
      this.field_d = 0;
      this.field_a = var2;
   }

   public final SegmentController a68() {
      return this.field_a.a1();
   }

   public final class_800 a40() {
      return this.field_a;
   }

   private void a69(int var1, boolean var2) {
      while(true) {
         class_802 var3 = (class_802)this.a68();
         if(var1 == Integer.MIN_VALUE) {
            this.a6().a27().a99().a39((Collection)null, (class_801)null);
            return;
         }

         if(var2) {
            this.field_a = null;
            this.field_b = 0;
         }

         if(this.field_a == null) {
            this.field_c = FastMath.b1(this.field_c + var1, var3.a().getModules().size());
            if(this.field_b != null && this.field_d < this.field_b.size() && !var2) {
               this.field_a = (ElementCollectionManager)this.field_b.get(this.field_d);
               ++this.field_d;
            } else {
               this.field_d = 0;
               this.field_b = null;
               ManagerModule var4;
               if((var4 = (ManagerModule)var3.a().getModules().get(this.field_c)).getElementManager() instanceof UsableControllableElementManager) {
                  UsableControllableElementManager var5 = (UsableControllableElementManager)var4.getElementManager();
                  this.field_b = var5.getCollectionManagers();
                  if(var5.getCollectionManagers().size() <= 0) {
                     this.field_a = null;
                     continue;
                  }

                  this.field_a = (ElementCollectionManager)var5.getCollectionManagers().get(0);
               } else if(var4.getElementManager() instanceof UsableControllableSingleElementManager) {
                  UsableControllableSingleElementManager var6 = (UsableControllableSingleElementManager)var4.getElementManager();
                  this.field_a = var6.getCollection();
               }
            }

            if(this.field_a != null && this.field_a.getCollection().size() == 0) {
               this.field_a = null;
               continue;
            }
         }

         if(this.field_a != null && this.field_b < this.field_a.getCollection().size() && this.field_b >= 0) {
            ElementCollection var7 = (ElementCollection)this.field_a.getCollection().get(this.field_b);
            if(Keyboard.isKeyDown(71)) {
               this.a6().a27().a99().a39(this.field_a.rawCollection, (class_801)var3);
            } else {
               this.a6().a27().a99().a39(var7.getNeighboringCollection(), (class_801)var3);
            }

            this.field_b = FastMath.b1(this.field_b + var1, var3.a().getModules().size());
            return;
         }

         this.field_b = 0;
         this.field_a = null;
         return;
      }
   }

   public void handleKeyEvent() {
      if(Keyboard.getEventKeyState()) {
         class_24 var10000 = this.a6().a14();
         class_47 var4 = null;
         class_443 var11 = var10000.field_a.field_a.field_a;
         Keyboard.getEventKey();
         if(var11.a1()) {
            return;
         }

         if(Keyboard.getEventKey() == 73) {
            this.a69(1, false);
         }

         if(Keyboard.getEventKey() == 72) {
            this.a69(-1, false);
         }

         if(Keyboard.getEventKey() == 77) {
            this.a69(1, true);
         }

         if(Keyboard.getEventKey() == 76) {
            this.a69(-1, true);
         }

         if(Keyboard.getEventKey() == 80) {
            this.a69(Integer.MIN_VALUE, true);
         }

         if(Keyboard.getEventKey() == class_367.field_B.a5()) {
            this.field_d = !this.field_d;
         } else {
            class_453 var1;
            if(Keyboard.getEventKey() == class_367.field_z.a5()) {
               var1 = this;
               if(this.field_e && this.field_a != null) {
                  if(this.field_a != null && this.field_a.a2(new class_47()).equals(this.field_a)) {
                     this.field_a = null;
                  } else {
                     try {
                        var1.field_a = var1.field_a.a1().getSegmentBuffer().a9(var1.field_a, true);
                     } catch (CannotImmediateRequestOnClientException var8) {
                        var8.printStackTrace();
                     }
                  }
               }
            } else if(!Keyboard.isKeyDown(42) && Keyboard.getEventKey() == class_367.field_R.a5()) {
               this.f2(true);
            } else if(!Keyboard.isKeyDown(42) && Keyboard.getEventKey() == class_367.field_S.a5()) {
               this.f2(false);
            } else if(!Keyboard.isKeyDown(42) && Keyboard.getEventKey() == class_367.field_T.a5()) {
               var1 = this;
               if(!this.field_a.isEmpty()) {
                  try {
                     var1.field_a = var1.field_a.a1().getSegmentBuffer().a9(var1.field_a.a(), true);
                     var1.field_a = Math.max(0, var1.field_a.indexOf(var1.field_a.a()));
                  } catch (CannotImmediateRequestOnClientException var7) {
                     var7.printStackTrace();
                  }
               }
            } else if(!Keyboard.isKeyDown(42) && Keyboard.getEventKey() == class_367.field_t.a5()) {
               this.field_a.a84(new class_47(8, 8, 0));
            } else if(!Keyboard.isKeyDown(42) && Keyboard.getEventKey() == class_367.field_A.a5()) {
               var1 = this;
               System.err.println("[CLIENT][SEGBUILDCONTROLLER] NORMAL CONNECTION");

               try {
                  var1.field_a.a1().setCurrentBlockController(var1.field_a, var1.field_a);
               } catch (CannotBeControlledException var6) {
                  this.a81(var6);
               }
            } else if(Keyboard.isKeyDown(42) && Keyboard.getEventKey() == class_367.field_A.a5()) {
               var1 = this;
               System.err.println("[CLIENT][SEGBUILDCONTROLLER] BULK CONNECTION");

               try {
                  class_850 var2 = ((SegmentBufferManager)var1.field_a.a1().getSegmentBuffer()).a30(var1.field_a);
                  new class_47();
                  if(var1.field_a != null && var2 != null && var2.field_a.size() > 0) {
                     System.err.println("[CLIENT][SEGBUILDCONTROLLER] BULK CONNECTING " + var2.field_a.size() + " elements of type " + var2.field_a);
                     boolean var3 = var1.field_a.a1().getControlElementMap().isControlling(var1.field_a.a2(new class_47()), var1.field_a, var2.field_a);
                     Iterator var10 = var2.field_a.iterator();

                     while(var10.hasNext()) {
                        var4 = (class_47)var10.next();
                        int var5 = var3?2:1;
                        var1.field_a.a1().setCurrentBlockController(var1.field_a, var4, var5);
                     }
                  }
               } catch (CannotBeControlledException var9) {
                  this.a81(var9);
               }
            }
         }

         if(class_367.field_U.a6()) {
            this.a6().a14().field_a.field_a.field_a.b();
         }
      }

      this.field_a.handleKeyEvent();
   }

   public final void a12(class_941 var1) {
      if(System.currentTimeMillis() - this.a6().a14().field_a.field_a.field_a.field_a >= 300L) {
         if(this.field_a.a1() != null && class_967.a1() != null && !super.field_a) {
            int var2 = class_943.field_a.b1()?1:0;
            int var3 = class_943.field_a.b1()?0:1;
            Vector3f var4;
            Vector3f var6;
            if(var1.field_a == var2) {
               var6 = new Vector3f(class_967.a1().a83());
               var4 = new Vector3f(class_967.a1().c10());
               if(Keyboard.isKeyDown(class_367.field_U.a5())) {
                  (var4 = new Vector3f(this.a6().a27().b9())).sub(var6);
               }

               boolean var5 = false;
               if(var1.field_a) {
                  this.field_a = null;
                  this.field_b = System.currentTimeMillis();
               } else {
                  var5 = this.field_b > 0L && System.currentTimeMillis() - this.field_b > 500L;
                  this.field_b = 0L;
               }

               if(!var1.field_a && !var5) {
                  this.a6().a14().field_a.field_a.field_a.a48(this.field_a.a1(), var6, var4, new class_451(this), new class_709(), this.field_a, 160.0F);
               }
            }

            if(var1.field_a == var3 && !var1.field_a) {
               var6 = new Vector3f(class_967.a1().a83());
               var4 = new Vector3f(class_967.a1().c10());
               if(Keyboard.isKeyDown(class_367.field_U.a5())) {
                  (var4 = new Vector3f(this.a6().a27().b9())).sub(var6);
               }

               this.a6().a14().field_a.field_a.field_a.a49(this.field_a.a1(), var6, var4, 160.0F, this.field_a);
            }
         }

      }
   }

   public final void b2(boolean var1) {
      if(var1) {
         if(this.field_a.a1() != this.field_a) {
            this.field_a = null;
            this.field_a = this.field_a.a1();
         }

         this.field_a.a1().getControlElementMap().setObs(this);
         this.field_a.clear();
         this.field_f = true;
         if(this.field_a != null && ((class_958)this.field_a.a184()).a140() == this.field_a.a1()) {
            if(this.field_a != null) {
               this.field_a.a78(class_967.a1());
            }
         } else if(this.field_a.a1() != null) {
            Transform var2 = new Transform(this.field_a.a1().getWorldTransform());
            GlUtil.d2(new Vector3f(0.0F, 1.0F, 0.0F), var2);
            GlUtil.c3(new Vector3f(1.0F, 0.0F, 0.0F), var2);
            GlUtil.a30(new Vector3f(0.0F, 0.0F, 1.0F), var2);
            class_243 var10001 = new class_243;
            this.a6();
            var10001.<init>(class_967.a1(), this.field_a);
            this.field_a = var10001;
            this.field_a.a84(new class_47(8, 8, 0));
            this.field_a.a(0.0F);
         } else if(this.field_a != null) {
            this.field_a.a78(class_967.a1());
         }

         if(this.field_a.a1() != null) {
            this.a6().a27();
            class_227.a88(this.field_a.a1());
         }

         this.a6().a4().c2("FlightMode");
         this.a6().a4().a26("BuildMode", "Build Mode", "(press " + class_367.field_r.b1() + " to switch to FLIGHT MODE; press " + class_367.field_v.b1() + " to exit structure)");
         if(!field_g && this.field_a.a1() == null) {
            throw new AssertionError();
         }

         class_967.a9(this.field_a);
      }

      super.b2(var1);
   }

   private void f2(boolean var1) {
      if(!this.field_a.isEmpty()) {
         this.field_a = FastMath.b1(this.field_a + (var1?1:-1), this.field_a.size() - 1);
         System.err.println("SWITCH " + var1 + " " + this.field_a);

         try {
            this.field_a = this.field_a.a1().getSegmentBuffer().a9((class_47)this.field_a.get(this.field_a), true);
         } catch (CannotImmediateRequestOnClientException var2) {
            var2.printStackTrace();
         }
      }
   }

   public final void a15(class_935 var1) {
      if(this.field_a != null) {
         this.field_a.a12();
         if(this.field_a.a9() == 0) {
            this.field_a = null;
         }
      }

      if(this.field_f) {
         this.field_a.clear();
         Iterator var5 = this.field_a.a1().getControlElementMap().getControllingMap().keySet().iterator();

         while(var5.hasNext()) {
            long var3 = ((Long)var5.next()).longValue();
            this.field_a.add(ElementCollection.getPosFromIndex(var3, new class_47()));
         }

         this.field_f = false;
      }

      Vector3f var8;
      if(this.field_b > 0L && Keyboard.isKeyDown(class_367.field_U.a5()) && System.currentTimeMillis() - this.field_b > 500L) {
         Vector3f var6 = new Vector3f(class_967.a1().a83());
         (var8 = new Vector3f(this.a6().a27().b9())).sub(var6);
         this.a6().a14().field_a.field_a.field_a.a48(this.field_a.a1(), var6, var8, new class_449(this), this.field_a, this.field_a, 160.0F);
      }

      boolean var10000 = this.field_d;
      class_1008.field_a = !Keyboard.isKeyDown(class_367.field_U.a5());
      if(this.field_a.a1() != null) {
         Vector3f var2 = new Vector3f(class_967.a1().a83());
         var8 = new Vector3f(class_967.a1().c10());
         Vector3f var4 = new Vector3f(var2);
         var8.scale(160.0F);
         var4.add(var8);
         if(Keyboard.isKeyDown(class_367.field_U.a5())) {
            var4 = new Vector3f(this.a6().a27().b9());
         }

         this.field_a = ((PhysicsExt)this.a6().a19()).testRayCollisionPoint(var2, var4, false, (SegmentController)null, this.field_a.a1(), false, this.field_a, true);
         if(this.field_a != null && this.field_a.hasHit() && this.field_a instanceof CubeRayCastResult) {
            CubeRayCastResult var7;
            if((var7 = (CubeRayCastResult)this.field_a).getSegment() != null && var7.cubePos != null) {
               var7.getSegment().a14(var7.cubePos, this.field_a);
               var7.getSegment().a16().getType(var7.cubePos);
               this.field_a = var7.getSegment();
               this.field_e = true;
               return;
            }

            this.field_a = null;
            this.field_e = false;
            return;
         }

         this.field_a = null;
         this.field_e = false;
      }

   }

   public final void b() {
      this.field_f = true;
   }

   public final class_433 a70() {
      return this.field_a;
   }

   // $FF: synthetic method
   static class_457 a71(class_453 var0) {
      return var0.field_a;
   }

   // $FF: synthetic method
   static class_800 a72(class_453 var0, class_800 var1) {
      return var0.field_a = var1;
   }

   // $FF: synthetic method
   static class_800 a73(class_453 var0) {
      return var0.field_a;
   }

   // $FF: synthetic method
   static class_709 a74(class_453 var0) {
      return var0.field_a;
   }

   // $FF: synthetic method
   static class_709 a75(class_453 var0, class_709 var1) {
      return var0.field_a = var1;
   }

}
