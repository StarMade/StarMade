import java.util.Observable;
import java.util.Observer;
import org.schema.schine.network.client.ClientState;

public abstract class class_114 extends class_966 implements Observer {

   private boolean field_a = true;
   private class_963 field_a;


   public class_114(float var1, ClientState var2) {
      super(var1, 140.0F, var2);
      ((class_371)this.a24()).a20().a132().deleteObserver(this);
      ((class_371)this.a24()).a20().a132().addObserver(this);
   }

   public final void c() {
      this.field_a = new class_963(this.a24());
      this.c6(this.field_a);
      super.c();
   }

   public final void b() {
      if(this.field_a) {
         this.a27(this.field_a);
         this.field_a = false;
      }

      super.b();
   }

   protected abstract void a27(class_963 var1);

   public void update(Observable var1, Object var2) {
      System.err.println("FACTION LIST NEEDS UPDATE");
      this.field_a = true;
   }
}
