
final class class_165 implements class_1410 {

   // $FF: synthetic field
   private class_167 field_a;


   class_165(class_167 var1) {
      this.field_a = var1;
      super();
   }

   public final boolean a1() {
      return false;
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.a()) {
         ((class_371)this.field_a.a24()).a4().a29().a2();
      }

   }
}
