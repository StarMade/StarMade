import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.util.Date;
import java.util.logging.Formatter;
import java.util.logging.LogRecord;

public final class class_30 extends Formatter {

   private DateFormat field_a;
   private static String field_a = System.getProperty("line.separator");


   public final String format(LogRecord var1) {
      StringBuffer var2 = new StringBuffer(180);
      if(this.field_a == null) {
         this.field_a = DateFormat.getDateTimeInstance();
      }

      var2.append('[');
      var2.append(this.field_a.format(new Date(var1.getMillis())));
      var2.append(var1.getSourceClassName());
      var2.append(var1.getSourceMethodName());
      var2.append(']');
      var2.append(' ');
      var2.append(var1.getLevel());
      var2.append(": ");
      var2.append(this.formatMessage(var1).replaceFirst("\\]", "] "));
      var2.append(field_a);
      Throwable var4;
      if((var4 = var1.getThrown()) != null) {
         StringWriter var3 = new StringWriter();
         var4.printStackTrace(new PrintWriter(var3, true));
         var2.append(var3.toString());
      }

      return var2.toString();
   }

}
