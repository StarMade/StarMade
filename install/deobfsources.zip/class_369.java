
public enum class_369 {

   field_a("GENERAL", 0, "General Controls", (class_369)null, 0),
   field_b("FREE_IN_SPACE", 1, "Controls of Character in Space", field_a, 1),
   field_c("SHIP_GENERAL", 2, "Ship General Controls", field_a, 1),
   field_d("SHIP_FLIGHT_MODE", 3, "Ship Flight Mode Controls", field_c, 2),
   field_e("SHIP_BUILD_MODE", 4, "Ship Build Mode Controls", field_c, 2);
   private final String field_a;
   private final class_369 field_f;
   private final int field_a;
   // $FF: synthetic field
   private static final class_369[] field_a = new class_369[]{field_a, field_b, field_c, field_d, field_e};


   private class_369(String var1, int var2, String var3, class_369 var4, int var5) {
      this.field_a = var3;
      this.field_f = var4;
      this.field_a = var5;
   }

   public final String a() {
      return this.field_a;
   }

   public final int a1() {
      return this.field_a;
   }

   public final class_369 a2() {
      return this.field_f;
   }

   public final boolean a3() {
      return this.field_f == null;
   }

}
