import java.util.Comparator;

final class class_176 implements Comparator {

   // $FF: synthetic method
   public final int compare(Object var1, Object var2) {
      class_972 var10000 = (class_972)var1;
      class_972 var3 = (class_972)var2;
      return ((class_248)var10000).a108().field_b - ((class_248)var3).a108().field_b;
   }
}
