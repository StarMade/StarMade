import javax.vecmath.Vector4f;

public final class class_244 extends class_196 {

   private class_1361 field_a;
   private final class_785 field_b;
   private class_1412 field_b;
   private class_940 field_b;
   private class_940 field_c;
   private class_940 field_d;
   private class_940 field_e;
   private class_940 field_f;
   private class_1402 field_a;
   private class_1402 field_b;
   private class_1402 field_c;
   private class_1402 field_d;
   final class_785 field_a;
   private boolean field_b;


   public class_244(class_371 var1, class_785 var2, class_428 var3, boolean var4) {
      super(var1, var3, "Edit Entry Permission", "Edit Entry Permission");
      this.field_b = var4;
      this.field_b = var2;
      this.field_a = new class_785(var2);
      this.field_a = new class_1361(this.a24(), 410.0F, 90.0F, new Vector4f(0.1F, 0.1F, 0.1F, 1.0F));
   }

   public final void c() {
      super.c();
      this.field_b = new class_1412(this.a24(), 400.0F, 100.0F);
      this.field_d = new class_940(100, 20, this.a24());
      this.field_e = new class_940(100, 20, this.a24());
      this.field_f = new class_940(100, 20, this.a24());
      this.field_c = new class_940(100, 20, this.a24());
      this.field_b = new class_940(100, 20, this.a24());
      this.field_c.a137("Faction");
      this.field_d.a137("Others");
      this.field_e.a137("HomeBase");
      this.field_f.a137("EnemyUsable");
      this.field_b.a137("Permissions");
      this.field_a = new class_246(this, this.a24());
      this.field_b = new class_252(this, this.a24());
      this.field_c = new class_100(this, this.a24());
      this.field_d = new class_102(this, this.a24());
      this.field_b.a9(this.field_b);
      this.field_c.a165(0.0F, 20.0F, 0.0F);
      this.field_d.a165(70.0F, 20.0F, 0.0F);
      this.field_e.a165(140.0F, 20.0F, 0.0F);
      this.field_f.a165(210.0F, 20.0F, 0.0F);
      this.field_b.a9(this.field_c);
      this.field_b.a9(this.field_d);
      this.field_b.a9(this.field_e);
      this.field_a.a165(0.0F, 35.0F, 0.0F);
      this.field_b.a165(70.0F, 35.0F, 0.0F);
      this.field_c.a165(140.0F, 35.0F, 0.0F);
      this.field_d.a165(210.0F, 35.0F, 0.0F);
      this.field_b.a9(this.field_a);
      this.field_b.a9(this.field_b);
      this.field_b.a9(this.field_c);
      if(this.field_b && ((Boolean)((class_371)this.a24()).a20().a117().isAdminClient.get()).booleanValue()) {
         this.field_b.a9(this.field_f);
         this.field_b.a9(this.field_d);
      }

      this.field_b.a83().field_y = 20.0F;
      this.field_a.a9(this.field_b);
      class_940 var1;
      (var1 = new class_940(100, 20, this.a24())).a137("Specify the permissions for " + this.field_b.field_a);
      this.field_a.a9(var1);
      this.field_a.a9(this.field_a);
   }

   public final void a2() {}

   public final void b() {
      this.k();
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public final class_785 a108() {
      return this.field_a;
   }
}
