import com.bulletphysics.linearmath.Transform;
import java.util.Iterator;
import javax.vecmath.Vector3f;

public final class class_471 extends class_15 {

   private class_1044 field_a;


   public class_471(class_371 var1) {
      super(var1);
   }

   public final void b2(boolean var1) {
      class_1008.field_a = !var1;
      if(var1) {
         this.a6().b4(false);
         boolean var2 = false;
         synchronized(this.a6().b()) {
            Iterator var4 = this.a6().b().iterator();

            while(true) {
               if(!var4.hasNext()) {
                  break;
               }

               if((class_11)var4.next() instanceof D) {
                  var2 = true;
               }
            }
         }

         if(!var2) {
            D var3 = new D(this.a6());
            this.a6().b().add(var3);
         }
      }

      super.b2(var1);
   }

   public final void a15(class_935 var1) {
      super.a15(var1);
      class_1008.field_a = false;
      if(this.field_a == null) {
         Transform var3;
         (var3 = new Transform()).setIdentity();
         class_958 var5 = new class_958(new class_473(var3));
         Vector3f var10000 = new Vector3f(class_307.a25().a83());
         this.a6().a23();
         Vector3f var4 = var10000;
         var10000.negate();
         var4.normalize();
         this.field_a = new class_1044(var5, new Vector3f(125.0F, 70.0F, 223.0F), var4);
      }

      if(class_967.a1() != this.field_a) {
         class_967.a9(this.field_a);
         this.field_a.a12(var1);
      }

   }
}
