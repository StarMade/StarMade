
final class class_129 implements class_1410 {

   // $FF: synthetic field
   private class_131 field_a;


   class_129(class_131 var1) {
      this.field_a = var1;
      super();
   }

   public final boolean a1() {
      return false;
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.a()) {
         ((class_371)this.field_a.a24()).a45().a147(((class_371)this.field_a.a24()).getPlayerName(), class_131.a36(this.field_a), true);
      }

   }
}
