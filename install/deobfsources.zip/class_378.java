import java.nio.FloatBuffer;

public interface class_378 {

   void a(int var1, byte var2, short var3, byte var4, byte var5, byte var6, byte var7, byte var8, FloatBuffer var9);
}
