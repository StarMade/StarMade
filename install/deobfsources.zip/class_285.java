import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import javax.vecmath.AxisAngle4f;
import javax.vecmath.Matrix3f;
import javax.vecmath.Vector3f;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.data.element.ElementCollection;
import org.schema.game.common.data.element.ElementKeyMap;
import org.schema.schine.graphicsengine.core.GlUtil;

public class class_285 implements class_923 {

   private final SegmentController field_a;
   private final Map field_a = new HashMap();
   private int field_a;
   private Vector3f field_a = new Vector3f();
   private Vector3f field_b = new Vector3f();
   private Vector3f field_c = new Vector3f();
   private Vector3f field_d = new Vector3f(0.0F, 1.0F, 0.0F);
   private Vector3f field_e = new Vector3f();
   private static Vector3f[] field_a = new Vector3f[8];
   private static Vector3f[] field_b = new Vector3f[8];
   private static Vector3f[] field_c = new Vector3f[8];
   private static Vector3f[] field_d = new Vector3f[8];
   private Matrix3f field_a = new Matrix3f();
   private AxisAngle4f field_a = new AxisAngle4f();
   private int field_b;
   private boolean field_a = true;
   private boolean field_b;
   private int field_c;
   private int field_d;
   private class_1395 field_a;
   private static IntBuffer field_a;
   private static IntBuffer field_b;
   private static IntBuffer field_c;
   // $FF: synthetic field
   private static boolean field_c = !eo.class.desiredAssertionStatus();


   public class_285(SegmentController var1) {
      this.field_a = var1;
   }

   public final void a() {
      if(this.field_a != 0) {
         GL15.glDeleteBuffers(this.field_a);
      }

   }

   public final void b() {
      if(this.field_a) {
         class_285 var1 = this;
         this.field_a.clear();
         Iterator var2 = this.field_a.getControlElementMap().getControllingMap().getAll().entrySet().iterator();

         while(var2.hasNext()) {
            Entry var3;
            if(((ObjectOpenHashSet)(var3 = (Entry)var2.next()).getValue()).size() > 0) {
               short var4 = 0;
               ObjectIterator var5 = ((ObjectOpenHashSet)var3.getValue()).iterator();

               while(var5.hasNext() && (var4 = ((class_897)var5.next()).field_a) == 32767) {
                  ;
               }

               if(ElementKeyMap.getFactorykeyset().contains(Short.valueOf(var4))) {
                  var1.field_a.put(ElementCollection.getPosFromIndex(((Long)var3.getKey()).longValue(), new class_47()), var3.getValue());
               } else {
                  System.err.println("the type is not a factory type: " + var4);
               }
            }
         }

         this.e();
         this.field_a = false;
      }

      if(!this.field_b && this.field_a.size() > 0) {
         GL11.glEnable(2903);
         GL11.glEnable(2896);
         this.field_a.a2();
         GL11.glEnableClientState('\u8074');
         GL11.glEnableClientState('\u8075');
         GL11.glEnableClientState('\u8078');
         GL15.glBindBuffer('\u8892', this.field_d);
         GL11.glTexCoordPointer(3, 5126, 0, 0L);
         GL15.glBindBuffer('\u8892', this.field_c);
         GL11.glNormalPointer(5126, 0, 0L);
         GL15.glBindBuffer('\u8892', this.field_a);
         GL11.glVertexPointer(3, 5126, 0, 0L);
         GL11.glDrawArrays(7, 0, this.field_b);
         GL15.glBindBuffer('\u8892', 0);
         GL11.glDisableClientState('\u8074');
         GL11.glDisableClientState('\u8075');
         GL11.glDisableClientState('\u8078');
         GL11.glDisable(2903);
      }

   }

   private void e() {
      int var1 = 0;
      Iterator var2 = this.field_a.entrySet().iterator();

      while(var2.hasNext()) {
         for(Iterator var4 = ((ObjectOpenHashSet)((Entry)var2.next()).getValue()).iterator(); var4.hasNext(); ++var1) {
            var4.next();
         }
      }

      this.field_b = var1 == 0;
      if(this.field_b) {
         System.err.println("NOTHING TO DRAW");
      } else {
         System.err.println("UPDATING CONNECTIONS: " + var1);
         this.field_b = var1 << 1 << 1 << 3;
         FloatBuffer var8 = GlUtil.a5(this.field_b * 3 << 2, 0).asFloatBuffer();
         FloatBuffer var3 = GlUtil.a5(this.field_b * 3 << 2, 1).asFloatBuffer();
         FloatBuffer var9 = GlUtil.a5(this.field_b * 3 << 2, 2).asFloatBuffer();
         var1 = 0;
         Iterator var5 = this.field_a.entrySet().iterator();

         while(var5.hasNext()) {
            Entry var6 = (Entry)var5.next();
            this.field_a.set(-8.0F + (float)((class_47)var6.getKey()).field_a, -8.0F + (float)((class_47)var6.getKey()).field_b, -8.0F + (float)((class_47)var6.getKey()).field_c);
            this.field_a.getWorldTransformClient().transform(this.field_a);

            for(Iterator var10 = ((ObjectOpenHashSet)var6.getValue()).iterator(); var10.hasNext(); var1 += this.a20(this.field_a, this.field_b, var8, var3, var9)) {
               class_897 var7 = (class_897)var10.next();
               this.field_b.set(-8.0F + (float)var7.field_a, -8.0F + (float)var7.field_b, -8.0F + (float)var7.field_c);
               this.field_a.getWorldTransformClient().transform(this.field_b);
            }
         }

         if(!field_c && this.field_b != var1) {
            throw new AssertionError(this.field_b + "/" + var1);
         } else {
            if(this.field_a == 0) {
               GL15.glGenBuffers(field_a);
               this.field_a = field_a.get(0);
               GL15.glGenBuffers(field_b);
               this.field_c = field_b.get(0);
               GL15.glGenBuffers(field_c);
               this.field_d = field_c.get(0);
            }

            GL15.glBindBuffer('\u8892', this.field_a);
            var8.flip();
            System.err.println("BUFFER LIMIT " + var8.limit() + " / " + (this.field_b * 3 << 2) + " (" + this.field_b + ")");
            GL15.glBufferData('\u8892', var8, '\u88e4');
            GL15.glBindBuffer('\u8892', this.field_c);
            var3.flip();
            GL15.glBufferData('\u8892', var3, '\u88e4');
            GL15.glBindBuffer('\u8892', this.field_d);
            var9.flip();
            GL15.glBufferData('\u8892', var9, '\u88e4');
            GL15.glBindBuffer('\u8892', 0);
            this.field_a = new class_1395();
            this.field_a.f();
            this.field_a.c1(new float[]{0.9F, 0.9F, 0.9F, 1.0F});
         }
      }
   }

   private int a20(Vector3f var1, Vector3f var2, FloatBuffer var3, FloatBuffer var4, FloatBuffer var5) {
      this.field_c.sub(var2, var1);
      this.field_e.cross(this.field_c, this.field_d);
      float var6 = 0.0F;
      float var7 = 0.0F;

      for(int var8 = 0; var8 < 8; ++var8) {
         this.field_a.set(this.field_c, var6);
         this.field_a.set(this.field_a);
         field_a[var8].set(0.0F, 0.1F, 0.0F);
         this.field_a.transform(field_a[var8]);
         field_b[var8].set(field_a[var8]);
         field_c[var8].set(field_a[var8]);
         field_a[var8].add(var1);
         field_c[var8].add(var2);
         field_d[var8].set(0.0F, var7, 0.0F);
         var7 += 0.125F;
         var6 += 0.7853982F;
      }

      for(int var9 = 0; var9 < 8; ++var9) {
         GlUtil.a24(var3, field_a[var9]);
         GlUtil.a24(var4, field_b[var9]);
         field_d[var9].field_x = 0.0F;
         GlUtil.a24(var5, field_d[var9]);
         GlUtil.a24(var3, field_a[(var9 + 1) % 8]);
         GlUtil.a24(var4, field_b[(var9 + 1) % 8]);
         field_d[(var9 + 1) % 8].field_x = 0.0F;
         GlUtil.a24(var5, field_d[(var9 + 1) % 8]);
         GlUtil.a24(var3, field_c[(var9 + 1) % 8]);
         GlUtil.a24(var4, field_b[(var9 + 1) % 8]);
         field_d[(var9 + 1) % 8].field_x = 1.0F;
         GlUtil.a24(var5, field_d[(var9 + 1) % 8]);
         GlUtil.a24(var3, field_c[var9]);
         GlUtil.a24(var4, field_b[var9]);
         field_d[var9].field_x = 1.0F;
         GlUtil.a24(var5, field_d[var9]);
      }

      return 32;
   }

   public final void c() {}

   public final void d() {
      this.field_a = true;
   }

   public final SegmentController a21() {
      return this.field_a;
   }

   static {
      for(int var0 = 0; var0 < 8; ++var0) {
         field_a[var0] = new Vector3f();
         field_c[var0] = new Vector3f();
         field_b[var0] = new Vector3f();
         field_d[var0] = new Vector3f();
      }

      field_a = BufferUtils.createIntBuffer(1);
      field_b = BufferUtils.createIntBuffer(1);
      field_c = BufferUtils.createIntBuffer(1);
   }
}
