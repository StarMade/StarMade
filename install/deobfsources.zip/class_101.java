import java.util.ArrayList;
import javax.vecmath.Vector4f;
import org.schema.schine.network.client.ClientState;

final class class_101 extends class_1412 {

   private class_940 field_a;
   private class_940 field_b;
   private class_928 field_a;
   private class_928 field_b;
   private class_940 field_c;


   public class_101(class_860 var1, ClientState var2, class_777 var3, String var4, int var5) {
      super(var2, 310.0F, 25.0F);
      this.field_a = new class_940(100, 10, var2);
      this.field_b = new class_940(100, 10, var2);
      this.field_c = new class_940(100, 10, var2);
      this.field_b.a83().field_x = 140.0F;
      this.field_c.a83().field_x = 190.0F;
      class_940 var6 = new class_940(100, 10, var2);
      class_103 var7 = new class_103(var3);
      class_92 var8 = new class_92(var3);
      class_94 var9 = new class_94(var3);
      class_96 var10 = new class_96(this, var3);
      class_98 var11 = new class_98(this, var3);
      this.field_a.field_b = new ArrayList();
      this.field_b.field_b = new ArrayList();
      this.field_c.field_b = new ArrayList();
      this.field_a.field_b.add(var7);
      this.field_b.field_b.add(var8);
      this.field_c.field_b.add(var9);
      var6.a137(var4);
      if(var4.length() > 0) {
         this.field_a.a83().field_x = 8.0F;
      }

      this.field_b = new class_928(var2, 90, 20, var11, class_860.a120(var1));
      this.field_b.field_a = "REL_" + var3.a3();
      this.field_b.a83().field_x = 310.0F;
      this.field_b.b14(10, 2);
      this.field_a = new class_928(this.a24(), 70, 20, var10, class_860.a120(var1));
      this.field_a.a83().field_x = 410.0F;
      this.field_a.field_a = "JOIN_" + var3.a3();
      this.field_a.a83().field_y = 2.0F;
      this.field_b.a83().field_y = 2.0F;
      this.field_c.a83().field_y = 2.0F;
      this.field_b.a83().field_y = 2.0F;
      this.field_a.a83().field_y = 2.0F;
      var6.a83().field_y = 2.0F;
      if(var5 < 0) {
         this.a9(this.field_a);
         this.a9(this.field_b);
         this.a9(this.field_c);
         this.a9(this.field_b);
         this.a9(this.field_a);
         this.a9(var6);
      } else {
         class_1361 var12;
         (var12 = new class_1361(this.a24(), 510.0F, this.a3(), var5 % 2 == 0?new Vector4f(0.0F, 0.0F, 0.0F, 0.0F):new Vector4f(0.1F, 0.1F, 0.1F, 0.5F))).a9(this.field_a);
         var12.a9(this.field_b);
         var12.a9(this.field_c);
         var12.a9(this.field_b);
         var12.a9(this.field_a);
         var12.a9(var6);
         this.a9(var12);
      }

      super.field_a = var3;
   }
}
