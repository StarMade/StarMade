import java.util.ArrayList;
import javax.vecmath.Vector3f;
import org.schema.schine.network.client.ClientState;

final class class_104 extends class_964 {

   private class_940 field_a;
   private class_940 field_b;
   private class_940 field_c;
   private class_940 field_d;
   private class_940 field_e;
   private int field_a = 100;


   public class_104(ClientState var1) {
      super(var1);
      this.field_a = new class_940(300, 30, class_28.b2(), var1);
      this.field_a.field_b = new ArrayList();
      this.field_a.field_b.add("");
      this.field_b = new class_940(300, 30, class_28.b2(), var1);
      this.field_b.field_b = new ArrayList();
      this.field_b.field_b.add("");
      Vector3f var10000 = this.field_b.a83();
      var10000.field_x += (float)this.field_a;
      this.field_c = new class_940(300, 30, class_28.b2(), var1);
      this.field_c.field_b = new ArrayList();
      this.field_c.field_b.add("");
      var10000 = this.field_c.a83();
      var10000.field_x += (float)(2 * this.field_a);
      this.field_d = new class_940(300, 30, class_28.b2(), var1);
      this.field_d.field_b = new ArrayList();
      this.field_d.field_b.add("");
      var10000 = this.field_d.a83();
      var10000.field_x += (float)(3 * this.field_a);
      this.field_e = new class_940(300, 30, class_28.b2(), var1);
      this.field_e.field_b = new ArrayList();
      this.field_e.field_b.add("");
      var10000 = this.field_e.a83();
      var10000.field_x += (float)(4 * this.field_a);
   }

   public final void a2() {}

   public final void b() {
      this.r();
      this.field_a.b();
      this.field_b.b();
      this.field_c.b();
      this.field_d.b();
      this.field_e.b();
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1() * 4.0F + (float)(4 * this.field_a);
   }

   public final void c() {
      this.field_a.c();
      this.field_b.c();
      this.field_c.c();
      this.field_d.c();
      this.field_e.c();
   }

   public final void a15(String var1, String var2, String var3, String var4, String var5) {
      this.field_a.field_b.set(0, var1);
      this.field_b.field_b.set(0, var2);
      this.field_c.field_b.set(0, var3);
      this.field_d.field_b.set(0, var4);
      this.field_e.field_b.set(0, var5);
   }
}
