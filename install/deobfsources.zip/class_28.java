import com.bulletphysics.linearmath.Transform;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import java.net.URLConnection;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Random;
import java.util.logging.FileHandler;
import java.util.logging.LogManager;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.vecmath.Matrix3f;
import javax.vecmath.Quat4f;
import javax.vecmath.Tuple4f;
import javax.vecmath.Vector3f;
import org.lwjgl.opengl.GLContext;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.UnicodeFont;
import org.newdawn.slick.font.effects.ColorEffect;
import org.newdawn.slick.font.effects.OutlineEffect;
import org.schema.common.FastMath;
import org.schema.game.common.crashreporter.CrashReporter;
import org.schema.schine.graphicsengine.core.GlUtil;

public final class class_28 implements class_1071 {

   private static class_29 field_a;
   private static class_29 field_b;
   private static FileHandler field_a;
   private static Logger field_a;
   private static ImageIcon[] field_a;
   public float field_a;
   private static UnicodeFont field_a;
   private static UnicodeFont field_b;
   private static UnicodeFont field_c;
   private static UnicodeFont field_d;
   private static UnicodeFont field_e;
   private static UnicodeFont field_f;
   private static UnicodeFont field_g;
   private static UnicodeFont field_h;
   private static UnicodeFont field_i;
   private static UnicodeFont field_j;
   private static UnicodeFont field_k;
   private static UnicodeFont field_l;
   private static UnicodeFont field_m;
   private static UnicodeFont field_n;
   private static UnicodeFont field_o;
   public static class_78[] field_a;


   public static void a() {
      if(field_b != null) {
         field_b.close();
      }

      if(field_a != null) {
         field_a.close();
      }

      if(field_a != null) {
         if(field_a != null) {
            field_a.removeHandler(field_a);
         }

         field_a.close();
      }

   }

   public static void b() {
      a();
      LogManager var0;
      (var0 = LogManager.getLogManager()).reset();
      File var1;
      if(!(var1 = new File("./logs/")).exists()) {
         var1.mkdirs();
      }

      (field_a = new FileHandler("./logs/log.txt", 4194304, 20)).setFormatter(new class_30());
      PrintStream var3 = System.out;
      PrintStream var2 = System.err;
      (field_a = Logger.getLogger("stdout")).addHandler(field_a);
      field_b = new class_29(var3, field_a, class_27.field_a, "OUT");
      System.setOut(new PrintStream(field_b, true));
      var0.addLogger(field_a);
      (field_a = Logger.getLogger("stderr")).addHandler(field_a);
      field_a = new class_29(var2, field_a, class_27.field_b, "ERR");
      System.setErr(new PrintStream(field_a, true));
      var0.addLogger(field_a);
   }

   public static void a1(Transform var0, Transform var1) {
      float var2 = var0.basis.m00;
      float var3 = var0.basis.m01;
      float var4 = var0.basis.m02;
      float var5 = var0.origin.field_x;
      float var6 = var0.basis.m10;
      float var7 = var0.basis.m11;
      float var8 = var0.basis.m12;
      float var9 = var0.origin.field_y;
      float var10 = var0.basis.m20;
      float var11 = var0.basis.m21;
      float var12 = var0.basis.m22;
      float var13 = var0.origin.field_z;
      float var14 = var1.basis.m00;
      float var15 = var1.basis.m01;
      float var16 = var1.basis.m02;
      float var17 = var1.origin.field_x;
      float var18 = var1.basis.m10;
      float var19 = var1.basis.m11;
      float var20 = var1.basis.m12;
      float var21 = var1.origin.field_y;
      float var22 = var1.basis.m20;
      float var23 = var1.basis.m21;
      float var24 = var1.basis.m22;
      float var28 = var1.origin.field_z;
      float var25 = var2 * var14 + var3 * var18 + var4 * var22 + var5 * 0.0F;
      float var26 = var2 * var15 + var3 * var19 + var4 * var23 + var5 * 0.0F;
      float var27 = var2 * var16 + var3 * var20 + var4 * var24 + var5 * 0.0F;
      var2 = var2 * var17 + var3 * var21 + var4 * var28 + var5;
      var3 = var6 * var14 + var7 * var18 + var8 * var22 + var9 * 0.0F;
      var4 = var6 * var15 + var7 * var19 + var8 * var23 + var9 * 0.0F;
      var5 = var6 * var16 + var7 * var20 + var8 * var24 + var9 * 0.0F;
      var6 = var6 * var17 + var7 * var21 + var8 * var28 + var9;
      var7 = var10 * var14 + var11 * var18 + var12 * var22 + var13 * 0.0F;
      var8 = var10 * var15 + var11 * var19 + var12 * var23 + var13 * 0.0F;
      var9 = var10 * var16 + var11 * var20 + var12 * var24 + var13 * 0.0F;
      var28 = var10 * var17 + var11 * var21 + var12 * var28 + var13;
      var0.basis.m00 = var25;
      var0.basis.m01 = var26;
      var0.basis.m02 = var27;
      var0.origin.field_x = var2;
      var0.basis.m10 = var3;
      var0.basis.m11 = var4;
      var0.basis.m12 = var5;
      var0.origin.field_y = var6;
      var0.basis.m20 = var7;
      var0.basis.m21 = var8;
      var0.basis.m22 = var9;
      var0.origin.field_z = var28;
   }

   public static Quat4f a2(float var0, Vector3f var1, Quat4f var2) {
      if(var1.field_x == 0.0F && var1.field_y == 0.0F && var1.field_z == 0.0F) {
         var2.set(0.0F, 0.0F, 0.0F, 1.0F);
      } else {
         float var3 = FastMath.h(var0 = 0.5F * var0);
         var2.field_w = FastMath.d(var0);
         var2.field_x = var3 * var1.field_x;
         var2.field_y = var3 * var1.field_y;
         var2.field_z = var3 * var1.field_z;
      }

      return var2;
   }

   public static Vector3f a3(Quat4f var0, Vector3f var1, Vector3f var2) {
      float var3 = var0.field_x;
      float var4 = var0.field_y;
      float var5 = var0.field_z;
      float var8 = var0.field_w;
      if(var2 == null) {
         var2 = new Vector3f();
      }

      if(var1.field_x == 0.0F && var1.field_y == 0.0F && var1.field_z == 0.0F) {
         var2.set(0.0F, 0.0F, 0.0F);
      } else {
         float var6 = var1.field_x;
         float var7 = var1.field_y;
         float var9 = var1.field_z;
         var2.field_x = var8 * var8 * var6 + var4 * 2.0F * var8 * var9 - var5 * 2.0F * var8 * var7 + var3 * var3 * var6 + var4 * 2.0F * var3 * var7 + var5 * 2.0F * var3 * var9 - var5 * var5 * var6 - var4 * var4 * var6;
         var2.field_y = var3 * 2.0F * var4 * var6 + var4 * var4 * var7 + var5 * 2.0F * var4 * var9 + var8 * 2.0F * var5 * var6 - var5 * var5 * var7 + var8 * var8 * var7 - var3 * 2.0F * var8 * var9 - var3 * var3 * var7;
         var2.field_z = var3 * 2.0F * var5 * var6 + var4 * 2.0F * var5 * var7 + var5 * var5 * var9 - var8 * 2.0F * var4 * var6 - var4 * var4 * var9 + var8 * 2.0F * var3 * var7 - var3 * var3 * var9 + var8 * var8 * var9;
      }

      return var2;
   }

   public static Quat4f a4(Quat4f var0, Quat4f var1, float var2, Quat4f var3) {
      if(var0.field_x == var1.field_x && var0.field_y == var1.field_y && var0.field_z == var1.field_z && var0.field_w == var1.field_w) {
         var3.set((Tuple4f)var0);
         return var3;
      } else {
         float var4;
         if((var4 = var0.field_x * var1.field_x + var0.field_y * var1.field_y + var0.field_z * var1.field_z + var0.field_w * var1.field_w) < 0.0F) {
            var1.field_x = -var1.field_x;
            var1.field_y = -var1.field_y;
            var1.field_z = -var1.field_z;
            var1.field_w = -var1.field_w;
            var4 = -var4;
         }

         float var5 = 1.0F - var2;
         float var6 = var2;
         if(1.0F - var4 > 0.1F) {
            var4 = FastMath.b(var4);
            var6 = 1.0F / FastMath.h(var4);
            var5 = FastMath.h(var5 * var4) * var6;
            var6 = FastMath.h(var2 * var4) * var6;
         }

         var3.field_x = var5 * var0.field_x + var6 * var1.field_x;
         var3.field_y = var5 * var0.field_y + var6 * var1.field_y;
         var3.field_z = var5 * var0.field_z + var6 * var1.field_z;
         var3.field_w = var5 * var0.field_w + var6 * var1.field_w;
         return var3;
      }
   }

   public static void a5(Matrix3f var0, Quat4f var1) {
      float var2;
      if((var2 = var0.m00 + var0.m11 + var0.m22) > 0.0F) {
         var2 = FastMath.l(var2 + 1.0F) * 2.0F;
         var1.field_w = 0.25F * var2;
         var1.field_x = (var0.m21 - var0.m12) / var2;
         var1.field_y = (var0.m02 - var0.m20) / var2;
         var1.field_z = (var0.m10 - var0.m01) / var2;
      } else if(var0.m00 > var0.m11 && var0.m00 > var0.m22) {
         var2 = FastMath.l(1.0F + var0.m00 - var0.m11 - var0.m22) * 2.0F;
         var1.field_w = (var0.m21 - var0.m12) / var2;
         var1.field_x = 0.25F * var2;
         var1.field_y = (var0.m01 + var0.m10) / var2;
         var1.field_z = (var0.m02 + var0.m20) / var2;
      } else if(var0.m11 > var0.m22) {
         var2 = FastMath.l(1.0F + var0.m11 - var0.m00 - var0.m22) * 2.0F;
         var1.field_w = (var0.m02 - var0.m20) / var2;
         var1.field_x = (var0.m01 + var0.m10) / var2;
         var1.field_y = 0.25F * var2;
         var1.field_z = (var0.m12 + var0.m21) / var2;
      } else {
         var2 = FastMath.l(1.0F + var0.m22 - var0.m00 - var0.m11) * 2.0F;
         var1.field_w = (var0.m10 - var0.m01) / var2;
         var1.field_x = (var0.m02 + var0.m20) / var2;
         var1.field_y = (var0.m12 + var0.m21) / var2;
         var1.field_z = 0.25F * var2;
      }
   }

   public static void a6(int var0, int var1, int var2, class_795 var3, int var4, Random var5) {
      if(var0 == 8 && var1 == 8 & var2 == 5) {
         var3.a199(var4, class_797.field_c);
         var3.a200(var4, class_799.field_b);
      } else if(var0 == 100 && var1 == 100 & var2 == 100) {
         var3.a199(var4, class_797.field_c);
         var3.a200(var4, class_799.field_b);
      } else if(var0 == 200 && var1 == 100 & var2 == 100) {
         var3.a199(var4, class_797.field_c);
         var3.a200(var4, class_799.field_c);
      } else if(var0 == 300 && var1 == 100 & var2 == 100) {
         var3.a199(var4, class_797.field_c);
         var3.a200(var4, class_799.field_e);
      } else if(var0 == 400 && var1 == 100 & var2 == 100) {
         var3.a199(var4, class_797.field_c);
         var3.a200(var4, class_799.field_a);
      } else if(var0 == 500 && var1 == 100 & var2 == 100) {
         var3.a199(var4, class_797.field_c);
         var3.a200(var4, class_799.field_d);
      } else if(var0 == 8 && var1 == 5 & var2 == 8) {
         var3.a199(var4, class_797.field_a);
         var3.a201(var4, class_784.field_a);
      } else if(var0 == 8 && var1 == 5 & var2 == 5) {
         var3.a199(var4, class_797.field_a);
         var3.a201(var4, class_784.field_c);
      } else if(class_673.field_b.a3(var0, var1, var2)) {
         var3.a199(var4, class_797.field_d);
      } else if(var0 == class_673.field_b.field_a && var1 == class_673.field_b.field_b - 1 && var2 == class_673.field_b.field_c) {
         var3.a199(var4, class_797.field_c);
         a7(var3, var4, var5);
      } else if((var0 = var5.nextInt(250)) < 5) {
         var3.a199(var4, class_797.field_c);
         a7(var3, var4, var5);
      } else if(var0 < 240) {
         var3.a199(var4, class_797.field_b);
      } else {
         var3.a199(var4, class_797.field_a);
         if(var5.nextInt(5) == 0) {
            var3.a201(var4, class_784.field_c);
         } else {
            var3.a201(var4, class_784.field_a);
         }
      }
   }

   private static void a7(class_795 var0, int var1, Random var2) {
      int var3;
      for(var3 = var2.nextInt(class_799.values().length); !class_799.values()[var3].field_a; var3 = var2.nextInt(class_799.values().length)) {
         ;
      }

      var0.a200(var1, class_799.values()[var3]);
   }

   public static ImageIcon a8(int var0) {
      if(field_a == null) {
         try {
            field_a = new ImageIcon[768];
            BufferedImage[] var1;
            (var1 = new BufferedImage[3])[0] = ImageIO.read(new File("./data/textures/block/t000.png"));
            var1[1] = ImageIO.read(new File("./data/textures/block/t001.png"));
            var1[2] = ImageIO.read(new File("./data/textures/block/t002.png"));

            for(int var2 = 0; var2 < field_a.length; ++var2) {
               int var3 = var2 % 256 % 16;
               int var4 = var2 % 256 / 16;
               BufferedImage var6 = var1[var2 / 256].getSubimage(var3 << 6, var4 << 6, 64, 64);
               field_a[var2] = new ImageIcon(var6);
            }
         } catch (IOException var5) {
            var5.printStackTrace();
            a12(var5);
         }
      }

      return field_a[var0];
   }

   public static void a9(String var0, String var1, String var2, String var3, File var4) {
      if(var0 != null && var3 != null && var4 != null) {
         StringBuffer var5 = new StringBuffer("ftp://");
         if(var1 != null && var2 != null) {
            var5.append(var1);
            var5.append(':');
            var5.append(var2);
            var5.append('@');
         }

         var5.append(var0);
         var5.append('/');
         var5.append(var3);
         var5.append(";type=i");
         BufferedInputStream var17 = null;
         BufferedOutputStream var18 = null;
         boolean var11 = false;

         try {
            var11 = true;
            URLConnection var19 = (new URL(var5.toString())).openConnection();
            var18 = new BufferedOutputStream(var19.getOutputStream());
            var17 = new BufferedInputStream(new FileInputStream(var4));

            int var20;
            while((var20 = var17.read()) != -1) {
               var18.write(var20);
            }

            var11 = false;
         } finally {
            if(var11) {
               if(var17 != null) {
                  try {
                     var17.close();
                  } catch (IOException var13) {
                     var13.printStackTrace();
                  }
               }

               if(var18 != null) {
                  try {
                     var18.close();
                  } catch (IOException var12) {
                     var12.printStackTrace();
                  }
               }

            }
         }

         try {
            var17.close();
         } catch (IOException var15) {
            var15.printStackTrace();
         }

         try {
            var18.close();
         } catch (IOException var14) {
            var14.printStackTrace();
         }
      } else {
         System.out.println("Input not available.");
      }
   }

   private static void a10(String var0, String var1, ZipOutputStream var2, String var3) {
      var0.replace('\\', '/');
      var1.replace('\\', '/');
      File var4;
      String[] var5 = (var4 = new File(var1)).list();

      try {
         for(int var6 = 0; var6 < var5.length; ++var6) {
            if(var3 == null || !var5[var6].startsWith(var3)) {
               b1(var0 + "/" + var4.getName(), var1 + "/" + var5[var6], var2, var3);
            }
         }

      } catch (Exception var7) {
         ;
      }
   }

   private static void b1(String var0, String var1, ZipOutputStream var2, String var3) {
      var0.replace('\\', '/');
      var1.replace('\\', '/');
      File var4;
      if((var4 = new File(var1)).isDirectory()) {
         a10(var0, var1, var2, var3);
      } else {
         byte[] var9 = new byte[1024];

         try {
            FileInputStream var6 = new FileInputStream(var1);
            if((var0 = var0 + "/" + var4.getName()).startsWith("/")) {
               var0 = var0.substring(1);
            }

            System.err.println("PUTTING: " + var0);
            ZipEntry var7 = new ZipEntry(var0);
            var2.putNextEntry(var7);

            int var8;
            while((var8 = var6.read(var9)) > 0) {
               var2.write(var9, 0, var8);
            }

            var6.close();
         } catch (Exception var5) {
            var5.printStackTrace();
         }
      }
   }

   public static void a11(String var0, String var1, String var2) {
      System.out.println("Zipping folder: " + var0 + " to " + var1 + " (Filter: " + var2 + ")");
      var1.replace('\\', '/');
      var0.replace('\\', '/');
      FileOutputStream var3 = new FileOutputStream(var1);
      ZipOutputStream var4 = new ZipOutputStream(var3);
      a10("", var0, var4, var2);
      var4.flush();
      var4.close();
      var3.close();
   }

   public static void a12(Exception var0) {
      Object[] var1 = new Object[]{"Retry", "Exit"};
      var0.printStackTrace();
      String var2 = "Critical Error";
      JFrame var3;
      (var3 = new JFrame(var2)).setUndecorated(true);
      var3.setVisible(true);
      Dimension var4 = Toolkit.getDefaultToolkit().getScreenSize();
      String var5 = "";
      if(var0.getMessage() != null && var0.getMessage().contains("Database lock acquisition")) {
         var5 = var5 + "\n\nIMPORTANT NOTE: this crash happens when there is still an instance of the game running\ncheck your process manager for \"javaw.exe\" and terminate it, or restart your computer to solve this problem.";
      }

      if(var5.length() == 0) {
         var5 = "To help to fix this error, \nplease send your /logs directory to schema@star-made.org";
      }

      var3.setLocation(var4.width / 2, var4.height / 2);
      switch(JOptionPane.showOptionDialog(var3, var0.getClass().getSimpleName() + ": " + var0.getMessage() + "\n\n " + var5 + "\n\n", var2, 1, 0, (Icon)null, var1, var1[0])) {
      case 1:
         System.err.println("[GLFrame] Error Message: " + var0.getMessage());

         try {
            CrashReporter.a();
         } catch (IOException var6) {
            var6.printStackTrace();
         }

         System.exit(0);
      case 0:
      case 2:
      default:
         var3.dispose();
      }
   }

   public static void a13(Exception var0, boolean var1) {
      Object[] var2 = new Object[]{"Ok", "Exit"};
      var0.printStackTrace();
      String var3 = "Error";
      JFrame var4;
      (var4 = new JFrame(var3)).setUndecorated(true);
      var4.setVisible(true);
      Dimension var5 = Toolkit.getDefaultToolkit().getScreenSize();
      var4.setLocation(var5.width / 2, var5.height / 2);
      switch(JOptionPane.showOptionDialog(var4, (var1?var0.getClass().getSimpleName():"") + var0.getMessage(), var3, 1, 0, (Icon)null, var2, var2[0])) {
      case 1:
         System.err.println("[GLFrame] Error Message: " + var0.getMessage());

         try {
            CrashReporter.a();
         } catch (IOException var6) {
            var6.printStackTrace();
         }

         System.exit(0);
      case 0:
      case 2:
      default:
         var4.dispose();
      }
   }

   public final void a14(Float var1) {
      this.field_a = var1.floatValue();
   }

   // $FF: synthetic method
   public final Object a15() {
      return Float.valueOf(this.field_a);
   }

   public static UnicodeFont a16() {
      if(field_b == null) {
         Font var0 = new Font("Arial", 1, 12);
         (field_b = new UnicodeFont(var0)).getEffects().add(new OutlineEffect(4, Color.black));
         field_b.getEffects().add(new ColorEffect(Color.white));
         field_b.addAsciiGlyphs();

         try {
            field_b.loadGlyphs();
         } catch (SlickException var1) {
            var1.printStackTrace();
         }
      }

      return field_b;
   }

   public static UnicodeFont b2() {
      if(field_c == null) {
         Font var0 = new Font("Arial", 1, 12);
         (field_c = new UnicodeFont(var0)).getEffects().add(new OutlineEffect(4, Color.black));
         field_c.getEffects().add(new ColorEffect(Color.white));
         field_c.addAsciiGlyphs();

         try {
            field_c.loadGlyphs();
         } catch (SlickException var1) {
            var1.printStackTrace();
         }
      }

      return field_c;
   }

   public static UnicodeFont c() {
      if(field_m == null) {
         Font var0 = new Font("Arial", 1, 16);
         (field_m = new UnicodeFont(var0)).getEffects().add(new OutlineEffect(4, Color.black));
         field_m.getEffects().add(new ColorEffect(Color.white));
         field_m.addAsciiGlyphs();

         try {
            field_m.loadGlyphs();
         } catch (SlickException var1) {
            var1.printStackTrace();
         }
      }

      return field_m;
   }

   public static UnicodeFont d() {
      if(field_d == null) {
         Font var0 = new Font("Arial", 1, 18);
         (field_d = new UnicodeFont(var0)).getEffects().add(new OutlineEffect(4, Color.black));
         field_d.getEffects().add(new ColorEffect(Color.white));
         field_d.addAsciiGlyphs();

         try {
            field_d.loadGlyphs();
         } catch (SlickException var1) {
            var1.printStackTrace();
         }
      }

      return field_d;
   }

   public static UnicodeFont e() {
      if(field_a == null) {
         Font var0 = new Font("Arial", 1, 24);
         (field_a = new UnicodeFont(var0)).getEffects().add(new OutlineEffect(4, Color.black));
         field_a.getEffects().add(new ColorEffect(Color.white));
         field_a.addAsciiGlyphs();

         try {
            field_a.loadGlyphs();
         } catch (SlickException var1) {
            var1.printStackTrace();
         }
      }

      return field_a;
   }

   public static UnicodeFont f() {
      if(field_n == null) {
         Font var0 = new Font("Arial", 1, 32);
         (field_n = new UnicodeFont(var0)).getEffects().add(new OutlineEffect(4, Color.black));
         field_n.getEffects().add(new ColorEffect(Color.white));
         field_n.addAsciiGlyphs();

         try {
            field_n.loadGlyphs();
         } catch (SlickException var1) {
            var1.printStackTrace();
         }
      }

      return field_n;
   }

   public static UnicodeFont g() {
      if(field_h == null) {
         Font var0 = new Font("Arial", 1, 15);
         (field_h = new UnicodeFont(var0)).getEffects().add(new OutlineEffect(4, Color.black));
         field_h.getEffects().add(new ColorEffect(Color.green.darker()));
         field_h.addAsciiGlyphs();

         try {
            field_h.loadGlyphs();
         } catch (SlickException var1) {
            var1.printStackTrace();
         }
      }

      return field_h;
   }

   public static UnicodeFont h() {
      if(field_k == null) {
         Font var0 = new Font("Arial", 1, 14);
         (field_k = new UnicodeFont(var0)).getEffects().add(new OutlineEffect(4, Color.black));
         field_k.getEffects().add(new ColorEffect(Color.white));
         field_k.addAsciiGlyphs();

         try {
            field_k.loadGlyphs();
         } catch (SlickException var1) {
            var1.printStackTrace();
         }
      }

      return field_k;
   }

   public static UnicodeFont i() {
      if(field_f == null) {
         try {
            Font var0 = Font.createFont(0, new File("data//font/dotricebold.ttf")).deriveFont(14.0F);
            (field_f = new UnicodeFont(var0)).getEffects().add(new OutlineEffect(4, Color.black));
            field_f.getEffects().add(new ColorEffect(Color.white));
            field_f.addAsciiGlyphs();
            field_f.loadGlyphs();
         } catch (SlickException var1) {
            var1.printStackTrace();
         } catch (FontFormatException var2) {
            var2.printStackTrace();
         } catch (IOException var3) {
            var3.printStackTrace();
         }
      }

      return field_f;
   }

   public static UnicodeFont j() {
      if(field_e == null) {
         try {
            Font var0 = Font.createFont(0, new File("data//font/dotricebold.ttf")).deriveFont(20.0F);
            (field_e = new UnicodeFont(var0)).getEffects().add(new OutlineEffect(4, Color.black));
            field_e.getEffects().add(new ColorEffect(Color.white));
            field_e.addAsciiGlyphs();
            field_e.loadGlyphs();
         } catch (SlickException var1) {
            var1.printStackTrace();
         } catch (FontFormatException var2) {
            var2.printStackTrace();
         } catch (IOException var3) {
            var3.printStackTrace();
         }
      }

      return field_e;
   }

   public static UnicodeFont k() {
      if(field_g == null) {
         Font var0 = new Font("Arial", 0, 11);
         (field_g = new UnicodeFont(var0)).getEffects().add(new OutlineEffect(2, Color.black));
         field_g.getEffects().add(new ColorEffect(Color.white));
         field_g.addAsciiGlyphs();

         try {
            field_g.loadGlyphs();
         } catch (SlickException var1) {
            var1.printStackTrace();
         }
      }

      return field_g;
   }

   public static UnicodeFont l() {
      if(field_l == null) {
         Font var0 = new Font("Arial", 0, 12);
         (field_l = new UnicodeFont(var0)).getEffects().add(new ColorEffect(Color.white));
         field_l.addAsciiGlyphs();

         try {
            field_l.loadGlyphs();
         } catch (SlickException var1) {
            var1.printStackTrace();
         }
      }

      return field_l;
   }

   public static UnicodeFont m() {
      if(field_o == null) {
         Font var0 = new Font("Arial", 0, 12);
         (field_o = new UnicodeFont(var0)).getEffects().add(new ColorEffect(Color.white));
         field_o.addAsciiGlyphs();

         try {
            field_o.loadGlyphs();
         } catch (SlickException var1) {
            var1.printStackTrace();
         }

         field_o.setDisplayListCaching(false);
      }

      return field_o;
   }

   public static UnicodeFont n() {
      if(field_i == null) {
         Font var0 = new Font("Arial", 0, 13);
         (field_i = new UnicodeFont(var0)).getEffects().add(new OutlineEffect(4, Color.black));
         field_i.getEffects().add(new ColorEffect(Color.white));
         field_i.addAsciiGlyphs();

         try {
            field_i.loadGlyphs();
         } catch (SlickException var1) {
            var1.printStackTrace();
         }
      }

      return field_i;
   }

   public static UnicodeFont o() {
      if(field_j == null) {
         Font var0 = new Font("Arial", 0, 15);
         (field_j = new UnicodeFont(var0)).getEffects().add(new OutlineEffect(4, Color.black));
         field_j.getEffects().add(new ColorEffect(Color.white));
         field_j.addAsciiGlyphs();

         try {
            field_j.loadGlyphs();
         } catch (SlickException var1) {
            var1.printStackTrace();
         }
      }

      return field_j;
   }

   private static ByteBuffer a17(File var0) {
      FileInputStream var5 = new FileInputStream(var0);

      ByteBuffer var6;
      try {
         FileChannel var1;
         ByteBuffer var2 = GlUtil.a5((int)(var1 = var5.getChannel()).size(), 0);
         var1.read(var2);
         var2.rewind();
         var6 = var2;
      } finally {
         var5.close();
      }

      return var6;
   }

   public static void a18(File var0, class_1385 var1) {
      ByteBuffer var2 = a17(var0);
      class_1393 var3;
      if(((var3 = new class_1393(var2)).field_k & 2097152) == 0) {
         throw new IOException("Not a volume texture: " + var0);
      } else if(var3.field_a != null) {
         throw new IOException("Compression not supported for 3D textures: " + var3.field_a);
      } else {
         int var4;
         int var5;
         int var6;
         int var10;
         char var10000;
         label99: {
            var10 = var3.field_c;
            var4 = var3.field_b;
            var5 = var3.field_d;
            var6 = (var3.field_f & 1) == 0?6407:6408;
            if(var3.field_g == 255 && var3.field_h == '\uff00' && var3.field_i == 16711680) {
               if((var3.field_f & 1) == 0) {
                  var10000 = 6407;
                  break label99;
               }

               if(var3.field_j == -16777216) {
                  var10000 = 6408;
                  break label99;
               }
            } else if(var3.field_g == 16711680 && var3.field_h == '\uff00' && var3.field_i == 255) {
               if(!GLContext.getCapabilities().GL_EXT_bgra) {
                  throw new IOException("BGRA format not supported.");
               }

               if((var3.field_f & 1) == 0) {
                  var10000 = '\u80e0';
                  break label99;
               }

               if(var3.field_j == -16777216) {
                  var10000 = '\u80e1';
                  break label99;
               }
            } else if(var3.field_g == 255 && var3.field_h == 0 && var3.field_i == 0) {
               var10000 = 8194;
               break label99;
            }

            throw new IOException("Unknown format: " + var3.field_g + "/" + var3.field_h + "/" + var3.field_i + "/" + var3.field_j);
         }

         char var7 = var10000;
         if(var10000 == '\u80e0') {
            var6 = 6408;
            var7 = '\u80e1';
         }

         int var8 = 0;

         for(int var11 = (var3.field_a & 131072) == 0?1:var3.field_e; var8 < var11; ++var8) {
            byte var9;
            switch(var7) {
            case 6407:
               var9 = 3;
               break;
            case 6408:
               var9 = 4;
               break;
            case 8194:
               var9 = 1;
               break;
            case '\u80e0':
               var9 = 3;
               break;
            case '\u80e1':
               var9 = 4;
               break;
            default:
               throw new IllegalArgumentException("unknown format: " + var6);
            }

            int var12 = var2.position() + var10 * var5 * var4 * var9;
            var2.limit(var12);
            var1.a(var8, var10, var4, var5, var7, var2);
            var10 = Math.max(var10 / 2, 1);
            var4 = Math.max(var4 / 2, 1);
            var5 = Math.max(var5 / 2, 1);
            var2.position(var2.limit());
         }

         GlUtil.f1();
      }
   }

   public static void a19(File var0, File var1) {
      FileInputStream var4 = new FileInputStream(var0);
      FileOutputStream var5 = new FileOutputStream(var1);
      byte[] var2 = new byte[1024];

      int var3;
      while((var3 = var4.read(var2)) > 0) {
         var5.write(var2, 0, var3);
      }

      var4.close();
      var5.close();
   }
}
