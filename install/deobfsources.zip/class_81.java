
public enum class_81 {

   field_a("FINISH", 0),
   field_b("BYTE", 1),
   field_c("SHORT", 2),
   field_d("INT", 3),
   field_e("LONG", 4),
   field_f("FLOAT", 5),
   field_g("DOUBLE", 6),
   field_h("BYTE_ARRAY", 7),
   field_i("STRING", 8),
   field_j("VECTOR3f", 9),
   field_k("VECTOR3i", 10),
   field_l("VECTOR3b", 11),
   field_m("LIST", 12),
   field_n("STRUCT", 13),
   field_o("SERIALIZABLE", 14);
   // $FF: synthetic field
   private static final class_81[] field_a = new class_81[]{field_a, field_b, field_c, field_d, field_e, field_f, field_g, field_h, field_i, field_j, field_k, field_l, field_m, field_n, field_o};


   private class_81(String var1, int var2) {}

}
