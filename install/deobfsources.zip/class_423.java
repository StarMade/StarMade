
public final class class_423 extends class_15 implements class_1410 {

   public class_350 field_a = new class_350(this.a6());
   public class_406 field_a = new class_406(this.a6());
   public class_348 field_a = new class_348(this.a6());


   public class_423(class_371 var1) {
      super(var1);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      this.field_a.c2(true);
   }

   public final void b2(boolean var1) {
      if(var1) {
         class_967.b("0022_menu_ui - swoosh scroll large");
         this.setChanged();
         this.notifyObservers();
      } else {
         class_967.b("0022_menu_ui - swoosh scroll small");
      }

      super.b2(var1);
   }

   public final void a15(class_935 var1) {
      class_1008.field_a = false;
      super.a15(var1);
   }

   private class_777 a46() {
      int var1 = this.a6().a20().h1();
      return this.a6().a45().a146(var1);
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.field_a && var2.field_a == 0) {
         if("PERSONAL".equals(var1.b19())) {
            this.a11(this.field_a);
            this.setChanged();
            this.notifyObservers();
            return;
         }

         if("HUB".equals(var1.b19())) {
            this.a11(this.field_a);
            this.setChanged();
            this.notifyObservers();
            return;
         }

         if("LOCAL".equals(var1.b19())) {
            this.a11(this.field_a);
            this.setChanged();
            this.notifyObservers();
            return;
         }

         if("INCOMING_INVITES".equals(var1.b19())) {
            (new class_258(this.a6(), this)).c1();
            return;
         }

         if("OUTGOING_INVITES".equals(var1.b19())) {
            (new class_121(this.a6(), this)).c1();
            return;
         }

         class_777 var4;
         if("EDIT_DESC".equals(var1.b19())) {
            this.e2(true);
            var4 = this.a46();
            (new class_424(this, this.a6(), "Edit Faction Description", "Enter a description for the faction", var4 != null?var4.c5():"ERROR: NO FACTION")).c1();
            return;
         }

         if("POST_NEWS".equals(var1.b19())) {
            this.e2(true);
            this.a46();
            (new class_410(this, this.a6(), "Post Faction News", "Enter text for a new News Post", "")).c1();
            return;
         }

         if("CREATE_FACTION".equals(var1.b19())) {
            if(this.a6().b().isEmpty()) {
               class_415 var3 = new class_415(this.a6(), "Change Faction Name", this);
               this.a6().b().add(var3);
               this.e2(true);
               this.setChanged();
               this.notifyObservers();
               return;
            }
         } else if("LEAVE_FACTION".equals(var1.b19())) {
            if(this.a6().b().isEmpty()) {
               (new class_409(this.a6(), "Confirm", "Do you really want to leave the faction")).c1();
               return;
            }
         } else if("ROLES".equals(var1.b19()) && this.a6().b().isEmpty()) {
            if((var4 = this.a46()) != null) {
               this.e2(true);
               (new class_413(this, this.a6(), var4)).c1();
               return;
            }

            this.a6().a4().b1("ERROR: not in a faction");
         }
      }

   }

   public final boolean a1() {
      return false;
   }

   public final void b() {
      this.e2(true);
      (new class_436(this.a6())).c1();
   }
}
