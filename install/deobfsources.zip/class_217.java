import org.schema.game.common.data.world.Segment;

final class class_217 implements class_892 {

   // $FF: synthetic field
   private class_219 field_a;


   private class_217(class_219 var1) {
      this.field_a = var1;
      super();
   }

   public final boolean handle(Segment var1) {
      class_661 var2;
      if((var2 = (class_661)var1).b6()) {
         class_219.a(this.field_a).add(var2);
      }

      return !class_927.a1();
   }

   // $FF: synthetic method
   class_217(class_219 var1, byte var2) {
      this(var1);
   }
}
