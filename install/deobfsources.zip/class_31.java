import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.Action;
import javax.swing.JList;
import javax.swing.KeyStroke;

public final class class_31 implements MouseListener {

   private static final KeyStroke field_a = KeyStroke.getKeyStroke(10, 0);
   private JList field_a;
   private KeyStroke field_b;


   public class_31(JList var1, Action var2) {
      this(var1, var2, field_a);
   }

   private class_31(JList var1, Action var2, KeyStroke var3) {
      this.field_a = var1;
      this.field_b = var3;
      var1.getInputMap().put(var3, var3);
      this.field_a.getActionMap().put(this.field_b, var2);
      var1.addMouseListener(this);
   }

   public final void mouseClicked(MouseEvent var1) {
      Action var3;
      if(var1.getClickCount() == 2 && (var3 = this.field_a.getActionMap().get(this.field_b)) != null) {
         ActionEvent var2 = new ActionEvent(this.field_a, 1001, "");
         var3.actionPerformed(var2);
      }

   }

   public final void mouseEntered(MouseEvent var1) {}

   public final void mouseExited(MouseEvent var1) {}

   public final void mousePressed(MouseEvent var1) {}

   public final void mouseReleased(MouseEvent var1) {}

}
