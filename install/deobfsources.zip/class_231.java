
public enum class_231 {

   field_a("BLUE", 0),
   field_b("GREEN", 1),
   field_c("RED", 2),
   field_d("WHITE", 3),
   field_e("PURPLE", 4),
   field_f("YELLOW", 5);
   // $FF: synthetic field
   private static final class_231[] field_a = new class_231[]{field_a, field_b, field_c, field_d, field_e, field_f};


   private class_231(String var1, int var2) {}

}
