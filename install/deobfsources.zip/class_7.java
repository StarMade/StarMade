import com.bulletphysics.collision.dispatch.CollisionWorld;
import com.bulletphysics.linearmath.Transform;
import java.util.Iterator;
import javax.vecmath.Matrix4f;
import javax.vecmath.Vector3f;
import javax.vecmath.Vector4f;
import org.schema.game.common.controller.EditableSendableSegmentController;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.controller.elements.ManagerContainer;
import org.schema.game.common.controller.elements.ShieldContainerInterface;
import org.schema.game.common.data.element.Element;
import org.schema.game.common.data.element.ElementDocking;
import org.schema.game.common.data.physics.CubeRayCastResult;
import org.schema.game.common.data.physics.ModifiedDynamicsWorld;
import org.schema.game.common.data.physics.PhysicsExt;
import org.schema.game.common.data.world.Segment;
import org.schema.game.common.data.world.Universe;
import org.schema.schine.network.Identifiable;
import org.schema.schine.network.StateInterface;
import org.schema.schine.network.objects.Sendable;

public class class_7 extends class_946 {

   private StateInterface field_a;
   private int field_a;
   private Vector3f field_a = new Vector3f();
   private Vector4f field_a = new Vector4f();
   private Vector3f field_b = new Vector3f();
   private Vector3f field_c = new Vector3f();
   private Vector3f field_d = new Vector3f();
   private Vector3f field_e = new Vector3f();
   private boolean field_a;
   private Segment field_a;
   // $FF: synthetic field
   private static boolean field_b = !L.class.desiredAssertionStatus();


   public class_7(StateInterface var1, int var2) {
      new Vector3f();
      this.field_a = var1;
      this.field_a = var2;
   }

   public final void a(SegmentController var1, Vector3f var2, Vector3f var3, float var4, float var5) {
      int var6 = super.a14(var2, var3);
      super.field_a.c1(var6, var4, var5, (float)var1.getId());
   }

   private boolean a1(SegmentController var1, Vector3f var2, Vector3f var3, int var4) {
      CollisionWorld.ClosestRayResultCallback var12;
      if((var12 = this.a2().testRayCollisionPoint(var2, var3, false, var1, (SegmentController)null, true, this.field_a, false)).hasHit() && var12.collisionObject != null) {
         if(!field_b && var12.collisionObject.getUserPointer() == null) {
            throw new AssertionError(var12.collisionObject);
         }

         Sendable var15;
         synchronized(this.field_a.getLocalAndRemoteObjectContainer().getLocalObjects()) {
            var15 = (Sendable)this.field_a.getLocalAndRemoteObjectContainer().getLocalUpdatableObjects().get(var12.collisionObject.getUserPointer());
         }

         if(var12 instanceof CubeRayCastResult && ((CubeRayCastResult)var12).getSegment() != null) {
            CubeRayCastResult var5;
            SegmentController var6 = (var5 = (CubeRayCastResult)var12).getSegment().a16().getSegmentController();
            boolean var7 = false;
            boolean var8 = false;
            if(var1.getDockingController().b3()) {
               SegmentController var9;
               var7 = (var9 = var1.getDockingController().a4().field_to.a7().a15()) == var6;
               Iterator var10 = var9.getDockingController().a5().iterator();

               while(var10.hasNext()) {
                  if(((ElementDocking)var10.next()).from.a7().a15().equals(var6)) {
                     var8 = true;
                     break;
                  }
               }
            }

            if(var7 || var8) {
               return true;
            }

            if(!var1.equals(var6) && !var7 && !var8) {
               Segment var18 = var5.getSegment();
               this.field_a = var5.getSegment();
               float var19 = super.field_a.c(var4, this.field_c).field_x;
               if(var18.a15() instanceof EditableSendableSegmentController && !((EditableSendableSegmentController)var18.a15()).canAttack(var1)) {
                  return true;
               }

               ManagerContainer var13;
               ShieldContainerInterface var14;
               if(var18.a15() instanceof class_802 && (var13 = ((class_802)var18.a15()).a()) instanceof ShieldContainerInterface && (var14 = (ShieldContainerInterface)var13).getShieldManager().getShields() > 0.0D && (var19 = (float)var14.handleShieldHit(var5.hitPointWorld, var1, var19)) <= 0.0F) {
                  return true;
               }

               var18.a15().handleHit(var5, var1, var19);
               return true;
            }
         }

         class_1419 var16 = (class_1419)var15;
         if(var12.hasHit() && (var16 == null || var1.getId() != ((Identifiable)var16).getId())) {
            if(var16 == null) {
               if(this.field_a instanceof class_371) {
                  ((class_371)this.field_a).a27().a91().a22(var12);
               }
            } else if(this.field_a instanceof StateInterface) {
               StateInterface var10000 = this.field_a;
               if(var15 instanceof C) {
                  float var17 = super.field_a.c(var4, this.field_c).field_x;
                  ((C)var15).handleHit(var12, var1, var17);
               }
            }

            return true;
         }
      } else if(var12.hasHit()) {
         return true;
      }

      return false;
   }

   private PhysicsExt a2() {
      return this.field_a instanceof class_1035?(PhysicsExt)((class_1035)this.field_a).a62().getSector(this.field_a).a67():(PhysicsExt)((class_371)this.field_a).a19();
   }

   public final StateInterface a3() {
      return this.field_a;
   }

   protected final void a4() {
      this.field_a = true;
   }

   public final void a5(int var1) {
      this.field_a = var1;
   }

   public final void a6(class_935 var1) {
      if(this.b1() > 0) {
         if(this.a2().getDynamicsWorld().getNumCollisionObjects() > 32) {
            ((ModifiedDynamicsWorld)this.a2().getDynamicsWorld()).buildCache();
         }

         super.a6(var1);
         ((ModifiedDynamicsWorld)this.a2().getDynamicsWorld()).cacheValid = false;
      }

   }

   public final boolean a7(int var1, class_935 var2) {
      super.field_a.d(var1, this.field_a);
      super.field_a.a2(var1, this.field_a);
      super.field_a.a4(var1, this.field_b);
      super.field_a.b(var1, this.field_d);
      this.field_e.set(this.field_b);
      float var3 = super.field_a.a3(var1);
      if(this.field_a.length() == 0.0F) {
         super.field_a.a6(var1, (float)((double)var3 + (double)var2.a() * 1000.1D));
      } else {
         this.field_a.scale((float)((double)var2.a() * 1000.0D));
         super.field_a.a6(var1, var3 + this.field_a.length());
         this.field_b.add(this.field_a);
      }

      super.field_a.a7(var1, this.field_b.field_x, this.field_b.field_y, this.field_b.field_z);
      Vector3f var6;
      float var4 = (var6 = super.field_a.c(var1, this.field_c)).field_y;
      int var7 = (int)var6.field_z;
      Sendable var5;
      if((var5 = (Sendable)this.field_a.getLocalAndRemoteObjectContainer().getLocalObjects().get(var7)) != null && var5 instanceof SegmentController) {
         boolean var8 = this.a1((SegmentController)var5, this.field_e, this.field_b, var1);
         if(this.field_a) {
            this.field_a = false;
         }

         return !var8 && this.field_a instanceof class_1035 && (Math.abs(this.field_b.field_x) > (float)(Universe.getSectorSizeWithMargin() / 3) || Math.abs(this.field_b.field_y) > (float)(Universe.getSectorSizeWithMargin() / 3) || Math.abs(this.field_b.field_z) > (float)(Universe.getSectorSizeWithMargin() / 3)) && this.a8(this.field_b, var1)?false:var3 < var4 && !var8;
      } else {
         System.err.println("Exception: No owner for particle found: " + var7 + " -> " + var5);
         return false;
      }
   }

   private boolean a8(Vector3f var1, int var2) {
      if(!field_b && !(this.field_a instanceof class_1035)) {
         throw new AssertionError();
      } else {
         Vector3f var3 = new Vector3f(var1);
         class_673 var4;
         if((var4 = ((class_1035)this.field_a).a62().getSector(this.field_a)) != null) {
            class_47 var5 = var4.field_a;
            int var6 = -1;
            Vector3f var7 = new Vector3f(var3);
            class_47 var8 = new class_47();
            boolean var9 = class_795.a19(var4.field_a);

            for(int var10 = 0; var10 < Element.DIRECTIONSi.length; ++var10) {
               class_47 var11;
               (var11 = new class_47(Element.DIRECTIONSi[var10])).a1(var5);
               Transform var12;
               (var12 = new Transform()).setIdentity();
               if(var9) {
                  Universe.calcSecPos(var5, var11, this.field_a.getController().calculateStartTime(), System.currentTimeMillis(), var12);
               } else {
                  var12.origin.set((float)Element.DIRECTIONSi[var10].field_a, (float)Element.DIRECTIONSi[var10].field_b, (float)Element.DIRECTIONSi[var10].field_c);
                  var12.origin.scale((float)Universe.getSectorSizeWithMargin());
               }

               Vector3f var14;
               (var14 = new Vector3f()).sub(var3, var12.origin);
               if(var14.lengthSquared() < var7.lengthSquared()) {
                  var7.set(var14);
                  var6 = var10;
               }
            }

            if(var6 < 0) {
               return false;
            }

            var8.b1(var5);
            var8.a1(Element.DIRECTIONSi[var6]);

            try {
               if(((class_1035)this.field_a).a62().isSectorLoaded(var8)) {
                  class_673 var15 = ((class_1035)this.field_a).a62().getSector(var8);
                  a10(this.field_a, var4, var15, var3, var1);
                  this.a9(var15.a66(), var2, var1);
                  return true;
               }
            } catch (Exception var13) {
               var13.printStackTrace();
            }
         } else {
            System.err.println("[SERVER][PROJECTILE] Stopping projectile: out of loaded sector range");
         }

         return true;
      }
   }

   private void a9(class_7 var1, int var2, Vector3f var3) {
      if(var1.field_b >= var1.field_a.a1() - 1) {
         var1.field_a.a8();
      }

      boolean var10000 = var1.field_c;
      int var5 = var1.field_b % var1.field_a.a1();
      ++var1.field_b;
      int var4 = var5;
      float[] var8 = super.field_a.a5();
      float[] var6 = var1.field_a.a5();

      for(int var7 = 0; var7 < 17; ++var7) {
         var6[var4 * 17 + var7] = var8[var2 * 17 + var7];
      }

      var1.field_a.a7(var4, var3.field_x, var3.field_y, var3.field_z);
   }

   public static void a10(StateInterface var0, class_673 var1, class_673 var2, Vector3f var3, Vector3f var4) {
      Transform var5;
      (var5 = new Transform()).setIdentity();
      var5.origin.set(var3);
      Universe.calcSecPos(var1.field_a, var2.field_a, var0.getController().calculateStartTime(), System.currentTimeMillis(), var5);
      Transform var6;
      (var6 = new Transform()).setIdentity();
      Transform var7;
      (var7 = new Transform()).setIdentity();
      float var10 = (float)((System.currentTimeMillis() - var0.getController().calculateStartTime()) % 1200000L) / 1200000.0F;
      class_47 var8 = class_793.a192(var1.field_a, new class_47());
      if(!class_795.a19(var1.field_a)) {
         var10 = 0.0F;
      }

      class_47 var9 = new class_47(var8);
      class_47 var11 = new class_47(var1.field_a);
      var9.a5(16);
      var9.a(8, 8, 8);
      var9.c1(var11);
      Vector3f var12;
      (var12 = new Vector3f()).set((float)(var9.field_a * Universe.getSectorSizeWithMargin()), (float)(var9.field_b * Universe.getSectorSizeWithMargin()), (float)(var9.field_c * Universe.getSectorSizeWithMargin()));
      var6.setIdentity();
      var6.origin.add(var12);
      var6.basis.rotX(6.2831855F * var10);
      var6.basis.transform(var6.origin);
      Transform var13;
      (var13 = new Transform()).setIdentity();
      var13.origin.set(var3);
      var13.origin.negate();
      var6.origin.add(var13.origin);
      var9 = new class_47(var8);
      var11 = new class_47(var2.field_a);
      var9.a5(16);
      var9.a(8, 8, 8);
      var9.c1(var11);
      (var12 = new Vector3f()).set((float)(var9.field_a * Universe.getSectorSizeWithMargin()), (float)(var9.field_b * Universe.getSectorSizeWithMargin()), (float)(var9.field_c * Universe.getSectorSizeWithMargin()));
      var7.setIdentity();
      var7.origin.add(var12);
      var7.basis.rotX(6.2831855F * var10);
      var7.basis.transform(var7.origin);
      Matrix4f var15 = new Matrix4f();
      Matrix4f var14 = new Matrix4f();
      var6.getMatrix(var15);
      var7.getMatrix(var14);
      new Transform(var6);
      var7.inverse();
      var6.mul(var7);
      var5.origin.set(var6.origin);
      var5.origin.negate();
      var4.set(var5.origin);
   }

}
