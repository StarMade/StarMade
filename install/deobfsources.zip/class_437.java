
public final class class_437 extends class_438 {

   public final String getUniqueIdentifier() {
      return "SYS_" + super.field_a;
   }
}
