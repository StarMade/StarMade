import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.schema.schine.graphicsengine.core.ResourceException;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public final class class_53 extends DefaultHandler {

   private static class_52 field_a;
   private class_52 field_b;


   public static class_52 a() {
      return field_a;
   }

   public final void characters(char[] var1, int var2, int var3) {}

   public final void endDocument() {}

   public final void endElement(String var1, String var2, String var3) {
      if(("".equals(var2)?var3:var2).equals(this.field_b.field_a)) {
         this.field_b.field_a = true;
         if(this.field_b.field_a != null) {
            this.field_b = this.field_b.field_a;
         }
      }

   }

   public final void a1(String var1) {
      try {
         long var3 = System.currentTimeMillis();
         System.out.println("[XMLParser] Parsing main configuration XML File: data/" + var1);
         SAXParser var2 = SAXParserFactory.newInstance().newSAXParser();

         try {
            var2.parse(class_66.field_a.a2("data/" + var1), this);
         } catch (ResourceException var5) {
            var5.printStackTrace();
         }

         System.out.println("[XMLParser] DONE Parsing main configuration. TIME: " + (System.currentTimeMillis() - var3) + "ms");
      } catch (ParserConfigurationException var6) {
         var6.printStackTrace();
      } catch (SAXException var7) {
         var7.printStackTrace();
      } catch (IOException var8) {
         var8.printStackTrace();
      }
   }

   public final void startDocument() {}

   public final void startElement(String var1, String var2, String var3, Attributes var4) {
      var1 = "".equals(var2)?var3:var2;
      if(field_a == null) {
         (field_a = new class_52()).field_a = var1;
         this.field_b = field_a;
      } else {
         class_52 var6;
         (var6 = new class_52()).field_a = var1;
         if(var4 != null) {
            class_65 var10001 = new class_65();
            String var10003 = var6.field_a;
            var6.field_a = var10001;

            for(int var5 = 0; var5 < var4.getLength(); ++var5) {
               var3 = var4.getLocalName(var5);
               if("".equals(var3)) {
                  var3 = var4.getQName(var5);
               }

               var6.field_a.a1(var4.getValue(var5), var3);
            }
         }

         this.field_b.field_a.add(var6);
         var6.field_a = this.field_b;
         if(!this.field_b.field_a) {
            this.field_b = var6;
         }

      }
   }

   static {
      System.getProperty("line.separator");
   }
}
