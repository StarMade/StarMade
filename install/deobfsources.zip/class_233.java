import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectHeapPriorityQueue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.schema.game.common.controller.EditableSendableSegmentController;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.controller.elements.UsableControllableElementManager;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.graphicsengine.forms.Mesh;

public class class_233 implements class_706, class_923, class_1368 {

   private final Map field_a = new HashMap();
   private final ArrayList field_a = new ArrayList();
   private final ArrayList field_b = new ArrayList();
   private boolean field_a = true;
   private static class_1385 field_a;
   static class_1376 field_a;
   static Mesh field_a;
   static Mesh field_b;
   private class_221 field_a;
   private int field_b;
   private class_229[] field_a;
   private float field_a;
   private boolean field_b;
   private final class_230 field_a;
   private final class_230 field_b;
   private final ObjectHeapPriorityQueue field_a;
   private static ArrayList field_c = new ArrayList();
   public static int field_a = 0;
   // $FF: synthetic field
   private static boolean field_c = !do.class.desiredAssertionStatus();


   public class_233() {
      this.field_a = new class_229[((Integer)class_943.field_ah.a4()).intValue()];
      this.field_a = new class_230(false);
      this.field_b = new class_230(true);
      this.field_a = new ObjectHeapPriorityQueue(this.field_a);
      new ObjectHeapPriorityQueue(this.field_b);
   }

   private static class_229 a(class_233 var0, List var1, class_231 var2) {
      if(field_c.isEmpty()) {
         return new class_229(var0, var1, var2);
      } else {
         var0 = null;
         ArrayList var3 = field_c;
         class_229 var5;
         synchronized(field_c) {
            var5 = (class_229)field_c.remove(0);
         }

         var5.a11(var1, var2);
         return var5;
      }
   }

   private static void a1(class_229 var0) {
      ArrayList var1 = field_c;
      synchronized(field_c) {
         var0.f();
         field_c.add(var0);
      }
   }

   private void a2(List var1, class_231 var2, EditableSendableSegmentController var3) {
      class_229 var5 = a(this, var1, var2);
      ArrayList var6 = this.field_b;
      synchronized(this.field_b) {
         this.field_b.add(new class_239(var5, var3));
      }
   }

   public final void a3() {}

   public final void e() {
      long var1 = System.currentTimeMillis();
      synchronized(this) {
         for(int var4 = 0; var4 < this.field_a.length; ++var4) {
            this.field_a[this.field_b] = null;
         }

         Iterator var8 = this.field_a.values().iterator();

         label31:
         while(true) {
            if(var8.hasNext()) {
               Iterator var5 = ((ArrayList)var8.next()).iterator();

               while(true) {
                  if(!var5.hasNext()) {
                     continue label31;
                  }

                  class_229 var6;
                  (var6 = (class_229)var5.next()).d();
                  a1(var6);
               }
            }

            this.field_b = 0;
            this.field_a.clear();
            break;
         }
      }

      long var3;
      if((var3 = System.currentTimeMillis() - var1) > 10L) {
         System.err.println("[CLIENT] WARNING: CLEARING BREAM DRAW MANAGER TOOK " + var3);
      }

   }

   public final void f() {
      if(this.field_a) {
         this.c();
      }

      if(this.field_b) {
         this.field_a.clear();

         for(int var1 = 0; var1 < this.field_b; ++var1) {
            this.field_a[var1].a9(this.field_a);
         }

      }
   }

   public final void g() {
      GL11.glDisable(2884);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glDepthMask(false);
      field_a.field_a = this;
      field_a.b();
      field_a.h1();
   }

   public final void b() {
      field_a = 0;
      if(this.field_a) {
         this.c();
      }

      if(this.field_b) {
         this.g();

         int var1;
         for(var1 = 0; var1 < this.field_b; ++var1) {
            this.field_a[var1].b();
         }

         h();
         GL11.glEnable(2884);
         GL11.glDisable(2896);
         class_1379.field_u.field_a = this.field_a;
         class_1379.field_u.b();
         field_b.h1();

         for(var1 = 0; var1 < this.field_b; ++var1) {
            this.field_a[var1].e();
         }

         field_b.m1();
         class_1379.field_u.d();
         GL11.glDepthMask(true);
         GL11.glEnable(2896);
         GL11.glDisable(3042);
      }
   }

   public static void h() {
      field_a.m1();
      field_a.d();
      GL11.glDepthMask(true);
   }

   public final void d() {
      GL13.glActiveTexture('\u84c0');
      GL11.glBindTexture('\u806f', 0);
      GL11.glDisable('\u806f');
   }

   public final void c() {
      if(field_a == null) {
         field_a = class_1379.field_w;
      }

      if(field_a == null) {
         field_a = (Mesh)class_967.a2().a4("SimpleBeam").a156().get(0);
      }

      if(field_a == null) {
         field_a = class_333.field_a;
      }

      field_b = (Mesh)class_967.a2().a4("Box").a156().get(0);
      this.field_a = new class_221(field_b.a157().a1().field_c);
      this.field_a = false;
   }

   public final void a4(class_704 var1, Object var2, Object var3) {
      if(var1 instanceof UsableControllableElementManager) {
         UsableControllableElementManager var5 = (UsableControllableElementManager)var1;
         ArrayList var6 = this.field_a;
         synchronized(this.field_a) {
            this.field_a.add(var5);
         }
      }
   }

   public final void a5(class_935 var1) {
      ArrayList var2;
      if(!this.field_b.isEmpty()) {
         var2 = this.field_b;
         synchronized(this.field_b) {
            while(!this.field_b.isEmpty()) {
               class_239 var3 = (class_239)this.field_b.remove(this.field_b.size() - 1);
               synchronized(this) {
                  if(!this.field_a.containsKey(var3.field_a)) {
                     this.field_a.put(var3.field_a, new ArrayList());
                  }

                  ((ArrayList)this.field_a.get(var3.field_a)).add(var3.field_a);
               }
            }
         }
      }

      if(!this.field_a.isEmpty()) {
         var2 = this.field_a;
         synchronized(this.field_a) {
            long var17;
            for(var17 = System.currentTimeMillis(); !this.field_a.isEmpty(); this.field_b = 0) {
               UsableControllableElementManager var5 = (UsableControllableElementManager)this.field_a.remove(0);
               ArrayList var6;
               int var7;
               if((var6 = (ArrayList)this.field_a.get(var5.getSegmentController())) != null) {
                  for(var7 = 0; var7 < var6.size(); ++var7) {
                     class_229 var8;
                     (var8 = (class_229)var6.get(var7)).d();
                     a1(var8);
                  }

                  var6.clear();
                  SegmentController var19 = var5.getSegmentController();
                  long var9 = System.currentTimeMillis();
                  if(var19 instanceof class_743) {
                     this.a2(((class_743)var19).a96().getSalvage().getCollectionManagers(), class_231.field_a, (class_743)var19);
                     this.a2(((class_743)var19).a96().getRepair().getCollectionManagers(), class_231.field_e, (class_743)var19);
                     this.a2(((class_743)var19).a96().getPowerDrain().getCollectionManagers(), class_231.field_c, (class_743)var19);
                     this.a2(((class_743)var19).a96().getPowerSupply().getCollectionManagers(), class_231.field_b, (class_743)var19);
                     ArrayList var11;
                     (var11 = new ArrayList()).add(((class_743)var19).a96().getDockingBeam().getDockingBeamManager());
                     this.a2(var11, class_231.field_d, (class_743)var19);
                  }

                  if(var19 instanceof class_780) {
                     this.a2(((class_780)var19).a179().getRepair().getCollectionManagers(), class_231.field_b, (class_780)var19);
                  }

                  if(var19 instanceof class_848) {
                     this.a2(((class_848)var19).a207().getRepair().getCollectionManagers(), class_231.field_b, (class_848)var19);
                  }

                  long var20;
                  if((var20 = System.currentTimeMillis() - var9) > 5L) {
                     System.err.println("[BEAMDRAWER] WARNING BeamDrawerRefresh of " + var19 + " took " + var20 + " ms");
                  }
               }

               for(var7 = 0; var7 < this.field_a.length; ++var7) {
                  this.field_a[var7] = null;
               }
            }

            long var18;
            if((var18 = System.currentTimeMillis() - var17) > 10L) {
               System.err.println("[CLIENT] WARNING: REFRESHED THE BEAM DRAWERS " + var18);
            }
         }
      }

      for(int var16 = 0; var16 < this.field_b; ++var16) {
         this.field_a[var16].a1(var1);
      }

      this.field_a = (float)((double)this.field_a + (double)(var1.a() / 100.0F) * ((Math.random() + 9.999999747378752E-5D) / 0.10000000149011612D));
      if(this.field_a > 1.0F) {
         this.field_a -= (float)((int)this.field_a);
      }

   }

   public final void a6(class_1376 var1) {
      if(!field_c && field_a.a1() <= 0) {
         throw new AssertionError();
      } else {
         GlUtil.a33(var1, "ticks", this.field_a);
         GL11.glEnable('\u806f');
         GL13.glActiveTexture('\u84c0');
         GL11.glBindTexture('\u806f', field_a.a1());
         GlUtil.a35(var1, "noiseTex", 0);
      }
   }

   public final void a7(Int2ObjectOpenHashMap var1) {
      Iterator var2 = this.field_a.keySet().iterator();

      while(var2.hasNext()) {
         EditableSendableSegmentController var3 = (EditableSendableSegmentController)var2.next();
         if(!var1.containsKey(var3.getId())) {
            Iterator var4 = ((ArrayList)this.field_a.get(var3)).iterator();

            while(var4.hasNext()) {
               class_229 var6;
               (var6 = (class_229)var4.next()).d();
               a1(var6);
            }

            var2.remove();
         }
      }

      Iterator var7 = var1.values().iterator();

      while(var7.hasNext()) {
         class_801 var5 = (class_801)var7.next();
         if(!this.field_a.containsKey(var5)) {
            if(var5 instanceof class_743) {
               System.err.println("ADDING BEAM FOR: " + var5);
               this.a2(((class_743)var5).a96().getSalvage().getCollectionManagers(), class_231.field_a, (class_743)var5);
               this.a2(((class_743)var5).a96().getRepair().getCollectionManagers(), class_231.field_e, (class_743)var5);
               this.a2(((class_743)var5).a96().getPowerDrain().getCollectionManagers(), class_231.field_c, (class_743)var5);
               this.a2(((class_743)var5).a96().getPowerSupply().getCollectionManagers(), class_231.field_b, (class_743)var5);
               ArrayList var8;
               (var8 = new ArrayList()).add(((class_743)var5).a96().getDockingBeam().getDockingBeamManager());
               this.a2(var8, class_231.field_d, (class_743)var5);
            }

            if(var5 instanceof class_780) {
               this.a2(((class_780)var5).a179().getRepair().getCollectionManagers(), class_231.field_b, (class_780)var5);
            }

            if(var5 instanceof class_848) {
               this.a2(((class_848)var5).a207().getRepair().getCollectionManagers(), class_231.field_b, (class_848)var5);
            }
         }
      }

   }

   public final void a8(class_229 var1, boolean var2) {
      System.err.println("NOTIFY: " + var2 + " on " + var1);
      if(var2) {
         if(this.field_b < this.field_a.length) {
            this.field_a[this.field_b] = var1;
            ++this.field_b;
         }
      } else if(this.field_b < this.field_a.length) {
         for(int var3 = 0; var3 < this.field_a.length; ++var3) {
            if(this.field_a[var3] == var1) {
               this.field_a[var3] = this.field_a[this.field_b - 1];
               --this.field_b;
               break;
            }
         }
      }

      this.field_b = this.field_b > 0;
   }

   public final ObjectHeapPriorityQueue a9() {
      return this.field_a;
   }

}
