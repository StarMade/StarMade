import com.bulletphysics.collision.shapes.ConvexShape;
import java.nio.FloatBuffer;
import org.schema.common.util.ByteUtil;
import org.schema.game.client.view.cubes.CubeMeshBufferContainer;
import org.schema.game.client.view.cubes.CubeOptOptMesh;

public abstract class class_384 {

   public static final int[][] field_a = new int[3][16];
   public static final int[][] field_b = new int[3][16];
   public static final int[][] field_c = new int[3][16];
   public static class_384[][] field_a;
   public static final int[][] field_d;
   // $FF: synthetic field
   private static boolean field_a = !dO.class.desiredAssertionStatus();


   protected static void a3(int var0, short var1, byte var2, short var3, byte var4, byte var5, boolean var6, boolean var7, int var8, int var9, short var10, int var11, float var12, CubeMeshBufferContainer var13) {
      ByteUtil.a2((byte)var0, var2, var3, var4, var5, (byte)(var6?1:0), (byte)(var7?1:0));
      byte var14 = var13.a2(var8, var9 + var10, 0);
      byte var15 = var13.a2(var8, var9 + var10, 1);
      byte var16 = var13.a2(var8, var9 + var10, 2);
      a4(var0, var1, var2, var3, var4, var5, var6, var7, var10, var11, var14, var15, var16, var12, var13.field_a);
   }

   protected static void a4(int var0, short var1, byte var2, short var3, byte var4, byte var5, boolean var6, boolean var7, short var8, int var9, byte var10, byte var11, byte var12, float var13, FloatBuffer var14) {
      float var16 = ByteUtil.a2((byte)var0, var2, var3, var4, var5, (byte)(var6?1:0), (byte)(var7?1:0));
      float var17 = ByteUtil.a3((float)var9, var10, var11, var12);
      float var15 = (float)((byte)field_d[var0][var1]) + var16;
      var14.put(var17);
      var14.put(var15);
      if(CubeMeshBufferContainer.field_a > 2) {
         var14.put(var13);
      }

      if(var9 + var8 > CubeOptOptMesh.field_e) {
         CubeOptOptMesh.field_e = var9 + var8;
      }

      if(!field_a && var9 + var8 >= '\uc000') {
         throw new AssertionError("vert index is bigger: " + (var9 + var8) + "/49152");
      }
   }

   public abstract void a1(int var1, byte var2, short var3, byte var4, byte var5, int var6, int var7, int var8, float var9, CubeMeshBufferContainer var10);

   public static void b(int var0, byte var1, short var2, byte var3, byte var4, int var5, int var6, int var7, float var8, CubeMeshBufferContainer var9) {
      for(short var10 = 0; var10 < 4; ++var10) {
         a3(var0, var10, var1, var2, var3, var4, false, false, var5, var6, var10, var7, var8, var9);
      }

   }

   public String toString() {
      return this.getClass().getSimpleName();
   }

   public static boolean a5() {
      return true;
   }

   public static ConvexShape a6(int var0, byte var1, boolean var2) {
      return field_a[var0 - 1][var1 + (var2?0:8)].a2();
   }

   protected abstract ConvexShape a2();

   static {
      for(int var0 = 0; var0 < field_a.length; ++var0) {
         for(int var1 = 0; var1 < 16; field_c[var0][var1] = var1++) {
            field_a[var0][var1] = var1;
            field_b[var0][var1] = var1;
         }
      }

      field_a[1][4] = 5;
      field_a[1][5] = 4;
      field_a[1][7] = 6;
      field_a[1][6] = 7;
      field_a[1][0] = 1;
      field_a[1][1] = 0;
      field_a[1][3] = 2;
      field_a[1][2] = 3;
      field_a[1][12] = 13;
      field_a[1][13] = 12;
      field_a[1][15] = 14;
      field_a[1][14] = 15;
      field_a[1][8] = 9;
      field_a[1][9] = 8;
      field_a[1][11] = 10;
      field_a[1][10] = 11;
      field_b[1][1] = 5;
      field_b[1][5] = 1;
      field_b[1][0] = 4;
      field_b[1][4] = 0;
      field_b[1][3] = 7;
      field_b[1][7] = 3;
      field_b[1][2] = 6;
      field_b[1][6] = 2;
      field_b[1][9] = 13;
      field_b[1][13] = 9;
      field_b[1][8] = 12;
      field_b[1][12] = 8;
      field_b[1][11] = 15;
      field_b[1][15] = 11;
      field_b[1][10] = 14;
      field_b[1][14] = 10;
      field_c[1][0] = 3;
      field_c[1][3] = 0;
      field_c[1][1] = 2;
      field_c[1][2] = 1;
      field_c[1][4] = 7;
      field_c[1][7] = 4;
      field_c[1][5] = 6;
      field_c[1][6] = 5;
      field_c[1][8] = 11;
      field_c[1][11] = 8;
      field_c[1][9] = 10;
      field_c[1][10] = 9;
      field_c[1][12] = 15;
      field_c[1][15] = 12;
      field_c[1][13] = 14;
      field_c[1][14] = 13;
      field_a[0][4] = 6;
      field_a[0][6] = 4;
      field_a[0][0] = 2;
      field_a[0][2] = 0;
      field_a[0][8] = 9;
      field_a[0][9] = 8;
      field_a[0][12] = 13;
      field_a[0][13] = 12;
      field_a[0][10] = 11;
      field_a[0][11] = 10;
      field_a[0][14] = 15;
      field_a[0][15] = 14;
      field_b[0][1] = 7;
      field_b[0][7] = 1;
      field_b[0][5] = 3;
      field_b[0][3] = 5;
      field_b[0][0] = 4;
      field_b[0][4] = 0;
      field_b[0][2] = 6;
      field_b[0][6] = 2;
      field_c[0][1] = 3;
      field_c[0][3] = 1;
      field_c[0][5] = 7;
      field_c[0][7] = 5;
      field_c[0][8] = 10;
      field_c[0][10] = 8;
      field_c[0][12] = 14;
      field_c[0][14] = 12;
      field_c[0][9] = 11;
      field_c[0][11] = 9;
      field_c[0][13] = 15;
      field_c[0][15] = 13;
      field_a = new class_384[][]{{new class_277(), new class_289(), new class_279(), new class_275(), new class_207(), new class_211(), new class_205(), new class_209(), new class_269(), new class_281(), new class_271(), new class_267(), new class_269(), new class_281(), new class_271(), new class_267(), new class_273()}, {new class_362(), new class_366(), new class_368(), new class_364(), new class_372(), new class_374(), new class_380(), new class_376(), new class_362(), new class_366(), new class_368(), new class_364(), new class_372(), new class_374(), new class_380(), new class_376(), new class_370()}, {new class_360(), new class_360(), new class_360(), new class_360(), new class_360(), new class_360(), new class_360(), new class_360()}};
      field_d = new int[][]{{1, 0, 2, 3}, {3, 2, 0, 1}, {1, 0, 2, 3}, {2, 3, 1, 0}, {3, 2, 0, 1}, {1, 0, 2, 3}};
   }
}
