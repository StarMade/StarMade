import org.schema.schine.ai.stateMachines.FSMException;

public class class_482 extends class_11 {

   private class_913 field_a;
   private class_454 field_a;
   // $FF: synthetic field
   private static boolean field_b = !bI.class.desiredAssertionStatus();


   public class_482(class_371 var1, String var2, class_454 var3) {
      super(var1);
      this.field_a = var3;
      this.field_a = new class_913(var1, this, var2);
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.field_a && var2.field_a == 0 && !b1()) {
         class_11.field_a = System.currentTimeMillis();
         if(var1.b19().equals("NEXT")) {
            class_967.b("0022_menu_ui - enter");
            this.field_a.b1();
            this.d();
            return;
         }

         if(var1.b19().equals("BACK")) {
            class_967.b("0022_menu_ui - enter");

            try {
               super.field_a.a4().a5().a();
               return;
            } catch (FSMException var3) {
               System.err.println("FSMException: " + var3.getMessage());
               return;
            }
         }

         if(var1.b19().equals("SKIP")) {
            class_967.b("0022_menu_ui - cancel");
            super.field_a.a4().a5().f();
            return;
         }

         if(var1.b19().equals("END")) {
            class_967.b("0022_menu_ui - cancel");
            super.field_a.a4().a5().b();
            return;
         }

         if(!field_b) {
            throw new AssertionError("not known command: " + var1.b19());
         }
      }

   }

   public final class_454 a80() {
      return this.field_a;
   }

   public final class_964 a3() {
      return this.field_a;
   }

   public void handleKeyEvent() {}

   public final boolean a1() {
      return false;
   }

   public final void a2() {}

}
