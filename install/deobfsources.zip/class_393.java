
public final class class_393 extends class_956 {

   private static final long serialVersionUID = 5630908075495941307L;


}
