
public final class class_389 extends class_956 {

   private static final long serialVersionUID = 1L;


}
