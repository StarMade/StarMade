
public final class class_469 extends class_15 implements class_1410 {

   public class_635 field_a;


   public class_469(class_371 var1) {
      super(var1);
   }

   public final class_371 a6() {
      return super.a6();
   }

   public final void handleKeyEvent() {}

   public final void a12(class_941 var1) {
      super.a12(var1);
   }

   public final void b2(boolean var1) {
      class_1008.field_a = !var1;
      if(var1) {
         class_967.b("0022_menu_ui - swoosh scroll large");
         this.setChanged();
         this.notifyObservers();
      } else {
         class_967.b("0022_menu_ui - swoosh scroll small");
      }

      super.a6().a14().field_a.field_a.field_a.a51().a45().field_a.e2(var1);
      super.a6().a14().field_a.field_a.field_a.a51().a45().field_a.e2(var1);
      super.b2(var1);
   }

   public final void a15(class_935 var1) {
      class_1008.field_a = false;
      super.a6().a14().field_a.field_a.field_a.e2(true);
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.field_a && var2.field_a == 0 && "CONVERT".equals(var1.b19()) && this.field_a != null && this.field_a instanceof class_639) {
         ((class_639)this.field_a).c1();
      }

   }

   public final boolean a1() {
      return false;
   }

   public final void b() {
      synchronized(super.a6().b()) {
         super.a6().b().add(new class_314(super.a6()));
         this.e2(true);
      }
   }
}
