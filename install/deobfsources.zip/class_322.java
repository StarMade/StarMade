import org.schema.game.common.data.element.ElementKeyMap;

public final class class_322 extends class_316 {

   public class_322(class_371 var1, short var2, class_739 var3) {
      super(var1, var2, "Buy Quantity", new class_320(ElementKeyMap.getInfo(var2), var3), 1);
      ((class_320)this.field_a).field_a = 1;
      this.a10(new class_324(this, var2));
      super.field_a.a83(new class_326(this));
   }

   public final boolean a7(String var1) {
      int var2 = Integer.parseInt(var1);
      super.field_a.a20().a115().a(this.field_a, var2);
      return true;
   }
}
