import java.io.IOException;
import org.schema.schine.graphicsengine.core.ResourceException;

final class class_315 extends class_73 {

   public final void a(class_66 var1) {
      try {
         System.err.println("Loading effects");
         (class_333.field_b = new class_1389[2])[0] = class_967.a3().a6("data/./effects/dudvmap.jpg", true);
         class_333.field_b[1] = class_967.a3().a6("data/./effects/noise.jpg", true);
         System.err.println("Loading effects done");
      } catch (IOException var2) {
         var2.printStackTrace();
         throw new ResourceException("data/./effects/");
      }
   }
}
