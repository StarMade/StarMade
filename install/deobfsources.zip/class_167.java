import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import java.util.TreeSet;
import org.schema.schine.network.client.ClientState;

public class class_167 extends class_964 implements Observer {

   private int field_a;
   private int field_b;
   private class_966 field_a;
   private class_963 field_a;
   private boolean field_a;
   // $FF: synthetic field
   private static boolean field_b = !hK.class.desiredAssertionStatus();


   public class_167(ClientState var1) {
      super(var1);
      ((class_371)var1).a45().addObserver(this);
      this.field_a = 540;
      this.field_b = 205;
   }

   public final void a2() {}

   public final void b() {
      if(((class_371)this.a24()).a4().a29() != null) {
         ((class_371)this.a24()).a4().a29().addObserver(this);
         if(this.field_a) {
            System.err.println("[FACTIONNEWS] UPDATE NEWS");
            class_167 var1 = this;
            class_777 var2 = ((class_371)this.a24()).a45().a146(((class_371)this.a24()).a20().h1());
            this.field_a.clear();
            if(var2 != null) {
               TreeSet var5 = (TreeSet)((class_371)this.a24()).a45().a154().get(Integer.valueOf(var2.a3()));
               if(!field_b && ((class_371)this.a24()).a4().a29() == null) {
                  throw new AssertionError();
               }

               if(!field_b && ((class_371)this.a24()).a4().a29().a7() == null) {
                  throw new AssertionError();
               }

               if(var5 != null) {
                  var5.addAll(((class_371)this.a24()).a4().a29().a7());
               } else {
                  var5 = ((class_371)this.a24()).a4().a29().a7();
               }

               if(var5 != null) {
                  int var3 = 0;
                  Iterator var6 = var5.descendingSet().iterator();

                  while(var6.hasNext()) {
                     class_760 var4 = (class_760)var6.next();
                     class_111 var9 = new class_111(var1.a24(), var4, var3);
                     ++var3;
                     var1.field_a.a144(var9);
                  }
               }

               class_1412 var7 = new class_1412(var1.a24(), 540.0F, 50.0F);
               class_928 var8 = new class_928((class_371)var1.a24(), 200, 20, "Request next 5", new class_165(var1));
               var7.a9(var8);
               var8.a83().field_x = 140.0F;
               var8.a83().field_y = 12.0F;
               var8.b14(40, 2);
               var1.field_a.a144(new class_972(var7, var7, var1.a24()));
            }

            this.field_a = false;
         }

         this.k();
      }
   }

   public final void c() {
      this.field_a = new class_966((float)this.field_a, (float)this.field_b, this.a24());
      this.field_a = new class_963(this.a24());
      this.field_a.c6(this.field_a);
      this.field_a = true;
      this.a9(this.field_a);
   }

   public final float a3() {
      return (float)this.field_b;
   }

   public final float b1() {
      return (float)this.field_a;
   }

   public void update(Observable var1, Object var2) {
      System.err.println("[CLIENT][GUI][FACTIONNEWS] OBSERVER: GUI UPDATE FLAG NEWS");
      this.field_a = true;
   }

}
