import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import java.util.concurrent.ConcurrentHashMap;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;
import org.schema.schine.network.objects.Sendable;

public final class class_116 extends class_964 implements Observer {

   private class_970 field_a = new class_970(class_967.a2().a5("panel-std-gui-"), this.a24());
   private class_966 field_a = new class_966(512.0F, 366.0F, this.a24());
   private class_963 field_a = new class_963(this.a24());
   private boolean field_a = true;
   private boolean field_b;
   private ConcurrentHashMap field_a = new ConcurrentHashMap();


   public class_116(ClientState var1) {
      super(var1);
      this.field_a.c6(this.field_a);
      this.a9(this.field_a);
      this.field_a.a9(this.field_a);
      this.field_a.a165(280.0F, 64.0F, 0.0F);
      ((class_371)var1).addObserver(this);
   }

   public final void a2() {}

   public final void b() {
      if(this.field_a) {
         this.c();
      }

      GlUtil.d1();
      this.r();
      this.field_a.b();
      GlUtil.c2();
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public final void c() {
      this.field_a.c();
      this.field_a.c();
      this.field_a = false;
      class_104 var1;
      (var1 = new class_104(this.a24())).a15("NAME", "KILLS", "DEATHS", "PING", "TEAM");
      class_972 var2 = new class_972(var1, var1, this.a24());
      this.field_a.a144(var2);
   }

   public final void update(Observable var1, Object var2) {
      this.field_b = true;
   }

   public final void a12(class_935 var1) {
      super.a12(var1);
      if(this.field_b) {
         class_116 var2 = this;
         synchronized(this.a24().getLocalAndRemoteObjectContainer().getLocalObjects()) {
            int var4 = 0;

            while(true) {
               if(var4 >= var2.field_a.size()) {
                  Iterator var8 = var2.a24().getLocalAndRemoteObjectContainer().getLocalObjects().values().iterator();

                  while(var8.hasNext()) {
                     Sendable var9;
                     if((var9 = (Sendable)var8.next()) instanceof class_744 && !var2.field_a.containsKey(var9)) {
                        var2.field_a.a144(new class_106(var2, (class_744)var9, var2.a24()));
                     }
                  }
                  break;
               }

               class_744 var5;
               if((var5 = (class_744)var2.field_a.a145(var4).field_a) != null && !var2.a24().getLocalAndRemoteObjectContainer().getLocalObjects().containsKey(var5.getId())) {
                  var2.field_a.b18(var4);
                  var2.field_a.remove(var5);
                  --var4;
               }

               ++var4;
            }
         }

         var2.field_a.e();
         this.field_b = false;
      }

      for(int var7 = 0; var7 < this.field_a.size(); ++var7) {
         this.field_a.a145(var7).a12(var1);
      }

   }

   // $FF: synthetic method
   static ConcurrentHashMap a30(class_116 var0) {
      return var0.field_a;
   }
}
