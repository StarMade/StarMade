import java.util.Iterator;
import java.util.LinkedList;

public final class class_52 {

   public String field_a;
   public boolean field_a = false;
   public class_65 field_a;
   public LinkedList field_a = new LinkedList();
   public class_52 field_a;


   public static class_52 a(String var0, class_52 var1, class_52 var2) {
      if(var0.equals(var1.field_a)) {
         return var1;
      } else {
         Iterator var3 = var1.field_a.iterator();

         do {
            if(!var3.hasNext()) {
               return var2;
            }

            var2 = (class_52)var3.next();
         } while(!(var2 = a(var0, var2, var1)).field_a.equals(var0));

         return var2;
      }
   }

   public final String toString() {
      String var1 = "";
      var1 = var1 + "<" + this.field_a + ">\n";

      class_52 var3;
      for(Iterator var2 = this.field_a.iterator(); var2.hasNext(); var1 = var1 + var3.toString()) {
         var3 = (class_52)var2.next();
      }

      return var1 + "</" + this.field_a + ">\n";
   }
}
