import org.schema.game.common.controller.SegmentController;

public interface class_197 {

   SegmentController a();
}
