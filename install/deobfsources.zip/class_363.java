
public final class class_363 {

   public final int field_a;
   public final int field_b;
   public final class_801 field_a;


   public class_363(class_801 var1, int var2, int var3) {
      this.field_a = var2;
      this.field_b = var3;
      this.field_a = var1;
   }

   public final int hashCode() {
      return this.field_a.hashCode() + this.field_a + this.field_b * 10000;
   }

   public final boolean equals(Object var1) {
      return ((class_363)var1).field_a == this.field_a && ((class_363)var1).field_a == this.field_a && ((class_363)var1).field_b == this.field_b;
   }

   public final String toString() {
      return "SectorChange[" + this.field_a + " -> " + this.field_b + "]";
   }
}
