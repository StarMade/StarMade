
final class class_296 extends class_14 {

   // $FF: synthetic field
   private class_286 field_a;


   class_296(class_286 var1, class_371 var2, Object var3, Object var4, String var5) {
      this.field_a = var1;
      super(var2, 50, var3, var4, var5);
   }

   public final String[] getCommandPrefixes() {
      return null;
   }

   public final String handleAutoComplete(String var1, class_1077 var2, String var3) {
      return var1;
   }

   public final boolean a1() {
      return super.field_a.b().indexOf(this) != super.field_a.b().size() - 1;
   }

   public final void a2() {
      this.field_a.a14().e2(false);
   }

   public final void onFailedTextCheck(String var1) {
      this.a9("ONWER INVALID: " + var1);
   }

   public final boolean a7(String var1) {
      if(class_286.a113(this.field_a) && ((Boolean)super.field_a.a20().a117().isAdminClient.get()).booleanValue()) {
         class_785 var2;
         (var2 = new class_785(class_286.a112(this.field_a))).field_b = var1;
         var2.field_a = true;
         super.field_a.a53().a181(var2);
      } else {
         System.err.println("ERROR: CANNOT CHANGE OWNER (PERMISSION DENIED)");
      }

      return true;
   }
}
