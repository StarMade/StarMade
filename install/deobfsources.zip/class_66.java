import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import org.schema.schine.graphicsengine.core.ResourceException;
import org.schema.schine.graphicsengine.forms.Mesh;

public class class_66 {

   public static class_38 field_a = new class_38();
   private class_53 field_a;
   private final List field_a = new ArrayList();
   private float field_a;
   private LinkedList field_a = new LinkedList();
   private int field_a = 0;
   private String field_a = "";
   private float field_b;
   private class_52 field_a;
   private String field_b;
   private String field_c;
   private String field_d;
   private boolean field_a = false;
   public static class_1385 field_b;
   private final class_72 field_a;
   private final class_71 field_a = new class_71();
   private final class_70 field_a;
   // $FF: synthetic field
   private static boolean field_b = !Ae.class.desiredAssertionStatus();


   public class_66() {
      this.field_a = new class_72(field_a);
      class_70 var10001 = new class_70();
      class_38 var10003 = field_a;
      this.field_a = var10001;
      this.field_a = new class_53();
   }

   public final class_71 a1() {
      return this.field_a;
   }

   public final LinkedList a2() {
      return this.field_a;
   }

   public final String a3() {
      return this.field_a;
   }

   public final Mesh a4(String var1) {
      return (Mesh)this.field_a.a2().get(var1);
   }

   public final class_1382 a5(String var1) {
      class_1382 var2 = (class_1382)this.field_a.a().get(var1);
      if(!field_b && var2 == null) {
         throw new AssertionError("Could not find sprites: " + var1);
      } else {
         return var2;
      }
   }

   public final boolean a6() {
      return this.field_a;
   }

   public final void a7() {
      if(class_53.a() == null) {
         this.field_a.a1(class_37.field_a);
      }

      this.field_a = class_53.a();

      try {
         String var2 = "data//audio-resource/";
         File var7;
         if(!(var7 = new File(var2)).exists()) {
            var7.mkdirs();
         }

         this.a9(var7);
      } catch (ResourceException var5) {
         ResourceException var1 = var5;

         try {
            class_927.a2(var1);
         } catch (Exception var4) {
            var4.printStackTrace();
         }

         System.err.println("COULD NOT LOAD AUDIO PATH!!!!!!");
         System.err.println("Exiting because  audio path cannot be loaded");
         System.exit(-1);
      }

      this.c();
      this.d();
      class_73 var6;
      (var6 = new class_73()).field_a = 3;
      var6.field_c = "FONT";
      var6.field_a = "FONT";
      var6.field_b = "FONT";
      var6.field_d = "FONT";
      this.field_a.add(var6);

      try {
         this.field_a.addAll(this.a());
      } catch (ResourceException var3) {
         ;
      }

      this.field_a = 100.0F / (float)this.field_a.size();
   }

   final void a8(class_73 var1) {
      try {
         class_70 var10000 = this.field_a;
         String var6 = var1.field_b + var1.field_c;
         String var4 = var1.field_d;
         String var3 = var1.field_a;
         String var2 = var6;
         if(class_943.field_g.b1()) {
            System.err.println("LOADING SOUND: " + var2);
            if(var4.toLowerCase(Locale.ENGLISH).equals("ogg") || var4.toLowerCase(Locale.ENGLISH).equals("wav")) {
               class_967.a().a3(var3, new File(var2));
            }
         }

         this.field_a.add(0, var1.field_a + ": " + var1.field_b + var1.field_c);
      } catch (Exception var5) {
         var5.printStackTrace();
         throw new ResourceException(var1.toString());
      }
   }

   private void a9(File var1) {
      if(var1.exists()) {
         File[] var2 = var1.listFiles();

         for(int var3 = 0; var3 < var2.length; ++var3) {
            if(var2[var3].isDirectory()) {
               this.a9(var2[var3]);
            } else {
               String var4;
               int var5;
               class_73 var6;
               String var7;
               if(var2[var3].getName().endsWith(".ogg")) {
                  var5 = (var5 = (var4 = var2[var3].getName()).lastIndexOf("/")) < 0?var4.lastIndexOf("\\"):var5;
                  var7 = var4.substring(var5 + 1, var4.lastIndexOf(".ogg"));
                  (var6 = new class_73()).field_a = var7;
                  var6.field_b = var1.getPath() + File.separator;
                  var6.field_c = var4;
                  var6.field_d = "OGG";
                  var6.field_a = 2;
                  this.field_a.add(var6);
               } else if(var2[var3].getName().endsWith(".wav")) {
                  var5 = (var5 = (var4 = var2[var3].getName()).lastIndexOf("/")) < 0?var4.lastIndexOf("\\"):var5;
                  var7 = var4.substring(var5 + 1, var4.lastIndexOf(".wav"));
                  (var6 = new class_73()).field_a = var7;
                  var6.field_b = var1.getPath() + File.separator;
                  var6.field_c = var4;
                  var6.field_d = "WAV";
                  var6.field_a = 2;
                  this.field_a.add(var6);
               }
            }
         }

      } else {
         throw new ResourceException("Audiopath not found");
      }
   }

   public List a() {
      ArrayList var1;
      (var1 = new ArrayList()).add(new class_67());
      return var1;
   }

   public final void b() {
      if(!this.field_a.isEmpty()) {
         ((class_73)this.field_a.remove(0)).a(this);
         ++this.field_a;
         this.field_b = (float)this.field_a * this.field_a;
         this.field_a = "...loaded  " + (int)this.field_b + "% ";
      } else {
         this.field_a = true;
      }
   }

   private void c() {
      this.field_b = "box";
      this.field_c = "/models/ground/";
      this.field_d = "Box";
      class_52 var1;
      Iterator var2 = (var1 = class_52.a("GroundObject", this.field_a, (class_52)null)).field_a.iterator();

      while(var2.hasNext()) {
         class_52 var3;
         String var4 = (String)(var3 = (class_52)var2.next()).field_a.a2("filename").a();
         String var5 = (String)var1.field_a.a2("path").a();
         class_73 var6;
         (var6 = new class_73()).field_a = var3.field_a;
         var6.field_b = var5;
         var6.field_c = var4;
         var6.field_a = 1;
         this.field_a.add(var6);
      }

   }

   private void d() {
      String var1 = "data//image-resource/";
      File var2;
      String var4;
      int var5;
      class_73 var6;
      String var10;
      if((var2 = new File(var1)).exists()) {
         String[] var8 = var2.list();

         for(int var9 = 0; var9 < var8.length; ++var9) {
            if(var8[var9].endsWith(".png")) {
               var5 = (var5 = (var4 = var8[var9]).lastIndexOf("/")) < 0?var4.lastIndexOf("\\"):var5;
               var10 = var4.substring(var5 + 1, var4.lastIndexOf(".png"));
               (var6 = new class_73()).field_a = var10;
               var6.field_b = var1;
               var6.field_c = var4;
               var6.field_a = 0;
               this.field_a.add(var6);
            }
         }

      } else {
         List var7;
         Iterator var3 = (var7 = field_a.b("data.image-resource")).iterator();

         while(var3.hasNext()) {
            if((var4 = (String)var3.next()).endsWith(".png")) {
               var5 = (var5 = var4.lastIndexOf("/")) < 0?var4.lastIndexOf("\\"):var5;
               var10 = var4.substring(var5 + 1, var4.lastIndexOf(".png"));
               (var6 = new class_73()).field_a = var10;
               var6.field_b = var1;
               var6.field_c = var4;
               var6.field_a = 0;
               this.field_a.add(var6);
            }
         }

         System.err.println("Icons from jar added: " + var7);
      }
   }

   final void b1(class_73 var1) {
      if(!this.field_a.a(var1.field_a, var1.field_c, var1.field_b)) {
         if(!this.field_a.a2().containsKey(this.field_d)) {
            this.field_a.a(this.field_d, this.field_b, this.field_c);
         }

         this.field_a.add(0, "**SKIPPED: " + var1.field_a + "... added default: " + this.field_d);
         this.field_a.a2().put(var1.field_a, this.field_a.a2().get(this.field_d));
      } else {
         this.field_a.add(0, var1.field_a + ": " + var1.field_b + var1.field_c);
      }
   }

   final void c1(class_73 var1) {
      this.field_a.a1(var1.field_b + var1.field_c, var1.field_a);
      this.field_a.add(0, var1.field_a + ": " + var1.field_b + var1.field_c);
   }

   public final void a10(String var1) {
      this.field_a = var1;
   }

}
