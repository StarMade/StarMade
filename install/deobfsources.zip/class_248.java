import org.schema.schine.network.client.ClientState;

public final class class_248 extends class_972 implements Comparable {

   private final class_785 field_a;


   public class_248(class_964 var1, class_964 var2, class_785 var3, ClientState var4) {
      super(var1, var2, var4);
      this.field_a = var3;
   }

   public final class_785 a108() {
      return this.field_a;
   }

   // $FF: synthetic method
   public final int compareTo(Object var1) {
      class_248 var2 = (class_248)var1;
      return null.compare(this, var2);
   }
}
