
final class class_92 {

   // $FF: synthetic field
   private class_777 field_a;


   class_92(class_777 var1) {
      this.field_a = var1;
      super();
   }

   public final String toString() {
      return this.field_a.a3() < 0?"[NPC]":"[" + this.field_a.a154().size() + "]";
   }
}
