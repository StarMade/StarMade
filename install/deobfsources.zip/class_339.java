
public class class_339 {

   public class_47 field_a;
   public byte field_a;
   public class_347[] field_a;


   public class_339() {}

   public class_339(byte var1, class_47 var2) {
      this.field_a = var1;
      this.field_a = var2;
   }

   public boolean equals(Object var1) {
      return this.field_a == ((class_339)var1).field_a && this.field_a.equals(((class_339)var1).field_a);
   }

   public int hashCode() {
      return this.field_a * 90000 + this.field_a.hashCode();
   }
}
