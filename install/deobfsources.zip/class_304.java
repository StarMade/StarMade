import org.schema.game.common.data.element.ElementKeyMap;

public final class class_304 extends class_316 {

   public class_304(class_371 var1, short var2, int var3, class_739 var4) {
      super(var1, var2, "Sell Quantity", new class_306(ElementKeyMap.getInfo(var2), var4), var3);
      ((class_306)this.field_a).field_a = -var3;
      this.a10(new class_310(this, var2));
      super.field_a.a83(new class_308(this));
   }

   public final boolean a7(String var1) {
      int var2 = Integer.parseInt(var1);
      super.field_a.a20().a115().b(this.field_a, var2);
      return true;
   }
}
