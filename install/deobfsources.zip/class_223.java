import javax.vecmath.Vector3f;
import org.schema.game.client.view.SegmentDrawer;
import org.schema.game.common.data.world.Segment;

final class class_223 implements class_892 {

   Vector3f field_a;
   // $FF: synthetic field
   private static boolean field_a = !SegmentDrawer.class.desiredAssertionStatus();
   // $FF: synthetic field
   private class_219 field_a;


   private class_223(class_219 var1) {
      this.field_a = var1;
      super();
      this.field_a = new Vector3f();
   }

   public final boolean handle(Segment var1) {
      class_661 var2 = (class_661)var1;
      Object var3 = var1.field_c;
      synchronized(var1.field_c) {
         if((!var2.g() || var2.field_c) && var2.a1()) {
            if(!field_a && var2.a16().getSegment() != var2) {
               throw new AssertionError();
            }

            SegmentDrawer var10000 = this.field_a.field_a;
            if(SegmentDrawer.a67(var1.a15(), var2, this.field_a, class_219.a1(this.field_a))) {
               this.field_a.field_a.add(var2);
               ++this.field_a.field_a.field_c;
            } else if(var2.b6()) {
               class_219.a(this.field_a).add(var2);
            }
         } else if(var2.g()) {
            var1 = null;
            ++this.field_a.field_a.field_a.field_i;
         } else if(var2.b6()) {
            class_219.a(this.field_a).add(var2);
         }

         class_353 var5 = this.field_a.field_a.field_a;
      }

      return !class_927.a1();
   }

   // $FF: synthetic method
   class_223(class_219 var1, byte var2) {
      this(var1);
   }

}
