
public interface class_74 extends class_68 {

   void fromTagStructure(class_79 var1);

   class_79 toTagStructure();
}
