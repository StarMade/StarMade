import java.util.ArrayList;
import org.lwjgl.opengl.GL11;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public final class class_198 extends class_964 {

   private class_970 field_a;
   private class_970 field_b;
   private class_970 field_c;
   private class_970 field_d;
   private class_940 field_a;
   private class_940 field_b;
   private class_970 field_e;
   private class_1410 field_b;
   private String field_b;
   private class_964 field_a;
   private boolean field_a = true;


   public class_198(ClientState var1, class_1410 var2, String var3) {
      super(var1);
      this.field_b = var2;
      this.field_b = var3;
      this.field_a = new class_1412(this.a24(), 39.0F, 26.0F);
      this.field_a.a143(var2);
      this.field_a.field_a = "X";
      this.field_a.field_g = true;
   }

   public final void a2() {
      this.field_e.a2();
      this.field_a.a2();
   }

   public final void b() {
      if(this.field_a) {
         this.c();
      }

      if(((class_371)this.a24()).a14().field_a.field_b) {
         GlUtil.d1();
         GL11.glEnable(3042);
         GL11.glBlendFunc(770, 771);
         this.r();
         if(0L < System.currentTimeMillis()) {
            this.field_b.field_b.clear();
         }

         this.field_a.a_2(class_319.field_e.a(this.field_a.a_()));
         this.field_d.a_2(class_319.field_f.a(this.field_d.a_()));
         this.field_b.a_2(class_319.field_n.a(this.field_b.a_()));
         this.field_c.a_2(class_319.field_m.a(this.field_c.a_()));
         this.field_e.b();
         GL11.glDisable(3042);
         GlUtil.c2();
      }
   }

   public final float a3() {
      return 256.0F;
   }

   public final float b1() {
      return 256.0F;
   }

   public final void c() {
      this.field_a = new class_940(256, 64, class_28.e(), this.a24());
      this.field_b = new class_940(256, 64, this.a24());
      this.field_e = new class_970(class_967.a2().a5("menu-panel-gui-"), this.a24());
      this.field_a = new class_970(class_967.a2().a5("buttons-8x8-gui-"), this.a24());
      this.field_a.a143(this.field_b);
      this.field_a.field_a = "JOIN";
      this.field_a.field_g = true;
      this.field_c = new class_970(class_967.a2().a5("buttons-8x8-gui-"), this.a24());
      this.field_c.a143(this.field_b);
      this.field_c.field_a = "GREEN_TEAM";
      this.field_c.field_g = true;
      this.field_b = new class_970(class_967.a2().a5("buttons-8x8-gui-"), this.a24());
      this.field_b.a143(this.field_b);
      this.field_b.field_a = "BLUE_TEAM";
      this.field_b.field_g = true;
      this.field_d = new class_970(class_967.a2().a5("buttons-8x8-gui-"), this.a24());
      this.field_d.a_2(3);
      this.field_d.a143(this.field_b);
      this.field_d.field_a = "EXIT";
      this.field_d.field_g = true;
      ArrayList var1;
      (var1 = new ArrayList()).add(this.field_b);
      this.field_a.field_b = var1;
      var1 = new ArrayList();
      this.field_b.field_b = var1;
      this.field_e.h2(48);
      this.field_e.c();
      this.field_a.c();
      this.field_a.c();
      this.field_d.c();
      this.field_b.c();
      this.field_c.c();
      this.a9(this.field_e);
      this.field_e.a9(this.field_a);
      this.field_e.a9(this.field_b);
      this.field_a.a165(216.0F, 0.0F, 0.0F);
      this.field_e.a9(this.field_a);
      System.err.println("GAME MODE: " + ((class_371)this.a24()).a11().name());
      this.field_e.a9(this.field_a);
      this.field_e.a9(this.field_d);
      this.field_a.a165(50.0F, 10.0F, 0.0F);
      this.field_b.a165(40.0F, 30.0F, 0.0F);
      this.field_a.a165(55.0F, 64.0F, 0.0F);
      this.field_c.a165(55.0F, 64.0F, 0.0F);
      this.field_b.a165(55.0F, 144.0F, 0.0F);
      this.field_d.a165(55.0F, 380.0F, 0.0F);
      this.field_a = false;
   }
}
