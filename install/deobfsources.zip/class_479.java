
public interface class_479 {

   void a(class_47 var1, class_47 var2, short var3);
}
