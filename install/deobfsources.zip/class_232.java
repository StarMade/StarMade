import com.bulletphysics.linearmath.Transform;
import javax.vecmath.Vector3f;

public final class class_232 implements class_1432 {

   private final class_228 field_a;
   private final Transform field_a;
   class_47 field_a = new class_47();
   final Vector3f field_a = new Vector3f();
   final Vector3f field_b = new Vector3f();
   final Vector3f field_c = new Vector3f();
   public class_47 field_b;
   private final class_47 field_c = new class_47();


   public class_232(class_228 var1) {
      this.field_a = var1;
      this.field_a = new Transform();
      this.field_a.setIdentity();
   }

   public final Transform getWorldTransform() {
      return this.field_a;
   }

   public final class_47 a(class_47 var1) {
      var1.b1(this.field_a);
      return var1;
   }

   public final void a1(int var1, int var2, int var3, boolean var4) {
      this.field_a.b(var1, var2, var3);
      System.err.println("[CLIENT][MAP][POS] SETTING TO " + this.field_a);
      this.a2(var4);
   }

   final void a2(boolean var1) {
      float var2 = (float)this.field_a.field_a;
      float var3 = (float)this.field_a.field_b;
      float var4 = (float)this.field_a.field_c;
      this.field_b.set((var2 - 7.5F) * 6.25F, (var3 - 7.5F) * 6.25F, (var4 - 7.5F) * 6.25F);
      if(var1) {
         this.getWorldTransform().origin.set(this.field_b);
         this.field_a.set(this.field_b);
      }

      this.field_b = class_793.a192(this.field_a, this.field_c);
      this.field_a.a30(this.field_a);
   }
}
