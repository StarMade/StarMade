import javax.vecmath.Vector3f;
import org.schema.common.FastMath;
import org.schema.game.client.view.cubes.CubeMeshBufferContainer;

public final class class_392 {

   private class_47[] field_a = new class_47[8];
   private Vector3f[] field_a = new Vector3f[4];
   private Vector3f[] field_b = new Vector3f[4];
   private class_47[] field_b = new class_47[4];
   private static float[] field_a = new float[]{1.0F, 0.5F, 0.33333334F, 0.25F};
   private Vector3f field_a = new Vector3f();


   public class_392() {
      int var1;
      for(var1 = 0; var1 < 8; ++var1) {
         this.field_a[var1] = new class_47();
      }

      for(var1 = 0; var1 < 4; ++var1) {
         this.field_b[var1] = new Vector3f();
         this.field_a[var1] = new Vector3f();
      }

   }

   private void a(class_47 var1, class_47[] var2, int var3, boolean var4, class_386 var5) {
      this.field_a[2].set(this.a1(var1, var2[0], var2[1], var2[2], var3, var5));
      this.field_a[3].set(this.a1(var1, var2[2], var2[3], var2[4], var3, var5));
      this.field_a[0].set(this.a1(var1, var2[4], var2[5], var2[6], var3, var5));
      this.field_a[1].set(this.a1(var1, var2[6], var2[7], var2[0], var3, var5));
      int var7 = var3 << 2;
      int var6 = CubeMeshBufferContainer.a((byte)var1.field_a, (byte)var1.field_b, (byte)var1.field_c);
      if(var4) {
         for(var3 = 3; var3 >= 0; --var3) {
            var5.a3().a5(var6, (byte)((int)(FastMath.a5(this.field_a[var3].field_x, 0.0F, 1.0F) * 15.0F)), var7 + (3 - var3), 0);
            var5.a3().a5(var6, (byte)((int)(FastMath.a5(this.field_a[var3].field_y, 0.0F, 1.0F) * 15.0F)), var7 + (3 - var3), 1);
            var5.a3().a5(var6, (byte)((int)(FastMath.a5(this.field_a[var3].field_z, 0.0F, 1.0F) * 15.0F)), var7 + (3 - var3), 2);
         }

      } else {
         for(var3 = 0; var3 < 4; ++var3) {
            var5.a3().a5(var6, (byte)((int)(FastMath.a5(this.field_a[var3].field_x, 0.0F, 1.0F) * 15.0F)), var7 + var3, 0);
            var5.a3().a5(var6, (byte)((int)(FastMath.a5(this.field_a[var3].field_y, 0.0F, 1.0F) * 15.0F)), var7 + var3, 1);
            var5.a3().a5(var6, (byte)((int)(FastMath.a5(this.field_a[var3].field_z, 0.0F, 1.0F) * 15.0F)), var7 + var3, 2);
         }

      }
   }

   private Vector3f a1(class_47 var1, class_47 var2, class_47 var3, class_47 var4, int var5, class_386 var6) {
      int var7 = 0;
      this.field_a.set(0.0F, 0.0F, 0.0F);
      this.field_b[0] = var1;
      this.field_b[1] = var2;
      this.field_b[2] = var3;
      this.field_b[3] = var4;

      for(int var8 = 0; var8 < 4; ++var8) {
         if(var6.a4(this.field_b[var8], var5, this.field_b[var8])) {
            this.field_a.add(this.field_b[var8]);
            ++var7;
         }
      }

      if(var7 > 1) {
         this.field_a.scale(field_a[var7 - 1]);
      }

      return this.field_a;
   }

   final void a2(class_47 var1, class_386 var2) {
      this.field_a[2].b(var1.field_a - 1, var1.field_b, var1.field_c);
      this.field_a[3].b(var1.field_a - 1, var1.field_b, var1.field_c - 1);
      this.field_a[4].b(var1.field_a, var1.field_b, var1.field_c - 1);
      this.field_a[5].b(var1.field_a + 1, var1.field_b, var1.field_c - 1);
      this.field_a[6].b(var1.field_a + 1, var1.field_b, var1.field_c);
      this.field_a[7].b(var1.field_a + 1, var1.field_b, var1.field_c + 1);
      this.field_a[0].b(var1.field_a, var1.field_b, var1.field_c + 1);
      this.field_a[1].b(var1.field_a - 1, var1.field_b, var1.field_c + 1);
      this.a(var1, this.field_a, 3, false, var2);
   }

   final void a3(class_47 var1, int var2, class_386 var3) {
      this.field_a[4].b(var1.field_a + 1, var1.field_b, var1.field_c);
      this.field_a[5].b(var1.field_a + 1, var1.field_b - 1, var1.field_c);
      this.field_a[6].b(var1.field_a, var1.field_b - 1, var1.field_c);
      this.field_a[7].b(var1.field_a - 1, var1.field_b - 1, var1.field_c);
      this.field_a[0].b(var1.field_a - 1, var1.field_b, var1.field_c);
      this.field_a[1].b(var1.field_a - 1, var1.field_b + 1, var1.field_c);
      this.field_a[2].b(var1.field_a, var1.field_b + 1, var1.field_c);
      this.field_a[3].b(var1.field_a + 1, var1.field_b + 1, var1.field_c);
      this.a(var1, this.field_a, var2, var2 != 5, var3);
   }

   final void b(class_47 var1, class_386 var2) {
      this.field_a[6].b(var1.field_a, var1.field_b + 1, var1.field_c);
      this.field_a[7].b(var1.field_a, var1.field_b + 1, var1.field_c - 1);
      this.field_a[0].b(var1.field_a, var1.field_b, var1.field_c - 1);
      this.field_a[1].b(var1.field_a, var1.field_b - 1, var1.field_c - 1);
      this.field_a[2].b(var1.field_a, var1.field_b - 1, var1.field_c);
      this.field_a[3].b(var1.field_a, var1.field_b - 1, var1.field_c + 1);
      this.field_a[4].b(var1.field_a, var1.field_b, var1.field_c + 1);
      this.field_a[5].b(var1.field_a, var1.field_b + 1, var1.field_c + 1);
      this.a(var1, this.field_a, 1, false, var2);
   }

   final void c(class_47 var1, class_386 var2) {
      this.field_a[6].b(var1.field_a, var1.field_b - 1, var1.field_c);
      this.field_a[7].b(var1.field_a, var1.field_b - 1, var1.field_c - 1);
      this.field_a[0].b(var1.field_a, var1.field_b, var1.field_c - 1);
      this.field_a[1].b(var1.field_a, var1.field_b + 1, var1.field_c - 1);
      this.field_a[2].b(var1.field_a, var1.field_b + 1, var1.field_c);
      this.field_a[3].b(var1.field_a, var1.field_b + 1, var1.field_c + 1);
      this.field_a[4].b(var1.field_a, var1.field_b, var1.field_c + 1);
      this.field_a[5].b(var1.field_a, var1.field_b - 1, var1.field_c + 1);
      this.a(var1, this.field_a, 0, false, var2);
   }

   final void d(class_47 var1, class_386 var2) {
      this.field_a[0].b(var1.field_a - 1, var1.field_b, var1.field_c);
      this.field_a[1].b(var1.field_a - 1, var1.field_b, var1.field_c + 1);
      this.field_a[2].b(var1.field_a, var1.field_b, var1.field_c + 1);
      this.field_a[3].b(var1.field_a + 1, var1.field_b, var1.field_c + 1);
      this.field_a[4].b(var1.field_a + 1, var1.field_b, var1.field_c);
      this.field_a[5].b(var1.field_a + 1, var1.field_b, var1.field_c - 1);
      this.field_a[6].b(var1.field_a, var1.field_b, var1.field_c - 1);
      this.field_a[7].b(var1.field_a - 1, var1.field_b, var1.field_c - 1);
      this.a(var1, this.field_a, 2, false, var2);
   }

}
