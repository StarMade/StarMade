
public final class class_426 extends class_15 {

   public class_426(class_371 var1) {
      super(var1);
   }
}
