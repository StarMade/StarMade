import javax.vecmath.Vector3f;
import org.lwjgl.input.Keyboard;
import org.schema.schine.graphicsengine.camera.Camera;

public final class class_483 extends class_15 {

   private Camera field_a;


   public class_483(class_371 var1) {
      super(var1);
      if(this.field_a == null) {
         class_971 var2 = new class_971();
         this.field_a = new Camera(var2);
      }

      if(class_967.a1() == null) {
         class_967.a9(this.field_a);
      }

   }

   public final void a12(class_941 var1) {
      super.a12(var1);
   }

   public final void b2(boolean var1) {
      class_1008.field_a = var1;
      if(var1) {
         class_971 var2 = new class_971();
         this.field_a = new Camera(var2);
         if(class_967.a1() != null) {
            this.field_a.a83().set(class_967.a1().a83());
         }

         class_967.a9(this.field_a);
      }

      super.b2(var1);
   }

   public final void a15(class_935 var1) {
      class_1008.field_a = true;
      class_960 var2 = class_967.a1().a184();
      Vector3f var3 = new Vector3f(var2.field_a.c10());
      Vector3f var4 = new Vector3f(var2.field_a.f5());
      Vector3f var5 = new Vector3f(var2.field_a.d7());
      float var6 = Keyboard.isKeyDown(42)?50.0F:5.0F;
      var3.scale(var6 * var1.a());
      var4.scale(var6 * var1.a());
      var5.scale(var6 * var1.a());
      if(!Keyboard.isKeyDown(17) || !Keyboard.isKeyDown(31)) {
         if(Keyboard.isKeyDown(17)) {
            var2.a83().add(var3);
         }

         if(Keyboard.isKeyDown(31)) {
            var3.scale(-1.0F);
            var2.a83().add(var3);
         }
      }

      if(!Keyboard.isKeyDown(30) || !Keyboard.isKeyDown(32)) {
         if(Keyboard.isKeyDown(30)) {
            var2.a83().add(var5);
         }

         if(Keyboard.isKeyDown(32)) {
            var5.scale(-1.0F);
            var2.a83().add(var5);
         }
      }

      if(!Keyboard.isKeyDown(16) || !Keyboard.isKeyDown(18)) {
         if(Keyboard.isKeyDown(16)) {
            var2.a83().add(var4);
         }

         if(Keyboard.isKeyDown(18)) {
            var4.scale(-1.0F);
            var2.a83().add(var4);
         }
      }

   }
}
