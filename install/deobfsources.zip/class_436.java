
public final class class_436 extends class_11 {

   private class_109 field_a;


   public class_436(class_371 var1) {
      super(var1);
      this.field_a = new class_109(var1, this);
      this.field_a.e();
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.a() && (var1.b19().equals("OK") || var1.b19().equals("CANCEL") || var1.b19().equals("X"))) {
         this.d();
      }

   }

   public final boolean a1() {
      return false;
   }

   public final void handleKeyEvent() {}

   public final class_964 a3() {
      return this.field_a;
   }

   public final void a2() {
      super.field_a.a14().field_a.field_a.field_a.a13(500);
      super.field_a.a14().field_a.field_a.field_a.e2(false);
   }
}
