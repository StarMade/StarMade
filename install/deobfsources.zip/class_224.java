import javax.vecmath.Vector3f;

public final class class_224 implements class_923 {

   public class_1356 field_a = new class_1356();
   private class_1357 field_a;
   private boolean field_b = true;
   public float field_a = 0.2F;
   public Vector3f field_a = new Vector3f();
   public Vector3f field_b = new Vector3f();
   public float field_b = 0.0F;
   public boolean field_a;


   public class_224() {
      this.field_a = new class_1357(this.field_a);
   }

   public final void a() {}

   public final void b() {
      if(class_943.field_q.b1()) {
         if(this.field_b) {
            this.c();
         }

         this.field_a.b();
         if(class_943.field_p.b1()) {
            class_969.field_a.add("SPACE PARTICLES: " + this.field_a.b1());
         }
      }

   }

   public final void c() {
      this.field_a.c();
      this.field_b = false;
   }
}
