import org.schema.schine.network.client.ClientState;

final class class_89 extends class_1402 {

   // $FF: synthetic field
   private class_85 field_a;


   class_89(class_85 var1, ClientState var2) {
      this.field_a = var1;
      super(var2);
   }

   protected final void e() {
      this.field_a.a11().field_b = 0;
   }

   protected final void f() {
      this.field_a.a11().field_b = 1;
   }

   protected final boolean b3() {
      return this.field_a.a11().field_b == 0;
   }
}
