
public final class class_62 extends class_58 {

   private static final long serialVersionUID = -8062062884428582893L;


   public class_62(Object var1, class_54 var2) {
      super(var1, var2);
   }
}
