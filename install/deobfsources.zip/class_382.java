import org.schema.common.FastMath;

public final class class_382 {

   private float[] field_a = new float[6];
   public class_388[] field_a = new class_388[40];
   private static int field_a = 52;


   public final void a() {
      float var1 = 3.1415927F * (3.0F - FastMath.l(5.0F));
      float var2 = 2.0F / (float)this.field_a.length;

      for(int var3 = 0; var3 < this.field_a.length; ++var3) {
         this.field_a[var3] = new class_388(field_a);
         float var4 = (float)var3 * var2 - 1.0F + var2 / 2.0F;
         float var5 = FastMath.l(1.0F - var4 * var4);
         float var6 = (float)var3 * var1;
         class_388 var10000 = this.field_a[var3];
         float var10001 = FastMath.j(var6) * var5;
         float var7 = FastMath.i(var6) * var5;
         var5 = var10001;
         class_388 var26 = var10000;
         var10000.field_a = new byte[var10000.field_a * 3];
         var26.field_b = new float[var26.field_a];
         float[] var13 = var26.field_b;
         byte[] var12 = var26.field_a;
         class_388 var8 = var26;
         float var14 = var5 * 0.3F;
         float var15 = var4 * 0.3F;
         float var16 = var7 * 0.3F;
         float var9 = 0.0F;
         float var10 = 0.0F;
         float var11 = 0.0F;
         int var17 = 0;
         int var18 = 0;
         int var19 = 0;
         int var20 = 0;

         for(int var21 = 0; var20 < var8.field_a * 3; var11 += var16) {
            int var22 = Math.round(var9);
            int var23 = Math.round(var10);
            int var24 = Math.round(var11);
            if(var22 != var17 || var23 != var18 || var24 != var19) {
               while(var20 < var8.field_a * 3 && (var22 != var17 || var23 != var18 || var24 != var19)) {
                  if(var22 != var17) {
                     if(var17 < var22) {
                        ++var17;
                     } else {
                        --var17;
                     }
                  } else if(var23 != var18) {
                     if(var18 < var23) {
                        ++var18;
                     } else {
                        --var18;
                     }
                  } else if(var24 != var19) {
                     if(var19 < var24) {
                        ++var19;
                     } else {
                        --var19;
                     }
                  }

                  float var25 = FastMath.l(var9 * var9 + var10 * var10 + var11 * var11);
                  var12[var20] = (byte)var17;
                  var12[var20 + 1] = (byte)var18;
                  var12[var20 + 2] = (byte)var19;
                  var13[var21] = 1.0F / var25;
                  var20 += 3;
                  ++var21;
               }
            }

            var9 += var14;
            var10 += var15;
         }

         var26.field_a[0] = (var5 < 0.0F?-var5:0.0F) * 1.5F;
         var26.field_a[1] = (var5 > 0.0F?var5:0.0F) * 1.5F;
         var26.field_a[2] = (var4 < 0.0F?-var4:0.0F) * 1.5F;
         var26.field_a[3] = (var4 > 0.0F?var4:0.0F) * 1.5F;
         var26.field_a[4] = (var7 < 0.0F?-var7:0.0F) * 1.5F;
         var26.field_a[5] = (var7 > 0.0F?var7:0.0F) * 1.5F;

         for(int var27 = 0; var27 < 6; ++var27) {
            this.field_a[var27] += this.field_a[var3].field_a[var27];
         }
      }

   }

}
