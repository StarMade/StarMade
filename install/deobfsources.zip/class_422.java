
public class class_422 extends class_11 {

   private final class_801 field_a;
   private class_141 field_a;


   public class_422(class_371 var1, class_801 var2) {
      super(var1);
      this.field_a = var2;
      this.field_a = new class_141(super.field_a, this, var2);
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.a()) {
         if(var1.b19().equals("NEUTRAL")) {
            super.field_a.a20().a132().a205(0, this.field_a);
            this.d();
            return;
         }

         if(var1.b19().equals("FACTION")) {
            super.field_a.a20().a132().a205(super.field_a.a20().h1(), this.field_a);
            this.d();
            return;
         }

         if(var1.b19().equals("HOMEBASE")) {
            super.field_a.a45().a156(super.field_a.a20().getName(), super.field_a.a20().h1(), this.field_a.getUniqueIdentifier(), super.field_a.a20().a44());
            this.d();
            return;
         }

         if(var1.b19().equals("HOMEBASE_REVOKE")) {
            super.field_a.a45().a156(super.field_a.a20().getName(), super.field_a.a20().h1(), "", new class_47());
            this.d();
            return;
         }

         if(var1.b19().equals("CANCEL") || var1.b19().equals("X")) {
            this.d();
         }
      }

   }

   public final boolean a1() {
      return false;
   }

   public void handleKeyEvent() {}

   public final class_964 a3() {
      return this.field_a;
   }

   public void a2() {}
}
