import java.io.File;
import java.io.IOException;
import org.schema.schine.graphicsengine.core.ResourceException;

final class class_67 extends class_73 {

   public final void a(class_66 var1) {
      try {
         class_66.field_b = new class_1385();
         class_28.a18(new File("data//effects/explosionMaps/explode.dds"), class_66.field_b);
      } catch (IOException var2) {
         var2.printStackTrace();
         throw new ResourceException("Explosion volume");
      }
   }
}
