
public final class class_401 extends class_300 {

   private static final long serialVersionUID = 9159389806588076558L;
   private boolean field_c;


   public class_401(class_983 var1, class_371 var2, String var3, int var4) {
      super(var1, var2, var3, var4);
   }

   protected final boolean a() {
      super.field_a.a4().a5();
      class_460.a2();
      if(this.field_c != this.field_a && this.field_a) {
         this.field_a = System.currentTimeMillis();
      }

      this.field_c = this.field_a;
      if(!this.field_a) {
         super.field_a.a4().a5();
         class_460.a2();
         return false;
      } else {
         return !super.field_a.a4().a5().b1() && System.currentTimeMillis() - this.field_a > (long)super.field_a;
      }
   }

   public final String a1() {
      if(this.field_a) {
         super.field_a.a4().a5();
         class_460.a2();
         return super.a1() + "(Tutorial will resume in " + ((long)super.field_a - (System.currentTimeMillis() - this.field_a)) / 1000L + " sec\nor press \'k\')";
      } else {
         return super.a1();
      }
   }

   public final boolean c() {
      this.field_c = false;
      return super.c();
   }
}
