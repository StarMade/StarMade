import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.nio.ShortBuffer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.schema.game.common.data.world.SegmentData;

public final class class_249 {

   private static ObjectArrayList field_a = new ObjectArrayList();
   private final Map field_a = new HashMap();
   private final class_291[] field_a = new class_291[64];
   private int field_a;
   private boolean field_a;


   public final void a(class_802 var1) {
      class_291 var2 = null;
      class_291 var10000;
      if(field_a.isEmpty()) {
         var10000 = new class_291(var1);
      } else {
         (var2 = (class_291)field_a.remove(0)).field_a = var1;
         var10000 = var2;
      }

      class_291 var3 = var10000;
      this.field_a.put(var3.field_a, var3);
   }

   public final void a1(Int2ObjectOpenHashMap var1) {
      Iterator var2 = this.field_a.values().iterator();

      while(var2.hasNext()) {
         class_291 var3 = (class_291)var2.next();
         if(!var1.containsKey(var3.field_a.a1().getId())) {
            var3.field_a = null;
            field_a.add(var3);
            var2.remove();
         }
      }

      Iterator var6 = var1.values().iterator();

      while(var6.hasNext()) {
         class_801 var4;
         if((var4 = (class_801)var6.next()) instanceof class_802 && !this.field_a.containsKey(var4)) {
            this.a((class_802)var4);
         }
      }

      for(int var7 = 0; var7 < this.field_a; ++var7) {
         this.field_a[var7] = null;
      }

      this.field_a = 0;
      var6 = this.field_a.values().iterator();

      while(var6.hasNext()) {
         class_291 var5;
         if((var5 = (class_291)var6.next()).a5()) {
            this.a3(var5, true);
         }
      }

   }

   public final void a2() {
      if(this.field_a) {
         for(int var1 = 0; var1 < this.field_a; ++var1) {
            this.field_a[var1].b();
         }
      }

   }

   public static void b() {}

   private void a3(class_291 var1, boolean var2) {
      if(var2) {
         if(this.field_a < this.field_a.length) {
            this.field_a[this.field_a] = var1;
            ++this.field_a;
         }
      } else if(this.field_a < this.field_a.length) {
         for(int var3 = 0; var3 < this.field_a.length; ++var3) {
            if(this.field_a[var3] == var1) {
               this.field_a[var3] = this.field_a[this.field_a - 1];
               --this.field_a;
               break;
            }
         }
      }

      this.field_a = this.field_a > 0;
   }

   public final void a4(class_661 var1) {
      ShortBuffer var2;
      int var3 = (var2 = var1.b4().field_a).position();
      var2.rewind();
      class_34 var4 = new class_34();
      new class_47();
      class_800 var5 = new class_800();
      class_291 var6;
      if((var6 = (class_291)this.field_a.get(var1.a15())) != null) {
         boolean var7 = var6.a5();
         class_661 var10 = var1;
         class_291 var9 = var6;

         for(int var11 = 0; var11 < var9.field_a.b1(); ++var11) {
            var9.field_a.field_a.a4(var11, var9.field_a);
            if((float)var10.field_a.field_a <= var9.field_a.field_x + 8.0F && (float)var10.field_a.field_b <= var9.field_a.field_y + 8.0F && (float)var10.field_a.field_c <= var9.field_a.field_z + 8.0F && (float)(var10.field_a.field_a + 16) > var9.field_a.field_x + 8.0F && (float)(var10.field_a.field_b + 16) > var9.field_a.field_y + 8.0F && (float)(var10.field_a.field_c + 16) > var9.field_a.field_z + 8.0F) {
               var9.field_a.b(var11);
               --var11;
            }
         }

         for(int var8 = 0; var8 < var3; ++var8) {
            SegmentData.getPositionFromIndex(var2.get(), var4);
            var5.a(var1, var4);
            var6.field_a.b1();
            class_226 var10000 = var6.field_a;
            class_47 var13 = var5.a2(var6.field_a);
            class_226 var15 = var10000;
            var10000.field_a.set(0.0F, 0.0F, 0.0F);
            int var14 = var15.a14(var15.field_a, var15.field_a);
            var15.field_a.a7(var14, (float)(var13.field_a - class_743.field_a.field_a), (float)(var13.field_b - class_743.field_a.field_b), (float)(var13.field_c - class_743.field_a.field_c));
            var15.field_a.b1(var14, (float)var13.field_a, (float)var13.field_b, (float)var13.field_c);
         }

         boolean var12 = var6.a5();
         if(var7 && !var12) {
            this.a3(var6, false);
         } else if(!var7 && var12) {
            this.a3(var6, true);
         }
      }

      var2.rewind();
   }

}
