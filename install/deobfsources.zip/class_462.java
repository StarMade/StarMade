
public final class class_462 extends class_999 {

   private static final long serialVersionUID = -2266101204277288192L;
   private class_1001 field_a;
   private class_1001 field_b;
   private class_405 field_a;


   public class_462(class_991 var1, class_985 var2) {
      super(var1, var2);
   }

   public final void a() {
      class_395 var1 = new class_395();
      class_385 var2 = new class_385();
      class_391 var3 = new class_391();
      class_393 var4 = new class_393();
      class_371 var5 = ((class_460)super.a1()).a1();
      this.field_a = new class_405(super.field_a);
      this.field_a = new class_300(super.field_a, var5, "Hello and welcome to StarMade", 3000);
      this.field_b = new class_399(super.field_a, var5, "You completed the tutorial.\nThank you for playing!\nTo find out more about the game\ngo to www.star-made.org");
      this.field_a.a9(var4, this.field_b);
      this.field_b.a9(var2, this.field_a);
      this.field_a.a9(var2, this.field_a);
      class_300 var6 = new class_300(super.field_a, var5, "Press \'ENTER\' to chat\nto other players.\nAlso, you can use admin commands in single player\nor if you are admin on a multiplayer server.\nA list of commands can be\nfound at www.star-made.org/help", 3000);
      class_1001 var7;
      (var7 = (new class_464(this.field_a, this.field_a, this.field_b, var5)).a3()).a9(var3, var6);
      var7.a9(new class_375(), this.field_a);
      var7.a9(var2, this.field_a);
      var7.a9(var4, this.field_b);
      var6.a9(new class_375(), this.field_b);
      var6.a9(new class_383(), var7);
      var6.a9(var2, this.field_a);
      var6.a9(var4, this.field_b);
      var6.a9(var1, var7);
      class_1001 var8 = (new class_458(var6, this.field_a, this.field_b, var5)).a3();
      var8 = (new class_470(var8, this.field_a, this.field_b, var5)).a3();
      (var8 = (new class_468(var8, this.field_a, this.field_b, var5)).a3()).a9(var3, this.field_b);
      var8.a9(var2, this.field_a);
      var8.a9(var4, this.field_b);
      this.field_b.a9(var3, this.field_a);
      this.a3(this.field_a);
   }
}
