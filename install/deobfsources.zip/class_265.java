
final class class_265 {

   // $FF: synthetic field
   private class_263 field_a;


   class_265(class_263 var1) {
      this.field_a = var1;
      super();
   }

   public final String toString() {
      return "(Characters Left: " + (class_263.a109(this.field_a).c4() - class_263.a109(this.field_a).a4().length()) + "/" + class_263.a109(this.field_a).c4() + "; New Lines Left: " + (class_263.a109(this.field_a).d5() - class_263.a109(this.field_a).a28() - 1) + "/" + (class_263.a109(this.field_a).d5() - 1) + ")";
   }
}
