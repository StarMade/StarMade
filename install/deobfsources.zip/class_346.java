
public class class_346 extends class_11 {

   private final class_90 field_a;
   private final class_777 field_a;


   public class_346(class_371 var1, class_777 var2) {
      super(var1);
      this.field_a = new class_90(super.field_a, this, var2);
      this.field_a = var2;
   }

   public final boolean a1() {
      return false;
   }

   public void handleKeyEvent() {}

   public final class_964 a3() {
      return this.field_a;
   }

   public void a2() {
      super.field_a.a14().field_a.field_a.field_a.a13(500);
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.a()) {
         class_156[] var5 = this.field_a.a13();

         for(int var3 = 0; var3 < 5; ++var3) {
            if(var5[var3].f1()) {
               return;
            }
         }

         if(var1.b19().equals("OK")) {
            class_637 var6;
            (var6 = new class_637()).field_a = this.field_a.a3();

            for(int var4 = 0; var4 < 5; ++var4) {
               if(var5[var4].e1()) {
                  var6.a59()[var4] |= 1L;
               }

               if(var5[var4].c1()) {
                  var6.a59()[var4] |= 4L;
               }

               if(var5[var4].b3()) {
                  var6.a59()[var4] |= 2L;
               }

               if(var5[var4].d1()) {
                  var6.a59()[var4] |= 8L;
               }

               var6.a60()[var4] = var5[var4].a16();
            }

            var1 = null;
            super.field_a.a45().a61(var6);
            this.d();
            return;
         }

         if(var1.b19().equals("CANCEL") || var1.b19().equals("X")) {
            var1 = null;
            this.d();
         }
      }

   }
}
