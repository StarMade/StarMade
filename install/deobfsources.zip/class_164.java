import java.util.Observable;
import java.util.Observer;
import org.schema.schine.network.client.ClientState;

public final class class_164 extends class_964 implements Observer {

   private class_160 field_a;
   private class_93 field_a;
   private boolean field_a;


   public class_164(ClientState var1) {
      super(var1);
   }

   public final void a2() {}

   public final void b() {
      if(this.field_a) {
         this.field_a.field_a = true;
         this.field_a = false;
      }

      this.k();
   }

   public final void c() {
      this.field_a = new class_93(this.a24());
      this.field_a.c();
      this.field_a = new class_162(this.a24(), (int)(340.0F - this.field_a.a3()));
      this.field_a.c();
      this.field_a.a83().field_y = this.field_a.a3();
      this.a9(this.field_a);
      this.a9(this.field_a);
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public final void update(Observable var1, Object var2) {
      this.field_a = true;
   }
}
