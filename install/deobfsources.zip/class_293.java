import com.bulletphysics.collision.dispatch.CollisionWorld;
import javax.vecmath.Vector3f;

public final class class_293 implements class_923 {

   public class_1401 field_a = new class_1401();
   private class_1360 field_a;
   private boolean field_a = true;


   public class_293() {
      this.field_a = new class_1360(this.field_a);
   }

   public final void a22(CollisionWorld.ClosestRayResultCallback var1) {
      class_1401 var10000 = this.field_a;
      Vector3f var10001 = new Vector3f(var1.hitPointWorld);
      class_967.a1().a83();
      var10000.a13(var10001, 4.0F);
   }

   public final void a23(Vector3f var1, float var2) {
      class_1401 var10000 = this.field_a;
      Vector3f var10001 = new Vector3f(var1);
      class_967.a1().a83();
      var10000.a13(var10001, var2);
   }

   public final void a() {}

   public final void b() {
      if(this.field_a) {
         this.c();
      }

      this.field_a.b();
   }

   public final void c() {
      this.field_a.c();
      this.field_a = false;
   }
}
