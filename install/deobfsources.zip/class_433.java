import org.schema.game.common.data.element.Element;
import org.schema.game.common.data.element.ElementInformation;
import org.schema.game.common.data.element.ElementKeyMap;

public final class class_433 {

   public final class_47 field_a = new class_47(8, 8, 8);
   public final class_47 field_b = new class_47(8, 8, 8);
   public final class_47 field_c = new class_47(8, 8, 8);
   public boolean field_a;
   public boolean field_b;
   public boolean field_c;
   public int field_a;
   public int field_b = 1;


   public static int a(short var0, boolean var1, int var2, boolean var3, boolean var4, boolean var5) {
      if(var0 != 0) {
         if(!var1) {
            var2 += 8;
         }

         ElementInformation var6;
         if((var6 = ElementKeyMap.getInfo(var0)).getBlockStyle() > 0) {
            var2 = Element.orientationMapping[var2];
            if(var3) {
               var2 = class_384.field_a[var6.blockStyle - 1][var2];
            }

            if(var4) {
               var2 = class_384.field_b[var6.blockStyle - 1][var2];
            }

            if(var5) {
               var2 = class_384.field_c[var6.blockStyle - 1][var2];
            }

            var2 = Element.orientationBackMapping[var2];
         }

         if(!var1) {
            var2 -= 8;
         }
      }

      return var2;
   }
}
