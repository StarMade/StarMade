import com.bulletphysics.linearmath.Transform;

final class class_473 implements class_1432 {

   // $FF: synthetic field
   private Transform field_a;


   class_473(Transform var1) {
      this.field_a = var1;
      super();
   }

   public final Transform getWorldTransform() {
      return this.field_a;
   }
}
