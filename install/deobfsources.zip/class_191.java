import com.bulletphysics.linearmath.Transform;
import javax.vecmath.Matrix3f;
import javax.vecmath.Vector3f;
import org.lwjgl.input.Keyboard;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.data.element.Element;
import org.schema.schine.graphicsengine.camera.Camera;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientStateInterface;

public final class class_191 extends Camera implements class_197 {

   boolean field_a;
   private Matrix3f field_a;
   class_193 field_a;
   private Camera field_a;
   private Vector3f field_a = new Vector3f(0.0F, 0.0F, 1.0F);
   private Vector3f field_b = new Vector3f(1.0F, 0.0F, 0.0F);
   private Vector3f field_c = new Vector3f(0.0F, 1.0F, 0.0F);
   public boolean field_b;
   private boolean field_c = false;
   private Matrix3f field_b;
   private float[] field_a;
   int field_a;
   final SegmentController field_a;
   private Camera field_b;
   private class_1006 field_a;


   public class_191(class_457 var1, Camera var2, class_800 var3) {
      super(new class_201(var1));
      this.field_a = var1.a1();
      this.field_a = new float[6];
      this.field_a[4] = 0.0F;
      this.field_a[5] = 3.1415927F;
      this.field_a[2] = -1.5707964F;
      this.field_a[3] = 1.5707964F;
      this.field_a[0] = -1.5707964F;
      this.field_a[1] = 1.5707964F;
      this.field_b = var2;
      this.field_c = true;
      byte var4 = var3.b1();
      var4 = (byte)Math.max(0, Math.min(5, var4));
      this.field_a = Element.orientationBackMapping[var4];
      if(this.field_a > 1 && this.field_a < 4) {
         Matrix3f var5;
         (var5 = new Matrix3f()).setIdentity();
         var5.rotY(1.5707964F);
         this.field_a = new Matrix3f();
         this.field_a.setIdentity();
         System.err.println("ROTATION_X: " + this.field_a[this.field_a] + " oo " + this.field_a + " orig: " + var4);
         this.field_a.rotX(this.field_a[this.field_a]);
         this.field_a.mul(var5);
         this.field_b = new Matrix3f();
         this.field_b.setIdentity();
         this.field_b.rotX(-this.field_a[this.field_a]);
         this.field_b.mul(var5);
      } else {
         this.field_a = new Matrix3f();
         this.field_a.setIdentity();
         System.err.println("ROTATION_Y: " + this.field_a[this.field_a] + " oo " + this.field_a + " orig: " + var4);
         this.field_a.rotY(this.field_a[this.field_a]);
         this.field_b = new Matrix3f();
         this.field_b.setIdentity();
         this.field_b.rotY(-this.field_a[this.field_a]);
      }

      this.field_a = new class_193(this, new class_201(var1));
      this.field_a = new Camera(new class_201(var1));
      this.a2();
      this.field_a.a2();
      this.field_a.a2();
   }

   public final Camera a76() {
      return this.field_a;
   }

   public final Vector3f b9() {
      Transform var1 = new Transform(this.field_a.getWorldTransform());
      return GlUtil.c(new Vector3f(), var1);
   }

   public final void a2() {
      super.a2();
      if(this.field_c) {
         this.getWorldTransform().basis.set(this.field_a.getWorldTransform().basis);
      }

   }

   public final synchronized void a12(class_935 var1) {
      if(this.field_c) {
         GlUtil.e(this.field_b, this.field_a.getWorldTransform());
         GlUtil.f(this.field_c, this.field_a.getWorldTransform());
         GlUtil.c(this.field_a, this.field_a.getWorldTransform());
         this.field_c = false;
      }

      super.a12(var1);
      if(class_1008.a1()) {
         ((class_201)this.field_a.a184()).a85().b1(((class_201)this.a184()).a85());
         ((class_201)this.field_a.a184()).a85().b1(((class_201)this.a184()).a85());
         this.field_a.a12(var1);
         this.field_a.a12(var1);
         if(this.field_a != null) {
            if(Keyboard.isKeyDown(class_367.field_u.a5())) {
               this.b25(this.field_a.e7());
               this.c12(this.field_a.f5());
               this.a163(this.field_a.c10());
            } else if(this.field_b) {
               Vector3f var2 = new Vector3f();
               Vector3f var3 = new Vector3f();
               Vector3f var4 = new Vector3f();
               GlUtil.e(var2, this.field_a.getWorldTransform());
               GlUtil.f(var3, this.field_a.getWorldTransform());
               GlUtil.c(var4, this.field_a.getWorldTransform());
               Transform var5 = new Transform();
               GlUtil.a30(this.field_a, var5);
               GlUtil.d2(this.field_c, var5);
               GlUtil.c3(this.field_b, var5);
               Transform var6 = new Transform();
               GlUtil.a30(var4, var6);
               GlUtil.d2(var3, var6);
               GlUtil.c3(var2, var6);
               Matrix3f var7;
               (var7 = new Matrix3f()).sub(var6.basis, var5.basis);
               this.field_a.getWorldTransform().basis.add(var7);
               this.field_b.set(var2);
               this.field_c.set(var3);
               this.field_a.set(var4);
            }
         }
      }

      if(this.field_a != null && !Keyboard.isKeyDown(157) && !Keyboard.isKeyDown(54)) {
         this.getWorldTransform().basis.set(this.field_a.getWorldTransform().basis);
         Matrix3f var8;
         (var8 = new Matrix3f(this.field_b)).invert();
         this.getWorldTransform().basis.mul(var8);
      }

      if(this.field_a != null && this.field_a.a4()) {
         this.field_a.a12(var1);
         this.getWorldTransform().set(this.field_a.getWorldTransform());
      }

      if(this.field_b != null) {
         this.a78(this.field_b);
         this.field_b = null;
      }

   }

   public final void a77(ClientStateInterface var1, class_935 var2) {
      if(Keyboard.isKeyDown(class_367.field_u.a5())) {
         this.field_a.a77(var1, var2);
      } else {
         this.field_a.a77(var1, var2);
      }

      super.a77(var1, var2);
   }

   public final void b() {
      this.field_a = true;
   }

   public final void a78(Camera var1) {
      this.field_a = new class_1006(var1, this);
   }

   public final SegmentController a79() {
      return this.field_a;
   }
}
