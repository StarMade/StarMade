import org.schema.schine.network.objects.remote.RemoteArray;
import org.schema.schine.network.objects.remote.RemoteStringArray;

final class class_486 extends class_14 {

   // $FF: synthetic field
   private class_303 field_a;


   class_486(class_303 var1, class_371 var2, Object var3, Object var4, String var5) {
      this.field_a = var1;
      super(var2, 50, var3, var4, var5);
   }

   public final String[] getCommandPrefixes() {
      return null;
   }

   public final String handleAutoComplete(String var1, class_1077 var2, String var3) {
      return var1;
   }

   public final boolean a1() {
      return super.field_a.b().indexOf(this) != super.field_a.b().size() - 1;
   }

   public final void a2() {
      this.field_a.e2(false);
   }

   public final void onFailedTextCheck(String var1) {
      this.a9("SHIPNAME INVALID: " + var1);
   }

   public final boolean a7(String var1) {
      if(super.field_a.a3() != null && super.field_a.a3().getPhysicsDataContainer() != null && super.field_a.a3().getPhysicsDataContainer().isInitialized()) {
         RemoteStringArray var2 = new RemoteStringArray(2, super.field_a.a20().a117());
         System.err.println("BUYING CATALOG: " + this.field_a.a33().field_a + " FOR " + super.field_a.a20().a117());
         var2.set(0, this.field_a.a33().field_a);
         var2.set(1, var1);
         super.field_a.a20().a117().catalogSaveAndBuyBuffer.add((RemoteArray)var2);
         return true;
      } else {
         System.err.println("[ERROR] Character might not have been initialized");
         return false;
      }
   }
}
