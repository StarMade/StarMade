import com.bulletphysics.linearmath.Transform;
import com.bulletphysics.util.ObjectPool;
import it.unimi.dsi.fastutil.objects.ObjectAVLTreeSet;
import it.unimi.dsi.fastutil.objects.ObjectBidirectionalIterator;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map.Entry;
import javax.vecmath.Matrix3f;
import javax.vecmath.Vector3f;
import javax.vecmath.Vector4f;
import org.schema.game.common.controller.elements.thrust.ThrusterUnit;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.graphicsengine.forms.Mesh;

public final class class_295 implements class_923, class_1368 {

   private class_743 field_a;
   private static class_1376 field_a;
   private static Matrix3f field_a = new Matrix3f();
   private ObjectAVLTreeSet field_a = new ObjectAVLTreeSet();
   private float field_a = 0.0F;
   private Vector4f field_a = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);
   private Vector4f field_b = new Vector4f(0.0F, 0.0F, 1.0F, 1.0F);
   private Vector4f field_c = new Vector4f();
   private Vector4f field_d = new Vector4f();
   private Transform field_a;
   private boolean field_a;
   private Vector3f field_a;
   private boolean field_b;
   private class_47 field_a;
   private long field_a;
   private ObjectPool field_a;
   private class_800 field_a;
   private static Vector4f field_e = new Vector4f();
   private static Vector4f field_f = new Vector4f();


   public class_295(class_743 var1) {
      new Vector3f();
      this.field_a = new Transform();
      this.field_a = new Vector3f(0.0F, 0.0F, -0.5F);
      this.field_b = true;
      this.field_a = new class_47();
      this.field_a = -1L;
      this.field_a = ObjectPool.get(eF.class);
      this.field_a = new class_800();
      this.field_a = var1;
      field_a.rotY(3.1415927F);
   }

   public final void a() {
      class_743 var10000 = this.field_a;
   }

   public final void b() {
      if(this.field_b) {
         field_a = class_1379.field_s;
      }

      if(!this.field_a.a7()) {
         if(!this.field_a) {
            if(this.field_a.getWorldTransform() != null) {
               this.field_a = System.currentTimeMillis();
               this.field_a = true;
            }

         } else {
            boolean var1 = true;
            ObjectBidirectionalIterator var2 = this.field_a.iterator();

            while(var2.hasPrevious()) {
               ((class_212)var2.previous()).a1(this.field_a, this.field_a);
               this.field_a.basis.mul(field_a);
               if(GlUtil.a20(this.field_a.origin, class_967.field_a.a()) && GlUtil.a18(this.field_a, class_218.field_a)) {
                  if(var1) {
                     float var3 = Math.min(0.99F, this.field_a.a8().length() / this.field_a.a14());
                     this.field_c.set(this.field_a);
                     this.field_d.set(this.field_b);
                     this.field_c.scale(var3);
                     this.field_d.scale(var3);
                     this.field_d.field_x = 0.5F - var3 / 2.0F;
                     this.field_d.field_z = var3;
                     if(!field_e.equals(this.field_c)) {
                        GlUtil.a42(field_a, "thrustColor0", this.field_c);
                        field_e.set(this.field_c);
                     }

                     if(!field_f.equals(this.field_d)) {
                        GlUtil.a42(field_a, "thrustColor1", this.field_d);
                        field_f.set(this.field_d);
                     }

                     GlUtil.a33(field_a, "ticks", this.field_a);
                     var1 = false;
                  }

                  GlUtil.d1();
                  GlUtil.b3(this.field_a);
                  ((Mesh)class_218.field_a.a156().get(0)).f();
                  GlUtil.c2();
               }
            }

         }
      }
   }

   public final class_743 a24() {
      return this.field_a;
   }

   public final void d() {}

   public final void c() {
      field_a = class_1379.field_s;
   }

   public final void e() {
      this.field_a = System.currentTimeMillis();
   }

   public final void a1(class_935 var1) {
      if(this.field_a > 0L && System.currentTimeMillis() - this.field_a > 500L) {
         class_295 var2 = this;
         ObjectAVLTreeSet var3 = this.field_a;
         synchronized(this.field_a) {
            Iterator var4 = var2.field_a.iterator();

            while(var4.hasNext()) {
               class_212 var5;
               (var5 = (class_212)var4.next()).a3();
               var2.field_a.release(var5);
            }

            var2.field_a.clear();
            var4 = var2.field_a.a96().getThrusterElementManager().getCollection().getCollection().iterator();

            while(var4.hasNext()) {
               Iterator var11 = ((ThrusterUnit)var4.next()).getLastElements().entrySet().iterator();

               while(var11.hasNext()) {
                  Entry var6 = (Entry)var11.next();
                  var2.field_a.b1((class_47)var6.getValue());
                  --var2.field_a.field_c;
                  class_800 var7 = null;

                  try {
                     var7 = var2.field_a.getSegmentBuffer().a10(var2.field_a, false, var2.field_a);
                  } catch (IOException var8) {
                     var8.printStackTrace();
                  } catch (InterruptedException var9) {
                     var9.printStackTrace();
                  }

                  if(var7 == null || var7.a9() == 0) {
                     class_212 var12;
                     (var12 = (class_212)var2.field_a.get()).a2(var2.field_a, (class_47)var6.getValue());
                     var2.field_a.add(var12);
                  }
               }
            }
         }

         this.field_a = -1L;
      }

      this.field_a = (float)((double)this.field_a + (double)(var1.a() / 100.0F) * ((Math.random() + 9.999999747378752E-5D) / 0.10000000149011612D));
      if(this.field_a > 1.0F) {
         this.field_a = 0.0F;
      }

   }

   public final void a13(class_1376 var1) {}

}
