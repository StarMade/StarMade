import com.bulletphysics.linearmath.Transform;
import javax.vecmath.Vector3f;
import org.schema.game.common.controller.SegmentController;

public class class_212 implements Comparable {

   private static final Vector3f field_a = new Vector3f();
   private static final Vector3f field_b = new Vector3f();
   private SegmentController field_a;
   private class_47 field_a;
   private static Vector3f field_c = new Vector3f();
   private static Transform field_a = new Transform();
   private static Vector3f field_d = new Vector3f(-50.0F, 0.0F, 0.0F);


   public final int a(class_212 var1) {
      if(var1 == null) {
         return 1;
      } else if(var1.hashCode() == this.hashCode()) {
         return 0;
      } else {
         this.a1(field_a, field_d);
         field_a.set(field_a.origin);
         var1.a1(field_a, field_d);
         field_b.set(field_a.origin);
         field_a.sub(class_967.a1().a83());
         field_b.sub(class_967.a1().a83());
         int var2;
         return (var2 = (int)(field_a.length() * 10000.0F - field_b.length() * 10000.0F)) == 0?1:var2;
      }
   }

   public boolean equals(Object var1) {
      return this.field_a.equals(((class_212)var1).field_a) && this.field_a == ((class_212)var1).field_a;
   }

   public final void a1(Transform var1, Vector3f var2) {
      field_a.set(this.field_a.getWorldTransformClient());
      field_c.set((float)(this.field_a.field_a - 8) + var2.field_x, (float)(this.field_a.field_b - 8) + var2.field_y, (float)(this.field_a.field_c - 8) + var2.field_z);
      field_a.basis.transform(field_c);
      field_a.origin.add(field_c);
      var1.set(field_a);
   }

   public int hashCode() {
      return this.field_a.hashCode() + this.field_a.hashCode();
   }

   public final void a2(SegmentController var1, class_47 var2) {
      this.field_a = var1;
      this.field_a = var2;
   }

   public final void a3() {
      this.field_a = null;
      this.field_a = null;
   }

   // $FF: synthetic method
   public int compareTo(Object var1) {
      return this.a((class_212)var1);
   }

}
