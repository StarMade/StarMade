import org.schema.schine.network.client.ClientState;

final class class_260 extends class_196 {

   public class_260(ClientState var1, class_1410 var2, Object var3, Object var4) {
      super(var1, var2, var3, var4);
      super.field_a = false;
   }

   public final void c() {
      super.c();
      class_262 var1;
      (var1 = new class_262(this.a24())).c();
      this.field_a.a9(var1);
   }
}
