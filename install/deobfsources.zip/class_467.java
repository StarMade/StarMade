import org.lwjgl.input.Keyboard;

public final class class_467 extends class_15 {

   private class_455 field_a = new class_455(this.a6());
   public class_483 field_a = new class_483(this.a6());
   public class_471 field_a = new class_471(this.a6());
   public class_445 field_a = new class_445(this.a6());


   public class_467(class_371 var1) {
      super(var1);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      this.field_a.c2(true);
   }

   public final class_471 a76() {
      return this.field_a;
   }

   public final class_455 a77() {
      return this.field_a;
   }

   public final class_483 a78() {
      return this.field_a;
   }

   public final class_445 a79() {
      return this.field_a;
   }

   public final void handleKeyEvent() {
      boolean var2;
      synchronized(this.a6().b()) {
         boolean var10000 = this.b1();
         var2 = false;
         if(var10000) {
            return;
         }
      }

      boolean var1 = this.field_a.field_b;
      if(Keyboard.getEventKeyState()) {
         if(Keyboard.getEventKey() == class_367.field_F.a5()) {
            if(!var1) {
               if(Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54)) {
                  System.err.println("USING FACTION CHAT");
                  this.a6().getChat().getTextInput().a9("/f ");
               }

               this.field_a.d2(true);
            } else {
               this.field_a.d2(false);
            }
         } else if(Keyboard.getEventKey() == 87 && !var1) {
            var2 = this.field_a.field_b;
            if(!this.field_a.field_b && !this.a6().b().isEmpty()) {
               return;
            }

            if(var2 && this.a6().a3() == null) {
               System.out.println("no player character: spawning");
               this.a6().a4().e1();
            } else {
               this.field_a.c2(var2);
               this.field_a.c2(!var2);
            }

            if(this.field_a.field_b && !var2) {
               this.field_a.c2(false);
               this.field_a.c2(true);
            }
         }
      }

      super.handleKeyEvent();
   }

   public final void a12(class_941 var1) {
      super.a12(var1);
   }

   public final void a15(class_935 var1) {
      super.a15(var1);
      if(!this.a6().b().isEmpty()) {
         class_1008.field_a = false;
      }

   }
}
