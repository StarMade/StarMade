import org.schema.schine.network.client.ClientState;

public final class class_141 extends class_196 {

   class_801 field_a;


   public class_141(ClientState var1, class_422 var2, class_801 var3) {
      super(var1, var2, "Faction Block Config", "");
      this.field_a = var3;
   }

   public final void c() {
      super.c();
      class_928 var1;
      (var1 = new class_928(this.a24(), 200, 20, "Reset Faction Signitaure", super.field_a)).field_a = "NEUTRAL";
      class_928 var2;
      (var2 = new class_928(this.a24(), 200, 20, "Enter Faction Signiture", super.field_a)).field_a = "FACTION";
      var2.a83().field_y = 30.0F;
      class_136 var3;
      (var3 = new class_136(this, this.a24(), "Make Faction Home", super.field_a)).field_a = "HOMEBASE";
      var3.a83().field_y = 60.0F;
      this.field_a.a9(var3);
      this.field_a.a9(var1);
      this.field_a.a9(var2);
   }
}
