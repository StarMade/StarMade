import java.util.ArrayList;
import org.schema.game.client.view.cubes.CubeMeshBufferContainer;

public class class_396 {

   private static final ArrayList field_a = new ArrayList(4);
   private static boolean field_a;
   // $FF: synthetic field
   private static boolean field_b = !dI.class.desiredAssertionStatus();


   public static CubeMeshBufferContainer a() {
      ArrayList var0 = field_a;
      synchronized(field_a) {
         while(field_a.isEmpty()) {
            field_a.wait();
         }

         return (CubeMeshBufferContainer)field_a.remove(0);
      }
   }

   private static void a1() {
      if(!field_a) {
         for(int var0 = 0; var0 < 4; ++var0) {
            field_a.add(CubeMeshBufferContainer.a1());
         }

         field_a = true;
      }

   }

   public static void a2(CubeMeshBufferContainer var0) {
      if(!field_b && field_a.contains(var0)) {
         throw new AssertionError();
      } else {
         ArrayList var1 = field_a;
         synchronized(field_a) {
            field_a.add(var0);
            field_a.notify();
         }

         if(!field_b && field_a.size() > 4) {
            throw new AssertionError();
         }
      }
   }

   static {
      a1();
   }
}
