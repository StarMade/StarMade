import javax.vecmath.Vector3f;

public final class class_214 extends class_946 {

   final class_253[] field_a;
   private Vector3f field_b = new Vector3f();
   private Vector3f field_c = new Vector3f();
   Vector3f field_a = new Vector3f();


   public class_214(class_253[] var1) {
      super(var1.length);
      super.field_c = true;
      this.field_a = var1;
   }

   public final boolean a7(int var1, class_935 var2) {
      super.field_a.c(var1, this.field_c);
      class_253 var3 = this.field_a[(int)this.field_c.field_x];
      if((int)this.field_c.field_y == var3.field_a && var3.field_a) {
         this.field_b.set(var3.field_a.origin);
         super.field_a.a7(Math.abs(var1 - this.field_c) % super.field_a.a1(), this.field_b.field_x, this.field_b.field_y, this.field_b.field_z);
         return true;
      } else {
         System.err.println("[MISSILETRAIL] HEAD DIED");
         return false;
      }
   }
}
