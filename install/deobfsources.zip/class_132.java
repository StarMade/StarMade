import java.util.ArrayList;
import org.lwjgl.opengl.GL11;
import org.newdawn.slick.Color;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public final class class_132 extends class_964 {

   private float field_b = 5.0F;
   private float field_c;
   private float field_d;
   private class_940 field_a;
   private boolean field_a = true;
   private float field_e = 0.0F;
   private Color field_a = new Color(1, 1, 1, 1);
   private String field_b;
   public float field_a = 0.0F;


   public class_132(String var1, ClientState var2, String var3, Color var4) {
      super(var2);
      this.field_b = var1;
      this.field_a = new class_940(800, 40, var2);
      this.field_a.field_b = new ArrayList();
      this.field_a.field_r = var4.field_r;
      this.field_a.field_g = var4.field_g;
      this.field_a.field_b = var4.field_b;
      this.field_a.field_a = var4.field_a;
      this.field_a.field_b.add(var3);
   }

   public final void a2() {}

   public final void b() {
      if(this.field_a) {
         this.c();
      }

      if(this.field_d >= 0.0F) {
         this.a83().field_x = 100.0F;
         this.a83().field_y = this.field_e + 100.0F;
         if(this.j1()) {
            float var1;
            if((var1 = this.field_b - this.field_c) < 1.0F) {
               this.field_a.field_a.field_a = var1;
            }

            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GlUtil.d1();
            this.r();
            this.field_a.b();
            GlUtil.c2();
            GL11.glDisable(3042);
            this.field_a.field_a.field_a = 1.0F;
            this.field_a.field_a.field_r = 1.0F;
            this.field_a.field_a.field_g = 1.0F;
            this.field_a.field_a.field_b = 1.0F;
         }
      }
   }

   public final boolean equals(Object var1) {
      return this.field_b.equals(((class_132)var1).field_b);
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final String a16() {
      return this.field_b;
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public final boolean a4() {
      return this.field_c < this.field_b;
   }

   public final void c() {
      this.field_a.a136(Color.white);
      this.field_a.field_a = class_28.e();
      this.field_a.c();
      this.field_a = false;
      this.field_e = -1.0F * (this.field_a.a3() * super.field_a.field_y + 5.0F);
   }

   public final void e() {
      this.field_c = 0.0F;
   }

   public final void a17(String var1) {
      this.field_a.field_b.set(0, var1);
   }

   public final void f() {
      this.field_d = 0.0F;
      this.field_c = 0.0F;
   }

   public final void a12(class_935 var1) {
      if(this.field_d < 0.0F) {
         this.field_d += var1.a();
      } else {
         this.field_c += var1.a();
         float var2 = this.field_a * (this.field_a.a3() * super.field_a.field_y + 5.0F);
         float var3 = Math.min(1.0F, Math.max(0.01F, Math.abs(this.field_e - var2)) / (this.field_a.a3() * super.field_a.field_y));
         if(this.field_e > var2) {
            this.field_e -= var1.a() * 1000.0F * var3;
            if(this.field_e <= var2) {
               this.field_e = var2;
               return;
            }
         } else if(this.field_e < var2) {
            this.field_e += var1.a() * 1000.0F * var3;
            if(this.field_e >= var2) {
               this.field_e = var2;
            }
         }

      }
   }
}
