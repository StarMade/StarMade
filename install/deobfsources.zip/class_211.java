import com.bulletphysics.collision.shapes.ConvexHullShape;
import com.bulletphysics.collision.shapes.ConvexShape;
import com.bulletphysics.util.ObjectArrayList;
import java.nio.FloatBuffer;
import javax.vecmath.Vector3f;
import org.schema.game.client.view.cubes.CubeMeshBufferContainer;

public final class class_211 extends class_384 implements class_378 {

   private ConvexHullShape field_a;


   public class_211() {
      ObjectArrayList var1;
      (var1 = new ObjectArrayList()).add(new Vector3f(-0.5F, 0.5F, -0.5F));
      var1.add(new Vector3f(-0.5F, 0.5F, 0.5F));
      var1.add(new Vector3f(0.5F, 0.5F, 0.5F));
      var1.add(new Vector3f(0.5F, 0.5F, -0.5F));
      var1.add(new Vector3f(-0.5F, -0.5F, -0.5F));
      var1.add(new Vector3f(-0.5F, -0.5F, 0.5F));
      this.field_a = new ConvexHullShape(var1);
   }

   public final void a(int var1, byte var2, short var3, byte var4, byte var5, byte var6, byte var7, byte var8, FloatBuffer var9) {
      for(short var10 = 0; var10 < 4; ++var10) {
         short var11 = var10;
         int var12 = var1;
         boolean var13 = false;
         switch(var1) {
         case 0:
            var11 = 0;
         case 1:
         case 2:
         default:
            break;
         case 3:
            if(var10 == 0) {
               var12 = 2;
               var11 = 0;
            } else if(var10 == 1) {
               var12 = 2;
               var11 = 3;
            } else if(var10 == 2) {
               var13 = true;
            } else if(var10 == 3) {
               var13 = true;
            }
            break;
         case 4:
            if(var10 == 3) {
               var11 = 0;
            }
            break;
         case 5:
            if(var10 == 0) {
               var11 = 3;
            }
         }

         a4(var12, var11, var2, var3, var4, var5, var13, false, var10, 2184, var6, var7, var8, 8421504.0F, var9);
      }

   }

   public final void a1(int var1, byte var2, short var3, byte var4, byte var5, int var6, int var7, int var8, float var9, CubeMeshBufferContainer var10) {
      for(short var11 = 0; var11 < 4; ++var11) {
         short var12 = var11;
         int var13 = var1;
         boolean var14 = false;
         switch(var1) {
         case 0:
            var12 = 0;
         case 1:
         case 2:
         default:
            break;
         case 3:
            if(var11 == 0) {
               var13 = 2;
               var12 = 0;
            } else if(var11 == 1) {
               var13 = 2;
               var12 = 3;
            } else if(var11 == 2) {
               var14 = true;
            } else if(var11 == 3) {
               var14 = true;
            }
            break;
         case 4:
            if(var11 == 3) {
               var12 = 0;
            }
            break;
         case 5:
            if(var11 == 0) {
               var12 = 3;
            }
         }

         a3(var13, var12, var2, var3, var4, var5, var14, false, var6, var7, var11, var8, var9, var10);
      }

   }

   protected final ConvexShape a2() {
      return this.field_a;
   }
}
