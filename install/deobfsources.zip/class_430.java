
public final class class_430 extends class_15 {

   public class_430(class_371 var1) {
      super(var1);
   }
}
