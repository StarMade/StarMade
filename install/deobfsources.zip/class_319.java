
public enum class_319 {

   field_a("BUY_BUTTON", 0),
   field_b("SELL_BUTTON", 1),
   field_c("OK_BUTTON", 2),
   field_d("CANCEL_BUTTON", 3),
   field_e("SPAWN_BUTTON", 4),
   field_f("EXIT_BUTTON", 5),
   field_g("RESUME_BUTTON", 6),
   field_h("OPTIONS_BUTTON", 7),
   field_i("EXIT_TO_WINDOWS_BUTTON", 8),
   field_j("SUICIDE_BUTTON", 9),
   field_k("BUY_MORE_BUTTON", 10),
   field_l("SELL_MORE_BUTTON", 11),
   field_m("GREEN_TEAM_BUTTON", 12),
   field_n("BLUE_TEAM_BUTTON", 13),
   field_s("SAVE_SHIP_BUTTON", 14),
   field_t("SAVE_SHIP_LOCAL_BUTTON", 15),
   field_u("UPLOAD_LOCAL_SHIP_BUTTON", 16),
   field_o("NEXT_BUTTON", 17),
   field_p("BACK_BUTTON", 18),
   field_q("SKIP_BUTTON", 19),
   field_r("END_TUTORIAL_BUTTON", 20);
   // $FF: synthetic field
   private static final class_319[] field_a = new class_319[]{field_a, field_b, field_c, field_d, field_e, field_f, field_g, field_h, field_i, field_j, field_k, field_l, field_m, field_n, field_s, field_t, field_u, field_o, field_p, field_q, field_r};


   private class_319(String var1, int var2) {}

   public final int a(boolean var1) {
      return this.ordinal() + (var1?32:0);
   }

}
