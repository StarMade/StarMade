import org.lwjgl.input.Keyboard;

public abstract class class_14 extends class_11 implements class_1077, class_952 {

   public final class_1075 field_a;
   public final class_196 field_a;


   public class_14(class_371 var1, int var2, Object var3, Object var4) {
      super(var1);
      this.field_a = new class_1075(var2, this);
      this.field_a = new class_259(var1, this, var3, var4, this.field_a);
      this.field_a.a143(this);
   }

   public class_14(class_371 var1, int var2, Object var3, Object var4, String var5) {
      this(var1, var2, var3, var4);
      if(var5 != null && var5.length() > 0) {
         this.field_a.a9(var5);
         this.field_a.e();
         this.field_a.g1();
      }

   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.field_a && var2.field_a == 0) {
         if(var1.b19().equals("OK")) {
            System.err.println("OK");
            this.field_a.b();
         }

         if(var1.b19().equals("CANCEL") || var1.b19().equals("X")) {
            System.err.println("CANCEL");
            this.d();
         }
      }

   }

   public final class_1075 a8() {
      return this.field_a;
   }

   public void handleKeyEvent() {
      if(Keyboard.getEventKeyState()) {
         if(super.field_a && Keyboard.getEventKey() == 1) {
            this.d();
            return;
         }

         this.field_a.handleKeyEvent();
      }

   }

   public abstract boolean a7(String var1);

   public void onTextEnter(String var1, boolean var2) {
      if(this.a7(var1)) {
         this.d();
      }

   }

   public final void a9(String var1) {
      this.field_a.a17(var1);
   }

   public final void a10(class_954 var1) {
      this.field_a.a10(var1);
   }
}
