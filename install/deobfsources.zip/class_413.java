
final class class_413 extends class_346 {

   // $FF: synthetic field
   private class_423 field_a;


   class_413(class_423 var1, class_371 var2, class_777 var3) {
      this.field_a = var1;
      super(var2, var3);
   }

   public final void a2() {
      super.a2();
      this.field_a.e2(false);
   }
}
