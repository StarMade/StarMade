import java.util.ArrayList;
import org.lwjgl.input.Keyboard;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public final class class_85 extends class_964 {

   private class_1412 field_a = new class_1412(this.a24(), 300.0F, 300.0F);
   private class_1412 field_b;
   private class_966 field_a;
   private class_940 field_a;
   private class_940 field_b;
   private class_893 field_a;
   private boolean field_a = true;
   private class_963 field_a;


   public class_85(ClientState var1) {
      super(var1);
      this.field_a = new class_893(var1);
   }

   public final void a9(class_964 var1) {
      this.field_a.a9(var1);
   }

   public final void a2() {
      this.field_a.a2();
   }

   public final void b2(class_964 var1) {
      this.field_a.b2(var1);
   }

   public final void b() {
      if(this.field_a) {
         this.c();
      }

      String var1;
      if(!(var1 = "press " + class_367.field_U.b1() + "\nto enter advanced\nbuild mode\n\n").equals(this.field_a.field_b.get(0))) {
         this.field_a.field_b.set(0, var1);
      }

      GlUtil.d1();
      this.field_a.h2(17);
      this.field_a.b();
      this.r();
      this.field_a.b();
      GlUtil.c2();
   }

   public final class_459 a10() {
      return ((class_371)this.a24()).a14().field_a.field_a.field_a.a50();
   }

   public final class_433 a11() {
      class_443 var1;
      return (var1 = ((class_371)this.a24()).a14().field_a.field_a.field_a).a51().a45().field_a.field_c?var1.a51().a45().field_a.a70():var1.a53().a36().a70();
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public final boolean a_() {
      return this.field_a.a_();
   }

   public final void c() {
      this.field_a.c();
      this.field_a = new class_940(100, 30, class_28.c(), this.a24());
      this.field_a.field_b = new ArrayList();
      this.field_a.field_b.add("press " + class_367.field_U.b1() + "\nto enter advanced\nbuild mode\n\n");
      this.field_a.field_b.add("press " + class_367.field_t.b1() + "\nto reset the camera\n\n");
      this.field_a.field_b.add("hold Shift\nto move faster\n\n");
      this.field_a.field_b.add("press " + class_367.field_r.b1() + "\nfor flight mode\n\n");
      this.field_a.field_b.add("Shift + MouseWheel to zoom\n\n");
      this.field_b = new class_1412(this.a24());
      this.field_b = new class_940(100, 30, class_28.d(), this.a24());
      this.field_b.field_b = new ArrayList();
      this.field_b.field_b.add("");
      this.field_b.a83().field_y = 100.0F;
      this.field_a = new class_966(533.0F, 316.0F, this.a24());
      this.field_a.a83().set(0.0F, 0.0F, 0.0F);
      this.field_a = new class_963(this.a24());
      this.field_a.a143(this.a10());
      this.field_b.a9(this.field_a);
      this.field_b.a9(this.field_b);
      this.field_a.c6(this.field_a);
      this.field_a.a9(this.field_b);
      this.field_a.c();
      this.field_a.clear();
      this.field_a.a144(new class_934(this.a24(), 100, "Remove Mode", new class_87(this, this.a24()), false));
      this.field_a.a144(new class_934(this.a24(), 60, "X", new class_82(this.a24(), this.a10().field_a), false));
      this.field_a.a144(new class_934(this.a24(), 60, "Y", new class_82(this.a24(), this.a10().field_b), false));
      this.field_a.a144(new class_934(this.a24(), 60, "Z", new class_82(this.a24(), this.a10().field_c), false));
      class_934 var2 = new class_934(this.a24(), 90, "Orientation", new class_272(this.a24()), false);
      this.field_a.a144(var2);
      class_940 var3;
      (var3 = new class_940(100, 40, class_28.d(), this.a24())).a137("Symmetry Build Planes");
      this.field_a.a144(new class_972(var3, var3, this.a24()));
      this.field_a.a144(new class_934(this.a24(), 60, "XY-Plane", new class_206(this.a24(), 1), false));
      this.field_a.a144(new class_934(this.a24(), 60, "XZ-Plane", new class_206(this.a24(), 2), false));
      this.field_a.a144(new class_934(this.a24(), 60, "YZ-Plane", new class_206(this.a24(), 4), false));
      this.field_a.a144(new class_934(this.a24(), 100, "Odd-sym Mode", new class_89(this, this.a24()), false));
      super.a9(this.field_a);
      this.field_a.a9(this.field_a);
      this.d();
      this.field_a.a83().set((float)(class_927.b() - 270), 64.0F, 0.0F);
      this.field_a.field_g = true;
      this.field_a = false;
   }

   public final void a12(class_935 var1) {
      super.a12(var1);
      if(Keyboard.isKeyDown(class_367.field_U.a5())) {
         this.field_a.c6(this.field_b);
      } else {
         this.field_a.c6(this.field_a);
      }
   }
}
