
final class class_169 {

   // $FF: synthetic field
   private class_171 field_a;


   class_169(class_171 var1) {
      this.field_a = var1;
      super();
   }

   public final String toString() {
      return class_171.a55(this.field_a).a171().a60()[class_171.a56(this.field_a).field_a];
   }
}
