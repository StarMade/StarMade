import com.bulletphysics.collision.dispatch.CollisionWorld;
import com.bulletphysics.linearmath.Transform;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import javax.vecmath.Vector3f;
import org.lwjgl.opengl.GL11;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.controller.elements.ManagerModuleCollection;
import org.schema.game.common.controller.elements.dockingBlock.DockingBlockCollectionManager;
import org.schema.game.common.controller.elements.dockingBlock.DockingBlockManagerInterface;
import org.schema.game.common.data.element.Element;
import org.schema.game.common.data.element.ElementInformation;
import org.schema.game.common.data.element.ElementKeyMap;
import org.schema.game.common.data.physics.CubeRayCastResult;
import org.schema.game.common.data.world.Segment;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.graphicsengine.forms.Mesh;

public final class class_331 implements class_923 {

   private boolean field_e = true;
   class_371 field_a;
   CollisionWorld.ClosestRayResultCallback field_a;
   class_1433 field_a;
   class_1433 field_b;
   private long field_a;
   private class_800 field_c;
   class_297 field_a;
   Segment field_a;
   class_34 field_a = new class_34();
   Segment field_b = null;
   class_800 field_a;
   ElementInformation field_a;
   class_800 field_b;
   ElementInformation field_b;
   boolean field_a;
   boolean field_b;
   boolean field_c;
   private Transform field_a = new Transform();
   private Mesh field_a;
   private class_47 field_c;
   private int field_a;
   private long field_b;
   private class_47 field_d;
   private class_221 field_a;
   private class_47 field_e;
   private Vector3f field_a;
   class_47 field_a;
   class_47 field_b;
   public boolean field_d;


   public class_331(class_371 var1) {
      new Transform();
      this.field_c = new class_47();
      this.field_a = -1;
      this.field_d = new class_47();
      this.field_e = new class_47();
      this.field_a = new Vector3f();
      this.field_a = new class_47();
      this.field_b = new class_47();
      this.field_a = var1;
      this.field_a = new class_1433();
      this.field_b = new class_1433(6.1F);
      this.field_a = new class_297(new Transform(), "");
   }

   public final void a27(class_800 var1) {
      this.field_a = System.currentTimeMillis();
      this.field_c = var1;
   }

   public final void a() {}

   public final void b() {
      if(this.field_e) {
         this.c();
      }

      Vector3f var5;
      if(this.field_c != null) {
         GlUtil.d1();
         this.field_a.h1();
         var5 = null;
         class_1379.field_u.field_a = this.field_a;
         class_1379.field_u.b();
         GL11.glDisable(2884);
         this.c2(this.field_c.a7().a15(), this.field_c);
         GL11.glEnable(2884);
         class_1379.field_u.d();
         this.field_a.m1();
         GlUtil.c2();
         if(System.currentTimeMillis() - this.field_a > 3000L) {
            this.field_c = null;
         }
      }

      class_743 var1 = this.field_a.a25();
      if(!this.a35().a36().g() && this.a33().c()) {
         class_227.field_a = false;
         if(this.field_e) {
            this.c();
         }

         if(this.field_a != this.field_a.a14().a18().a79().a60().a28()) {
            if(this.field_a >= 0) {
               this.field_b = System.currentTimeMillis();
            }

            this.field_a = this.field_a.a14().a18().a79().a60().a28();
         }

         class_800 var12;
         if((var12 = this.a33().a40()) != null) {
            GlUtil.d1();
            this.field_a.h1();
            var5 = null;
            class_1379.field_u.field_a = this.field_a;
            class_1379.field_u.b();
            GlUtil.a41(class_1379.field_u, "selectionColor", 0.9F, 0.6F, 0.2F, 0.65F);
            this.b3(var12.a7().a15(), var12);
            GlUtil.a41(class_1379.field_u, "selectionColor", 0.4F, 0.1F, 0.9F, 0.65F);
            this.a28(var12.a7().a15(), var12);
            class_1379.field_u.d();
            this.field_a.m1();
            GlUtil.c2();
         }

         if(this.field_a.a3() != null && System.currentTimeMillis() - this.field_b < 3000L) {
            this.b4(this.field_a.a3().getWorldTransform());
         }

      } else {
         class_227.field_a = true;
         if(this.a35().a36().g() && var1 != null) {
            GlUtil.d1();
            this.field_a.h1();
            var5 = null;
            class_1379.field_u.field_a = this.field_a;
            class_1379.field_u.b();
            GL11.glDisable(2884);
            Transform var2 = this.a31(var1);
            GlUtil.a41(class_1379.field_u, "selectionColor", 1.0F, 1.0F, 0.0F, 1.0F);
            this.a29(var1);
            this.c2(var1, (class_800)null);
            GlUtil.a41(class_1379.field_u, "selectionColor", 0.9F, 0.6F, 0.2F, 0.65F);
            this.b3(var1, this.a35().a36().a40());
            GlUtil.a41(class_1379.field_u, "selectionColor", 0.4F, 0.1F, 0.9F, 0.65F);
            this.a28(var1, this.a35().a36().a40());
            GL11.glEnable(2884);
            class_1379.field_u.d();
            this.field_a.m1();
            class_433 var3;
            if((var3 = this.a32().a70()).field_a || var3.field_b || var3.field_c) {
               this.b2(var1);
            }

            if(var3.field_a > 0) {
               this.a30(var1, var3.field_a, this.field_e, (float)var3.field_b * 0.5F);
            }

            CubeRayCastResult var4;
            if(this.field_a != null && this.field_a.hasHit() && this.field_a instanceof CubeRayCastResult && (var4 = (CubeRayCastResult)this.field_a).getSegment() != null && !class_367.field_U.a6()) {
               this.field_a.set(var1.getWorldTransform());
               Vector3f var10000 = var5 = new Vector3f((float)var4.getSegment().field_a.field_a, (float)var4.getSegment().field_a.field_b, (float)var4.getSegment().field_a.field_c);
               var10000.field_x += (float)(var4.cubePos.field_a - 8);
               var5.field_y += (float)(var4.cubePos.field_b - 8);
               var5.field_z += (float)(var4.cubePos.field_c - 8);
               short var13 = this.field_a.a14().a18().a79().a60().a54();
               Vector3f var6 = new Vector3f();
               class_800 var7;
               if((var7 = this.a32().a40()) != null && var7.a9() != 0 && var13 != 0) {
                  class_47 var8 = var7.a2(new class_47());
                  var6.set((float)(var8.field_a - 8), (float)(var8.field_b - 8), (float)(var8.field_c - 8));
                  Vector3f var14 = new Vector3f(this.field_a.hitPointWorld);
                  var1.getWorldTransformInverse().transform(var14);
                  new Vector3f();
                  switch(Element.getSide(var14, this.field_c)) {
                  case 0:
                     ++var5.field_x;
                     break;
                  case 1:
                     --var5.field_x;
                     break;
                  case 2:
                     ++var5.field_y;
                     break;
                  case 3:
                     --var5.field_y;
                     break;
                  case 4:
                     ++var5.field_z;
                     break;
                  case 5:
                     --var5.field_z;
                     break;
                  default:
                     System.err.println("[BUILDMODEDRAWER] WARNING: NO SIDE recognized!!!");
                  }

                  this.field_c.b((int)var5.field_x, (int)var5.field_y, (int)var5.field_z);
                  GlUtil.d1();
                  GlUtil.b3(this.field_a);
                  GL11.glDisable(3553);
                  GL11.glEnable(2903);
                  GL11.glDisable(2896);
                  GL11.glEnable(3042);
                  GL11.glBlendFunc(770, 771);
                  GL11.glLineWidth(4.0F);
                  if(ElementKeyMap.getInfo(var13).getControlledBy().contains(Short.valueOf(var7.a9()))) {
                     GlUtil.a38(0.0F, 0.8F, 0.0F, 1.0F);
                  } else {
                     GlUtil.a38(0.8F, 0.0F, 0.0F, 0.6F);
                  }

                  GL11.glBegin(1);
                  GL11.glVertex3f(var6.field_x, var6.field_y, var6.field_z);
                  GL11.glVertex3f(var5.field_x, var5.field_y, var5.field_z);
                  GL11.glEnd();
                  GL11.glLineWidth(2.0F);
                  GL11.glDisable(3042);
                  GL11.glDisable(2903);
                  GL11.glEnable(2896);
                  GL11.glEnable(3553);
                  GlUtil.c2();
                  new Transform(this.field_a);
               }
            }

            if(var2 != null) {
               this.b4(var2);
            }

            GlUtil.c2();
         }

         if(this.a34().a36().g()) {
            SegmentController var10 = this.a34().a40().a7().a15();
            GlUtil.d1();
            this.field_a.h1();
            var5 = null;
            class_1379.field_u.field_a = this.field_a;
            class_1379.field_u.b();
            GL11.glDisable(2884);
            GlUtil.a41(class_1379.field_u, "selectionColor", 0.7F, 0.77F, 0.1F, 1.0F);
            Transform var11 = this.a31(var10);
            this.c2(var10, (class_800)null);
            GlUtil.a41(class_1379.field_u, "selectionColor", 1.0F, 1.0F, 0.0F, 1.0F);
            this.a29(var10);
            GlUtil.a41(class_1379.field_u, "selectionColor", 0.9F, 0.6F, 0.2F, 0.65F);
            this.b3(var10, this.a34().a36().a40());
            GlUtil.a41(class_1379.field_u, "selectionColor", 0.4F, 0.1F, 0.9F, 0.65F);
            this.a28(var10, this.a34().a36().a40());
            GL11.glEnable(2884);
            class_1379.field_u.d();
            this.field_a.m1();
            class_433 var9;
            if((var9 = this.a34().a36().a70()).field_a || var9.field_b || var9.field_c) {
               this.b2(var10);
            }

            if(var9.field_a > 0) {
               this.a30(var10, var9.field_a, this.field_e, (float)var9.field_b * 0.5F);
            }

            if(var11 != null) {
               this.b4(var11);
            }

            GlUtil.c2();
         }

      }
   }

   private void a28(SegmentController var1, class_800 var2) {
      try {
         if(class_943.field_ak.b1() && var2 != null) {
            class_47 var7 = var2.a2(this.field_d);
            class_858 var8;
            if((var8 = var1.getControlElementMap().getControlledElements((short)32767, var7)) != null) {
               this.a14(var1.getWorldTransform());
               var1 = null;
               Iterator var6 = var8.field_a.iterator();

               while(var6.hasNext()) {
                  class_897 var9 = (class_897)var6.next();
                  class_1433 var4 = this.field_b;
                  if(var9 != null) {
                     this.field_a.set((float)(var9.field_a - 8), (float)(var9.field_b - 8), (float)(var9.field_c - 8));
                     GlUtil.d1();
                     GlUtil.c4(this.field_a.field_x, this.field_a.field_y, this.field_a.field_z);
                     float var10001 = var4.a1();
                     GlUtil.b5(1.05F + var10001 * 0.05F, 1.05F + var10001 * 0.05F, 1.05F + var10001 * 0.05F);
                     this.field_a.i();
                     GlUtil.c2();
                  }
               }

               d();
            }
         }

      } catch (ConcurrentModificationException var5) {
         var5.printStackTrace();
      }
   }

   private void a14(Transform var1) {
      this.field_a.set(var1);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glDisable(2896);
      GL11.glEnable(2903);
      GlUtil.a38(1.0F, 0.0F, 1.0F, 0.6F);
      GlUtil.d1();
      GlUtil.b3(var1);
   }

   private static void d() {
      GlUtil.a38(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glEnable(2896);
      GL11.glDisable(2903);
      GL11.glDisable(3042);
      GlUtil.c2();
   }

   private void a29(SegmentController var1) {
      if(class_967.a1() instanceof class_243) {
         this.field_a.set(var1.getWorldTransform());
         Vector3f var2 = ((class_243)class_967.a1()).b9();
         this.field_a.basis.transform(var2);
         this.field_a.origin.add(var2);
         GlUtil.d1();
         GlUtil.b3(this.field_a);
         GL11.glScalef(1.01F, 1.01F, 1.01F);
         GL11.glDisable(2896);
         GL11.glEnable(3042);
         GL11.glBlendFunc(770, 771);
         GL11.glEnable(2903);
         GlUtil.a38(0.0F, 0.0F, 1.0F, 0.6F);
         GlUtil.b5(0.1F, 0.1F, 0.1F);
         this.field_a.i();
         GlUtil.a38(1.0F, 1.0F, 1.0F, 1.0F);
         GL11.glEnable(2896);
         GL11.glDisable(2903);
         GL11.glDisable(3042);
         GlUtil.c2();
      }

   }

   private void b2(SegmentController var1) {
      class_433 var2 = this.a32().a70();
      GL11.glDisable(2896);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2903);
      GlUtil.a38(1.0F, 1.0F, 1.0F, 0.7F);
      GL11.glDisable(2884);
      float var3 = (float)var2.field_b * 0.5F;
      Vector3f var4 = new Vector3f((float)(var2.field_c.field_a - 8) + var3, (float)(var2.field_b.field_b - 8) + var3, (float)(var2.field_a.field_c - 8) + var3);
      this.field_a.set(var1.getWorldTransform());
      GlUtil.d1();
      GlUtil.b3(this.field_a);
      GL11.glBegin(1);
      if(var2.field_a && var2.field_b && var2.field_c) {
         GL11.glVertex3f((float)(var1.getMinPos().field_a << 4), var4.field_y, var4.field_z);
         GL11.glVertex3f((float)(var1.getMaxPos().field_a << 4), var4.field_y, var4.field_z);
         GL11.glVertex3f(var4.field_x, (float)(var1.getMinPos().field_b << 4), var4.field_z);
         GL11.glVertex3f(var4.field_x, (float)(var1.getMaxPos().field_b << 4), var4.field_z);
         GL11.glVertex3f(var4.field_x, var4.field_y, (float)(var1.getMinPos().field_c << 4));
         GL11.glVertex3f(var4.field_x, var4.field_y, (float)(var1.getMaxPos().field_c << 4));
      } else if(var2.field_a && var2.field_b) {
         GL11.glVertex3f((float)(var1.getMinPos().field_a << 4), var4.field_y, var4.field_z);
         GL11.glVertex3f((float)(var1.getMaxPos().field_a << 4), var4.field_y, var4.field_z);
      } else if(var2.field_a && var2.field_c) {
         GL11.glVertex3f(var4.field_x, (float)(var1.getMinPos().field_b << 4), var4.field_z);
         GL11.glVertex3f(var4.field_x, (float)(var1.getMaxPos().field_b << 4), var4.field_z);
      } else if(var2.field_b && var2.field_c) {
         GL11.glVertex3f(var4.field_x, var4.field_y, (float)(var1.getMinPos().field_c << 4));
         GL11.glVertex3f(var4.field_x, var4.field_y, (float)(var1.getMaxPos().field_c << 4));
      }

      GL11.glEnd();
      GlUtil.c2();
      GL11.glBindTexture(3553, 0);
      GL11.glEnable(2884);
      GlUtil.a38(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glEnable(2896);
      GL11.glDisable(2903);
      GL11.glDisable(3042);
      if(var2.field_a) {
         this.a30(var1, 1, var2.field_a, var3);
      }

      if(var2.field_b) {
         this.a30(var1, 2, var2.field_b, var3);
      }

      if(var2.field_c) {
         this.a30(var1, 4, var2.field_c, var3);
      }

   }

   private void a30(SegmentController var1, int var2, class_47 var3, float var4) {
      GL11.glDepthMask(false);
      GL11.glDisable(2896);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 1);
      GL11.glEnable(2903);
      GL11.glDisable(2884);
      class_967.a2().a5("shield_tex").a157().a1().a();
      Vector3f var5;
      Vector3f var10000;
      if(var2 == 1) {
         var10000 = var5 = new Vector3f(0.0F, 0.0F, (float)var3.field_c);
         var10000.field_x -= 8.0F;
         var5.field_y -= 8.0F;
         var5.field_z -= 8.0F;
         this.field_a.set(var1.getWorldTransform());
         GlUtil.d1();
         GlUtil.b3(this.field_a);
         GlUtil.a38(0.0F, 0.0F, 1.0F, 0.3F);
         GL11.glBegin(7);
         GL11.glTexCoord2f(0.0F, 0.0F);
         GL11.glVertex3f((float)(var1.getMinPos().field_a << 4), (float)(var1.getMinPos().field_b << 4), var5.field_z + var4);
         GL11.glTexCoord2f(0.0F, (float)var1.getMaxPos().field_b / 0.07F);
         GL11.glVertex3f((float)(var1.getMinPos().field_a << 4), (float)(var1.getMaxPos().field_b << 4), var5.field_z + var4);
         GL11.glTexCoord2f((float)var1.getMaxPos().field_a / 0.07F, (float)var1.getMaxPos().field_b / 0.07F);
         GL11.glVertex3f((float)(var1.getMaxPos().field_a << 4), (float)(var1.getMaxPos().field_b << 4), var5.field_z + var4);
         GL11.glTexCoord2f((float)var1.getMaxPos().field_a / 0.07F, 0.0F);
         GL11.glVertex3f((float)(var1.getMaxPos().field_a << 4), (float)(var1.getMinPos().field_b << 4), var5.field_z + var4);
         GL11.glEnd();
         GlUtil.c2();
      }

      if(var2 == 2) {
         var10000 = var5 = new Vector3f(0.0F, (float)var3.field_b, 0.0F);
         var10000.field_x -= 8.0F;
         var5.field_y -= 8.0F;
         var5.field_z -= 8.0F;
         this.field_a.set(var1.getWorldTransform());
         GlUtil.d1();
         GlUtil.b3(this.field_a);
         GlUtil.a38(0.0F, 1.0F, 0.0F, 0.3F);
         GL11.glBegin(7);
         GL11.glTexCoord2f(0.0F, 0.0F);
         GL11.glVertex3f((float)(var1.getMinPos().field_a << 4), var5.field_y + var4, (float)(var1.getMinPos().field_c << 4));
         GL11.glTexCoord2f(0.0F, (float)var1.getMaxPos().field_c / 0.07F);
         GL11.glVertex3f((float)(var1.getMinPos().field_a << 4), var5.field_y + var4, (float)(var1.getMaxPos().field_c << 4));
         GL11.glTexCoord2f((float)var1.getMaxPos().field_a / 0.07F, (float)var1.getMaxPos().field_c / 0.07F);
         GL11.glVertex3f((float)(var1.getMaxPos().field_a << 4), var5.field_y + var4, (float)(var1.getMaxPos().field_c << 4));
         GL11.glTexCoord2f((float)var1.getMaxPos().field_a / 0.07F, 0.0F);
         GL11.glVertex3f((float)(var1.getMaxPos().field_a << 4), var5.field_y + var4, (float)(var1.getMinPos().field_c << 4));
         GL11.glEnd();
         GlUtil.c2();
      }

      if(var2 == 4) {
         var10000 = var5 = new Vector3f((float)var3.field_a, 0.0F, 0.0F);
         var10000.field_x -= 8.0F;
         var5.field_y -= 8.0F;
         var5.field_z -= 8.0F;
         this.field_a.set(var1.getWorldTransform());
         GlUtil.d1();
         GlUtil.b3(this.field_a);
         GlUtil.a38(1.0F, 0.0F, 0.0F, 0.3F);
         GL11.glBegin(7);
         GL11.glTexCoord2f(0.0F, 0.0F);
         GL11.glVertex3f(var5.field_x + var4, (float)(var1.getMinPos().field_b << 4), (float)(var1.getMinPos().field_c << 4));
         GL11.glTexCoord2f(0.0F, (float)var1.getMaxPos().field_c / 0.07F);
         GL11.glVertex3f(var5.field_x + var4, (float)(var1.getMinPos().field_b << 4), (float)(var1.getMaxPos().field_c << 4));
         GL11.glTexCoord2f((float)var1.getMaxPos().field_b / 0.07F, (float)var1.getMaxPos().field_c / 0.07F);
         GL11.glVertex3f(var5.field_x + var4, (float)(var1.getMaxPos().field_b << 4), (float)(var1.getMaxPos().field_c << 4));
         GL11.glTexCoord2f((float)var1.getMaxPos().field_b / 0.07F, 0.0F);
         GL11.glVertex3f(var5.field_x + var4, (float)(var1.getMaxPos().field_b << 4), (float)(var1.getMinPos().field_c << 4));
         GL11.glEnd();
         GlUtil.c2();
      }

      GL11.glBindTexture(3553, 0);
      GL11.glEnable(2884);
      GlUtil.a38(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glEnable(2896);
      GL11.glDisable(2903);
      GL11.glDisable(3042);
      GL11.glDepthMask(true);
   }

   private void b3(SegmentController var1, class_800 var2) {
      if(var2 != null) {
         this.a14(var1.getWorldTransform());
         var2.a12();
         class_47 var4 = var2.a2(this.field_d);
         class_1433 var3 = this.field_a;
         if(var4 != null) {
            this.field_a.set((float)(var4.field_a - 8), (float)(var4.field_b - 8), (float)(var4.field_c - 8));
            GlUtil.d1();
            GlUtil.c4(this.field_a.field_x, this.field_a.field_y, this.field_a.field_z);
            float var10001 = var3.a1();
            GlUtil.b5(1.05F + var10001 * 0.05F, 1.05F + var10001 * 0.05F, 1.05F + var10001 * 0.05F);
            this.field_a.i();
            GlUtil.c2();
         }

         d();
      }

   }

   private void c2(SegmentController var1, class_800 var2) {
      try {
         if(var1 instanceof class_802 && ((class_802)var1).a() instanceof DockingBlockManagerInterface) {
            Iterator var3 = ((DockingBlockManagerInterface)((class_802)var1).a()).getDockingBlock().iterator();

            while(var3.hasNext()) {
               ManagerModuleCollection var4 = (ManagerModuleCollection)var3.next();
               class_800 var7 = var2;
               SegmentController var6 = var1;
               ManagerModuleCollection var5 = var4;
               class_331 var13 = this;
               Iterator var14 = var5.getCollectionManagers().iterator();

               while(var14.hasNext()) {
                  DockingBlockCollectionManager var8 = (DockingBlockCollectionManager)var14.next();
                  if(var7 == null || var8.getControllerElement().equals(var7)) {
                     class_47 var9 = new class_47();
                     class_47 var10 = new class_47();
                     var8.getDockingArea(var9, var10);
                     Vector3f var15 = new Vector3f((float)Math.abs(var9.field_a - var10.field_a) / 2.0F, (float)Math.abs(var9.field_b - var10.field_b) / 2.0F, (float)Math.abs(var9.field_c - var10.field_c) / 2.0F);
                     var10 = var8.getControllerElement().a2(new class_47());
                     Vector3f var11 = new Vector3f();
                     switch(Element.orientationBackMapping[var8.getControllerElement().b1()]) {
                     case 0:
                        var11.set((float)var10.field_a + var15.field_x / 2.0F - 8.0F + 0.5F, (float)(var10.field_b - 8), (float)(var10.field_c - 8));
                        break;
                     case 1:
                        var11.set((float)var10.field_a - var15.field_x / 2.0F - 8.0F - 0.5F, (float)(var10.field_b - 8), (float)(var10.field_c - 8));
                        break;
                     case 2:
                        var11.set((float)(var10.field_a - 8), (float)var10.field_b + var15.field_y / 2.0F - 8.0F + 0.5F, (float)(var10.field_c - 8));
                        break;
                     case 3:
                        var11.set((float)(var10.field_a - 8), (float)var10.field_b - var15.field_y / 2.0F - 8.0F - 0.5F, (float)(var10.field_c - 8));
                        break;
                     case 4:
                        var11.set((float)(var10.field_a - 8), (float)(var10.field_b - 8), (float)var10.field_c + var15.field_z / 2.0F - 8.0F + 0.5F);
                        break;
                     case 5:
                        var11.set((float)(var10.field_a - 8), (float)(var10.field_b - 8), (float)var10.field_c - var15.field_z / 2.0F - 8.0F - 0.5F);
                     }

                     var13.field_a.set(var6.getWorldTransform());
                     var13.field_a.basis.transform(var11);
                     var13.field_a.origin.add(var11);
                     GlUtil.d1();
                     GlUtil.b3(var13.field_a);
                     GL11.glScalef(1.01F, 1.01F, 1.01F);
                     GL11.glDisable(2896);
                     GL11.glEnable(3042);
                     GL11.glBlendFunc(770, 771);
                     GL11.glEnable(2903);
                     if(var8.hasCollision()) {
                        GlUtil.a41(class_1379.field_u, "selectionColor", 1.0F, 0.0F, 0.0F, 1.0F);
                     } else {
                        GlUtil.a41(class_1379.field_u, "selectionColor", 0.0F, 1.0F, 0.0F, 1.0F);
                     }

                     GlUtil.b5(var15.field_x, var15.field_y, var15.field_z);
                     var13.field_a.i();
                     GlUtil.a38(1.0F, 1.0F, 1.0F, 1.0F);
                     GL11.glEnable(2896);
                     GL11.glDisable(2903);
                     GL11.glDisable(3042);
                     GlUtil.c2();
                  }
               }
            }
         }

      } catch (Exception var12) {
         var12.printStackTrace();
         System.err.println("CATCHED THIS EXCEPTION (just a warning)");
      }
   }

   private void b4(Transform var1) {
      GlUtil.d1();
      Mesh var2 = (Mesh)class_967.a2().a4("Arrow").a156().get(0);
      var1 = new Transform(var1);
      SegmentController.setContraintFrameOrientation((byte)this.field_a.a14().a18().a79().a60().a28(), var1, GlUtil.d(new Vector3f(), var1), GlUtil.f(new Vector3f(), var1), GlUtil.c(new Vector3f(), var1));
      Vector3f var3;
      (var3 = new Vector3f(0.0F, 0.0F, 0.1F)).scale(this.field_a.a1() / 5.0F);
      var3.field_z -= 0.3F;
      var1.basis.transform(var3);
      var1.origin.add(var3);
      GlUtil.b3(var1);
      GlUtil.b5(0.13F, 0.13F, 0.13F);
      GL11.glEnable(3042);
      GL11.glDisable(2884);
      GL11.glEnable(2896);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2903);
      GlUtil.a38(1.0F, 1.0F, 1.0F, this.field_a.a1() - 0.5F);
      var2.b();
      GlUtil.c2();
      GL11.glDisable(2903);
      GL11.glDisable(3042);
      GlUtil.a38(1.0F, 1.0F, 1.0F, 1.0F);
   }

   private Transform a31(SegmentController var1) {
      if(this.field_a != null && this.field_a.hasHit() && this.field_a instanceof CubeRayCastResult) {
         CubeRayCastResult var2;
         if((var2 = (CubeRayCastResult)this.field_a).getSegment() == null) {
            return null;
         } else {
            this.field_a.set(var1.getWorldTransform());
            Vector3f var3;
            Vector3f var10000 = var3 = new Vector3f((float)var2.getSegment().field_a.field_a, (float)var2.getSegment().field_a.field_b, (float)var2.getSegment().field_a.field_c);
            var10000.field_x += (float)(var2.cubePos.field_a - 8);
            var3.field_y += (float)(var2.cubePos.field_b - 8);
            var3.field_z += (float)(var2.cubePos.field_c - 8);
            Vector3f var8 = new Vector3f(this.field_a.hitPointWorld);
            var1.getWorldTransformInverse().transform(var8);
            this.field_c.b((int)var3.field_x, (int)var3.field_y, (int)var3.field_z);
            this.field_e.b(this.field_c.field_a + 8, this.field_c.field_b + 8, this.field_c.field_c + 8);
            class_459 var6 = this.field_a.a14().a18().a79().a60().a50();
            Vector3f var4 = new Vector3f((float)var6.c4(), (float)var6.b6(), (float)var6.a28());
            if(!var6.field_d) {
               GlUtil.a41(class_1379.field_u, "selectionColor", 0.7F, 0.1F, 0.1F, 1.0F);
               var4.field_x = -var4.field_x;
               var4.field_y = -var4.field_y;
               var4.field_z = -var4.field_z;
            } else {
               GlUtil.a41(class_1379.field_u, "selectionColor", 0.7F, 0.77F, 0.1F, 1.0F);
            }

            if(!class_367.field_U.a6()) {
               var4.set(1.0F, 1.0F, 1.0F);
            }

            Vector3f var5 = new Vector3f();
            switch(Element.getSide(var8, this.field_c)) {
            case 0:
               if(var6.field_d) {
                  ++var3.field_x;
               }

               ++this.field_e.field_a;
               var5.set(var4.field_x, var4.field_y, var4.field_z);
               break;
            case 1:
               if(var6.field_d) {
                  --var3.field_x;
               }

               --this.field_e.field_a;
               var5.set(-var4.field_x, var4.field_y, var4.field_z);
               break;
            case 2:
               if(var6.field_d) {
                  ++var3.field_y;
               }

               ++this.field_e.field_b;
               var5.set(var4.field_x, var4.field_y, var4.field_z);
               break;
            case 3:
               if(var6.field_d) {
                  --var3.field_y;
               }

               --this.field_e.field_b;
               var5.set(var4.field_x, -var4.field_y, var4.field_z);
               break;
            case 4:
               if(var6.field_d) {
                  ++var3.field_z;
               }

               ++this.field_e.field_c;
               var5.set(var4.field_x, var4.field_y, var4.field_z);
               break;
            case 5:
               if(var6.field_d) {
                  --var3.field_z;
               }

               --this.field_e.field_c;
               var5.set(var4.field_x, var4.field_y, -var4.field_z);
               break;
            default:
               System.err.println("[BUILDMODEDRAWER] WARNING: NO SIDE recognized!!!");
            }

            var3.field_x += var5.field_x / 2.0F - 0.5F * Math.signum(var5.field_x);
            var3.field_y += var5.field_y / 2.0F - 0.5F * Math.signum(var5.field_y);
            var3.field_z += var5.field_z / 2.0F - 0.5F * Math.signum(var5.field_z);
            Vector3f var7 = new Vector3f(var3);
            this.field_a.basis.transform(var7);
            this.field_a.origin.add(var7);
            GlUtil.d1();
            GlUtil.b3(this.field_a);
            var5.scale(0.99993F);
            GL11.glScalef(var5.field_x, var5.field_y, var5.field_z);
            GL11.glEnable(3042);
            GL11.glDisable(2896);
            GL11.glBlendFunc(770, 771);
            GlUtil.a38(1.0F, 1.0F, 1.0F, 1.0F);
            this.field_a.i();
            GlUtil.a38(1.0F, 1.0F, 1.0F, 1.0F);
            GL11.glEnable(2896);
            GL11.glDisable(3042);
            GlUtil.c2();
            return new Transform(this.field_a);
         }
      } else {
         return null;
      }
   }

   public final class_453 a32() {
      return this.a34().a36().g()?this.a34().a36():(this.a35().a36().g()?this.a35().a36():null);
   }

   public final class_431 a33() {
      return this.field_a.a14().a18().a79().a60().a52();
   }

   public final class_447 a34() {
      return this.field_a.a14().a18().a79().a60().a53();
   }

   public final class_328 a35() {
      return this.field_a.a14().a18().a79().a60().a51().a45();
   }

   public final void c() {
      this.field_a = (Mesh)class_967.a2().a4("Box").a156().get(0);
      this.field_a = new class_221(this.field_a.a157().a1().field_c);
      this.field_e = false;
   }
}
