import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import org.schema.game.client.view.SegmentDrawer;

public final class class_213 extends Thread {

   private ArrayList field_a;
   public Object field_a;
   public int field_a;
   public long field_a;
   // $FF: synthetic field
   private SegmentDrawer field_a;


   public class_213(SegmentDrawer var1) {
      this.field_a = var1;
      super("SegmentLightingUpdateThreadManager");
      SegmentDrawer.a66(var1, new HashSet(100));
      SegmentDrawer.b9(var1, new HashSet(100));
      this.field_a = new ArrayList(2);

      for(int var2 = 0; var2 < 2; ++var2) {
         class_215 var3;
         (var3 = new class_215(var1, this)).start();
         this.field_a.add(var3);
      }

   }

   public final void a(class_215 var1, class_661 var2, boolean var3) {
      if(var3) {
         synchronized(SegmentDrawer.b10(this.field_a)) {
            SegmentDrawer.b10(this.field_a).remove(var2);
         }
      }

      ArrayList var6 = this.field_a;
      synchronized(this.field_a) {
         this.field_a.add(var1);
         this.field_a.notify();
      }
   }

   public final void a1(class_661 var1) {
      if(var1.g()) {
         var1.e(false);
      } else {
         if(!var1.field_b) {
            var1.field_b = true;
            SegmentDrawer.c4(this.field_a).add(var1);
         }

      }
   }

   public final void a2() {
      if(!SegmentDrawer.c4(this.field_a).isEmpty()) {
         synchronized(SegmentDrawer.d2(this.field_a)) {
            SegmentDrawer.d2(this.field_a).addAll(SegmentDrawer.c4(this.field_a));
            SegmentDrawer.d2(this.field_a).notify();
         }

         SegmentDrawer.c4(this.field_a).clear();
      }

   }

   public final void run() {
      class_215 var1;
      try {
         while(class_967.a1() == null) {
            ;
         }

         while(!class_927.a1()) {
            var1 = null;
            ArrayList var2 = this.field_a;
            synchronized(this.field_a) {
               while(this.field_a.isEmpty()) {
                  this.field_a.wait();
               }

               var1 = (class_215)this.field_a.remove(0);
            }

            synchronized(SegmentDrawer.d2(this.field_a)) {
               while(SegmentDrawer.d2(this.field_a).isEmpty()) {
                  SegmentDrawer.d2(this.field_a).wait();
               }

               class_357 var10000 = new class_357();
               SegmentDrawer var10002 = this.field_a;
               class_357 var3 = var10000;
               class_357.a1(var10000).set(class_967.a1().a83());
               class_661 var4 = null;
               Iterator var5 = SegmentDrawer.d2(this.field_a).iterator();

               while(var5.hasNext()) {
                  class_661 var6 = (class_661)var5.next();
                  if(var4 == null || var3.a(var4, var6) > 0) {
                     var4 = var6;
                  }
               }

               class_661 var13 = var4;
               SegmentDrawer.d2(this.field_a).remove(var4);
               var4.field_b = false;
               synchronized(SegmentDrawer.b10(this.field_a)) {
                  synchronized(SegmentDrawer.a65(this.field_a)) {
                     if(var13.c() || SegmentDrawer.b10(this.field_a).contains(var13)) {
                        this.a(var1, var13, false);
                        continue;
                     }

                     SegmentDrawer.b10(this.field_a).add(var13);
                  }
               }

               Object var14 = var4.field_a;
               synchronized(var4.field_a) {
                  var13.d2(true);
                  var13.field_c = System.currentTimeMillis();
                  var13.e(false);
               }

               var1.a(var4);
            }
         }

      } catch (InterruptedException var12) {
         var1 = null;
         var12.printStackTrace();
      }
   }
}
