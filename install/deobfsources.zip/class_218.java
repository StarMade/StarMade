import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.lwjgl.opengl.GL11;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.graphicsengine.forms.Mesh;
import org.schema.schine.graphicsengine.shader.ErrorDialogException;

public final class class_218 implements class_923 {

   static Mesh field_a;
   private static class_1385 field_a;
   private boolean field_a = true;
   public final ArrayList field_a = new ArrayList();
   public final ArrayList field_b = new ArrayList();
   public final Map field_a = new HashMap();
   private final Map field_b = new HashMap();


   public final void a() {}

   public final void d() {
      Iterator var1 = this.field_b.values().iterator();

      while(var1.hasNext()) {
         class_356 var2 = (class_356)var1.next();

         try {
            var2.a3();
         } catch (ErrorDialogException var4) {
            var4.printStackTrace();
         }
      }

      this.field_b.clear();
      var1 = this.field_a.values().iterator();

      while(var1.hasNext()) {
         class_295 var5 = (class_295)var1.next();

         try {
            var5.a();
         } catch (ErrorDialogException var3) {
            var3.printStackTrace();
         }
      }

      this.field_a.clear();
   }

   public final void b() {
      if(this.field_a) {
         this.c();
      }

      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable('\u806f');
      class_1376 var1 = class_1379.field_s;
      class_1379.field_s.c();
      GL11.glBindTexture('\u806f', field_a.a1());
      GlUtil.a35(var1, "noiseTex", 0);
      ((Mesh)field_a.a156().get(0)).g();
      Iterator var2 = this.field_a.values().iterator();

      while(var2.hasNext()) {
         ((class_295)var2.next()).b();
      }

      GlUtil.a35(var1, "noiseTex", 0);
      var2 = this.field_b.values().iterator();

      while(var2.hasNext()) {
         ((class_356)var2.next()).b();
      }

      ((Mesh)field_a.a156().get(0)).l();
      GL11.glDisable('\u806f');
      GL11.glDisable(3042);
      class_1376.e();
   }

   public final void c() {
      if(field_a == null) {
         field_a = class_967.a2().a4("ExaustPlum");
      }

      if(field_a == null) {
         field_a = class_333.field_a;
      }

      this.field_a = false;
   }

   public final void a1(class_935 var1) {
      while(!this.field_a.isEmpty()) {
         class_295 var2 = (class_295)this.field_a.remove(0);
         this.field_a.put(var2.a24(), var2);
      }

      while(!this.field_b.isEmpty()) {
         class_356 var3 = (class_356)this.field_b.remove(0);
         this.field_b.put(var3.a10(), var3);
      }

      Iterator var4 = this.field_a.values().iterator();

      while(var4.hasNext()) {
         ((class_295)var4.next()).a1(var1);
      }

      var4 = this.field_b.values().iterator();

      while(var4.hasNext()) {
         ((class_356)var4.next()).a5(var1);
      }

   }
}
