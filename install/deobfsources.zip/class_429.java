
public final class class_429 extends class_11 {

   private final class_91 field_a;
   private final class_785 field_a;


   public class_429(class_371 var1, class_785 var2) {
      super(var1);
      this.field_a = new class_91(var1, this, var2);
      this.field_a.c();
      this.field_a = var2;
   }

   public final boolean a1() {
      return false;
   }

   public final void handleKeyEvent() {}

   public final class_964 a3() {
      return this.field_a;
   }

   public final void a2() {
      super.field_a.a14().field_a.field_a.field_a.a13(500);
      super.field_a.a14().field_a.field_a.field_a.e2(false);
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.a()) {
         if(var1.b19() instanceof Integer) {
            int var3 = ((Integer)var1.b19()).intValue();
            super.field_a.a53().a180(super.field_a.getPlayerName(), this.field_a.field_a, var3 + 1);
            this.d();
            return;
         }

         if(var1.b19().equals("CANCEL") || var1.b19().equals("X")) {
            this.d();
         }
      }

   }
}
