import org.schema.game.common.controller.CannotBeControlledException;

final class class_449 implements class_479 {

   // $FF: synthetic field
   private class_453 field_a;


   class_449(class_453 var1) {
      this.field_a = var1;
      super();
   }

   public final void a(class_47 var1, class_47 var2, short var3) {
      var3 = this.field_a.a6().a14().a18().a79().a60().a54();
      boolean var4 = false;
      if(class_453.a74(this.field_a) == null) {
         var4 = true;
         class_453.a75(this.field_a, new class_709());
      }

      if(var1 != null && var4) {
         class_709 var7;
         int var9;
         class_709 var10000;
         if(var1.field_a - var2.field_a != 0) {
            var10000 = class_453.a74(this.field_a);
            var9 = var1.field_a;
            var7 = var10000;
            var10000.field_a[0] = var9;
            var7.field_a[0] = true;
         } else if(var1.field_b - var2.field_b != 0) {
            var10000 = class_453.a74(this.field_a);
            var9 = var1.field_b;
            var7 = var10000;
            var10000.field_a[1] = var9;
            var7.field_a[1] = true;
         } else if(var1.field_c - var2.field_c != 0) {
            var10000 = class_453.a74(this.field_a);
            var9 = var1.field_c;
            var7 = var10000;
            var10000.field_a[2] = var9;
            var7.field_a[2] = true;
         }
      }

      if(var3 == 8) {
         class_800 var8;
         if((var8 = class_453.a71(this.field_a).a1().getSegmentBuffer().a9(class_453.a71(this.field_a).a(), false)) != null) {
            try {
               class_453.a71(this.field_a).a1().setCurrentBlockController(var8, var1);
               return;
            } catch (CannotBeControlledException var5) {
               this.field_a.a81(var5);
            }
         }

      } else {
         if(class_453.a73(this.field_a) != null && var1 != null) {
            class_453.a73(this.field_a).a12();
            if(class_453.a73(this.field_a).a9() != 0) {
               try {
                  class_453.a71(this.field_a).a1().setCurrentBlockController(class_453.a73(this.field_a), var1);
                  return;
               } catch (CannotBeControlledException var6) {
                  this.field_a.a81(var6);
               }
            }
         }

      }
   }
}
