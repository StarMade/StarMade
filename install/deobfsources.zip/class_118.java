
final class class_118 extends class_12 {

   // $FF: synthetic field
   private class_762 field_a;
   // $FF: synthetic field
   private int field_a;
   // $FF: synthetic field
   private class_112 field_a;


   class_118(class_112 var1, class_371 var2, Object var3, Object var4, class_762 var5, int var6) {
      this.field_a = var1;
      this.field_a = var5;
      this.field_a = var6;
      super(var2, var3, var4);
   }

   public final boolean a1() {
      return false;
   }

   public final void b() {
      if(!this.field_a.d7(this.field_a.field_a)) {
         super.field_a.a4().b1("You cannot change role:\npermission denied!");
      } else if(this.field_a.field_a < this.field_a.field_a.field_a) {
         super.field_a.a4().b1("You cannot change\nroles of higher ranked\nplayers");
      } else {
         this.field_a.field_a.b31(super.field_a.a20().getName(), this.field_a.field_a.field_a, (byte)this.field_a, super.field_a.a12());
      }

      this.d();
   }

   public final void a2() {}
}
