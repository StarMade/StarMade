import java.io.InputStream;
import java.nio.ByteBuffer;

public final class class_32 extends InputStream {

   private ByteBuffer field_a;


   public class_32(ByteBuffer var1) {
      this.field_a = var1;
   }

   public final synchronized int read() {
      return !this.field_a.hasRemaining()?-1:this.field_a.get() & 255;
   }

   public final synchronized int read(byte[] var1, int var2, int var3) {
      if(!this.field_a.hasRemaining()) {
         return -1;
      } else {
         var3 = Math.min(var3, this.field_a.remaining());
         this.field_a.get(var1, var2, var3);
         return var3;
      }
   }
}
