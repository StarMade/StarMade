import com.bulletphysics.linearmath.Transform;
import it.unimi.dsi.fastutil.objects.ObjectHeapPriorityQueue;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import java.util.Iterator;
import java.util.List;
import javax.vecmath.Matrix3f;
import javax.vecmath.Vector3f;
import javax.vecmath.Vector4f;
import org.lwjgl.opengl.GL11;
import org.schema.common.FastMath;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.data.element.BeamHandler;
import org.schema.game.common.data.element.BeamHandler$BeamState;
import org.schema.schine.graphicsengine.core.GlUtil;

public class class_229 implements class_923 {

   private List field_a;
   private static final Vector4f field_a = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);
   private Vector4f field_b;
   private static final Vector4f field_c = new Vector4f(0.0F, 0.0F, 1.0F, 1.0F);
   private static final Vector4f field_d = new Vector4f(0.0F, 1.0F, 0.0F, 1.0F);
   private static final Vector4f field_e = new Vector4f(0.7F, 0.0F, 0.0F, 1.0F);
   private static final Vector4f field_f = new Vector4f(1.0F, 1.0F, 0.0F, 1.0F);
   private static final Vector4f field_g = new Vector4f(0.7F, 0.7F, 0.7F, 1.0F);
   private static final Vector4f field_h = new Vector4f(1.0F, 0.3F, 1.0F, 1.0F);
   private static final Vector4f field_i = new Vector4f();
   private static final Vector4f field_j = new Vector4f();
   private static Vector3f field_a = new Vector3f();
   private static Vector3f field_b = new Vector3f();
   private static Vector3f field_c = new Vector3f();
   private ObjectOpenHashSet field_a = new ObjectOpenHashSet();
   private final class_1433 field_a = new class_1433();
   private static final Vector3f field_d = new Vector3f(0.0F, 0.0F, 1.0F);
   private static final Vector3f field_e = new Vector3f(0.0F, 0.0F, 1.0F);
   private final Transform field_a = new Transform();
   private final class_47 field_a = new class_47();
   private static final Vector3f field_f = new Vector3f();
   private static final Vector3f field_g = new Vector3f();
   private static final Vector3f field_h = new Vector3f();
   private boolean field_a;
   private final class_233 field_a;
   private static Vector3f field_i = new Vector3f();
   private static float field_a;
   private static Vector3f field_j;
   // $FF: synthetic field
   private static boolean field_b = !dm.class.desiredAssertionStatus();


   public class_229(class_233 var1, List var2, class_231 var3) {
      this.field_a = var1;
      this.a11(var2, var3);
   }

   public final void a() {}

   public final void d() {
      Iterator var1 = this.field_a.iterator();

      while(var1.hasNext()) {
         ((class_717)var1.next()).getHandler().setDrawer((class_229)null);
      }

      this.field_a.clear();
   }

   public final void b() {
      if(this.field_a == null) {
         try {
            throw new NullPointerException("[CLIENT][ERROR] ########## beam handlers null of beam drawer " + this);
         } catch (NullPointerException var3) {
            var3.printStackTrace();
         }
      } else {
         if(this.field_a) {
            Iterator var1 = this.field_a.iterator();

            while(var1.hasNext()) {
               BeamHandler var2 = (BeamHandler)var1.next();
               this.a8(var2);
            }
         }

      }
   }

   private void a8(BeamHandler var1) {
      for(Iterator var3 = var1.getBeamStates().values().iterator(); var3.hasNext(); ++class_233.field_a) {
         BeamHandler$BeamState var2 = (BeamHandler$BeamState)var3.next();
         if(!field_b && var2 == null) {
            throw new AssertionError();
         }

         var2.color.set(this.field_b);
         a10(var2, this.field_a);
      }

   }

   public final void a9(ObjectHeapPriorityQueue var1) {
      if(this.field_a) {
         Iterator var2 = this.field_a.iterator();

         while(var2.hasNext()) {
            Iterator var3 = ((BeamHandler)var2.next()).getBeamStates().values().iterator();

            while(var3.hasNext()) {
               BeamHandler$BeamState var4;
               (var4 = (BeamHandler$BeamState)var3.next()).color.set(this.field_b);
               field_j.sub(class_967.a1().a83(), var4.from);
               var4.camDistStart = field_j.lengthSquared();
               var1.enqueue(var4);
            }
         }
      }

   }

   public static void a10(BeamHandler$BeamState var0, Transform var1) {
      field_a.set(var0.from);
      if(var0.hitPoint != null) {
         field_b.set(var0.hitPoint);
      } else {
         field_b.set(var0.field_to);
      }

      if(GlUtil.a19(field_a, field_b, class_967.field_a.a())) {
         field_c.sub(field_a, field_b);
         float var2 = field_c.length();
         field_d.set(0.0F, 0.0F, 1.0F);
         var1.origin.set(field_a);
         field_i.cross(field_c, field_d);
         field_i.normalize();
         GlUtil.a30(field_c, var1);
         GlUtil.d2(field_i, var1);
         field_d.cross(field_c, field_i);
         field_d.normalize();
         GlUtil.c3(field_d, var1);
         Vector3f var10000 = field_a;
         Vector3f var10001 = field_b;
         Vector3f var10002 = class_967.a1().a83();
         Matrix3f var3 = var1.basis;
         Vector3f var6 = var10002;
         Vector3f var5 = var10001;
         Vector3f var4 = var10000;
         field_f.sub(var6, var4);
         field_g.sub(var5, var4);
         field_h.cross(field_f, field_g);
         field_h.normalize();
         field_e.set(0.0F, 1.0F, 0.0F);
         var3.transform(field_e);
         float var8 = (float)FastMath.a2((double)field_e.dot(field_h));
         field_e.set(1.0F, 0.0F, 0.0F);
         var3.transform(field_e);
         float var7 = (float)FastMath.a2((double)field_e.dot(field_h));
         if(1.5707964F > var7) {
            var8 = 6.2831855F - var8;
         }

         Vector4f var9 = var0.color;
         if(!field_i.equals(field_a)) {
            field_i.set(field_a);
            GlUtil.a42(class_233.field_a, "thrustColor0", field_i);
         }

         if(!field_j.equals(var9)) {
            field_j.set(var9);
            GlUtil.a42(class_233.field_a, "thrustColor1", field_j);
         }

         float var10;
         if(Float.compare(var10 = var2 / 20.0F, field_a) != 0) {
            GlUtil.a33(class_233.field_a, "texCoordMult", var10);
            field_a = var10;
         }

         GlUtil.d1();
         GlUtil.b3(var1);
         GlUtil.a29(57.295776F * (var8 + 1.5707964F));
         class_233.field_a.i();
         GlUtil.c2();
      }
   }

   public final void e() {
      Iterator var1 = this.field_a.iterator();

      while(var1.hasNext()) {
         BeamHandler var2 = (BeamHandler)var1.next();
         BeamHandler var3 = var2;
         class_229 var8 = this;
         if(var3.getSegmentController().isClientOwnObject()) {
            GlUtil.a41(class_1379.field_u, "selectionColor", 0.7F, 0.77F, 0.1F, 1.0F);
            Iterator var9 = var3.getBeamStates().values().iterator();

            while(var9.hasNext()) {
               BeamHandler$BeamState var4 = (BeamHandler$BeamState)var9.next();
               if(!field_b && var4 == null) {
                  throw new AssertionError();
               }

               if(var4.segmentHit != null) {
                  var4.segmentHit.a12();
                  if(var4.segmentHit.a9() != 0) {
                     class_47 var10001 = var4.segmentHit.a2(var8.field_a);
                     SegmentController var10002 = var4.segmentHit.a7().a15();
                     class_1433 var7 = var8.field_a;
                     SegmentController var6 = var10002;
                     class_47 var5 = var10001;
                     var8.field_a.set(var6.getWorldTransformClient());
                     Vector3f var11 = new Vector3f((float)(var5.field_a - 8), (float)(var5.field_b - 8), (float)(var5.field_c - 8));
                     var8.field_a.basis.transform(var11);
                     var8.field_a.origin.add(var11);
                     GlUtil.d1();
                     GlUtil.b3(var8.field_a);
                     float var10 = var7.a1();
                     GL11.glScalef(1.05F + var10 * 0.05F, 1.05F + var10 * 0.05F, 1.05F + var10 * 0.05F);
                     class_233.field_b.i();
                     GlUtil.c2();
                  }
               }
            }
         }
      }

   }

   public final void c() {}

   public final void f() {
      if(this.field_a != null) {
         this.d();
      }

      this.field_a = null;
   }

   public final void a11(List var1, class_231 var2) {
      switch(class_235.field_a[var2.ordinal()]) {
      case 1:
         this.field_b = field_c;
         break;
      case 2:
         this.field_b = field_d;
         break;
      case 3:
         this.field_b = field_e;
         break;
      case 4:
         this.field_b = field_h;
         break;
      case 5:
         this.field_b = field_f;
         break;
      case 6:
         this.field_b = field_g;
         break;
      default:
         this.field_b = field_d;
      }

      this.field_a = var1;
      if(this.field_a == null) {
         this.d();
      } else {
         class_229 var4 = this;
         this.d();
         Iterator var3 = this.field_a.iterator();

         while(var3.hasNext()) {
            ((class_717)var3.next()).getHandler().setDrawer(var4);
         }

      }
   }

   public final void a1(class_935 var1) {
      this.field_a.a(var1);
   }

   public final void a12(BeamHandler var1, boolean var2) {
      if(var2) {
         this.field_a.add(var1);
      } else {
         this.field_a.remove(var1);
      }

      if(this.field_a != !this.field_a.isEmpty()) {
         this.field_a.a8(this, !this.field_a.isEmpty());
      }

      this.field_a = !this.field_a.isEmpty();
   }

   static {
      new Vector3f(-8.0F, -8.0F, -8.0F);
      field_j = new Vector3f();
      new Vector3f();
   }
}
