import org.schema.game.common.data.element.ElementKeyMap;

public final class class_440 extends class_454 {

   private static final long serialVersionUID = 438885771406304916L;
   private short field_a;


   public class_440(class_983 var1, class_371 var2, short var3) {
      super(var1, "", var2);
      this.field_a = var3;
      this.field_b = true;
   }

   protected final boolean a() {
      if(super.field_a.a4().a5().field_a != null) {
         Integer var1;
         return (var1 = Integer.valueOf(super.field_a.a4().a5().field_a.getElementClassCountMap().a1(this.field_a))) != null && var1.intValue() > 0;
      } else {
         this.a8().a8().a2().a1(new class_389());
         return false;
      }
   }

   public final boolean d() {
      int var1;
      if((var1 = super.field_a.a20().getInventory((class_47)null).a42(this.field_a)) < 0) {
         super.field_a = "You don\'t have any \n" + ElementKeyMap.getInfo(this.field_a).getName() + "\nModules.\nPlease buy one in\nthe shop (Press B)\n";
      } else if(var1 > 10) {
         super.field_a = "Please drag \n" + ElementKeyMap.getInfo(this.field_a).getName() + "\nto the bottom bar from\nthe inventory (Press I)";
      } else {
         super.field_a = "Please select \n" + ElementKeyMap.getInfo(this.field_a).getName() + " (press " + (var1 + 1) % 10 + ")\nfrom the bottom bar and place\none on the ship";
      }

      return super.d();
   }
}
