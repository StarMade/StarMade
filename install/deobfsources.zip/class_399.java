
public final class class_399 extends class_300 {

   private static final long serialVersionUID = 6050895723297381559L;


   public class_399(class_983 var1, class_371 var2, String var3) {
      super(var1, var2, var3, 3000);
   }
}
