import javax.vecmath.Vector4f;
import org.schema.schine.network.client.ClientState;

public final class class_286 extends class_964 implements class_1410 {

   private class_371 field_a;
   private class_785 field_a;
   private boolean field_a;


   public class_286(ClientState var1, class_785 var2, boolean var3) {
      super(var1);
      this.field_a = var3;
      this.field_a = (class_371)this.a24();
      this.field_a = var2;
   }

   public final void a2() {}

   public final void b() {
      this.k();
   }

   public final void c() {
      class_928 var1;
      (var1 = new class_928(this.field_a, 70, 30, new Vector4f(0.3F, 0.6F, 0.3F, 0.9F), new Vector4f(0.99F, 0.99F, 0.99F, 1.0F), class_28.d(), "BUY", this, this.a14())).field_a = "buy";
      var1.b14(14, 4);
      class_928 var2;
      (var2 = new class_928(this.field_a, 80, 20, "owner", this, this.a14())).field_a = "owner";
      var2.b14(5, 1);
      class_928 var3;
      (var3 = new class_928(this.field_a, 90, 20, "description", this, this.a14())).field_a = "description";
      var3.b14(5, 1);
      class_928 var4;
      (var4 = new class_928(this.field_a, 90, 20, "permissions", this, this.a14())).field_a = "permission";
      var4.b14(5, 1);
      class_928 var5;
      (var5 = new class_928(this.field_a, 45, 20, "rate", this, this.a14())).field_a = "rate";
      var5.b14(5, 1);
      class_928 var6;
      (var6 = new class_928(this.field_a, 65, 20, new Vector4f(0.7F, 0.2F, 0.2F, 0.9F), new Vector4f(0.99F, 0.99F, 0.99F, 1.0F), class_28.o(), "delete", this, this.a14())).field_a = "delete";
      var6.b14(6, 1);
      var2.a83().field_x = var1.a83().field_x + 80.0F;
      var3.a83().field_x = var2.a83().field_x + 90.0F;
      var4.a83().field_x = var3.a83().field_x + 100.0F;
      var5.a83().field_x = var4.a83().field_x + 100.0F;
      var6.a83().field_x = var5.a83().field_x + 70.0F;
      class_940 var7;
      (var7 = new class_940(10, 10, this.field_a)).a83().field_y = 35.0F;
      var7.a137(this.field_a.field_c);
      this.a9(var1);
      this.a9(var4);
      this.a9(var6);
      this.a9(var7);
      this.a9(var3);
      this.a9(var5);
      if(this.field_a) {
         this.a9(var2);
      }

   }

   public final float a3() {
      return 80.0F;
   }

   public final float b1() {
      return 510.0F;
   }

   public final void a1(class_964 var1, class_941 var2) {
      if(var2.a()) {
         String var3;
         if("buy".equals(var1.field_a)) {
            if(!((class_371)this.a24()).d2()) {
               ((class_371)this.a24()).a4().b1("ERROR:\nCannot buy!\nYou are not near a shop!");
            }

            this.a14().e2(true);
            var3 = "Please type in a name for your new Ship!";
            class_292 var5;
            (var5 = new class_292(this, (class_371)this.a24(), "New Ship", var3, this.field_a.field_a + "_" + System.currentTimeMillis())).a10(new class_290());
            var5.c1();
            return;
         }

         if("description".equals(var1.field_a)) {
            this.a14().e2(true);
            (new class_284(this, (class_371)this.a24(), "Edit entry Description", "Enter a description for the entry", new String(this.field_a.field_c))).c1();
            return;
         }

         if("permission".equals(var1.field_a)) {
            System.err.println("EDIT PERMISSION");
            this.a14().e2(true);
            (new class_428(this.field_a, this.field_a, this.field_a)).c1();
            return;
         }

         if("delete".equals(var1.field_a)) {
            if((!this.field_a || !((Boolean)((class_371)this.a24()).a20().a117().isAdminClient.get()).booleanValue()) && !((class_371)this.a24()).a20().getName().equals(this.field_a.field_b)) {
               ((class_371)this.a24()).a4().b1("ERROR:\nCannot delete!\nYou don not own this!");
               return;
            }

            this.a14().e2(true);
            (new class_282(this, (class_371)this.a24(), "Confirm", "Do you really want to delete this entry\n(a backup will be created on the server)")).c1();
            return;
         }

         if("owner".equals(var1.field_a)) {
            this.a14().e2(true);
            var3 = "Change the owner of \"" + this.field_a.field_a + "\"";
            class_296 var4;
            (var4 = new class_296(this, (class_371)this.a24(), "Change Owner", var3, this.field_a.field_b)).a10(new class_294());
            var4.c1();
            return;
         }

         if("rate".equals(var1.field_a)) {
            this.a14().e2(true);
            class_429 var10000 = new class_429;
            boolean var10004 = this.field_a;
            var10000.<init>(this.field_a, this.field_a);
            var10000.c1();
         }
      }

   }

   public final class_427 a14() {
      return ((class_371)this.a24()).a14().field_a.field_a.field_a;
   }

   public final boolean a4() {
      return false;
   }

   // $FF: synthetic method
   static class_785 a112(class_286 var0) {
      return var0.field_a;
   }

   // $FF: synthetic method
   static boolean a113(class_286 var0) {
      return var0.field_a;
   }
}
