import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.Arrays;
import javax.vecmath.Vector3f;
import org.lwjgl.BufferUtils;
import org.schema.common.FastMath;
import org.schema.game.client.view.cubes.CubeMeshBufferContainer;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.data.element.Element;
import org.schema.game.common.data.element.ElementInformation;
import org.schema.game.common.data.element.ElementKeyMap;
import org.schema.game.common.data.world.Segment;
import org.schema.game.common.data.world.SegmentData;

public class class_386 {

   private SegmentData field_a;
   private class_382 field_a;
   private class_392 field_a;
   private CubeMeshBufferContainer field_a;
   private class_34 field_a;
   private class_34 field_b;
   private ShortBuffer field_a;
   private FloatBuffer field_a;
   private FloatBuffer field_b;
   private FloatBuffer field_c;
   private ByteBuffer field_a;
   private class_47 field_a;
   private class_47 field_b;
   private boolean field_a;
   private Segment[] field_a;
   private float field_a;
   private final class_47 field_c;
   private int[] field_a;
   private final Segment field_a;
   // $FF: synthetic field
   private static boolean field_b = !dL.class.desiredAssertionStatus();


   public class_386() {
      new class_47(-16, 32, 32);
      this.field_a = new class_34();
      this.field_b = new class_34();
      this.field_a = BufferUtils.createShortBuffer(5832);
      this.field_a = BufferUtils.createFloatBuffer('\u88b0');
      this.field_b = BufferUtils.createFloatBuffer('\u88b0');
      this.field_c = BufferUtils.createFloatBuffer(104976);
      this.field_a = BufferUtils.createByteBuffer('\u88b0');
      new class_47();
      new class_34();
      this.field_a = new class_47();
      this.field_b = new class_47();
      this.field_a = false;
      this.field_a = new Segment[729];
      this.field_c = new class_47();
      this.field_a = new int[]{a6(0, -1, -1), -a6(0, -1, -1), a6(-1, 0, -1), -a6(-1, 0, -1), a6(-1, -1, 0), -a6(-1, -1, 0)};
      this.field_a = new class_675((SegmentController)null);
      this.field_a = new class_392();
      if(this.field_a == null) {
         this.field_a = new class_382();
         this.field_a.a();
      }

      this.field_a = 0.1F;
   }

   private void a() {
      boolean var1 = false;

      byte var2;
      byte var3;
      byte var4;
      for(var2 = -1; var2 < 17; ++var2) {
         for(var3 = -1; var3 < 17; ++var3) {
            for(var4 = -1; var4 < 17; ++var4) {
               this.field_b.b(var4, var3, var2);
               int var5 = a6(this.field_b.field_a, this.field_b.field_b, this.field_b.field_c);
               short var6;
               int var7;
               int var10;
               if((var6 = this.field_a.get(var5)) != 0 && SegmentData.valid(this.field_b.field_a, this.field_b.field_b, this.field_b.field_c) && this.field_a.containsFast(var7 = SegmentData.getInfoIndex(this.field_b))) {
                  ElementInformation var8 = ElementKeyMap.getInfo((short)Math.abs(var6));
                  class_34 var10002 = this.field_b;
                  var10 = var5;
                  class_386 var9 = this;
                  byte var12 = 63;
                  boolean var13 = this.field_a.get(var5) < 0;
                  if(var8.getBlockStyle() == 3) {
                     var12 = 51;
                  } else {
                     for(int var14 = 0; var14 < 6; ++var14) {
                        boolean var10000;
                        label262: {
                           short var15;
                           ElementInformation var16;
                           if((var15 = var9.field_a.get(var10 + var9.field_a[var14])) == 0 || (var16 = ElementKeyMap.getInfo(FastMath.a1(var15))).getBlockStyle() <= 0 && (var16.getId() != 122 || var15 >= 0)) {
                              if(var13) {
                                 var10000 = var15 != 0;
                                 break label262;
                              }

                              if(var15 > 0) {
                                 var10000 = true;
                                 break label262;
                              }
                           }

                           var10000 = false;
                        }

                        if(var10000) {
                           var12 = (byte)(var12 - Element.SIDE_FLAG[var14]);
                        }
                     }
                  }

                  if(var8.getBlockStyle() == 1 || var8.getBlockStyle() == 2) {
                     var12 = 63;
                  }

                  this.field_a.a6(var7 / 3, var12);
                  var1 = var1 || var12 > 0;
               }

               if(var6 <= 0) {
                  boolean var21 = var2 >= 16 || var3 >= 16 || var4 >= 16 || var2 < 0 || var3 < 0 || var4 < 0;
                  int var23 = a6(this.field_b.field_a, this.field_b.field_b, this.field_b.field_c);

                  for(var5 = 0; var5 < 6; ++var5) {
                     class_34 var10003 = Element.DIRECTIONSb[var5];
                     int var29 = Element.OPPOSITE_SIDE[var5];
                     class_34 var20 = var10003;
                     class_34 var27 = this.field_b;
                     byte var30 = (byte)(var27.field_a + var20.field_a);
                     byte var33 = (byte)(var27.field_b + var20.field_b);
                     byte var17 = (byte)(var27.field_c + var20.field_c);
                     if(!var21 || var17 < 17 && var33 < 17 && var30 < 17 && var17 >= -1 && var33 >= -1 && var30 >= -1) {
                        int var18 = var23 + this.field_a[var5];
                        if(this.field_a.get(var18) != 0) {
                           int var35 = var18 * 6;
                           int var32;
                           int var39 = var32 = var23 * 6;
                           FloatBuffer var31 = this.field_b;
                           int var11 = var39;
                           float var36 = var31.get(var11);
                           var31 = this.field_b;
                           float var19 = var31.get(var32 + 1);
                           var31 = this.field_b;
                           float var28 = var31.get(var32 + 2);
                           var31 = this.field_a;
                           float var37 = var31.get(var32 + var5);
                           float var34 = var37 + var36;
                           float var24 = var37 + var19;
                           float var26 = var37 + var28;
                           var10 = var35 * 3 + var29 * 3;
                           this.field_c.put(var10, var34);
                           this.field_c.put(var10 + 1, var24);
                           this.field_c.put(var10 + 2, var26);
                        }
                     }
                  }
               }
            }
         }
      }

      if(!var1) {
         ((class_661)this.field_a.getSegment()).c2(false);
      } else {
         ((class_661)this.field_a.getSegment()).c2(true);

         for(var2 = 0; var2 < 16; ++var2) {
            for(var3 = 0; var3 < 16; ++var3) {
               for(var4 = 0; var4 < 16; ++var4) {
                  this.field_a.b(var4, var3, var2);
                  SegmentData var38 = this.field_a;
                  class_47 var25 = this.field_a;
                  byte var22;
                  if(this.field_a.get(a6(var25.field_a, var25.field_b, var25.field_c)) != 0 && (var22 = this.field_a.a3((byte)var25.field_a, (byte)var25.field_b, (byte)var25.field_c)) > 0) {
                     if(var22 >= 32) {
                        this.field_a.a3(var25, 5, this);
                        var22 = (byte)(var22 - 32);
                     }

                     if(var22 >= 16) {
                        this.field_a.a3(var25, 4, this);
                        var22 = (byte)(var22 - 16);
                     }

                     if(var22 >= 8) {
                        this.field_a.a2(var25, this);
                        var22 = (byte)(var22 - 8);
                     }

                     if(var22 >= 4) {
                        this.field_a.d(var25, this);
                        var22 = (byte)(var22 - 4);
                     }

                     if(var22 >= 2) {
                        this.field_a.b(var25, this);
                        var22 = (byte)(var22 - 2);
                     }

                     if(var22 > 0) {
                        this.field_a.c(var25, this);
                     }
                  }
               }
            }
         }

      }
   }

   public final void a1(SegmentData var1, CubeMeshBufferContainer var2) {
      this.field_a = var1;
      this.field_a = var2;
      class_386 var21 = this;
      this.field_a = false;

      boolean var10000;
      for(byte var3 = -1; var3 < 17; ++var3) {
         for(byte var4 = -1; var4 < 17; ++var4) {
            for(byte var5 = -1; var5 < 17; ++var5) {
               class_386 var6 = var21;
               var21.field_b.b(var5, var4, var3);
               Segment var10;
               SegmentData var10001;
               if(SegmentData.allNeighborsInside(var5, var4, var3)) {
                  var10 = var21.field_a.getSegment();
               } else {
                  var10001 = var21.field_a;
                  var10 = var21.a5(var21.field_b, var21.field_a.getSegment(), var21.field_a.getSegment(), var21.field_b);
               }

               int var11 = a6(var5, var4, var3);
               var21.field_a.put(var11, (short)0);
               if(var10 == null) {
                  if(var21.field_a.getSegmentController().isInboundSegmentPos(var21.field_b)) {
                     var10000 = var21.field_a;
                     var21.field_a = true;
                     continue;
                  }

                  var21.field_a.a25(var21.field_b.field_a, var21.field_b.field_b, var21.field_b.field_c);
                  var10 = var21.field_a;
               }

               boolean var12;
               int var13;
               short var14;
               if(!(var12 = var10.g()) && var10.a16().containsFast(var21.field_b)) {
                  var13 = SegmentData.getInfoIndex(var21.field_b);
                  if((var14 = var10.a16().getType(var13)) == 62) {
                     var21.field_a.field_a.put((short)var13);
                  }

                  if(!ElementKeyMap.getInfo(var14).isBlended() && (var14 != 122 || var10.a16().isActive(var13))) {
                     var21.field_a.put(var11, var14);
                  } else {
                     var21.field_a.put(var11, (short)(-var14));
                  }
               } else {
                  var13 = SegmentData.getInfoIndex(var21.field_b);
               }

               short var25 = var12?0:var10.a16().getType(var13);
               if(var12 || var25 == 0 || ElementKeyMap.getInfo(var25).isBlended() || !ElementKeyMap.getInfo(var25).isPhysical(var10.a16().isActive(var13))) {
                  class_47 var28 = var21.field_b;
                  class_34 var18 = var21.field_b;
                  if(var21.field_a.getSegmentController().hasNeighborElements(var10, var18.field_a, var18.field_b, var18.field_c, var28)) {
                     boolean var33 = false;
                     var11 = a6(var5, var4, var3) * 6;
                     class_388[] var26 = var21.field_a.field_a;
                     var13 = var21.field_a.field_a.length;

                     int var20;
                     float var31;
                     int var32;
                     for(int var15 = 0; var15 < var13; ++var15) {
                        class_388 var16 = var26[var15];
                        boolean var9 = false;
                        int var17 = 0;

                        for(var32 = 0; var17 < var16.field_a.length; ++var32) {
                           byte var7 = var16.field_a[var17];
                           byte var8 = var16.field_a[var17 + 1];
                           byte var19 = var16.field_a[var17 + 2];
                           byte var30 = (byte)(var6.field_b.field_a + var7);
                           var7 = (byte)(var6.field_b.field_b + var8);
                           var8 = (byte)(var6.field_b.field_c + var19);
                           var6.field_a.b(var30, var7, var8);
                           if(!field_b && var6.field_a.getSegment() == null) {
                              throw new AssertionError();
                           }

                           var10001 = var6.field_a;
                           Segment var23;
                           if((var23 = var6.a5(var6.field_a, var10, var6.field_a.getSegment(), var6.field_b)) == null) {
                              if(var6.field_a.getSegmentController().isInboundSegmentPos(var6.field_b)) {
                                 var6.field_a = true;
                              }
                              break;
                           }

                           if(!var23.g()) {
                              int var24 = SegmentData.getInfoIndex(var6.field_a.field_a, var6.field_a.field_b, var6.field_a.field_c);
                              if((var14 = var23.a16().getType(var24)) != 0) {
                                 ElementInformation var29;
                                 if(!(var29 = ElementKeyMap.getInfo(var14)).isBlended() && var29.isPhysical(var23.a16().isActive(var24))) {
                                    var9 = true;
                                    if(var29.isLightSource() && var23.a16().isActive(var24)) {
                                       float var22 = var16.field_b[var32] * 2.3F;
                                       var6.a2(var11, var29.getLightSourceColor().field_x * var22);
                                       var6.a2(var11 + 1, var29.getLightSourceColor().field_y * var22);
                                       var6.a2(var11 + 2, var29.getLightSourceColor().field_z * var22);
                                    }
                                 }
                                 break;
                              }
                           }

                           var17 += 3;
                        }

                        if(!var9) {
                           for(var17 = 0; var17 < 6; ++var17) {
                              var20 = var11 + var17;
                              var31 = var16.field_a[var17];
                              var32 = var20;
                              var6.field_a.put(var32, var6.field_a.get(var32) + var31);
                           }
                        }
                     }

                     for(int var27 = 0; var27 < 6; ++var27) {
                        var20 = var11 + var27;
                        var31 = var6.field_a;
                        var32 = var20;
                        var6.field_a.put(var32, Math.min(1.0F, var6.field_a.get(var32) * var31));
                     }
                  }
               }
            }
         }
      }

      var10000 = var21.field_a;
      var21.a();
      if(this.field_a) {
         ((class_661)var1.getSegment()).field_a = true;
         ((class_661)var1.getSegment()).field_b = System.currentTimeMillis();
      }

   }

   private void a2(int var1, float var2) {
      this.field_b.put(var1, Math.min(1.0F, this.field_b.get(var1) + var2));
   }

   public final CubeMeshBufferContainer a3() {
      return this.field_a;
   }

   public final boolean a4(class_47 var1, int var2, Vector3f var3) {
      int var4;
      if(this.field_a.get(var4 = a6(var1.field_a, var1.field_b, var1.field_c)) != 0) {
         var4 = var4 * 6 * 3 + var2 * 3;
         var3.field_x = this.field_c.get(var4);
         var3.field_y = this.field_c.get(var4 + 1);
         var3.field_z = this.field_c.get(var4 + 2);
         return true;
      } else {
         return false;
      }
   }

   private Segment a5(class_34 var1, Segment var2, Segment var3, class_47 var4) {
      if(((var1.field_a | var1.field_b | var1.field_c) & 240) == 0) {
         return var2;
      } else {
         int var5 = var1.field_a >> 4;
         int var6 = var1.field_b >> 4;
         int var7 = var1.field_c >> 4;
         this.field_c.field_a = var2.field_b.field_a + var5;
         this.field_c.field_b = var2.field_b.field_b + var6;
         this.field_c.field_c = var2.field_b.field_c + var7;
         var4.field_a = var2.field_a.field_a + (var5 << 4);
         var4.field_b = var2.field_a.field_b + (var6 << 4);
         var4.field_c = var2.field_a.field_c + (var7 << 4);
         var1.field_a = (byte)(var1.field_a & 15);
         var1.field_b = (byte)(var1.field_b & 15);
         var1.field_c = (byte)(var1.field_c & 15);
         class_47 var10001 = var4;
         Segment var11 = var3;
         class_47 var9 = this.field_c;
         class_47 var8 = var10001;
         var5 = var9.field_a - var11.field_b.field_a + 4;
         var6 = var9.field_b - var11.field_b.field_b + 4;
         int var10 = (var9.field_c - var11.field_b.field_c + 4) * 81 + var6 * 9 + var5;
         if(this.field_a[var10] == null) {
            if((var2 = this.field_a.getSegmentController().getSegmentBuffer().a5(var8)) == null) {
               return null;
            }

            this.field_a[var10] = var2;
         }

         return this.field_a[var10];
      }
   }

   private static int a6(int var0, int var1, int var2) {
      return (var2 + 1) * 324 + (var1 + 1) * 18 + var0 + 1;
   }

   public final void a7(CubeMeshBufferContainer var1) {
      int var2;
      for(var2 = 0; var2 < '\u88b0'; ++var2) {
         this.field_a.put(var2, 0.0F);
         this.field_b.put(var2, 0.0F);
         this.field_a.put(var2, (byte)0);
      }

      for(var2 = 0; var2 < 104976; ++var2) {
         this.field_c.put(var2, 0.0F);
      }

      Arrays.fill(this.field_a, (Object)null);
      var1.a4();
   }

}
