import org.schema.game.common.data.element.ElementInformation;
import org.schema.game.common.data.element.ElementKeyMap;

final class class_324 implements class_954 {

   // $FF: synthetic field
   private short field_a;
   // $FF: synthetic field
   private class_322 field_a;


   class_324(class_322 var1, short var2) {
      this.field_a = var1;
      this.field_a = var2;
      super();
   }

   public final boolean a(String var1, class_1077 var2) {
      try {
         if(var1.length() > 0) {
            ElementInformation var3 = ElementKeyMap.getInfo(this.field_a);
            int var7;
            if((var7 = Integer.parseInt(var1)) <= 0) {
               this.field_a.a6().a4().b1("ERROR: Invalid quantity");
               return false;
            }

            class_739 var4;
            if((var4 = this.field_a.a6().a5()) == null) {
               this.field_a.a6().a4().b1("ERROR: no shop available");
               return false;
            }

            int var5;
            if((var5 = var4.a90().a42(this.field_a)) >= 0 && var4.a90().a41(var5) >= var7) {
               var5 = var4.a89(var3, var7);
               if(this.field_a.a6().a20().b4() >= var5) {
                  class_967.b("0022_action - purchase with credits");
                  return true;
               }

               var7 = this.field_a.a6().a20().b4() / var4.a89(var3, 1);
               this.field_a.a6().a4().b1("ERROR\nYou can\'t affort that many!\nYou can only affort " + var7);
               this.field_a.a8().a2();
               this.field_a.a8().a9(String.valueOf(var7));
               this.field_a.a8().e();
               this.field_a.a8().g1();
               return false;
            }

            this.field_a.a6().a4().b1("ERROR: shop out of item");
            if(var5 >= 0) {
               this.field_a.a8().a2();
               this.field_a.a8().a9(String.valueOf(var4.a90().a41(var5)));
               this.field_a.a8().e();
               this.field_a.a8().g1();
            }

            return false;
         }
      } catch (NumberFormatException var6) {
         ;
      }

      var2.onFailedTextCheck("Please only enter numbers!");
      return false;
   }
}
