
public final class class_415 extends class_14 {

   private class_15 field_a;


   public class_415(class_371 var1, String var2, class_15 var3) {
      super(var1, 23, var2, "Enter a name for the new faction\n\nWARNING: if you aleady are in a faction,\nyou will leave that faction\nwhen creating a new one", (String)null);
      System.err.println("CURRENT FACTION CODE: " + var1.a20().h1());
      this.field_a = var3;
      this.a10(new class_407());
   }

   public final String[] getCommandPrefixes() {
      return null;
   }

   public final String handleAutoComplete(String var1, class_1077 var2, String var3) {
      return var1;
   }

   public final boolean a1() {
      return super.field_a.b().indexOf(this) != super.field_a.b().size() - 1;
   }

   public final void a2() {
      this.field_a.e2(false);
   }

   public final void onFailedTextCheck(String var1) {
      this.a9(var1);
   }

   public final boolean a7(String var1) {
      super.field_a.a20().a132().a203(class_769.a(), var1, "a faction");
      return true;
   }
}
