import org.schema.game.client.view.SegmentDrawer;
import org.schema.game.common.data.world.Segment;

public final class class_311 implements class_892 {

   // $FF: synthetic field
   private SegmentDrawer field_a;


   public class_311(SegmentDrawer var1) {
      this.field_a = var1;
      super();
   }

   public final boolean handle(Segment var1) {
      if(var1 != null) {
         synchronized(SegmentDrawer.a65(this.field_a)) {
            SegmentDrawer.a65(this.field_a).add((class_661)var1);
         }

         ((class_661)var1).e(true);
      }

      return true;
   }
}
