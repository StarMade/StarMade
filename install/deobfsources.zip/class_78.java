import java.io.DataInputStream;

public interface class_78 {

   Object create(DataInputStream var1);
}
