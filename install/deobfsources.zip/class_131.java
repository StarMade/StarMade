import java.util.ArrayList;
import javax.vecmath.Vector4f;
import org.schema.schine.network.client.ClientState;

final class class_131 extends class_972 {

   private class_1361 field_a;
   private class_625 field_a;


   public class_131(ClientState var1, class_625 var2, int var3) {
      super(var1);
      this.field_a = var2;
      this.field_a = new class_1361(this.a24(), 410.0F, 100.0F, var3 % 2 == 0?new Vector4f(0.1F, 0.1F, 0.1F, 1.0F):new Vector4f(0.2F, 0.2F, 0.2F, 1.0F));
      super.field_a = this.field_a;
      super.field_b = this.field_a;
   }

   public final void c() {
      super.c();
      class_940 var1;
      (var1 = new class_940(200, 80, this.a24())).field_b = new ArrayList();
      class_777 var2 = ((class_371)this.a24()).a45().a146(this.field_a.field_a);
      class_777 var3 = ((class_371)this.a24()).a45().a146(this.field_a.field_b);
      if(var2 != null && var3 != null) {
         if(this.field_a.a7()) {
            var1.field_b.add("WAR DECLARATION");
         } else if(this.field_a.b2()) {
            var1.field_b.add("ALLIANCE PROPOSAL");
         } else if(this.field_a.c()) {
            var1.field_b.add("PEACE OFFER");
         }

         var1.field_b.add("From: [" + var2.a() + "]" + this.field_a.b());
         String[] var4;
         int var5 = (var4 = this.field_a.a().split("\\\\n")).length;

         for(int var6 = 0; var6 < var5; ++var6) {
            String var7 = var4[var6];
            var1.field_b.add(var7);
         }

         class_928 var8 = new class_928(this.a24(), 80, 18, "Accept", new class_129(this));
         class_928 var9 = new class_928(this.a24(), 80, 18, "Decline", new class_135(this));
         var8.a83().field_x = 220.0F;
         var9.a83().field_x = 310.0F;
         this.field_a.a9(var1);
         this.field_a.a9(var8);
         this.field_a.a9(var9);
         System.err.println("[GUI] attached faction offer! " + var2.a() + " -> " + var3.a());
      } else {
         System.err.println("Invalid offer: " + this.field_a.field_a + " / " + this.field_a.field_b);
      }
   }

   // $FF: synthetic method
   static class_625 a36(class_131 var0) {
      return var0.field_a;
   }
}
