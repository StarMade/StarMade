import javax.vecmath.Vector3f;
import javax.vecmath.Vector4f;

final class class_352 implements class_953 {

   Vector3f field_a;
   float field_a;
   int field_a;
   public Vector4f field_a;


   private class_352() {
      this.field_a = new Vector3f();
      this.field_a = 0;
      this.field_a = new Vector4f();
   }

   public final Vector3f a83() {
      return this.field_a;
   }

   public final int a105(class_1382 var1) {
      return this.field_a;
   }

   public final float a106(long var1) {
      return this.field_a;
   }

   public final Vector4f a63() {
      return this.field_a;
   }

   // $FF: synthetic method
   class_352(byte var1) {
      this();
   }
}
