import java.util.ArrayList;
import org.lwjgl.opengl.GL11;
import org.newdawn.slick.Color;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public final class class_238 extends class_964 {

   private float field_b = 5.0F;
   private float field_c;
   private float field_d;
   private class_940 field_a;
   private boolean field_a = true;
   private float field_e = 0.0F;
   private Color field_a = new Color(1, 1, 1, 1);
   private String field_b;
   public float field_a = 0.0F;
   private class_940 field_b;


   public class_238(String var1, ClientState var2, String var3, String var4, Color var5) {
      super(var2);
      this.field_b = var1;
      this.field_a = new class_940(10, 40, class_28.f(), var2);
      this.field_a.field_b = new ArrayList();
      this.field_b = new class_940(10, 40, class_28.c(), var2);
      this.field_b.field_b = new ArrayList();
      this.field_a.field_r = var5.field_r;
      this.field_a.field_g = var5.field_g;
      this.field_a.field_b = var5.field_b;
      this.field_a.field_a = var5.field_a;
      this.field_a.field_b.add(var3);
      this.field_b.field_b.add(var4);
   }

   public final void a2() {}

   public final void b() {
      if(this.field_a) {
         this.c();
      }

      if(this.field_d >= 0.0F) {
         this.a83().field_x = (float)(class_927.b() / 2 - this.field_a.field_a.getWidth(this.field_a.field_b.get(0).toString()) / 2);
         this.a83().field_y = this.field_e + (float)((int)((float)class_927.a() / 3.5F));
         if(this.j1()) {
            float var1;
            if((var1 = this.field_b - this.field_c) < 1.0F) {
               this.field_a.field_a.field_a = var1;
               this.field_b.field_a.field_a = var1;
            }

            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GlUtil.d1();
            this.r();
            this.field_a.b();
            GlUtil.c2();
            this.a83().field_x = (float)(class_927.b() / 2 - this.field_b.field_a.getWidth(this.field_b.field_b.get(0).toString()) / 2);
            GlUtil.d1();
            this.r();
            GlUtil.c4(0.0F, (float)(this.field_a.field_a.getLineHeight() + 5), 0.0F);
            this.field_b.b();
            GlUtil.c2();
            GL11.glDisable(3042);
            this.field_a.a138(1.0F, 1.0F);
            this.field_b.a138(1.0F, 1.0F);
         }
      }
   }

   public final boolean equals(Object var1) {
      return this.field_b.equals(((class_238)var1).field_b);
   }

   public final float a3() {
      return this.field_a.a3() + 5.0F + this.field_b.a3();
   }

   public final String a16() {
      return this.field_b;
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public final boolean a4() {
      return this.field_c < this.field_b;
   }

   public final void c() {
      this.field_a.a136(Color.white);
      this.field_a.c();
      this.field_a = false;
      this.field_e = -1.0F * (this.a3() * super.field_a.field_y + 5.0F);
   }

   public final void a_1() {
      this.field_c = 0.0F;
   }

   public final void a17(String var1) {
      this.field_a.field_b.set(0, var1);
   }

   public final void e() {
      this.field_d = 0.0F;
      this.field_c = 0.0F;
   }

   public final void f() {
      if(this.field_c < this.field_b - 1.0F) {
         this.field_c = this.field_b - 1.0F;
      }

   }

   public final void a12(class_935 var1) {
      if(this.field_d < 0.0F) {
         this.field_d += var1.a();
      } else {
         this.field_c += var1.a();
         float var2 = this.field_a * (this.a3() * super.field_a.field_y + 5.0F);
         float var3 = Math.min(1.0F, Math.max(0.01F, Math.abs(this.field_e - var2)) / (this.a3() * super.field_a.field_y));
         if(this.field_e > var2) {
            this.field_e -= var1.a() * 1000.0F * var3;
            if(this.field_e <= var2) {
               this.field_e = var2;
               return;
            }
         } else if(this.field_e < var2) {
            this.field_e += var1.a() * 1000.0F * var3;
            if(this.field_e >= var2) {
               this.field_e = var2;
            }
         }

      }
   }
}
