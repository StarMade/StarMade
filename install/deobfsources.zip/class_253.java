import com.bulletphysics.linearmath.Transform;
import javax.vecmath.Vector3f;

public final class class_253 extends class_946 {

   Transform field_a;
   Transform field_b;
   boolean field_a = false;
   private Vector3f field_a = new Vector3f();
   private Vector3f field_b = new Vector3f();
   private Vector3f field_c = new Vector3f();
   private Vector3f field_d = new Vector3f();
   boolean field_b;
   public int field_a = -1;
   private int field_d = 10;


   public class_253(Transform var1) {
      super(512);
      super.field_c = true;
      this.field_a = var1;
   }

   private void a11(Vector3f var1) {
      if(!this.field_b) {
         this.a14(var1, this.field_a);
      }

   }

   public final boolean a7(int var1, class_935 var2) {
      float var3 = super.field_a.a3(var1);
      super.field_a.a4(var1, this.field_c);
      super.field_a.d(var1, this.field_d);
      super.field_a.a6(var1, var3 + var2.a() * 1000.0F);
      super.field_a.a7(var1, this.field_c.field_x + this.field_d.field_x, this.field_c.field_y + this.field_d.field_y, this.field_c.field_z + this.field_d.field_z);
      return var3 < 3000.0F;
   }

   public final void a6(class_935 var1) {
      if(this.field_b == null) {
         this.a11(this.field_a.origin);
         this.field_b = new Transform(this.field_a);
      } else {
         this.field_b.set(this.field_a.origin);
         this.field_b.sub(this.field_b.origin);
         float var2;
         if((var2 = this.field_b.length()) > class_1353.field_a) {
            this.field_b.normalize();
            this.field_b.origin.add(this.field_b);
            float var3 = class_1353.field_a;
            int var4 = (int)(var2 / var3);
            float var5 = class_1353.field_a;
            if(var4 > this.field_d) {
               var5 = var2 / (float)this.field_d;
            }

            this.field_b.scale(var5);

            while(var3 < var2) {
               this.field_b.origin.add(this.field_b);
               this.a11(this.field_b.origin);
               var3 += var5;
            }

            this.field_b.set(this.field_a);
         }
      }

      super.a6(var1);
      if(this.field_b && this.b1() <= 0) {
         this.field_a = false;
      }

   }
}
