
final class class_312 implements class_954 {

   // $FF: synthetic field
   private class_314 field_a;


   class_312(class_314 var1) {
      this.field_a = var1;
      super();
   }

   public final boolean a(String var1, class_1077 var2) {
      try {
         if(var1.length() > 0) {
            if(Integer.parseInt(var1) <= 0) {
               this.field_a.a6().a4().b1("ERROR: Invalid quantity");
               return false;
            }

            class_967.b("0022_action - purchase with credits");
            return true;
         }
      } catch (NumberFormatException var3) {
         ;
      }

      var2.onFailedTextCheck("Please only enter numbers!");
      return false;
   }
}
