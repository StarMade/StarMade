import org.schema.schine.ai.stateMachines.FSMException;

public abstract class class_454 extends class_1001 {

   final class_371 field_a;
   String field_a;
   private boolean field_c;
   protected boolean field_a;
   protected boolean field_b;
   private static final long serialVersionUID = 111733781395879161L;
   private class_110 field_a;
   private class_482 field_a;


   public class_454(class_983 var1, String var2, class_371 var3) {
      super(var1);
      this.field_a = var3;
      this.field_a = var2;
   }

   protected abstract boolean a();

   public final void a2() {
      this.field_c = true;
   }

   public String a1() {
      return this.field_a;
   }

   public boolean c() {
      this.field_a = false;
      this.field_a = null;
      this.field_c = false;

      try {
         if(this.field_b && this.a()) {
            System.err.println("AUTO SKIP STATE " + this);
            this.field_c = true;
         }
      } catch (FSMException var1) {
         var1.printStackTrace();
      }

      if(!this.field_c) {
         this.field_a.a4().a5();
         class_460.a2();
         if(!(this instanceof class_403)) {
            this.field_a = new class_482(this.field_a, this.a1() + "\n(click NEXT to take control)", this);
         } else {
            this.field_a = new class_482(this.field_a, this.a1(), this);
         }

         this.field_a.b().add(this.field_a);
      }

      return true;
   }

   public boolean b() {
      if(this.field_a != null) {
         this.field_a.d();
      }

      return true;
   }

   public boolean d() {
      this.field_a.a4().a5();
      class_460.a2();
      if((!this.field_a || !this.a()) && !this.field_c) {
         this.field_a.a4().a5();
         class_460.a2();
         if(this.field_a) {
            this.field_a.a4().a5();
            class_460.a2();
            if(this.field_a == null) {
               this.field_a = this.field_a.a4().e(this.a1());
            } else {
               if(!(this instanceof class_403)) {
                  this.field_a.a17(this.a1() + "\n(press \'k\' to skip)");
               } else {
                  this.field_a.a17(this.a1());
               }

               this.field_a.e();
            }
         }

         return true;
      } else {
         this.field_c = false;
         if(this.field_a != null) {
            this.field_a.g();
         }

         this.a8().a8().a2().a1(new class_391());
         return false;
      }
   }

   public final void b1() {
      this.field_a = true;
   }

   public String toString() {
      return super.toString() + ": " + this.a1();
   }
}
