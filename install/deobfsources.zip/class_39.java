import java.util.HashMap;

public final class class_39 {

   public static HashMap field_a = new HashMap();


   public static void a(String var0) {
      field_a.put(var0, Long.valueOf(System.currentTimeMillis()));
   }

   public static void b(String var0) {
      field_a.put(var0, Long.valueOf(System.currentTimeMillis() - ((Long)field_a.get(var0)).longValue()));
   }

   public static long a1(String var0) {
      Long var1;
      return (var1 = (Long)field_a.get(var0)) != null?var1.longValue():-1L;
   }

}
