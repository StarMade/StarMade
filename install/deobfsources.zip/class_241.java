import com.bulletphysics.linearmath.Transform;
import org.schema.schine.graphicsengine.camera.Camera;

public final class class_241 extends Camera {

   private Transform field_a;


   public class_241(class_1432 var1) {
      super(new class_299(var1));
      ((class_958)this.a184()).a141(var1);
      this.field_a = new Transform();
      this.field_a.setIdentity();
      super.field_a = new class_1012(this);
   }

   public final void a12(class_935 var1) {
      ((class_1012)super.field_a).field_a.set(this.field_a);
      super.a12(var1);
   }
}
