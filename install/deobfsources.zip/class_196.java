import java.util.ArrayList;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public class class_196 extends class_964 {

   private class_970 field_b;
   private class_970 field_c;
   private class_940 field_b;
   protected class_940 field_a;
   private class_940 field_c;
   protected class_970 field_a;
   protected class_1412 field_a;
   public boolean field_a = true;
   private boolean field_b = true;
   private long field_a;
   private long field_b;
   private boolean field_c = true;
   private class_1412 field_b;


   public class_196(ClientState var1, class_1410 var2, Object var3, Object var4) {
      super(var1);
      this.a143(var2);
      this.field_b = new class_940(256, 64, class_28.d(), var1);
      this.field_a = new class_940(256, 64, class_28.b2(), var1);
      this.field_c = new class_940(256, 64, var1);
      this.field_a = new class_970(class_967.a2().a5("textinput-panel-gui-"), var1);
      this.field_b = new class_970(class_967.a2().a5("buttons-8x8-gui-"), var1);
      this.field_b.a_2(class_319.field_c.a(false));
      this.field_b.a143(var2);
      this.field_b.field_a = "OK";
      this.field_b.field_g = true;
      this.field_c = new class_970(class_967.a2().a5("buttons-8x8-gui-"), var1);
      this.field_c.a_2(3);
      this.field_c.a143(var2);
      this.field_c.field_a = Integer.valueOf(class_319.field_d.a(false));
      this.field_c.field_a = "CANCEL";
      this.field_c.field_g = true;
      this.field_b = new class_1412(this.a24(), 39.0F, 26.0F);
      this.field_b.a143(var2);
      this.field_b.field_a = "X";
      this.field_b.field_g = true;
      ArrayList var5;
      (var5 = new ArrayList()).add(var3);
      this.field_b.field_b = var5;
      (var5 = new ArrayList()).add(var4);
      this.field_a.field_b = var5;
      var5 = new ArrayList();
      this.field_c.field_b = var5;
      this.field_a.h2(48);
   }

   public void a2() {
      this.field_a.a2();
      this.field_b.a2();
   }

   public void b() {
      if(this.field_c) {
         this.c();
      }

      if(this.k1()) {
         this.field_a.h2(48);
      }

      GlUtil.d1();
      this.r();
      if(this.field_a < System.currentTimeMillis() - this.field_b) {
         this.field_c.field_b.clear();
      }

      this.field_b.a_2(class_319.field_c.a(this.field_b.a_()));
      this.field_c.a_2(class_319.field_d.a(this.field_c.a_()));
      this.field_a.b();
      GlUtil.c2();
   }

   public float a3() {
      return 256.0F;
   }

   public float b1() {
      return 256.0F;
   }

   public void c() {
      this.field_a.c();
      this.field_b.c();
      this.field_b.c();
      this.field_c.c();
      this.field_a.c();
      this.field_b.a83().set(472.0F, 8.0F, 0.0F);
      this.field_b.c();
      this.a9(this.field_a);
      this.field_a.a9(this.field_b);
      this.field_a.a9(this.field_c);
      this.field_a.a9(this.field_b);
      if(this.field_a) {
         this.field_a.a9(this.field_b);
      }

      if(this.field_b) {
         this.field_a.a9(this.field_c);
      }

      this.field_b.a165(20.0F, 20.0F, 0.0F);
      this.field_a.a165(2.0F, 2.0F, 0.0F);
      this.field_a = new class_1412(this.a24());
      this.field_a.a165(46.0F, 62.0F, 0.0F);
      this.field_a.a9(this.field_a);
      this.field_a.a9(this.field_a);
      this.field_c.a165(20.0F, 50.0F, 0.0F);
      this.field_b.a165(335.0F, 213.0F, 0.0F);
      this.field_b.b29(0.45F, 0.45F, 0.45F);
      this.field_c.a165(400.0F, 213.0F, 0.0F);
      this.field_c.b29(0.45F, 0.45F, 0.45F);
      this.field_c = false;
   }

   public final void a17(String var1) {
      this.field_c.field_b.add(var1);
      this.field_a = System.currentTimeMillis();
      this.field_b = 2000L;
   }

   public final void e() {
      this.field_a = false;
   }
}
