import org.lwjgl.input.Keyboard;

public final class class_23 extends class_15 {

   public int field_a;
   private int field_b = 3;


   public class_23(class_371 var1) {
      super(var1);
   }

   public final void handleKeyEvent() {
      super.handleKeyEvent();
      if(Keyboard.getEventKeyState()) {
         switch(Keyboard.getEventKey()) {
         case 203:
            --this.field_a;
            if(this.field_a < 0) {
               this.field_a = this.field_b - 1;
               return;
            }
            break;
         case 205:
            this.field_a = (this.field_a + 1) % this.field_b;
         }
      }

   }
}
