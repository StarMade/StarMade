import com.bulletphysics.linearmath.Transform;
import java.util.Iterator;
import javax.vecmath.AxisAngle4f;
import javax.vecmath.Matrix3f;
import javax.vecmath.Vector3f;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.schema.common.FastMath;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.graphicsengine.forms.Mesh;
import org.schema.schine.network.objects.Sendable;

public final class class_404 implements class_923 {

   private final class_746 field_a;
   private class_1058 field_a;
   class_1030 field_a;
   class_297 field_a;
   private boolean field_b = true;
   private Vector3f field_a = new Vector3f();
   private float field_a;
   private class_371 field_a;
   boolean field_a;
   class_744 field_a;
   class_935 field_a;
   private Transform field_a = new Transform();
   private Transform field_b = new Transform();
   private Matrix3f field_a = new Matrix3f();
   private Vector3f field_b = new Vector3f(0.0F, 1.0F, 0.0F);
   private Vector3f field_c = new Vector3f(0.0F, -1.0F, 0.0F);


   public class_404(class_746 var1) {
      this.field_a = var1;
      this.field_a = (class_371)var1.getState();
      this.field_a = new class_297(var1.getWorldTransform(), this.a40() + " (" + this.field_a.a51() + ")");
      this.field_a.setIdentity();
   }

   public final void a() {}

   public final void b() {
      if(this.field_b) {
         this.c();
      }

      if(this.field_a != null && this.field_a != null) {
         if(this.field_a.isHidden()) {
            class_883.field_a.remove(this.field_a);
         } else {
            GlUtil.c3(this.field_a.a135().upAxisDirection[0], this.field_a);
            GlUtil.d2(this.field_a.a135().upAxisDirection[1], this.field_a);
            GlUtil.a30(this.field_a.a135().upAxisDirection[2], this.field_a);
            this.field_a.a5(this.field_a);
            Vector3f var1 = this.field_a.a8();
            Vector3f var2 = this.field_a.c9();
            if(!Mouse.isButtonDown(2) && !Keyboard.isKeyDown(54)) {
               if(var1.epsilonEquals(this.field_b, 0.01F)) {
                  this.field_a = FastMath.a3(-var2.field_x, -var2.field_z);
               } else if(var1.epsilonEquals(this.field_c, 0.01F)) {
                  this.field_a = FastMath.a3(var2.field_x, var2.field_z);
               } else {
                  this.field_a = FastMath.a3(var1.field_x, var1.field_z);
               }
            }

            AxisAngle4f var3 = new AxisAngle4f(this.field_b, this.field_a);
            this.field_a.set(var3);
            if(this.field_a == this.field_a.a3()) {
               this.field_a.set(class_967.a1().a83());
               this.field_a.sub(this.field_a.a136().origin);
               if(this.field_a.length() < 0.2F) {
                  class_883.field_a.remove(this.field_a);
                  return;
               }
            }

            if(!class_883.field_a.contains(this.field_a)) {
               class_883.field_a.add(this.field_a);
            }

            GlUtil.d1();
            this.field_b.set(this.field_a.getWorldTransformClient());
            this.field_b.basis.mul(this.field_a);
            GlUtil.b3(this.field_b);
            class_988.field_a.set(this.field_b);
            Mesh var4 = (Mesh)class_967.a2().a4("Konata").a156().get(0);
            GlUtil.c4(0.0F, -0.1F, 0.0F);
            GlUtil.b5(1.0F, 1.0F, 1.0F);
            var4.a177().a7(this.field_a.a131().a5());
            var4.e();
            GlUtil.c2();
         }
      }
   }

   final void d() {
      int var1 = this.field_a.a3();
      synchronized(this.field_a.getLocalAndRemoteObjectContainer().getLocalObjects()) {
         Iterator var3 = this.field_a.getLocalAndRemoteObjectContainer().getLocalObjects().values().iterator();

         while(var3.hasNext()) {
            Sendable var4;
            if((var4 = (Sendable)var3.next()) instanceof class_744 && ((class_744)var4).a3() == var1) {
               this.field_a = (class_744)var4;
               return;
            }
         }
      }

      throw new IllegalArgumentException("[WARNING] Could not find Player for ID " + var1);
   }

   final String a40() {
      return this.field_a == null?"<nobody>":this.field_a.getName();
   }

   public final void c() {
      try {
         this.d();
      } catch (IllegalArgumentException var3) {
         System.err.println(var3.getMessage());
      }

      class_1380 var1 = ((Mesh)class_967.a2().a4("Konata").a156().get(0)).a177();
      this.field_a = new class_1058(var1);
      this.field_a = this.field_a.a();
      class_1030 var10000 = this.field_a;
      String var4 = var1.a6().a7().field_a;
      var10000.a1(var10000.field_a.a3().a3(var4));

      try {
         this.field_a.a2("default", 0.15F);
      } catch (Exception var2) {
         ;
      }

      this.field_b = false;
   }

   public final void e() {
      class_883.field_a.remove(this.field_a);
   }
}
