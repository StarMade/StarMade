import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;
import javax.vecmath.Vector3f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;
import org.schema.game.client.view.cubes.CubeOptOptMesh;
import org.schema.schine.graphicsengine.core.GLException;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.graphicsengine.core.settings.StateParameterNotFoundException;
import org.schema.schine.graphicsengine.forms.Mesh;
import org.schema.schine.graphicsengine.shader.ErrorDialogException;
import org.schema.schine.network.client.ClientState;
import org.schema.schine.network.server.ServerProcessor;

public final class class_307 extends class_969 {

   private class_371 field_a;
   private class_1351 field_a;
   private class_1351 field_b;
   private class_919 field_b;
   private class_1370 field_a;
   private class_919 field_c;
   private class_919 field_d;
   private class_1396 field_a;
   private Vector3f field_a = new Vector3f();
   private final class_1381 field_a = new class_1381();
   private long field_a;
   private String field_a = "";


   public class_307(class_371 var1) {
      this.field_a = var1;
   }

   public final void a() {
      class_1379.a();
      this.field_a.a27().a2();
      if(this.field_a != null) {
         this.field_a.a();
      }

   }

   private void e() {
      int var1 = class_927.b();
      int var2 = class_927.a();
      if(this.field_a != null) {
         this.field_a.a();
      }

      if(this.field_b != null) {
         this.field_b.a();
      }

      if(this.field_d != null) {
         this.field_d.a();
      }

      if(this.field_c != null) {
         this.field_c.a();
      }

      this.field_a = new class_919(var1, var2);
      this.field_b = new class_919(var1, var2);
      this.field_b.field_b = false;
      this.field_d = new class_919(var1, var2);
      this.field_c = new class_919(var1 / 2, var2 / 2);
      if(this.field_a == null) {
         this.field_a = new class_1370();
      }

   }

   public final void b() {
      this.field_a.a27().j();
      boolean var1 = class_943.field_x.b1() || class_943.field_V.b1();
      if(class_967.a2().a6() && this.field_a.isReady()) {
         if(this.field_a) {
            this.c();
            this.field_a = false;
         }

         if(class_943.field_u.b1()) {
            System.err.println("RECOMPILING SHADERS");
            class_1379.c();

            try {
               class_943.field_u.d();
            } catch (StateParameterNotFoundException var4) {
               var4.printStackTrace();
            }
         }

         GL11.glDepthFunc(515);
         class_986.g3();
         GlUtil.a12(5889);
         GlUtil.b2();
         float var6 = (float)class_927.b() / (float)class_927.a();
         GlUtil.a15(class_967.field_b, ((Float)class_943.field_f.a4()).floatValue(), var6, class_969.field_b, class_969.field_a, true);
         GlUtil.a38(0.2F, 1.0F, 0.3F, 1.0F);
         if(class_943.field_k.b1()) {
            class_969.field_a.rewind();
            class_969.field_a.put(class_969.field_a);
            class_969.field_a.rewind();
            GL11.glEnable(2912);
            GL11.glFogi(2917, 2049);
            GL11.glFog(2918, class_969.field_a);
            GL11.glFogf(2914, 0.1F);
            GL11.glHint(3156, 4354);
         }

         GlUtil.a12(5888);
         GlUtil.b2();
         class_967.a1().c();
         this.field_a.a4();
         class_1381 var10000 = this.field_a;
         this.field_a.a23();
         var10000.a2(class_969.field_a.a83(), this.field_a, false);
         if(var1) {
            if(this.field_a == null || class_927.b1()) {
               this.e();
               this.g();
            }

            this.field_b.d();
            GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
            GL11.glClear(16640);
            this.field_a.a27().a96().e();
            this.field_b.b1();
            this.field_d.d();
            GL11.glClear(16640);
            class_39.a("SCENE-DRAW");
            this.f();
            class_39.b("SCENE-DRAW");
            this.field_d.b1();
            class_1379.field_q.field_a = this.field_a;
            this.field_c.d();
            GL11.glClear(16640);
            this.field_a.field_a = this.field_d.a3();
            this.field_a.field_a.set(1.0F, 1.0F, 1.0F, 1.0F);
            class_1379.field_q.b();
            this.field_a.a27().g();
            class_1379.field_q.d();
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            this.field_a.field_a.set(0.0F, 0.0F, 0.0F, 1.0F);
            class_1379.field_q.b();
            this.field_d.c1();
            class_1379.field_q.d();
            GL11.glDisable(3042);
            this.field_c.b1();
            if(class_943.field_V.b1()) {
               class_307 var5 = this;
               if(this.field_a == null) {
                  try {
                     var5.field_a = new class_1351(var5.field_a);
                     var5.field_b = new class_1351(var5.field_c);
                     var5.field_a.a2(var5.field_c.a3());
                     var5.field_b.a2(var5.field_c.a3());
                     var5.field_a = new class_1396();
                     var5.field_a.a14(var5.field_c.a3(), var5.field_a);
                     class_1379.field_x.field_a = var5.field_a;
                  } catch (GLException var3) {
                     var3.printStackTrace();
                  }
               }

               this.field_a.d();
               GL11.glClear(16640);
               this.field_a.a27().a96().d();
               GL11.glEnable(3042);
               GL11.glBlendFunc(770, 771);
               this.field_b.c1();
               GL11.glDisable(3042);
               GL11.glEnable(3042);
               GL11.glBlendFunc(1, 771);
               this.field_d.c1();
               GL11.glDisable(3042);
               this.field_a.field_a.set(this.field_a);
               this.field_a.b1();
               GL11.glEnable(3042);
               GL11.glBlendFunc(770, 771);
               this.field_a.b();
               GL11.glDisable(3042);
               this.field_a.a9();
               GL11.glEnable(3042);
               GL11.glBlendFunc(1, 1);
               this.field_a.a2(class_1379.field_x);
               GL11.glDisable(3042);
               GL11.glBlendFunc(770, 771);
               this.field_a.a27().e();
            } else {
               this.field_a.d();
               GL11.glClear(16640);
               this.field_a.a27().a96().d();
               this.field_a.a27().a96().e();
               GL11.glEnable(3042);
               GL11.glBlendFunc(1, 771);
               this.field_d.c1();
               this.field_a.a27().e();
               GL11.glDisable(3042);
               this.field_a.b1();
               this.field_a.c1();
            }
         } else {
            GL11.glClear(16640);
            this.field_a.a27().a96().b();
            class_39.a("SCENE-DRAW");
            this.f();
            class_39.b("SCENE-DRAW");
            this.field_a.a27().e();
         }

         class_39.a("INFO-DRAW");
         GlUtil.d1();
         this.d();
         GlUtil.c2();
         class_39.b("INFO-DRAW");
         GlUtil.a38(1.0F, 1.0F, 1.0F, 1.0F);
         this.field_a.a27().h1();
      } else {
         if(super.field_a == null) {
            super.field_a = new class_940(300, 300, (ClientState)null);
         }

         GlUtil.a12(5889);
         GlUtil.d1();
         GlUtil.b2();
         GLU.gluOrtho2D(0.0F, (float)class_927.b(), (float)class_927.a(), 0.0F);
         GlUtil.a12(5888);
         GlUtil.b2();
         class_1382 var2;
         if((var2 = class_967.a2().a5("schine")) != null) {
            var2.a165((float)(class_927.b() - var2.c5()), (float)(class_927.a() - var2.a57()), 0.0F);
            var2.b();
            GL11.glDisable(2896);
            GL11.glBindTexture(3553, 0);
            GL11.glDisable(3042);
            GL11.glDisable(2929);
            GL11.glDisable(3553);
            GL11.glEnable(2903);
            GlUtil.a38(0.9F, 0.9F, 0.9F, 0.8F);
            GlUtil.a38(0.2F, 0.9F, 0.2F, 0.9F);
            class_964.i();
            if(super.field_a.b16() == null) {
               super.field_a.b17(new ArrayList());
            }

            super.field_a.b16().clear();
            super.field_a.b16().add(class_967.a2().a3());
            super.field_a.b16().add("");
            super.field_a.b16().add("");
            super.field_a.b16().addAll(class_967.a2().a2());
            super.field_a.b();
            class_964.h1();
            GL11.glDisable(2903);
            GL11.glBindTexture(3553, 0);
            GL11.glEnable(2929);
            GlUtil.a12(5889);
            GlUtil.c2();
            GlUtil.a12(5888);
            this.field_a = true;
         } else {
            throw new ErrorDialogException("Failed to load shine Logo");
         }
      }
   }

   private void f() {
      GlUtil.d1();
      class_969.field_a.b();
      GlUtil.a38(1.0F, 1.0F, 1.0F, 1.0F);
      class_39.a("WORLD-DRAW");
      this.field_a.a27().b();
      class_39.b("WORLD-DRAW");
      if((this.field_a.a23().field_a == null || !this.field_a.a23().field_a.field_a) && class_943.field_F.b1()) {
         GL11.glDisable(2896);
         this.field_a.a19().getDynamicsWorld().debugDrawWorld();
         this.field_a.a19().drawDebugObjects();
         GL11.glEnable(2929);
         class_1426.b();
         class_1426.c();
         class_1426.f();
         class_1426.d();
         class_1426.e();
      }

      field_a.clear();
      GlUtil.c2();
   }

   public static class_1000 a25() {
      return class_969.field_a;
   }

   public final class_1381 a26() {
      return this.field_a;
   }

   private void g() {
      try {
         this.field_a.e();
         this.field_b.e();
         this.field_d.e();
         this.field_c.e();
      } catch (GLException var1) {
         var1.printStackTrace();
      }
   }

   public final void c() {
      class_1379.b();
      if(class_943.field_x.b1() || class_943.field_V.b1()) {
         this.e();
         this.g();
      }

      new class_1388(new class_982(new ArrayList()));
      this.field_a.a19().getDynamicsWorld().setDebugDrawer(new class_921());
      class_967.a2().a4("Box");
      Mesh.k();
      this.field_a.a27().c();
   }

   public final void a1(class_935 var1) {
      System.currentTimeMillis();
      field_a.add(0, "[FPS] " + var1.a1());
      field_a.add(1, "[PING] " + this.field_a.getPing());
      if(System.currentTimeMillis() - this.field_a > 900L) {
         this.field_a = "[MEMORY] free: " + class_371.field_b / 1024L + "kb, taken: " + class_371.field_c / 1024L + "kb, total " + class_371.field_a / 1024L + "kb";
         this.field_a = System.currentTimeMillis();
      }

      field_a.add(2, this.field_a);
      field_a.add(3, "[CL SEG A/F; D; [VRAM-save]] " + class_371.field_b + " / " + class_371.field_c + " (CMI: " + CubeOptOptMesh.field_a + "); " + class_371.field_i + "; [" + class_371.field_j / 1024 / 1024 + " / " + class_371.field_k / 1024 / 1024 + " mb] " + class_400.field_a);
      field_a.add(4, "[SE SEG A/F; PGK; SEC] " + class_1035.field_b + " / " + class_1035.field_c + "; " + ServerProcessor.totalPackagesQueued + "; " + class_1035.field_j + "/" + class_1035.field_i);
      class_371.field_i = 0;
      class_400.field_a = 0;
      CubeOptOptMesh.field_b = 0;
      CubeOptOptMesh.field_c = 0;
      Iterator var2 = class_39.field_a.entrySet().iterator();

      while(var2.hasNext()) {
         Entry var3 = (Entry)var2.next();
         field_a.add((String)var3.getKey() + ": " + (float)((Long)var3.getValue()).longValue());
      }

      if(!this.field_a.a27().a101().a24(var1) && class_967.a1() != null) {
         field_a.add("cam-pos:   " + class_967.a1().getClass().getSimpleName() + ": " + class_967.a1().a83());
         class_967.a1().a12(var1);
      }

      this.field_a.a27().a12(var1);
   }
}
