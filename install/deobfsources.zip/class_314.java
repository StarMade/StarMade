import org.schema.schine.network.objects.remote.RemoteInteger;
import org.schema.schine.network.objects.remote.Streamable;

public final class class_314 extends class_316 {

   public class_314(class_371 var1) {
      super(var1, "Drop Credits", "How many credits do you want to drop");
      this.a10(new class_312(this));
      super.field_a.a83(new class_318(this));
   }

   public final boolean a7(String var1) {
      int var2 = Integer.parseInt(var1);
      super.field_a.a20().a117().creditsDropBuffer.add((Streamable)(new RemoteInteger(Integer.valueOf(var2), false)));
      return true;
   }
}
