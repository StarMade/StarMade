
final class class_409 extends class_12 {

   class_409(class_371 var1, Object var2, Object var3) {
      super(var1, var2, var3);
   }

   public final boolean a1() {
      return false;
   }

   public final void b() {
      System.err.println("[CLIENT][FactionControlManager] leaving Faction");
      super.field_a.a20().a132().c1();
      this.d();
   }

   public final void a2() {}
}
