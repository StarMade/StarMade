import java.util.Iterator;

public final class class_338 extends class_15 implements class_1410 {

   public class_340 field_a = new class_340();


   public class_338(class_371 var1) {
      super(var1);
   }

   public final void a(class_964 var1, class_941 var2) {
      if(super.field_c && !super.field_a) {
         Iterator var5 = this.a6().getMouseEvents().iterator();

         while(var5.hasNext()) {
            class_941 var3;
            if((var3 = (class_941)var5.next()).field_a == 0 && !var3.field_a && var1 instanceof class_972) {
               class_963 var4;
               class_972 var6;
               (var4 = (class_963)(var6 = (class_972)var1).a158()).indexOf(var6);
               var4.e();
               var6.a29(true);
               this.a6().a14().field_a.field_a.field_a.a56(((class_847)var6.a149()).a60());
            }
         }
      }

   }

   public final void handleKeyEvent() {
      super.handleKeyEvent();
   }

   public final void a12(class_941 var1) {
      super.a12(var1);
   }

   public final boolean a1() {
      return !this.a6().b().isEmpty();
   }

   public final void b2(boolean var1) {
      class_1008.field_a = !var1;
      if(var1) {
         class_967.b("0022_menu_ui - swoosh scroll large");
      } else {
         class_967.b("0022_menu_ui - swoosh scroll small");
      }

      this.a6().a14().field_a.field_a.field_a.a51().a45().field_a.e2(var1);
      this.a6().a14().field_a.field_a.field_a.a51().a45().field_a.e2(var1);
      super.b2(var1);
   }

   public final void a15(class_935 var1) {
      class_1008.field_a = false;
      this.a6().a14().field_a.field_a.field_a.e2(true);
   }

   public final class_340 a44() {
      return new class_340(this.field_a);
   }
}
