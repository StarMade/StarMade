
public final class class_427 extends class_15 implements class_1410 {

   public class_430 field_a = new class_430(this.a6());
   public class_425 field_a = new class_425(this.a6());
   public class_426 field_a = new class_426(this.a6());


   public class_427(class_371 var1) {
      super(var1);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      this.field_a.c2(true);
   }

   public final void b2(boolean var1) {
      if(var1) {
         class_967.b("0022_menu_ui - swoosh scroll large");
         this.setChanged();
         this.notifyObservers();
      } else {
         class_967.b("0022_menu_ui - swoosh scroll small");
      }

      super.b2(var1);
   }

   public final void a15(class_935 var1) {
      class_1008.field_a = false;
      super.a15(var1);
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.field_a && var2.field_a == 0) {
         if("PERSONAL".equals(var1.b19())) {
            this.a11(this.field_a);
            this.setChanged();
            this.notifyObservers();
            return;
         }

         if("ACCESSIBLE".equals(var1.b19())) {
            this.a11(this.field_a);
            this.setChanged();
            this.notifyObservers();
            return;
         }

         if("ADMIN".equals(var1.b19()) && ((Boolean)this.a6().a20().a117().isAdminClient.get()).booleanValue()) {
            this.a11(this.field_a);
            this.setChanged();
            this.notifyObservers();
         }
      }

   }

   public final boolean a1() {
      return false;
   }
}
