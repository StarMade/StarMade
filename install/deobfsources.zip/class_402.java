import java.util.ArrayList;
import java.util.Iterator;
import org.schema.schine.graphicsengine.forms.Mesh;

public final class class_402 implements class_923 {

   private class_371 field_a;
   public ArrayList field_a = new ArrayList();
   private boolean field_a = true;


   public class_402(class_371 var1) {
      this.field_a = var1;
   }

   public final void a() {}

   public final void b() {
      if(this.field_a) {
         this.c();
      }

      for(int var1 = 0; var1 < this.field_a.size(); ++var1) {
         ((class_404)this.field_a.get(var1)).b();
      }

   }

   public final void c() {
      ((Mesh)class_967.a2().a4("Konata").a156().get(0)).a177().a7(class_333.field_b.field_c);
      this.field_a = false;
   }

   public final void a1(class_935 var1) {
      for(int var2 = 0; var2 < this.field_a.size(); ++var2) {
         class_404 var10000 = (class_404)this.field_a.get(var2);
         class_935 var4 = var1;
         class_404 var3 = var10000;

         try {
            if(var3.field_a == null) {
               var3.d();
            }

            if(var3.field_a != null) {
               try {
                  boolean var5;
                  if((var5 = var3.field_a.a122(class_367.field_c) | var3.field_a.a122(class_367.field_d) | var3.field_a.a122(class_367.field_a) | var3.field_a.a122(class_367.field_b) | var3.field_a.a122(class_367.field_e) | var3.field_a.a122(class_367.field_f)) != var3.field_a && var3.field_a != null) {
                     if(var5) {
                        var3.field_a.a2("flying", 0.5F);
                     } else {
                        var3.field_a.a2("default", 0.5F);
                     }

                     var3.field_a = var5;
                  }

                  var3.field_a = var4;
                  var3.field_a.field_a = var3.a40() + var3.field_a.a132().b();
               } catch (Exception var6) {
                  System.err.println("DRAWABLE CHARACTER UPDATE FAILED: " + var6.getClass().getSimpleName() + ": " + var6.getMessage() + "; channel " + var3.field_a + ", PlayerState: " + var3.field_a);
               }
            }
         } catch (IllegalArgumentException var7) {
            System.err.println(var7.getMessage());
         }
      }

   }

   public final void d() {
      while(this.field_a.size() > 0) {
         ((class_404)this.field_a.remove(0)).e();
      }

      Iterator var1 = this.field_a.a7().values().iterator();

      while(var1.hasNext()) {
         class_801 var2;
         if((var2 = (class_801)var1.next()) instanceof class_746) {
            class_404 var3 = new class_404((class_746)var2);
            this.field_a.add(var3);
         }
      }

   }
}
