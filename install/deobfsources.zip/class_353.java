
public final class class_353 {

   public long field_a;
   public long field_b;
   public long field_c;
   public long field_d;
   public long field_e;
   public long field_f;
   public long field_g;
   public long field_h;
   long field_i;
   public long field_j;
   public long field_k;
   public long field_l;
   public long field_m;
   public long field_n;
   public long field_o;
   public long field_p;
   public int field_a;
   public int field_b;
   public long field_q;


   private class_353() {}

   // $FF: synthetic method
   public class_353(byte var1) {
      this();
   }

   // $FF: synthetic method
   public static long a(class_353 var0, long var1) {
      return var0.field_n += var1;
   }

   // $FF: synthetic method
   public static long b(class_353 var0, long var1) {
      return var0.field_h += var1;
   }
}
