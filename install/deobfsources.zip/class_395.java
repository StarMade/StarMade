
public final class class_395 extends class_956 {

   private static final long serialVersionUID = -6970548770389232891L;


}
