
// $FF: synthetic class
final class class_235 {

   // $FF: synthetic field
   static final int[] field_a = new int[class_231.values().length];


   static {
      try {
         field_a[class_231.field_a.ordinal()] = 1;
      } catch (NoSuchFieldError var5) {
         ;
      }

      try {
         field_a[class_231.field_b.ordinal()] = 2;
      } catch (NoSuchFieldError var4) {
         ;
      }

      try {
         field_a[class_231.field_c.ordinal()] = 3;
      } catch (NoSuchFieldError var3) {
         ;
      }

      try {
         field_a[class_231.field_e.ordinal()] = 4;
      } catch (NoSuchFieldError var2) {
         ;
      }

      try {
         field_a[class_231.field_f.ordinal()] = 5;
      } catch (NoSuchFieldError var1) {
         ;
      }

      try {
         field_a[class_231.field_d.ordinal()] = 6;
      } catch (NoSuchFieldError var0) {
         ;
      }
   }
}
