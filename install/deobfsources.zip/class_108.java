import java.util.ArrayList;
import javax.vecmath.Vector4f;
import org.lwjgl.opengl.GL11;
import org.newdawn.slick.Color;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public final class class_108 extends class_964 {

   private class_970 field_a;
   private float field_a;
   private float field_b;
   private class_940 field_a;
   private boolean field_a = true;
   private class_1433 field_a = new class_1433(30.0F);
   private String field_b;
   private Color field_a = new Color(1, 1, 1, 1);
   private boolean field_b = true;


   public class_108(ClientState var1, String var2, Color var3) {
      super(var1);
      if(this.field_a == null) {
         this.field_a = new class_970(class_967.a2().a5("std-message-gui-"), var1);
         this.field_a = new class_940(300, 300, var1);
         class_940 var10000 = this.field_a;
         ArrayList var10001 = new ArrayList();
         var1 = null;
         var10000.field_b = var10001;
      }

      String var4 = null;
      this.field_b = var2;
      this.field_a.field_r = var3.field_r;
      this.field_a.field_g = var3.field_g;
      this.field_a.field_b = var3.field_b;
      this.field_a.field_a = var3.field_a;
      this.field_a.field_b.clear();
      String[] var5;
      int var6 = (var5 = var2.split("\n")).length;

      for(int var7 = 0; var7 < var6; ++var7) {
         var4 = var5[var7];
         this.field_a.field_b.add(var4);
      }

   }

   public final void a2() {}

   public final void e() {
      this.field_b = false;
   }

   public final void b() {
      if(this.field_a) {
         this.c();
      }

      if(this.field_b && this.field_b >= 0.0F) {
         this.field_a.a151().a63().set(this.field_a.field_r, this.field_a.field_g, this.field_a.field_b, 1.0F);
         if(this.field_a < 0.3F && this.field_a.a1() < 0.5F) {
            float var1 = Math.max(1.0F, 1.0F - this.field_a * 5.0F);
            this.field_a.a151().a63().set(var1 / 2.0F + this.field_a.field_r, var1 / 2.0F + this.field_a.field_g, var1 / 2.0F + this.field_a.field_b, 1.0F);
         }

         GL11.glEnable(3042);
         GL11.glBlendFunc(770, 771);
         GlUtil.d1();
         this.r();
         this.field_a.b();
         GlUtil.c2();
         GL11.glDisable(3042);
         this.field_a.a151().a63().set(1.0F, 1.0F, 1.0F, 1.0F);
         this.field_a.field_a.field_a = 1.0F;
         this.field_a.field_a.field_r = 1.0F;
         this.field_a.field_a.field_g = 1.0F;
         this.field_a.field_a.field_b = 1.0F;
      }
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final String a16() {
      return this.field_b;
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public final void c() {
      this.field_a.a165(30.0F, 30.0F, 0.0F);
      this.field_a.a136(Color.white);
      this.field_a.field_a = class_28.b2();
      this.field_a.c();
      this.field_a.a151().c7(new Vector4f(1.0F, 1.0F, 1.0F, 1.0F));
      this.field_a.c();
      this.field_a.a9(this.field_a);
      this.field_a = false;
   }

   public final void f() {
      this.field_b = true;
   }

   public final void g() {
      this.field_b = 0.0F;
      this.field_a = 0.0F;
   }

   public final void a12(class_935 var1) {
      if(this.field_b < 0.0F) {
         this.field_b += var1.a();
      } else {
         this.field_a += var1.a();
         this.field_a.a(var1);
      }
   }
}
