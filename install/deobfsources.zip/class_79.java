import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PushbackInputStream;
import java.util.Collection;
import java.util.Iterator;
import java.util.zip.GZIPInputStream;
import javax.vecmath.Vector3f;

public class class_79 {

   private final class_81 field_a;
   private class_81 field_b;
   private final String field_a;
   private Object field_a;
   // $FF: synthetic field
   private static boolean field_a = !Aj.class.desiredAssertionStatus();


   private static Object a(DataInputStream var0, byte var1) {
      class_79[] var3;
      switch(var1) {
      case 0:
         return null;
      case 1:
         return Byte.valueOf(var0.readByte());
      case 2:
         return Short.valueOf(var0.readShort());
      case 3:
         return Integer.valueOf(var0.readInt());
      case 4:
         return Long.valueOf(var0.readLong());
      case 5:
         return Float.valueOf(var0.readFloat());
      case 6:
         return Double.valueOf(var0.readDouble());
      case 7:
         byte[] var6 = new byte[var0.readInt()];
         var0.readFully(var6);
         return var6;
      case 8:
         return var0.readUTF();
      case 9:
         return new Vector3f(var0.readFloat(), var0.readFloat(), var0.readFloat());
      case 10:
         return new class_47(var0.readInt(), var0.readInt(), var0.readInt());
      case 11:
         return new class_34((float)var0.read(), (float)var0.read(), (float)var0.read());
      case 12:
         var1 = var0.readByte();
         int var8;
         var3 = new class_79[var8 = var0.readInt()];

         for(int var9 = 0; var9 < var8; ++var9) {
            var3[var9] = new class_79(class_81.values()[var1], (String)null, a(var0, var1));
         }

         return var3.length == 0?class_81.values()[var1]:var3;
      case 13:
         class_79[] var5 = new class_79[0];

         byte var4;
         do {
            var4 = var0.readByte();
            String var7 = null;
            if(var4 != 0) {
               var7 = var0.readUTF();
            }

            var3 = new class_79[var5.length + 1];
            System.arraycopy(var5, 0, var3, 0, var5.length);
            var3[var5.length] = new class_79(class_81.values()[var4], var7, a(var0, var4));
            var5 = var3;
         } while(var4 != 0);

         return var3;
      case 14:
         byte var2 = var0.readByte();
         return class_28.field_a[var2].create(var0);
      default:
         return null;
      }
   }

   public class_79(String var1, class_81 var2) {
      this(class_81.field_m, var1, (Object)var2);
   }

   public class_79(class_81 var1, String var2, Object var3) {
      this.field_b = null;
      switch(class_80.field_a[var1.ordinal()]) {
      case 1:
         if(var3 != null) {
            throw new IllegalArgumentException();
         }
         break;
      case 2:
         if(!(var3 instanceof Byte)) {
            throw new IllegalArgumentException();
         }
         break;
      case 3:
         if(!(var3 instanceof Short)) {
            throw new IllegalArgumentException();
         }
         break;
      case 4:
         if(!(var3 instanceof Integer)) {
            throw new IllegalArgumentException();
         }
         break;
      case 5:
         if(!(var3 instanceof Long)) {
            throw new IllegalArgumentException();
         }
         break;
      case 6:
         if(!(var3 instanceof Float)) {
            throw new IllegalArgumentException();
         }
         break;
      case 7:
         if(!(var3 instanceof Double)) {
            throw new IllegalArgumentException();
         }
         break;
      case 8:
         if(!(var3 instanceof byte[])) {
            throw new IllegalArgumentException();
         }
         break;
      case 9:
         if(!(var3 instanceof String)) {
            throw new IllegalArgumentException();
         }
         break;
      case 10:
         if(!(var3 instanceof Vector3f)) {
            throw new IllegalArgumentException();
         }
         break;
      case 11:
         if(!(var3 instanceof class_47)) {
            throw new IllegalArgumentException();
         }
         break;
      case 12:
         if(!(var3 instanceof class_34)) {
            throw new IllegalArgumentException();
         }
         break;
      case 13:
         if(var3 instanceof class_81) {
            this.field_b = (class_81)var3;
            var3 = new class_79[0];
         } else {
            if(!(var3 instanceof class_79[])) {
               throw new IllegalArgumentException();
            }

            this.field_b = ((class_79[])var3)[0].field_a;
         }
         break;
      case 14:
         if(!(var3 instanceof class_79[])) {
            throw new IllegalArgumentException();
         }
         break;
      case 15:
         if(!(var3 instanceof class_69)) {
            throw new IllegalArgumentException();
         }
         break;
      default:
         throw new IllegalArgumentException();
      }

      this.field_a = var1;
      this.field_a = var2;
      this.field_a = var3;
   }

   public class_79(class_81 var1, String var2, class_79[] var3) {
      this(var1, var2, (Object)var3);
      if(!field_a && var1 != class_81.field_a && var3[var3.length - 1].field_a != class_81.field_a) {
         throw new AssertionError();
      }
   }

   public final void a1(class_79 var1) {
      if(this.field_a != class_81.field_m && this.field_a != class_81.field_n) {
         throw new RuntimeException();
      } else {
         int var2 = ((class_79[])this.field_a).length;
         if(this.field_a == class_81.field_n) {
            --var2;
         }

         if(this.field_a != class_81.field_m && this.field_a != class_81.field_n) {
            throw new RuntimeException();
         } else {
            class_79[] var4;
            if((var4 = (class_79[])this.field_a).length > 0 && this.field_a == class_81.field_m && var1.field_a != this.field_b) {
               throw new IllegalArgumentException();
            } else if(var2 > var4.length) {
               throw new IndexOutOfBoundsException();
            } else {
               class_79[] var5 = new class_79[var4.length + 1];
               System.arraycopy(var4, 0, var5, 0, var2);
               var5[var2] = var1;
               System.arraycopy(var4, var2, var5, var2 + 1, var4.length - var2);
               this.field_a = var5;
            }
         }
      }
   }

   public final String a2() {
      return this.field_a;
   }

   public final class_81 a3() {
      return this.field_a;
   }

   public final Object a4() {
      return this.field_a;
   }

   public final void a5(Object var1) {
      switch(class_80.field_a[this.field_a.ordinal()]) {
      case 1:
         if(var1 != null) {
            throw new IllegalArgumentException();
         }
         break;
      case 2:
         if(!(var1 instanceof Byte)) {
            throw new IllegalArgumentException();
         }
         break;
      case 3:
         if(!(var1 instanceof Short)) {
            throw new IllegalArgumentException();
         }
         break;
      case 4:
         if(!(var1 instanceof Integer)) {
            throw new IllegalArgumentException();
         }
         break;
      case 5:
         if(!(var1 instanceof Long)) {
            throw new IllegalArgumentException();
         }
         break;
      case 6:
         if(!(var1 instanceof Float)) {
            throw new IllegalArgumentException();
         }
         break;
      case 7:
         if(!(var1 instanceof Double)) {
            throw new IllegalArgumentException();
         }
         break;
      case 8:
         if(!(var1 instanceof byte[])) {
            throw new IllegalArgumentException();
         }
         break;
      case 9:
         if(!(var1 instanceof String)) {
            throw new IllegalArgumentException();
         }
         break;
      case 10:
         if(!(var1 instanceof Vector3f)) {
            throw new IllegalArgumentException();
         }
         break;
      case 11:
         if(!(var1 instanceof class_47)) {
            throw new IllegalArgumentException();
         }
         break;
      case 12:
         if(!(var1 instanceof class_34)) {
            throw new IllegalArgumentException();
         }
         break;
      case 13:
         if(var1 instanceof class_81) {
            this.field_b = (class_81)var1;
            var1 = new class_79[0];
         } else {
            if(!(var1 instanceof class_79[])) {
               throw new IllegalArgumentException();
            }

            this.field_b = ((class_79[])var1)[0].field_a;
         }
         break;
      case 14:
         if(!(var1 instanceof class_79[])) {
            throw new IllegalArgumentException();
         }
         break;
      case 15:
         if(!(var1 instanceof class_69)) {
            throw new IllegalArgumentException();
         }
         break;
      default:
         throw new IllegalArgumentException();
      }

      this.field_a = var1;
   }

   public static class_79 a6(Collection var0, String var1) {
      class_79[] var2;
      (var2 = new class_79[var0.size() + 1])[var0.size()] = new class_79(class_81.field_a, (String)null, (class_79[])null);
      int var3 = 0;

      for(Iterator var5 = var0.iterator(); var5.hasNext(); ++var3) {
         class_74 var4 = (class_74)var5.next();
         var2[var3] = var4.toTagStructure();
      }

      return new class_79(class_81.field_n, var1, var2);
   }

   public static void a7(Collection var0, class_79[] var1) {
      if(!field_a && var1[var1.length - 1].field_a != class_81.field_a) {
         throw new AssertionError();
      } else {
         for(int var2 = 0; var2 < var1.length - 1; ++var2) {
            var0.add(var1[var2].field_a);
         }

      }
   }

   public static class_79 a8(Collection var0, class_81 var1, String var2) {
      class_79[] var3;
      (var3 = new class_79[var0.size() + 1])[var0.size()] = new class_79(class_81.field_a, (String)null, (class_79[])null);
      int var4 = 0;

      for(Iterator var6 = var0.iterator(); var6.hasNext(); ++var4) {
         Object var5 = var6.next();
         var3[var4] = new class_79(var1, (String)null, var5);
      }

      return new class_79(class_81.field_n, var2, var3);
   }

   public String toString() {
      return this.field_a.name() + ": " + this.field_a + "->" + (this.field_a == null?"null":(this.field_a instanceof class_79[]?"STRUCT":this.field_a));
   }

   private void a9(DataOutputStream var1) {
      int var4;
      switch(class_80.field_a[this.field_a.ordinal()]) {
      case 1:
         return;
      case 2:
         var1.writeByte(((Byte)this.field_a).byteValue());
         return;
      case 3:
         var1.writeShort(((Short)this.field_a).shortValue());
         return;
      case 4:
         var1.writeInt(((Integer)this.field_a).intValue());
         return;
      case 5:
         var1.writeLong(((Long)this.field_a).longValue());
         return;
      case 6:
         var1.writeFloat(((Float)this.field_a).floatValue());
         return;
      case 7:
         var1.writeDouble(((Double)this.field_a).doubleValue());
         return;
      case 8:
         byte[] var9 = (byte[])this.field_a;
         var1.writeInt(var9.length);
         var1.write(var9);
         return;
      case 9:
         var1.writeUTF((String)this.field_a);
         return;
      case 10:
         var1.writeFloat(((Vector3f)this.field_a).field_x);
         var1.writeFloat(((Vector3f)this.field_a).field_y);
         var1.writeFloat(((Vector3f)this.field_a).field_z);
         return;
      case 11:
         var1.writeInt(((class_47)this.field_a).field_a);
         var1.writeInt(((class_47)this.field_a).field_b);
         var1.writeInt(((class_47)this.field_a).field_c);
         return;
      case 12:
         var1.write(((class_34)this.field_a).field_a);
         var1.write(((class_34)this.field_a).field_b);
         var1.write(((class_34)this.field_a).field_c);
         return;
      case 13:
         class_79[] var7 = (class_79[])this.field_a;
         var1.writeByte(this.field_b.ordinal());
         var1.writeInt(var7.length);
         int var8 = (var7 = var7).length;

         for(var4 = 0; var4 < var8; ++var4) {
            var7[var4].a9(var1);
         }

         return;
      case 14:
         class_79[] var10000 = (class_79[])this.field_a;
         class_79 var2 = null;
         class_79[] var3 = var10000;
         var4 = var10000.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            class_81 var6 = (var2 = var3[var5]).field_a;
            var1.writeByte(var6.ordinal());
            if(var6 != class_81.field_a) {
               var1.writeUTF(var2.field_a != null?var2.field_a:"null");
               var2.a9(var1);
            }
         }
      case 15:
         var1.writeByte(((class_69)this.field_a).getFactoryId());
         ((class_69)this.field_a).writeToTag(var1);
         return;
      default:
      }
   }

   public static class_79 a10(InputStream var0, boolean var1) {
      PushbackInputStream var5 = new PushbackInputStream(var0, 2);
      byte[] var2 = new byte[2];
      var5.read(var2);
      var5.unread(var2);
      DataInputStream var6;
      if(var2[0] == 31 && var2[1] == -117) {
         var6 = new DataInputStream(new GZIPInputStream(var5, 4096));
      } else {
         (var6 = new DataInputStream(new BufferedInputStream(var5, 4096))).readShort();
      }

      byte var7;
      class_79 var8;
      if((var7 = var6.readByte()) == 0) {
         var8 = new class_79(class_81.field_a, (String)null, (class_79[])null);
      } else {
         String var3 = var6.readUTF();

         try {
            var8 = new class_79(class_81.values()[var7], var3, a(var6, var7));
         } catch (IOException var4) {
            System.err.println("EXCEPTION WHILE READING TAG " + var3);
            throw var4;
         }
      }

      if(var1) {
         var6.close();
      }

      return var8;
   }

   public final void a11(OutputStream var1, boolean var2) {
      DataOutputStream var3;
      if(var1 instanceof DataOutputStream) {
         var3 = (DataOutputStream)var1;
      } else {
         var3 = new DataOutputStream(var1);
      }

      var3.writeShort(0);
      var3.writeByte(this.field_a.ordinal());
      if(this.field_a != class_81.field_a) {
         var3.writeUTF(this.field_a);
         this.a9(var3);
      }

      if(var2) {
         var1.close();
      }

   }

   static {
      new class_75();
   }
}
