import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import javax.vecmath.Vector3f;
import org.schema.game.client.view.SegmentDrawer;
import org.schema.game.common.controller.SegmentBufferManager;
import org.schema.game.common.controller.SegmentController;

public final class class_219 extends Thread {

   private Vector3f field_a;
   protected ArrayList field_a;
   private ArrayList field_b;
   private class_355 field_a;
   private class_309 field_a;
   private class_223 field_a;
   private class_217 field_a;
   public Object field_a;
   private HashSet field_a;
   private final Vector3f field_b;
   private Vector3f field_c;
   // $FF: synthetic field
   private static boolean field_a = !SegmentDrawer.class.desiredAssertionStatus();
   // $FF: synthetic field
   final SegmentDrawer field_a;


   public class_219(SegmentDrawer var1) {
      super("SegentSorter");
      this.field_a = var1;
      this.field_a = new Vector3f();
      this.field_a = new Object();
      this.field_a = new HashSet();
      this.field_b = new Vector3f();
      this.field_c = new Vector3f();
      this.setPriority(1);
      this.field_a = new class_355();
      this.field_a = new class_309();
      this.field_a = new ArrayList();
      this.field_b = new ArrayList();
      this.field_a = new class_223(this, (byte)0);
      this.field_a = new class_217(this, (byte)0);
   }

   public final void run() {
      while(!class_927.a1()) {
         try {
            this.field_b.set(class_967.a1().a83());
            class_355.a2(this.field_a).set(this.field_b);
            class_309.a2(this.field_a).set(this.field_b);
            this.field_a.field_a.set(this.field_b);
            System.currentTimeMillis();
            ArrayList var2;
            int var3;
            class_219 var4;
            synchronized(SegmentDrawer.a68(this.field_a)) {
               var2 = SegmentDrawer.a68(this.field_a);
               var4 = this;
               var3 = 0;

               while(true) {
                  if(var3 >= var2.size()) {
                     break;
                  }

                  SegmentController var5;
                  synchronized(((SegmentBufferManager)(var5 = (SegmentController)var2.get(var3)).getSegmentBuffer()).a26()) {
                     Iterator var7 = ((SegmentBufferManager)var5.getSegmentBuffer()).a26().values().iterator();

                     while(true) {
                        if(!var7.hasNext()) {
                           break;
                        }

                        class_890 var24 = (class_890)var7.next();
                        var4.field_b.add((class_888)var24);
                     }
                  }

                  ++var3;
               }
            }

            try {
               Collections.sort(this.field_b, this.field_a);
            } catch (Exception var11) {
               var11.printStackTrace();
               continue;
            }

            this.field_a.clear();
            var2 = this.field_b;
            var4 = this;
            this.field_a.field_a.field_i = 0L;
            class_353 var10000 = this.field_a.field_a;
            this.field_a.field_c = 0;
            this.field_a.clear();
            var3 = SegmentDrawer.field_a.field_a << 3;
            int var26 = 0;

            for(int var6 = 0; var6 < var2.size(); ++var6) {
               class_888 var29 = (class_888)var2.get(var6);
               if(var26 + var29.c() < var3) {
                  if(!(var29.a12() instanceof class_743) || !((class_743)var29.a12()).a7() || ((class_743)var29.a12()).a78().contains(SegmentDrawer.a71(var4.field_a).a20())) {
                     var26 += var29.c();
                     var29.b3(var4.field_a, true);
                  }
               } else if(var29.a16()) {
                  System.err.println("DEACTIVATING REGION: " + var29.a11() + " of " + var29.a12() + "; fill: " + var26);
                  var29.b3(var4.field_a, true);
               }
            }

            var10000 = var4.field_a.field_a;
            System.currentTimeMillis();
            this.field_b.clear();
            var10000 = this.field_a.field_a;
            System.currentTimeMillis();

            int var1;
            for(var1 = 0; var1 < this.field_a.size(); ++var1) {
               class_661 var17;
               (var17 = (class_661)this.field_a.get(var1)).a15().getAbsoluteSegmentWorldPositionClient(var17, this.field_c);
               this.field_c.sub(this.field_b);
               var17.field_a = this.field_c.lengthSquared();
            }

            try {
               Collections.sort(this.field_a, this.field_a);
            } catch (Exception var10) {
               var10.printStackTrace();
               System.err.println("[Exception] Catched: Resorting triggered by exception");
               continue;
            }

            var1 = 0;
            int var18 = 0;
            if(this.field_a.field_b.length != SegmentDrawer.field_a.field_a && !field_a) {
               throw new AssertionError();
            }

            for(Iterator var20 = this.field_a.iterator(); var20.hasNext(); ++var18) {
               class_661 var28 = (class_661)var20.next();
               if(var18 < SegmentDrawer.field_a.field_a - 100) {
                  class_661 var22 = this.field_a.field_b[var1];
                  this.field_a.field_d[var1] = var22;
                  this.field_a.field_b[var1] = var28;
                  this.field_a.field_b[var1].a5(this.field_a.field_b);
                  int var19 = var28.field_a;
                  if(var28.field_a == class_667.field_d || var28.field_a == class_667.field_e) {
                     var28.field_a = class_667.field_b;
                     var28.field_a = 0;
                     ((class_19)var28.a15().getSegmentProvider()).a13(var28);
                  }

                  ++var1;
               } else if(var28.b6()) {
                  this.field_a.add(var28);
                  var28.e(true);
               }
            }

            class_661[] var21 = this.field_a.field_a;
            synchronized(this.field_a.field_a) {
               class_661[] var25 = this.field_a.field_a;
               class_661[] var27 = this.field_a.field_c;
               SegmentDrawer.a69(this.field_a, var1);
               this.field_a.field_a = this.field_a.field_b;
               this.field_a.field_c = this.field_a.field_d;
               this.field_a.field_b = var25;
               this.field_a.field_d = var27;
               if(!field_a && this.field_a.field_b == this.field_a.field_a) {
                  throw new AssertionError("Pointers equal...");
               }
            }

            synchronized(SegmentDrawer.a65(this.field_a)) {
               SegmentDrawer.a65(this.field_a).addAll(this.field_a);
            }

            Object var23 = this.field_a;
            synchronized(this.field_a) {
               SegmentDrawer.a70(this.field_a);
               this.field_a.wait();
            }

            Thread.sleep(500L);
            ++this.field_a.field_b;
         } catch (InterruptedException var15) {
            var15.printStackTrace();
         } catch (Exception var16) {
            var16.printStackTrace();
         }
      }

   }

   // $FF: synthetic method
   static HashSet a(class_219 var0) {
      return var0.field_a;
   }

   // $FF: synthetic method
   static Vector3f a1(class_219 var0) {
      return var0.field_a;
   }

}
