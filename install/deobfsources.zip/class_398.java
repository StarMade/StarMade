import java.util.Collection;
import java.util.Iterator;
import org.lwjgl.opengl.GL11;
import org.schema.game.common.data.element.ElementCollection;
import org.schema.schine.graphicsengine.core.GlUtil;

public class class_398 implements class_923 {

   private Collection field_a;
   private class_801 field_a;
   private int field_a;
   private boolean field_a;
   // $FF: synthetic field
   private static boolean field_b = !dF.class.desiredAssertionStatus();


   public final void a() {}

   public final void a39(Collection var1, class_801 var2) {
      this.field_a = var1;
      this.field_a = var2;
      this.field_a = false;
   }

   public final void b() {
      if(this.field_a != null) {
         if(!this.field_a) {
            if(this.field_a != 0) {
               GL11.glDeleteLists(this.field_a, 1);
            }

            this.field_a = GL11.glGenLists(1);
            GL11.glNewList(this.field_a, 4864);
            GL11.glBegin(0);
            class_47 var2 = new class_47();
            Iterator var3 = this.field_a.iterator();

            while(var3.hasNext()) {
               ElementCollection.getPosFromIndex(((Long)var3.next()).longValue(), var2);
               var2.c(8, 8, 8);
               GL11.glVertex3f((float)var2.field_a, (float)var2.field_b, (float)var2.field_c);
            }

            GL11.glEnd();
            GL11.glEndList();
            this.field_a = true;
         }

         GlUtil.d1();
         GlUtil.b3(this.field_a.getWorldTransform());
         GL11.glBlendFunc(770, 771);
         GL11.glEnable(3042);
         GL11.glDisable(2929);
         GL11.glDisable(2896);
         GL11.glEnable(2903);
         GL11.glDisable(3553);
         GlUtil.a38(1.0F, 1.0F, 1.0F, 1.0F);
         if(!field_b && !this.field_a) {
            throw new AssertionError();
         } else {
            GL11.glCallList(this.field_a);
            GL11.glDisable(2903);
            GlUtil.a38(1.0F, 1.0F, 1.0F, 1.0F);
            GL11.glDisable(3042);
            GL11.glEnable(2929);
            GlUtil.c2();
         }
      }
   }

   public final void c() {}

}
