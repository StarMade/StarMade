import com.bulletphysics.collision.dispatch.CollisionWorld;
import com.bulletphysics.linearmath.Transform;
import javax.vecmath.Vector3f;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.data.physics.CubeRayCastResult;
import org.schema.game.common.data.physics.PhysicsExt;
import org.schema.schine.graphicsengine.camera.Camera;

public final class class_195 extends Camera implements class_952 {

   private class_371 field_a;
   private class_746 field_a;
   private Transform field_a;
   private CollisionWorld.ClosestRayResultCallback field_a;
   private Transform field_b;


   public class_195(class_371 var1, class_746 var2) {
      super(new class_299(var2));
      this.a82(var2);
      this.field_a = var1;
      this.field_a = new Transform();
      this.field_a.setIdentity();
      super.field_a = new class_1012(this);
   }

   public final class_746 a80() {
      return this.field_a;
   }

   public final void handleKeyEvent() {
      ((class_202)this.a184()).handleKeyEvent();
   }

   protected final int a81(int var1) {
      return Math.max(0, Math.min(var1, 2500));
   }

   public final void a82(class_746 var1) {
      this.field_a = var1;
      ((class_958)this.a184()).a141(var1);
   }

   public final void a12(class_935 var1) {
      Vector3f var3 = null;
      if(!this.field_a.getGravity().b() && !this.field_a.getGravity().a()) {
         this.field_b = null;
         ((class_1012)super.field_a).field_a.set(this.field_a);
      } else if(this.field_a.getGravity().a()) {
         ((class_1012)super.field_a).field_a.set(this.field_a.getGravity().field_a.getWorldTransform());
         this.field_b = null;
      } else {
         if(this.field_b == null) {
            this.field_b = new Transform(this.field_a.getGravity().field_a.getWorldTransform());
         }

         ((class_1012)super.field_a).field_a.set(this.field_b);
      }

      super.a12(var1);
      class_746 var2 = this.field_a;
      CollisionWorld.ClosestRayResultCallback var10001;
      if(super.field_a > 0.0F) {
         Vector3f var6 = new Vector3f(var2.a136().origin);
         var3 = new Vector3f(this.c16(new Vector3f()));
         CubeRayCastResult var4;
         (var4 = new CubeRayCastResult(var6, var3, Boolean.valueOf(false), (SegmentController)null)).setRespectShields(false);
         var4.onlyCubeMeshes = true;
         var10001 = ((PhysicsExt)this.field_a.a19()).testRayCollisionPoint(var6, var3, var4, false);
      } else {
         var10001 = null;
      }

      this.field_a = var10001;
      if(this.field_a != null && this.field_a.hasHit()) {
         Vector3f var5;
         (var5 = new Vector3f()).sub(this.c16(new Vector3f()), this.field_a.hitPointWorld);
         var5.scale(1.01F);
         this.getWorldTransform().origin.sub(var5);
      }

   }
}
