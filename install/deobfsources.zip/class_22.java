import java.util.Comparator;

final class class_22 implements Comparator {

   // $FF: synthetic field
   private class_19 field_a;


   class_22(class_19 var1) {
      this.field_a = var1;
      super();
   }

   // $FF: synthetic method
   public final int compare(Object var1, Object var2) {
      class_47 var10001 = (class_47)var1;
      class_47 var3 = (class_47)var2;
      class_47 var4 = var10001;
      return (int)(class_19.a17(this.field_a, var4) - class_19.a17(this.field_a, var3));
   }
}
