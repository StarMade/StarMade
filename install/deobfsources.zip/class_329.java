import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Collections;
import java.util.WeakHashMap;
import javax.vecmath.Vector2f;
import javax.vecmath.Vector3f;

public final class class_329 {

   public static FloatBuffer a(int var0) {
      FloatBuffer var1;
      (var1 = ByteBuffer.allocateDirect(4 * var0).order(ByteOrder.nativeOrder()).asFloatBuffer()).clear();
      return var1;
   }

   static {
      new Vector2f();
      new Vector3f();
      new class_35();
      Collections.synchronizedMap(new WeakHashMap());
   }
}
