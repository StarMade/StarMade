import org.schema.game.common.controller.EditableSendableSegmentController;

public interface class_457 {

   class_47 a();

   EditableSendableSegmentController a1();
}
