import java.util.Comparator;

enum class_180 {

   field_a("NAME", 0, new class_178()),
   field_b("PRICE", 1, new class_176()),
   field_c("RATING", 2, new class_174()),
   field_d("OWNER", 3, new class_139());
   Comparator field_a;
   // $FF: synthetic field
   private static final class_180[] field_a = new class_180[]{field_a, field_b, field_c, field_d};


   private class_180(String var1, int var2, Comparator var3) {
      this.field_a = var3;
   }

}
