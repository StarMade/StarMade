import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import java.util.concurrent.ConcurrentHashMap;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;
import org.schema.schine.network.objects.Sendable;

public final class class_242 extends class_964 implements Observer {

   private class_970 field_a = new class_970(class_967.a2().a5("panel-std-gui-"), this.a24());
   private class_966 field_a = new class_966(800.0F, 366.0F, this.a24());
   private class_963 field_a = new class_963(this.a24());
   private boolean field_a = true;
   private boolean field_b;
   private ConcurrentHashMap field_a = new ConcurrentHashMap();
   private float field_a;


   public class_242(ClientState var1) {
      super(var1);
      this.field_a.c6(this.field_a);
      this.a9(this.field_a);
      this.field_a.a9(this.field_a);
      this.field_a.a165(280.0F, 64.0F, 0.0F);
      ((class_371)var1).addObserver(this);
   }

   public final void a2() {}

   public final void b() {
      if(this.field_a) {
         this.c();
      }

      GlUtil.d1();
      this.r();
      this.field_a.b();
      GlUtil.c2();
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public final void c() {
      this.field_a.c();
      this.field_a.c();
      this.field_a = false;
      class_190 var1;
      (var1 = new class_190(this.a24())).a15("ID", "NAME", "TYPE", "sector", "...");
      class_972 var2 = new class_972(var1, var1, this.a24());
      this.field_a.a144(var2);
   }

   public final void update(Observable var1, Object var2) {
      this.field_b = true;
   }

   public final void a12(class_935 var1) {
      super.a12(var1);
      this.field_a += var1.a();
      if(this.field_a > 1.0F) {
         this.field_b = true;
         this.field_a = 0.0F;
      }

      if(this.field_b) {
         class_242 var2 = this;
         synchronized(this.a24().getLocalAndRemoteObjectContainer().getLocalObjects()) {
            var2.field_a.clear();
            var2.field_a.clear();
            Iterator var4 = var2.a24().getLocalAndRemoteObjectContainer().getLocalObjects().values().iterator();

            while(true) {
               if(!var4.hasNext()) {
                  break;
               }

               Sendable var5 = (Sendable)var4.next();
               if(!var2.field_a.containsKey(var5)) {
                  var2.field_a.a144(new class_240(var2, var5, var2.a24()));
               }
            }
         }

         var2.field_a.e();
         this.field_b = false;
      }

      for(int var7 = 0; var7 < this.field_a.size(); ++var7) {
         this.field_a.a145(var7).a12(var1);
      }

   }

   // $FF: synthetic method
   static ConcurrentHashMap a107(class_242 var0) {
      return var0.field_a;
   }
}
