import org.schema.schine.network.client.ClientState;

final class class_246 extends class_1402 {

   // $FF: synthetic field
   private class_244 field_a;


   class_246(class_244 var1, ClientState var2) {
      this.field_a = var1;
      super(var2);
   }

   protected final boolean b3() {
      return this.field_a.field_a.b2();
   }

   protected final void f() {
      this.field_a.field_a.a189(false, 1);
   }

   protected final void e() {
      this.field_a.field_a.a189(true, 1);
   }
}
