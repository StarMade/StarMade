
public final class class_458 extends class_456 {

   public class_458(class_1001 var1, class_1001 var2, class_1001 var3, class_371 var4) {
      super(var1, var2, var3, var4);
   }

   protected final class_1001 a(class_1001 var1) {
      class_442 var2 = new class_442(super.field_a.a8(), "Press \'" + class_367.field_H.b1() + "\' to enter \nyour inventory.", this.field_a);
      class_300 var3 = new class_300(super.field_a.a8(), this.field_a, "Good!\nHere you see all the building\nmodules you currently have.\n", 8000);
      class_300 var4 = new class_300(super.field_a.a8(), this.field_a, "You can drag and stack item\n", 8000);
      class_300 var5 = new class_300(super.field_a.a8(), this.field_a, "To take a custom amount of an item,\nright-click on it.", 12000);
      class_300 var6 = new class_300(super.field_a.a8(), this.field_a, "You can also drag them in the\naction bar at the bottom to assign them\nto the respective number on your keyboard.", 12000);
      this.a2(var1, var2);
      this.a2(var2, var3);
      this.a2(var3, var4);
      this.a2(var4, var5);
      this.a2(var5, var6);
      return var6;
   }

   public final void a1() {
      super.field_b = new class_300(super.field_a.a8(), this.field_a, "Let\'s go on to learn about the inventory", 8000);
      super.field_c = new class_444(super.field_a.a8(), "when you are done, press \'" + class_367.field_H.b1() + "\' again \nto exit from your inventory", this.field_a);
   }
}
