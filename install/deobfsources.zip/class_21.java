
public final class class_21 {

   public final class_19 field_a;
   public final class_675 field_a;


   public class_21(class_19 var1, class_675 var2) {
      this.field_a = var1;
      this.field_a = var2;
   }
}
