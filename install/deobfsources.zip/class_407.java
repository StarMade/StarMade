import java.util.regex.Pattern;

final class class_407 implements class_954 {

   public final boolean a(String var1, class_1077 var2) {
      if(var1.length() >= 6 && var1.length() < 24) {
         if(Pattern.matches("[a-zA-Z0-9 _-]+", var1)) {
            return true;
         }

         System.err.println("MATCH FOUND ^ALPHANUMERIC");
      }

      var2.onFailedTextCheck("Please only alphanumeric (and space, _, -) values \nand between 6 and 24 long!");
      return false;
   }
}
