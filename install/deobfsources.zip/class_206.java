import java.util.ArrayList;
import org.schema.schine.network.client.ClientState;

public final class class_206 extends class_932 {

   private class_940 field_a;
   private class_928 field_a;
   private boolean field_a;
   private final int field_a;


   public class_206(ClientState var1, int var2) {
      super(var1);
      super.field_g = true;
      this.field_a = var2;
      this.field_a = new class_940(30, 30, class_28.e(), this.a24());
   }

   public final class_433 a11() {
      class_443 var1;
      return (var1 = ((class_371)this.a24()).a14().field_a.field_a.field_a).a51().a45().field_a.field_c?var1.a51().a45().field_a.a70():var1.a53().a36().a70();
   }

   public final void a2() {}

   protected final void d() {}

   public final void b() {
      if(!this.field_a) {
         this.c();
      }

      super.k();
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return 100.0F;
   }

   public final void c() {
      this.field_a.field_b = new ArrayList();
      switch(this.field_a) {
      case 1:
         this.field_a.field_b.add("XY-Plane");
         break;
      case 2:
         this.field_a.field_b.add("XZ-Plane");
      case 3:
      default:
         break;
      case 4:
         this.field_a.field_b.add("YZ-Plane");
      }

      this.field_a.c();
      this.field_a = new class_928(this.a24(), 70, 20, new class_208(this), new class_210(this));
      this.field_a.a83().field_x = 40.0F;
      this.a9(this.field_a);
      this.field_a = true;
   }

   // $FF: synthetic method
   static int a86(class_206 var0) {
      return var0.field_a;
   }
}
