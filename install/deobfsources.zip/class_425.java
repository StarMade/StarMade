
public final class class_425 extends class_15 {

   public class_425(class_371 var1) {
      super(var1);
   }
}
