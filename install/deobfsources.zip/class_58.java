import java.io.Serializable;

public class class_58 implements Serializable {

   private static final long serialVersionUID = -6331218458640407293L;
   private Object field_a;
   class_54 field_a;


   public class_58(Object var1, class_54 var2) {
      this.field_a = var1;
      this.field_a = var2;
   }

   public final Object a() {
      return this.field_a;
   }

   public String toString() {
      return this.field_a.toString();
   }
}
