import java.io.IOException;
import java.util.ArrayList;
import org.schema.game.common.data.world.DeserializationException;

public final class class_16 extends Thread {

   private ArrayList field_a = new ArrayList();


   public class_16() {
      super("LocalSegmentRetriever");
   }

   public final void a(class_21 var1) {
      ArrayList var2 = this.field_a;
      synchronized(this.field_a) {
         this.field_a.add(var1);
         this.field_a.notify();
      }
   }

   private class_21 a1() {
      ArrayList var1 = this.field_a;
      synchronized(this.field_a) {
         while(this.field_a.isEmpty()) {
            try {
               this.field_a.wait();
            } catch (InterruptedException var3) {
               var3.printStackTrace();
            }
         }

         return (S)this.field_a.remove(0);
      }
   }

   public final void run() {
      while(true) {
         class_21 var1;
         class_675 var2 = (var1 = this.a1()).field_a;
         boolean var4 = false;

         int var3;
         try {
            var3 = var1.field_a.a9(var2);
         } catch (IOException var7) {
            var7.printStackTrace();
            System.err.println("CORRUPT SEGMENT DATA: RELOADING FROM SERVER. Writing Jobs: " + class_19.field_a);
            var4 = true;
            var3 = 0;
         } catch (DeserializationException var8) {
            var8.printStackTrace();
            System.err.println("CORRUPT SEGMENT DATA: RELOADING FROM SERVER. Writing Jobs: " + class_19.field_a);
            var4 = true;
            var3 = 0;
         }

         if(!var4 && var3 != 2) {
            if(var3 == 1 && var2.field_a.field_a == 0 && var2.field_a.field_b == 0 && var2.field_a.field_c == 0) {
               System.err.println("[CLIENT][DB-READ] WARNING 0,0,0 on " + var1.field_a.a26() + " IS EMPTY");
            }

            synchronized(var1.field_a.a4()) {
               var1.field_a.a4().add(var2);
            }
         } else {
            if(var4) {
               System.err.println("[CLIENT][SEGMENTPROVIDER][WARNING] Requesting corrupt segment!! " + var2.field_a + ": " + var2.a15());
            } else {
               System.err.println("[CLIENT][SEGMENTPROVIDER][WARNING] VersionOK but no data in DB! Re-Requesting segment from server!! " + var2.field_a + ": " + var2.a15());
            }

            synchronized(var1.field_a.c2()) {
               var1.field_a.c2().add(new class_47(var2.field_a));
            }
         }
      }
   }
}
