
final class class_326 implements class_951 {

   // $FF: synthetic field
   private class_322 field_a;


   class_326(class_322 var1) {
      this.field_a = var1;
      super();
   }

   public final void a(String var1) {
      try {
         ((class_320)this.field_a.field_a).field_a = Integer.parseInt(var1);
      } catch (Exception var2) {
         ;
      }
   }
}
