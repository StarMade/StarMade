
public final class class_412 extends class_14 {

   // $FF: synthetic field
   private class_423 field_a;


   public class_412(class_423 var1, class_371 var2, Object var3, Object var4) {
      this.field_a = var1;
      super(var2, 50, var3, var4);
   }

   public final boolean a1() {
      return false;
   }

   public final void onFailedTextCheck(String var1) {}

   public final String handleAutoComplete(String var1, class_1077 var2, String var3) {
      return null;
   }

   public final String[] getCommandPrefixes() {
      return null;
   }

   public final boolean a7(String var1) {
      if(super.field_a.a20().h1() != 0) {
         class_765 var2 = new class_765(super.field_a.getPlayerName(), var1, super.field_a.a20().h1(), System.currentTimeMillis());
         super.field_a.a45().c16(var2);
         super.field_a.a4().d1("Invitation sent to " + var1);
      }

      return true;
   }

   public final void a2() {
      this.field_a.e2(false);
   }
}
