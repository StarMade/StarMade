import org.schema.schine.graphicsengine.core.settings.StateParameterNotFoundException;

final class class_124 implements class_1410 {

   // $FF: synthetic field
   private class_126 field_a;


   class_124(class_126 var1) {
      this.field_a = var1;
      super();
   }

   public final void a(class_964 var1, class_941 var2) {
      var1 = null;
      if(var2.field_a && var2.field_a == 0) {
         try {
            class_126.a34(this.field_a).c1();
            class_126.a35(this.field_a);
            return;
         } catch (StateParameterNotFoundException var3) {
            var3.printStackTrace();
            class_927.a2(var3);
         }
      }

   }

   public final boolean a1() {
      return false;
   }
}
