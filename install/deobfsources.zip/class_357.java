import java.util.Comparator;
import javax.vecmath.Vector3f;

public final class class_357 implements Comparator {

   private final Vector3f field_a;


   public class_357() {
      new Vector3f();
      this.field_a = new Vector3f();
   }

   public final synchronized int a(class_661 var1, class_661 var2) {
      return var1 != var2 && !var1.equals(var2)?Float.compare(var1.field_a, var2.field_a):0;
   }

   // $FF: synthetic method
   public final int compare(Object var1, Object var2) {
      return this.a((class_661)var1, (class_661)var2);
   }

   // $FF: synthetic method
   static Vector3f a1(class_357 var0) {
      return var0.field_a;
   }
}
