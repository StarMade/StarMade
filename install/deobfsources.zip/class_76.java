import com.bulletphysics.linearmath.Transform;

public interface class_76 extends class_68, class_1432, class_1419 {

   String a();

   String b();

   float b1();

   Transform getWorldTransformClient();
}
