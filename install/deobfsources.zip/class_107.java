
final class class_107 implements class_1410 {

   // $FF: synthetic field
   private class_762 field_a;
   // $FF: synthetic field
   private class_117 field_a;


   class_107(class_117 var1, class_762 var2) {
      this.field_a = var1;
      this.field_a = var2;
      super();
   }

   public final boolean a1() {
      return false;
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.a()) {
         if(!class_112.a21(this.field_a.field_a).field_a.equals(((class_371)this.field_a.a24()).a20().getName())) {
            if(!class_117.a31(this.field_a).a171().b10(this.field_a.field_a)) {
               ((class_371)this.field_a.a24()).a4().b1("You don\'t have kick permission!");
            } else if(this.field_a.field_a <= class_112.a21(this.field_a.field_a).field_a) {
               ((class_371)this.field_a.a24()).a4().b1("You cannot kick\nhigher ranked players!");
            } else {
               class_117.a31(this.field_a).a167(this.field_a.field_a, class_112.a21(this.field_a.field_a).field_a, ((class_371)this.field_a.a24()).a12());
            }

            this.field_a.field_a.d();
            return;
         }

         ((class_371)this.field_a.a24()).a4().b1("You cannot kick yourself");
      }

   }
}
