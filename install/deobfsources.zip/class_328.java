import org.lwjgl.input.Keyboard;
import org.schema.game.common.controller.EditableSendableSegmentController;

public final class class_328 extends class_15 implements class_457 {

   public class_332 field_a;
   public class_453 field_a = new class_453(this.a6(), this);


   public class_328(class_371 var1) {
      super(var1);
      super.field_a.add(this.field_a);
      this.field_a = new class_332(this);
      super.field_a.add(this.field_a);
   }

   public final class_47 a35() {
      return new class_47(class_743.field_a);
   }

   public final class_453 a36() {
      return this.field_a;
   }

   public final EditableSendableSegmentController a37() {
      return this.a6().a25();
   }

   public final class_332 a38() {
      return this.field_a;
   }

   public final void handleKeyEvent() {
      super.handleKeyEvent();
      if(Keyboard.getEventKeyState() && Keyboard.getEventKey() == class_367.field_r.a5()) {
         boolean var2 = this.field_a.field_b;
         this.field_a.c2(var2);
         this.field_a.c2(!var2);
      }

   }

   public final void a12(class_941 var1) {
      super.a12(var1);
   }

   public final void b2(boolean var1) {
      if(var1 && !this.field_a.field_b && !this.field_a.field_b) {
         this.field_a.c2(true);
      }

      super.b2(var1);
   }

   public final void a15(class_935 var1) {
      if(this.a6().a25() != null) {
         super.a15(var1);
      }
   }
}
