import javax.vecmath.Vector3f;
import org.schema.schine.graphicsengine.core.GlUtil;

public final class class_299 extends class_958 {

   public class_299(class_1432 var1) {
      super(var1);
   }

   public final Vector3f a83() {
      Vector3f var1 = super.a83();
      Vector3f var2;
      (var2 = GlUtil.f(new Vector3f(), this.field_a)).scale(0.485F);
      var1.add(var2);
      return var1;
   }
}
