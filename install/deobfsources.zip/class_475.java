import java.util.HashSet;
import java.util.Iterator;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public final class class_475 extends class_15 {

   public static final HashSet field_b = new HashSet();
   private long field_b;


   public class_475(class_371 var1) {
      super(var1);
   }

   public final void handleKeyEvent() {
      super.handleKeyEvent();
      if(Keyboard.getEventKeyState() && Keyboard.getEventKey() == 88) {
         this.a6().a4().a29().a8().a(new class_47(0, 0, 0));
      }

      this.a6().a27().a101().handleKeyEvent();
   }

   public final void a12(class_941 var1) {
      if(var1.field_a && var1.field_a == 0) {
         boolean var2 = System.currentTimeMillis() - this.field_b < 300L;

         class_347 var4;
         for(Iterator var3 = field_b.iterator(); var3.hasNext(); System.err.println("[CLIENT][MAPMANAGER] clicked on " + var4)) {
            var4 = (class_347)var3.next();
            if(var2) {
               class_47 var5 = this.a6().a27().a101().a29().field_b;
               class_337 var6 = (class_337)var4;
               this.a6().a27().a101().a29().a1((int)(var6.a8().field_x / 6.25F) + (var5.field_a << 4), (int)(var6.a8().field_y / 6.25F) + (var5.field_b << 4), (int)(var6.a8().field_z / 6.25F) + (var5.field_c << 4), false);
            }
         }

         this.field_b = System.currentTimeMillis();
      }

      super.a12(var1);
   }

   public final void b2(boolean var1) {
      System.err.println("MAP CONTROL MANAGER ACTIVE: " + var1);
      if(var1) {
         class_967.b("0022_menu_ui - swoosh scroll large");
         this.a6().a4().a29().a8().a(new class_47(0, 0, 0));
      } else {
         class_967.b("0022_menu_ui - swoosh scroll small");
      }

      this.a6().a14().field_a.field_a.field_a.a51().a45().field_a.e2(var1);
      this.a6().a14().field_a.field_a.field_a.a51().a45().field_a.e2(var1);
      if(var1) {
         this.a6().a27().a101().d();
      }

      super.b2(var1);
   }

   public final void a15(class_935 var1) {
      class_1008.field_a = Mouse.isButtonDown(1);
      this.a6().a14().field_a.field_a.field_a.e2(true);
   }

}
