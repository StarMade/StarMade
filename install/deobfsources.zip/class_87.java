import org.schema.schine.network.client.ClientState;

final class class_87 extends class_1402 {

   // $FF: synthetic field
   private class_85 field_a;


   class_87(class_85 var1, ClientState var2) {
      this.field_a = var1;
      super(var2);
   }

   protected final void e() {
      this.field_a.a10().field_d = false;
   }

   protected final void f() {
      this.field_a.a10().field_d = true;
   }

   protected final boolean b3() {
      return !this.field_a.a10().field_d;
   }
}
