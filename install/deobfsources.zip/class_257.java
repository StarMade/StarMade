import java.util.ArrayList;
import javax.vecmath.Vector4f;
import org.newdawn.slick.Color;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public final class class_257 extends class_42 {

   private class_970 field_a;
   private class_194 field_a;
   private class_194 field_b;
   private class_966 field_a;
   private static class_1414 field_a;
   private boolean field_a;
   private class_41 field_a;
   private String field_b;
   private float field_a = 0.0F;
   private class_940 field_a;
   private class_940 field_b;
   private class_940 field_c;
   private Vector4f field_a;
   private String field_c;


   public class_257(ClientState var1, class_41 var2, String var3, String var4) {
      super(var1);
      this.field_a = var2;
      this.field_c = var4;
      this.field_a = new class_970(class_967.a2().a5("info-panel-gui-"), var1);
      this.field_a = new class_966(363.0F, 110.0F, var1);
      this.field_b = var3;
      this.field_a = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F - this.field_a);
   }

   public final void a2() {}

   public final void b() {
      if(!this.field_a) {
         this.c();
      }

      GlUtil.d1();
      this.r();
      this.field_a.set(1.0F, 1.0F, 1.0F, 1.0F - this.field_a);
      this.field_a.a151().c7(this.field_a);
      this.field_a.a151().c7(this.field_a);
      this.field_a.a136(new Color(this.field_a.field_x, this.field_a.field_y, this.field_a.field_z, this.field_a.field_w));
      this.field_a.b();
      this.field_a.a151().c7((Vector4f)null);
      this.field_a.a151().c7((Vector4f)null);
      this.field_a.a136(new Color(1, 1, 1, 1));
      GlUtil.c2();
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public final void c() {
      this.field_a = new class_940(220, 100, class_28.n(), this.a24());
      this.field_a.field_b = new ArrayList();
      this.field_a.field_b.add(this.field_b);
      this.field_b = new class_940(200, 30, class_28.d(), this.a24());
      this.field_b.field_b = new ArrayList();
      this.field_b.field_b.add(this.field_c);
      this.field_c = new class_940(200, 30, class_28.k(), this.a24());
      this.field_c.field_b = new ArrayList();
      this.field_c.field_b.add("(click to drag)");
      this.field_a = new class_194(class_967.a2().a5("buttons-8x8-gui-"), this.a24(), class_319.field_c, "OK", this.field_a);
      this.field_b = new class_194(class_967.a2().a5("buttons-8x8-gui-"), this.a24(), class_319.field_d, "CANCEL", this.field_a);
      if(field_a == null) {
         field_a = new class_1414(this.a24(), this.field_a);
         this.field_a.h2(48);
      } else {
         this.field_a.a83().set(field_a.field_a.a83());
         field_a = new class_1414(this.a24(), this.field_a);
      }

      this.field_a.c6(this.field_a);
      this.field_a.a9(this.field_b);
      this.field_a.a9(this.field_c);
      this.field_a.a9(this.field_a);
      this.field_a.a9(this.field_a);
      this.field_a.a9(field_a);
      this.field_b.a165(14.0F, 10.0F, 0.0F);
      this.field_c.a165(280.0F, 15.0F, 0.0F);
      this.field_a.a165(23.0F, 42.0F, 0.0F);
      this.field_a.b29(0.5F, 0.5F, 0.5F);
      this.field_b.b29(0.5F, 0.5F, 0.5F);
      this.field_a.a165(330.0F, 158.0F, 0.0F);
      this.field_b.a165(220.0F, 158.0F, 0.0F);
      this.field_a = true;
   }

   public final void a(float var1) {
      this.field_a = var1;
   }
}
