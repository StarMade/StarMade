import java.util.ArrayList;
import org.lwjgl.input.Mouse;
import org.newdawn.slick.Color;
import org.newdawn.slick.UnicodeFont;
import org.schema.game.common.data.element.ElementKeyMap;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public class class_161 extends class_964 {

   private class_185[] field_a = new class_185[256];
   private class_940[] field_a = new class_940[256];
   private class_970 field_a;
   private class_185 field_a;
   private class_940 field_a;
   private class_635 field_a;
   // $FF: synthetic field
   private static boolean field_a = !hN.class.desiredAssertionStatus();


   public class_161(class_371 var1) {
      super(var1);
      this.field_a = a53(class_28.e(), var1);
      this.field_a = new class_185(var1, false, this);
      this.field_a.a9(this.field_a);
      this.field_a.b29(1.0F, 1.0F, 1.0F);

      for(int var2 = 0; var2 < this.field_a.length; ++var2) {
         this.field_a[var2] = a53(class_28.e(), var1);
         this.field_a[var2] = new class_185(var1, true, this);
         this.field_a[var2].a9(this.field_a[var2]);
         this.field_a[var2].b29(1.0F, 1.0F, 1.0F);
      }

      this.field_a = new class_970(class_967.a2().a5("build-icons-00-16x16-gui-"), var1);
   }

   public final void a2() {}

   public final void b() {
      GlUtil.d1();
      if(((class_371)this.a24()).a14().field_a.field_a.field_a.a51().a45().field_a != null) {
         this.r();

         for(int var1 = this.field_a.a3(); var1 < this.field_a.b4(); ++var1) {
            if(!field_a && var1 < this.field_a.a3()) {
               throw new AssertionError();
            }

            short var2 = 0;
            int var3 = 511;
            int var4 = 0;
            if(!this.field_a.a18(var1)) {
               var2 = this.field_a.a45(var1);
               var4 = this.field_a.a41(var1);
               var3 = ElementKeyMap.getInfo(var2).getBuildIconNum();
            }

            int var5 = (var1 - this.field_a.a3()) / 7;
            int var6 = (var1 - this.field_a.a3()) % 7;
            this.l();
            GlUtil.d1();
            this.field_a[var1].f4(var1);
            this.field_a[var1].a74(var2);
            this.field_a[var1].a72(var4);
            int var7;
            if((var7 = this.field_a[var1].a68(false)) > 0) {
               this.field_a[var1].field_b.set(0, String.valueOf(var7));
            } else {
               var3 = 511;
               this.field_a[var1].field_b.set(0, "");
            }

            this.field_a[var1].b20(false);
            this.field_a[var1].a83().field_y = 3.0F + (float)var5 * 72.0F;
            this.field_a[var1].a83().field_x = 3.0F + (float)var6 * 72.0F;
            var7 = var3 / 256;
            this.field_a[var1].e4(var7);
            short var8 = (short)(var3 % 256);
            this.field_a[var1].a151().b13(var8);
            this.field_a[var1].b();
            GlUtil.c2();
         }

         this.field_a[0].a151().b13(0);
         GlUtil.c2();
      }
   }

   public final void a48(class_185 var1) {
      class_964.i();
      this.field_a.a165((float)(Mouse.getX() - var1.a57()), (float)(class_927.a() - Mouse.getY() - var1.b12()), 0.0F);
      int var2;
      int var3 = (var2 = ElementKeyMap.getInfo(var1.a70()).getBuildIconNum()) / 256;
      this.field_a.e4(var3);
      var2 %= 256;
      this.field_a.a_2(var2);
      this.field_a.field_b.set(0, String.valueOf(var1.a68(true)));
      this.field_a.b();
      class_964.h1();
   }

   public final void e() {
      GlUtil.d1();

      for(int var1 = 0; var1 < this.field_a.length; ++var1) {
         this.field_a[var1].e();
      }

      GlUtil.c2();
   }

   public final float a3() {
      return ((class_964)this.a158()).a3();
   }

   public final class_635 a52() {
      return this.field_a;
   }

   public final float b1() {
      return ((class_964)this.a158()).b1();
   }

   private static class_940 a53(UnicodeFont var0, ClientState var1) {
      class_940 var2;
      (var2 = new class_940(32, 32, var0, var1)).a136(Color.white);
      var2.field_b = new ArrayList();
      var2.field_b.add("undefined");
      var2.a165(2.0F, 2.0F, 0.0F);
      return var2;
   }

   public final boolean a_() {
      return super.a_() && (this.a158() == null || ((class_964)this.a158()).a_());
   }

   public final void c() {
      for(int var1 = 0; var1 < this.field_a.length; ++var1) {
         this.field_a[var1].c();
         this.field_a[var1].c();
      }

      this.field_a.c();
      this.field_a.c();
      this.field_a.c();
   }

   public final void a54(class_635 var1) {
      this.field_a = var1;
   }

}
