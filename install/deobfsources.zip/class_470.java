
public final class class_470 extends class_456 {

   private static class_956 field_a = new class_381();
   private class_435 field_a;


   public class_470(class_1001 var1, class_1001 var2, class_1001 var3, class_371 var4) {
      super(var1, var2, var3, var4);
   }

   protected final class_1001 a(class_1001 var1) {
      class_302 var2 = new class_302(super.field_a.a8(), "Please press \'" + class_367.field_G.b1() + "\' to open the shop!\n", this.field_a);
      class_401 var3 = new class_401(super.field_a.a8(), this.field_a, "Very Good!\nThis is the shop screen!\nLook around for a bit!\n", 10000);
      class_300 var4 = new class_300(super.field_a.a8(), this.field_a, "Shops can only be accessed,\nwhen you are near a shop\nand you see the [SHOP] sign\non top of you screen", 10000);
      class_300 var5 = new class_300(super.field_a.a8(), this.field_a, "You can read more about every\nelement, if you click on it.\n", 6000);
      class_300 var6 = new class_300(super.field_a.a8(), this.field_a, "Every shop has an individual stock of items.\nThe price of an item is relative to\nthe amount in stock (demand)\n", 6000);
      class_300 var7 = new class_300(super.field_a.a8(), this.field_a, "To buy or sell,\njust click on an element you like,\nand use the respective buttons, \nor drag items into the shop\n", 9000);
      class_448 var8 = new class_448(super.field_a.a8(), "when you are done, press \'b\' again \nto exit the shop screen", this.field_a);
      class_300 var9 = new class_300(super.field_a.a8(), this.field_a, "There is an infinite amount of shops\nscattered all over the universe.\nIf this one runs out of stock, try to find another one.\n", 0);
      class_300 var10 = new class_300(super.field_a.a8(), this.field_a, "You can also profit by buying an item\nfrom a shop with good stock,\nand selling it to a shop that is currently\nout of that item.", 0);
      this.a4(var1, this.field_a, super.field_b);
      this.a2(this.field_a, var2);
      this.a2(var2, var3);
      this.a2(var3, var4);
      this.a2(var4, var5);
      this.a2(var5, var6);
      this.a2(var6, var7);
      this.a2(var7, var8);
      this.a4(var8, var9, var7);
      this.a2(var9, var10);
      return var10;
   }

   public final void a1() {
      this.field_a = new class_435(super.field_a.a8(), "You are not in Range of a Shop\nPlease go to the next Shop\n(follow the purple indicator)", this.field_a);
      super.field_b = new class_300(super.field_a.a8(), this.field_a, "Awesome!\nNow let\'s do some shopping!", 5000);
      super.field_c = new class_300(super.field_a.a8(), this.field_a, "Very Good!\nYou have completed the shop introduction!\n", 5000);
   }

   protected final void a2(class_1001 var1, class_1001 var2) {
      super.a2(var1, var2);
      var1.a9(field_a, this.field_a);
   }

}
