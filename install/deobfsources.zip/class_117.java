import javax.vecmath.Vector4f;
import org.schema.game.common.data.player.faction.FactionNotFoundException;
import org.schema.schine.network.client.ClientState;

final class class_117 extends class_196 {

   private class_928 field_a;
   private class_105[] field_a;
   private class_777 field_a;
   // $FF: synthetic field
   final class_112 field_a;


   public class_117(class_112 var1, ClientState var2, class_1410 var3, Object var4, Object var5, class_777 var6) {
      super(var2, var3, var4, var5);
      this.field_a = var1;
      this.field_a = new class_105[5];
      this.field_a = var6;
      super.field_a = false;
   }

   public final void a2() {}

   public final void b() {
      int var1 = ((class_371)this.a24()).a20().a132().a3();
      if(((class_371)this.a24()).a12().a51().a146(var1) == this.field_a) {
         super.b();
      } else {
         this.field_a.d();
      }
   }

   public final void c() {
      super.c();

      try {
         int var2 = ((class_371)this.a24()).a20().a132().a3();
         class_777 var3;
         if((var3 = ((class_371)this.a24()).a12().a51().a146(var2)) == null) {
            throw new FactionNotFoundException(Integer.valueOf(var2));
         } else {
            class_762 var1;
            if((var1 = (class_762)var3.a154().get(((class_371)this.a24()).a20().getName())) == null) {
               throw new FactionNotFoundException(Integer.valueOf(var2));
            } else {
               if(var1.b23(this.field_a)) {
                  this.field_a = new class_928(this.a24(), 50, 20, new Vector4f(0.5F, 0.0F, 0.0F, 1.0F), new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), class_28.h(), "Kick", new class_107(this, var1));
                  this.field_a.a165(340.0F, 0.0F, 0.0F);
                  this.field_a.a9(this.field_a);
               }

               if(var1.d7(this.field_a)) {
                  class_1412 var6 = new class_1412(this.a24());
                  class_940 var8;
                  (var8 = new class_940(100, 20, this.a24())).a137("Choose a role for this player");

                  for(int var4 = 0; var4 < 5; ++var4) {
                     this.field_a[var4] = new class_105(this.field_a, this.a24(), var4);
                     this.field_a[var4].c();
                     this.field_a[var4].a83().field_x = (float)(var4 * 130 % 390);
                     this.field_a[var4].a83().field_y = (float)(var4 / 3 * 30 + 20);
                     var6.a9(this.field_a[var4]);
                  }

                  var6.a9(var8);
                  class_966 var9;
                  (var9 = new class_966(406.0F, 80.0F, this.a24())).c6(var6);
                  var9.a83().field_y = 25.0F;
                  this.field_a.a9(var9);
               }

               if(!var1.b23(this.field_a) && !var1.d7(this.field_a)) {
                  class_940 var7;
                  (var7 = new class_940(100, 20, this.a24())).a137("You don\'t have permission to edit this member!");
                  this.field_a.a9(var7);
               }

            }
         }
      } catch (FactionNotFoundException var5) {
         var5.printStackTrace();
         this.field_a.d();
      }
   }

   public final float a3() {
      return 0.0F;
   }

   public final float b1() {
      return 0.0F;
   }

   // $FF: synthetic method
   static class_777 a31(class_117 var0) {
      return var0.field_a;
   }
}
