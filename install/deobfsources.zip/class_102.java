import org.schema.schine.network.client.ClientState;

final class class_102 extends class_1402 {

   // $FF: synthetic field
   private class_244 field_a;


   class_102(class_244 var1, ClientState var2) {
      this.field_a = var1;
      super(var2);
   }

   protected final boolean b3() {
      return this.field_a.field_a.d10();
   }

   protected final void f() {
      this.field_a.field_a.a189(false, 16);
   }

   protected final void e() {
      this.field_a.field_a.a189(true, 16);
   }
}
