import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public final class class_24 extends class_15 {

   private class_17 field_a;
   public class_467 field_a;
   public class_477 field_a;
   public class_25 field_a;
   public class_23 field_a;
   public boolean field_d;


   public class_24(class_371 var1) {
      super(var1);
   }

   public final void b() {
      if(!class_843.b3()) {
         boolean var1 = this.field_a.field_b;
         this.field_a.c2(var1);
         if(!var1 && this.field_a.field_b) {
            this.field_a.c2(false);
         }

         this.field_a.c2(!var1);
         if(!this.field_a.field_b) {
            synchronized(this.a6().b()) {
               for(int var2 = 0; var2 < this.a6().b().size(); ++var2) {
                  if((class_11)this.a6().b().get(var2) instanceof class_1) {
                     ((class_11)this.a6().b().get(var2)).d();
                     break;
                  }
               }

            }
         }
      }
   }

   public final class_23 a17() {
      return this.field_a;
   }

   public final class_467 a18() {
      return this.field_a;
   }

   public final class_25 a19() {
      return this.field_a;
   }

   public final void handleKeyEvent() {
      super.handleKeyEvent();
      if(Keyboard.isKeyDown(15)) {
         this.field_a.handleKeyEvent();
      }

      if(!this.field_a.field_b) {
         this.b1();
      }

      if(Keyboard.getEventKeyState()) {
         if(Keyboard.getEventKey() == class_367.field_P.a5()) {
            class_1008.field_b = !class_1008.field_b;
         } else if(Keyboard.getEventKey() == class_367.field_W.a5() && !Keyboard.isKeyDown(15)) {
            class_227.field_c = true;
         } else if(Keyboard.getEventKey() == class_367.field_X.a5() && !Keyboard.isKeyDown(15)) {
            class_227.field_d = true;
         }

         boolean var1;
         switch(Keyboard.getEventKey()) {
         case 1:
            if(class_943.field_aa.b1()) {
               System.err.println("ESCAPE: EXIT: " + class_943.field_aa.b1());
               class_927.a3();
               return;
            }

            if(!this.field_a.field_a.field_a.field_a && this.field_a.field_a.field_a.field_b) {
               this.b();
               return;
            }

            System.err.println("DEACTIVATING ALL");
            this.field_a.field_a.b();
            return;
         case 37:
            if(this.a6().a4().a5() != null && this.a6().b().isEmpty()) {
               this.a6().a4().a5().f();
               return;
            }
            break;
         case 59:
            var1 = this.field_a.field_b;
            this.field_a.c2(!var1);
            return;
         case 78:
            var1 = this.field_a.field_b;
            this.field_a.c2(var1);
            if(!var1 && this.field_a.field_b) {
               this.field_a.c2(false);
            }

            this.field_a.c2(!var1);
            if(!this.field_a.field_b) {
               synchronized(this.a6().b()) {
                  for(int var2 = 0; var2 < this.a6().b().size(); ++var2) {
                     if((class_11)this.a6().b().get(var2) instanceof class_3) {
                        ((class_11)this.a6().b().get(var2)).d();
                        break;
                     }
                  }

                  return;
               }
            }
            break;
         case 199:
            if(this.a6().a4().a5() != null && this.a6().b().isEmpty()) {
               this.a6().a4().a5().e();
               return;
            }
            break;
         case 207:
            if(this.a6().a4().a5() != null && this.a6().b().isEmpty()) {
               this.a6().a4().a5().c();
               return;
            }
            break;
         case 210:
            if(this.a6().a4().a5() != null && this.a6().b().isEmpty()) {
               this.a6().a4().a5().d();
               return;
            }
            break;
         case 211:
            if(this.a6().a4().a5() != null && this.a6().b().isEmpty()) {
               this.a6().a4().a5().b();
               return;
            }
         }
      }

   }

   public final void a12(class_941 var1) {
      super.a12(var1);
      if(Mouse.getEventButtonState() && class_1008.field_b) {
         class_1008.field_b = false;
      }

   }

   public final void c1() {
      this.field_a = new class_17(this.a6());
      this.field_a = new class_467(this.a6());
      this.field_a = new class_477(this.a6());
      this.field_a = new Z(this.a6());
      this.field_a = new class_23(this.a6());
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      super.field_a.add(this.field_a);
      this.field_a.c2(true);
      this.field_d = true;
   }
}
