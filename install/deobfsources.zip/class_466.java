import java.io.IOException;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import org.schema.game.server.data.admin.AdminCommandIllegalArgument;
import org.schema.game.server.data.admin.AdminCommands;
import org.schema.schine.network.objects.Sendable;

public final class class_466 extends class_454 implements Observer {

   private static final long serialVersionUID = 438885771406304916L;
   private boolean field_c;
   private String field_b;
   private class_371 field_b;


   public class_466(class_983 var1, String var2, class_371 var3) {
      super(var1, var2, var3);
      this.field_b = var3;
      this.field_b = true;
   }

   protected final boolean a() {
      if(this.field_c) {
         this.field_c = false;
         return true;
      } else {
         return false;
      }
   }

   public final boolean b() {
      this.field_b.a14().a18().a79().a60().a52().deleteObserver(this);
      return super.b();
   }

   public final boolean c() {
      this.field_b.a14().a18().a79().a60().a52().addObserver(this);
      super.field_a.a4().a5().field_a = null;
      if(!super.field_a.a20().getInventory((class_47)null).b2()) {
         System.err.println("[TUTORIAL] ship core does NOT exist");
         super.field_a.a4().b1("WARNING\nYou already used your core!\nYou will be given one more.\n\n(this works if you\'re an admin)");

         try {
            super.field_a.a4().a23(AdminCommands.field_q, AdminCommands.a2(AdminCommands.field_q, new String[]{super.field_a.a20().getName(), "1", "1"}));
         } catch (IOException var1) {
            var1.printStackTrace();
         } catch (InterruptedException var2) {
            var2.printStackTrace();
         } catch (AdminCommandIllegalArgument var3) {
            var3.printStackTrace();
         }
      } else {
         System.err.println("[TUTORIAL] ship core exists");
      }

      return super.c();
   }

   public final boolean d() {
      if(super.field_a.a4().a5().field_a != null) {
         this.field_c = true;
      }

      if(this.field_b != null) {
         synchronized(super.field_a.getLocalAndRemoteObjectContainer().getLocalObjects()) {
            Iterator var2 = super.field_a.getLocalAndRemoteObjectContainer().getLocalObjects().values().iterator();

            while(var2.hasNext()) {
               Sendable var3;
               if((var3 = (Sendable)var2.next()) instanceof class_743 && ((class_743)var3).getUniqueIdentifier().equals(this.field_b)) {
                  super.field_a.a4().a5().field_a = (class_743)var3;
                  super.field_a.a14().a18().a79().a60().a56((class_801)var3);
                  this.field_b = null;
               }
            }
         }
      }

      return super.d();
   }

   public final void update(Observable var1, Object var2) {
      System.err.println("UPDATE BY PLAYER EXTERNAL CONTROLLER " + var2);
      if(var1 instanceof class_431 && var2 != null && var2 instanceof String && !var2.equals("ON_SWITCH")) {
         this.field_b = (String)var2;
      }

   }
}
