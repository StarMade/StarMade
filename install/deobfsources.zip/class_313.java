import java.io.IOException;
import org.schema.schine.graphicsengine.core.ResourceException;

final class class_313 extends class_73 {

   public final void a(class_66 var1) {
      System.err.println("Loading BACK ground");
      String var3;
      if(!class_943.field_ab.b1()) {
         var3 = "data//sky/milkyway/Milky-Way-texture-cube";
      } else {
         var3 = "data//sky/generic/generic";
      }

      try {
         class_333.field_a = class_967.a3().a4(var3, "png");
         System.err.println("Loading BACK ground DONE");
      } catch (IOException var2) {
         var2.printStackTrace();
         throw new ResourceException("data/" + var3);
      }
   }
}
