
public final class class_405 extends class_1001 {

   private static final long serialVersionUID = -334972996033688715L;


   public class_405(class_983 var1) {
      super(var1);
   }

   public final boolean c() {
      return true;
   }

   public final boolean b() {
      return true;
   }

   public final boolean d() {
      return true;
   }
}
