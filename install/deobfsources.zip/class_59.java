
public final class class_59 extends class_58 {

   private static final long serialVersionUID = 58195803456789676L;


   public class_59(Object var1, class_54 var2) {
      super(var1, var2);
   }
}
