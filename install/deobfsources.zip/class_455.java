import org.lwjgl.input.Keyboard;

public final class class_455 extends class_15 {

   public class_455(class_371 var1) {
      super(var1);
   }

   public final void handleKeyEvent() {
      this.a6().getChat().handleKeyEvent();
   }

   public final void a12(class_941 var1) {
      super.a12(var1);
   }

   public final void b2(boolean var1) {
      this.a6().a14().field_a.field_a.e2(var1);
      this.a6().a14().field_a.field_a.e2(var1);
      this.a6().a14().field_a.field_a.e2(var1);
      super.b2(var1);
   }

   public final void c2(boolean var1) {
      super.c2(var1);
      Keyboard.enableRepeatEvents(var1);
   }

   public final void a15(class_935 var1) {
      super.a15(var1);
      class_1008.field_a = false;
   }
}
