
final class class_268 implements class_1410 {

   // $FF: synthetic field
   private class_272 field_a;


   class_268(class_272 var1) {
      this.field_a = var1;
      super();
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.field_a && var2.field_a == 0) {
         int var3 = this.field_a.a28().a28();
         this.field_a.a28().a54();
         var3 = (var3 + 1) % class_272.a110(this.field_a);
         this.field_a.a28().c3(var3);
         class_272.a111(this.field_a);
      }

   }

   public final boolean a1() {
      return false;
   }
}
