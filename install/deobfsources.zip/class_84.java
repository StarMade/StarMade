import java.util.Observable;
import java.util.Observer;
import org.schema.schine.network.client.ClientState;

public final class class_84 extends class_964 implements Observer {

   private class_255 field_a;
   private class_815 field_a;
   private class_819 field_a;
   private class_1412 field_a;
   private class_1412 field_b;
   private class_1412 field_c;
   private class_940 field_a;
   private class_940 field_b;
   private class_940 field_c;
   private class_970 field_a;
   private boolean field_a = true;
   private class_964 field_a;


   public class_84(ClientState var1) {
      super(var1);
   }

   public final void a2() {}

   public final void b() {
      if(this.field_a) {
         if(this.field_a != null) {
            this.field_a.b2(this.field_a);
         }

         this.field_a = false;
         if(this.a8().field_a.field_b) {
            this.field_a.a9(this.field_a);
            this.field_a = this.field_a;
            this.a7(this.field_c);
         } else if(this.a8().field_a.field_b) {
            this.field_a.a9(this.field_a);
            this.field_a = this.field_a;
            this.a7(this.field_a);
         } else if(this.a8().field_a.field_b) {
            this.field_a.a9(this.field_a);
            this.field_a = this.field_a;
            this.a7(this.field_b);
         } else {
            this.field_a = true;
         }
      }

      this.k();
   }

   private void a7(class_940 var1) {
      this.field_c.field_a.field_a = 1.0F;
      this.field_c.field_a.field_r = 0.5F;
      this.field_c.field_a.field_g = 0.5F;
      this.field_c.field_a.field_b = 0.5F;
      this.field_a.field_a.field_a = 1.0F;
      this.field_a.field_a.field_r = 0.5F;
      this.field_a.field_a.field_g = 0.5F;
      this.field_a.field_a.field_b = 0.5F;
      this.field_b.field_a.field_a = 1.0F;
      this.field_b.field_a.field_r = 0.5F;
      this.field_b.field_a.field_g = 0.5F;
      this.field_b.field_a.field_b = 0.5F;
      var1.field_a.field_a = 1.0F;
      var1.field_a.field_r = 1.0F;
      var1.field_a.field_g = 1.0F;
      var1.field_a.field_b = 1.0F;
   }

   public final void c() {
      this.field_a = new class_970(class_967.a2().a5("faction-personal-panel-gui-"), this.a24());
      this.a8().addObserver(this);
      this.field_a = new class_819(this.a24());
      this.field_a = new class_815(this.a24());
      this.field_a = new class_255(this.a24());
      this.field_a.a165(264.0F, 105.0F, 0.0F);
      this.field_a.a165(264.0F, 105.0F, 0.0F);
      this.field_a.a165(264.0F, 105.0F, 0.0F);
      this.field_a.c();
      this.field_a.c();
      this.field_a.c();
      this.field_a = new class_1412(this.a24(), 180.0F, 30.0F);
      this.field_c = new class_1412(this.a24(), 180.0F, 30.0F);
      this.field_b = new class_1412(this.a24(), 180.0F, 30.0F);
      this.field_a = new class_940(180, 40, class_28.d(), this.a24());
      this.field_c = new class_940(180, 40, class_28.d(), this.a24());
      this.field_b = new class_940(180, 40, class_28.d(), this.a24());
      this.field_a.a137("Personal");
      this.field_b.a137("Faction");
      this.field_c.a137("Faction Hub");
      this.field_a.a9(this.field_a);
      this.field_c.a9(this.field_c);
      this.field_b.a9(this.field_b);
      this.field_a.a9(this.field_a);
      this.field_a.a9(this.field_b);
      this.field_a.a9(this.field_c);
      this.field_a.a165(264.0F, 74.0F, 0.0F);
      this.field_b.a165(444.0F, 74.0F, 0.0F);
      this.field_c.a165(625.0F, 74.0F, 0.0F);
      this.field_a.field_g = true;
      this.field_b.field_g = true;
      this.field_c.field_g = true;
      this.field_a.field_a = "PERSONAL";
      this.field_a.a143(this.a8());
      this.field_b.field_a = "LOCAL";
      this.field_b.a143(this.a8());
      this.field_c.field_a = "HUB";
      this.field_c.a143(this.a8());
      this.field_a = this.field_a;
      this.a9(this.field_a);
      this.h2(48);
      super.field_g = true;
   }

   private class_423 a8() {
      return ((class_371)this.a24()).a14().field_a.field_a.field_a;
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public final void update(Observable var1, Object var2) {
      this.field_a = true;
   }
}
