
// $FF: synthetic class
final class class_88 {

   // $FF: synthetic field
   static final int[] field_a = new int[class_631.values().length];


   static {
      try {
         field_a[class_631.field_b.ordinal()] = 1;
      } catch (NoSuchFieldError var2) {
         ;
      }

      try {
         field_a[class_631.field_c.ordinal()] = 2;
      } catch (NoSuchFieldError var1) {
         ;
      }

      try {
         field_a[class_631.field_a.ordinal()] = 3;
      } catch (NoSuchFieldError var0) {
         ;
      }
   }
}
