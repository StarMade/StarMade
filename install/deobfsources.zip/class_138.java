import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import org.schema.schine.network.client.ClientState;

public abstract class class_138 extends class_964 implements Observer {

   private int field_a;
   private int field_b;
   private class_1412 field_a;
   private class_940 field_a;
   private String field_b;
   private boolean field_a;


   public class_138(ClientState var1, int var2) {
      super(var1);
      this.field_a = var2;
      this.field_b = 80;
      ((class_371)this.a24()).a45().addObserver(this);
   }

   public final void a2() {
      ((class_371)this.a24()).a45().deleteObserver(this);
   }

   public final void b() {
      if(this.field_a) {
         this.field_b = this.a16();
         this.field_a.field_b = new ArrayList();
         String[] var1 = this.field_b.split("\\\\n");
         this.field_a.field_b.clear();

         for(int var2 = 0; var2 < var1.length; ++var2) {
            this.field_a.field_b.add(var1[var2]);
         }

         this.field_a = false;
      }

      this.k();
   }

   public abstract String a16();

   public final void c() {
      this.field_a = new class_1412(this.a24(), (float)this.field_a, (float)this.field_b);
      this.field_a = new class_940(this.field_a, this.field_b, this.a24());
      this.field_b = this.a16();
      this.field_a.field_b = new ArrayList();
      String[] var1 = this.field_b.split("\\\\n");

      for(int var2 = 0; var2 < var1.length; ++var2) {
         this.field_a.field_b.add(var1[var2]);
      }

      this.field_a.a9(this.field_a);
      this.a9(this.field_a);
   }

   public final float a3() {
      return (float)this.field_b;
   }

   public final float b1() {
      return (float)this.field_a;
   }

   public void update(Observable var1, Object var2) {
      this.field_a = true;
   }
}
