import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import org.lwjgl.opengl.GL11;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.UnicodeFont;
import org.newdawn.slick.font.effects.ColorEffect;
import org.newdawn.slick.font.effects.OutlineEffect;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public final class class_128 extends class_964 {

   private class_940 field_a;
   private class_940 field_b;
   private class_970 field_a;
   private String field_b;
   private boolean field_a = true;
   private static UnicodeFont field_a;


   public class_128(ClientState var1, String var2) {
      super(var1);
      this.field_b = var2;
   }

   public final void a2() {
      this.field_a.a2();
      this.field_a.a2();
   }

   public final void b() {
      if(this.field_a) {
         this.c();
      }

      this.field_a.field_b.set(0, this.field_b);
      GlUtil.d1();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      this.r();
      if(0L < System.currentTimeMillis()) {
         this.field_b.field_b.clear();
      }

      this.field_a.b();
      GL11.glDisable(3042);
      GlUtil.c2();
   }

   public final float a3() {
      return 256.0F;
   }

   public final float b1() {
      return 256.0F;
   }

   public final void c() {
      if(field_a == null) {
         Font var1 = new Font("Arial", 1, 28);
         (field_a = new UnicodeFont(var1)).getEffects().add(new OutlineEffect(4, Color.black));
         field_a.getEffects().add(new ColorEffect(Color.white));
         field_a.addAsciiGlyphs();

         try {
            field_a.loadGlyphs();
         } catch (SlickException var2) {
            var2.printStackTrace();
         }
      }

      this.field_a = new class_940(256, 64, field_a, this.a24());
      this.field_b = new class_940(256, 64, this.a24());
      this.field_a = new class_970(class_967.a2().a5("panel-std-gui-"), this.a24());
      ArrayList var3;
      (var3 = new ArrayList()).add(this.field_b);
      this.field_a.field_b = var3;
      var3 = new ArrayList();
      this.field_b.field_b = var3;
      this.field_a.h2(48);
      this.field_a.c();
      this.field_a.c();
      this.a9(this.field_a);
      this.field_a.a9(this.field_a);
      this.field_a.a9(this.field_b);
      this.field_a.a165(280.0F, 80.0F, 0.0F);
      this.field_b.a165(300.0F, 30.0F, 0.0F);
      this.field_a = false;
   }

   public final void a17(String var1) {
      this.field_b = var1;
   }
}
