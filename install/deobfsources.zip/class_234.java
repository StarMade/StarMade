import javax.vecmath.Vector3f;
import javax.vecmath.Vector4f;

final class class_234 implements class_953 {

   private Vector4f field_a;
   // $FF: synthetic field
   private class_228 field_a;


   class_234(class_228 var1) {
      this.field_a = var1;
      super();
      this.field_a = new Vector4f();
   }

   public final int a105(class_1382 var1) {
      return 10;
   }

   public final float a106(long var1) {
      return 0.1F + 0.07F * class_228.a31(this.field_a).a1();
   }

   public final Vector3f a83() {
      return class_1218.a1(class_228.a32(this.field_a).a3().getWorldTransform().origin, class_228.a32(this.field_a).a20().a44());
   }

   public final Vector4f a63() {
      this.field_a.set((1.0F - class_228.a31(this.field_a).a1()) / 2.0F + 0.5F, 1.0F, (1.0F - class_228.a31(this.field_a).a1()) / 2.0F + 0.5F, 1.0F);
      return this.field_a;
   }
}
