import java.util.Iterator;
import org.lwjgl.input.Keyboard;
import org.schema.game.common.data.player.ShipConfigurationNotFoundException;

public class class_334 extends class_15 implements class_1410 {

   private class_800 field_a;
   private boolean field_d;
   // $FF: synthetic field
   private static boolean field_e = !bm.class.desiredAssertionStatus();


   public class_334(class_371 var1) {
      super(var1);
   }

   public final void a(class_964 var1, class_941 var2) {
      var2 = null;
      if(super.field_c && !super.field_a) {
         Iterator var6 = this.a6().getMouseEvents().iterator();

         while(var6.hasNext()) {
            class_941 var3;
            if((var3 = (class_941)var6.next()).field_a == 0 && !var3.field_a && var1 instanceof class_972) {
               class_963 var4;
               class_972 var7;
               int var5 = (var4 = (class_963)(var7 = (class_972)var1).a158()).indexOf(var7);
               var4.e();
               var7.a29(true);
               System.err.println("Controller manager call back: index: " + var5);
               this.field_a = (class_800)var7.a149().b19();
               this.setChanged();
               if(this.field_a != null) {
                  this.field_a.a15(-2);
               }

               this.notifyObservers(this.field_a);
            }
         }
      }

   }

   public final void b() {
      this.field_d = true;
   }

   public final class_800 a40() {
      return this.field_a;
   }

   public void handleKeyEvent() {
      super.handleKeyEvent();
      if(Keyboard.getEventKeyState() && Keyboard.getEventKey() >= 2 && Keyboard.getEventKey() <= 11) {
         int var2 = Keyboard.getEventKey() - 2;
         class_334 var1 = this;
         if(this.field_a != null) {
            if(!field_e && this.a6().a25() == null) {
               throw new AssertionError();
            }

            if(!this.a6().a20().a121(this.a6().a25())) {
               this.a6().a20().a78().add(new class_359(this.a6().a20(), this.a6().a25().getUniqueIdentifier()));
            }

            try {
               class_359 var3 = var1.a6().a20().a118(var1.a6().a25());
               int var4 = -1;
               class_47 var5 = var1.field_a.a2(new class_47());
               if(var3.a19(var5)) {
                  var4 = var3.a23(var5);
                  var1.setChanged();
               }

               System.err.println("PRESSED " + var2 + ": REMOVE: " + var4);
               if(var4 != var2) {
                  System.err.println("ASSINGING: " + var2 + " to " + var1.field_a);
                  var3.a20(var2, var5, true);
                  var1.setChanged();
               }

               var1.notifyObservers(var1.field_a);
               return;
            } catch (ShipConfigurationNotFoundException var6) {
               var6.printStackTrace();
            }
         }
      }

   }

   public final void a12(class_941 var1) {
      super.a12(var1);
   }

   public final boolean h() {
      return this.field_d;
   }

   public final boolean a1() {
      return !this.a6().b().isEmpty();
   }

   public final void b2(boolean var1) {
      class_1008.field_a = !var1;
      if(var1) {
         class_967.b("0022_menu_ui - swoosh scroll large");
      } else {
         class_967.b("0022_menu_ui - swoosh scroll small");
      }

      this.a6().a14().field_a.field_a.field_a.a51().a45().field_a.e2(var1);
      this.a6().a14().field_a.field_a.field_a.a51().a45().field_a.e2(var1);
      this.setChanged();
      this.notifyObservers();
      super.b2(var1);
   }

   public final void c1() {
      this.field_d = false;
   }

   public final void a15(class_935 var1) {
      class_1008.field_a = false;
      this.a6().a14().field_a.field_a.field_a.e2(true);
   }

}
