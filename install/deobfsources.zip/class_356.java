import com.bulletphysics.linearmath.Transform;
import it.unimi.dsi.fastutil.objects.ObjectAVLTreeSet;
import it.unimi.dsi.fastutil.objects.ObjectBidirectionalIterator;
import java.util.ArrayList;
import java.util.Iterator;
import javax.vecmath.Vector3f;
import javax.vecmath.Vector4f;
import org.schema.game.common.controller.elements.weapon.WeaponElementManager;
import org.schema.game.common.data.element.ElementCollection;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.graphicsengine.forms.Mesh;

public final class class_356 implements class_706, class_923 {

   private class_743 field_a;
   private static class_1376 field_a;
   private final ObjectAVLTreeSet field_a = new ObjectAVLTreeSet();
   private final Vector4f field_a = new Vector4f(1.0F, 0.4F, 0.2F, 0.9F);
   private final Vector4f field_b = new Vector4f(1.0F, 0.0F, 0.0F, 1.0F);
   private final Vector4f field_c = new Vector4f();
   private final Vector4f field_d = new Vector4f();
   private float field_a = 0.0F;
   private final Transform field_a = new Transform();
   private final Vector3f field_a = new Vector3f(0.0F, 0.0F, 0.5F);
   private boolean field_a = true;
   private final ArrayList field_a = new ArrayList();


   public class_356(class_743 var1) {
      this.field_a = var1;
      ((WeaponElementManager)this.field_a.a96().getWeapon().getElementManager()).addObserver(this);
   }

   public final void a3() {
      if(this.field_a != null) {
         ((WeaponElementManager)this.field_a.a96().getWeapon().getElementManager()).deleteObserver(this);
      }

   }

   public final void b() {
      if(this.field_a) {
         this.c();
      }

      if(!this.field_a.isEmpty()) {
         ObjectBidirectionalIterator var1 = this.field_a.iterator(this.field_a.last());

         while(var1.hasPrevious()) {
            class_287 var2;
            if((var2 = (class_287)var1.previous()).a()) {
               float var5 = (float)(System.currentTimeMillis() - var2.field_a);
               this.field_a = Math.min(1.0F, 0.7F + var5 / 200.0F * 0.3F);
               this.field_c.set(this.field_a);
               this.field_d.set(this.field_b);
               this.field_c.scale(this.field_a);
               this.field_d.scale(this.field_a);
               this.field_d.field_x = 0.5F - this.field_a / 2.0F;
               this.field_d.field_z = this.field_a;
               GlUtil.a42(field_a, "thrustColor0", this.field_c);
               GlUtil.a42(field_a, "thrustColor1", this.field_d);
               GlUtil.a33(field_a, "ticks", var2.field_a);
               var2.a3(this.field_a, this.field_a);
               if(GlUtil.a20(this.field_a.origin, class_967.field_a.a()) && GlUtil.a18(this.field_a, class_218.field_a)) {
                  GlUtil.d1();
                  GlUtil.b3(this.field_a);
                  ((Mesh)class_218.field_a.a156().get(0)).f();
                  GlUtil.c2();
               }
            }
         }
      }

   }

   public final class_743 a10() {
      return this.field_a;
   }

   public final void c() {
      field_a = class_1379.field_s;
      this.field_a = false;
   }

   public final void a4(class_704 var1, Object var2, Object var3) {
      if(var2 != null && var2 instanceof ElementCollection && "s".equals(var3)) {
         ElementCollection var4 = (ElementCollection)var2;
         class_287 var5 = new class_287(this.field_a, var4);
         if(!this.field_a.contains(var5)) {
            this.field_a.add(var5);
         }
      }

   }

   public final void a5(class_935 var1) {
      while(!this.field_a.isEmpty()) {
         class_287 var2 = (class_287)this.field_a.remove(0);
         if(this.field_a.contains(var2)) {
            Iterator var3 = this.field_a.iterator();

            while(var3.hasNext()) {
               class_287 var4 = (class_287)var3.next();
               if(var2.equals(var4)) {
                  var4.a1();
                  break;
               }
            }
         } else {
            var2.a1();
            this.field_a.add(var2);
         }
      }

      ObjectBidirectionalIterator var5 = this.field_a.iterator();

      while(var5.hasNext()) {
         class_287 var6;
         if(!(var6 = (class_287)var5.next()).a()) {
            var5.remove();
         } else {
            var6.a2(var1);
         }
      }

   }

   static {
      new ArrayList();
   }
}
