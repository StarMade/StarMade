import java.util.ArrayList;
import javax.vecmath.Vector4f;
import org.lwjgl.opengl.GL11;
import org.newdawn.slick.Color;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public final class class_110 extends class_964 {

   private class_970 field_a;
   private float field_b = 5.0F;
   private float field_c;
   private float field_d;
   private class_940 field_a;
   private boolean field_a = true;
   private float field_e = 0.0F;
   private String field_b;
   private Color field_a = new Color(1, 1, 1, 1);
   public float field_a = 0.0F;


   public class_110(ClientState var1, String var2, Color var3) {
      super(var1);
      this.field_a = new class_940(300, 300, var1);
      this.field_a.field_b = new ArrayList();
      this.field_b = var2;
      this.field_a.field_r = var3.field_r;
      this.field_a.field_g = var3.field_g;
      this.field_a.field_b = var3.field_b;
      this.field_a.field_a = var3.field_a;
      String[] var5;
      int var6 = (var5 = var2.split("\n")).length;

      for(int var7 = 0; var7 < var6; ++var7) {
         String var4 = var5[var7];
         this.field_a.field_b.add(var4);
      }

   }

   public final void a2() {}

   public final void b() {
      if(this.field_a) {
         this.c();
      }

      if(this.field_d >= 0.0F) {
         this.a83().field_x = (float)class_927.b() - super.field_a.field_x * this.field_a.b1() - 96.0F;
         this.a83().field_y = this.field_e;
         if(this.j1()) {
            float var1 = this.field_b - this.field_c;
            this.field_a.a151().a63().set(this.field_a.field_r, this.field_a.field_g, this.field_a.field_b, 1.0F);
            if(var1 < 1.0F) {
               this.field_a.a151().a63().set(this.field_a.field_r, this.field_a.field_g, this.field_a.field_b, var1);
               this.field_a.field_a.field_a = var1;
            }

            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GlUtil.d1();
            this.r();
            this.field_a.b();
            GlUtil.c2();
            GL11.glDisable(3042);
            this.field_a.a151().a63().set(1.0F, 1.0F, 1.0F, 1.0F);
            this.field_a.field_a.field_a = 1.0F;
            this.field_a.field_a.field_r = 1.0F;
            this.field_a.field_a.field_g = 1.0F;
            this.field_a.field_a.field_b = 1.0F;
         }
      }
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final String a16() {
      return this.field_b;
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public final boolean a4() {
      return this.field_c < this.field_b;
   }

   public final void c() {
      this.field_a = new class_970(class_967.a2().a5("std-message-gui-"), this.a24());
      this.field_a.a165(30.0F, 30.0F, 0.0F);
      this.field_a.a136(Color.white);
      this.field_a.field_a = class_28.b2();
      this.field_a.c();
      this.field_a.a151().c7(new Vector4f(1.0F, 1.0F, 1.0F, 1.0F));
      this.field_a.c();
      this.field_a.a9(this.field_a);
      this.field_e = -1.0F * (this.field_a.a3() * super.field_a.field_y + 5.0F);
      this.field_a = false;
   }

   public final void e() {
      String[] var1 = this.field_b.split("\n");
      this.field_a.field_b.clear();
      int var2 = (var1 = var1).length;

      for(int var3 = 0; var3 < var2; ++var3) {
         String var4 = var1[var3];
         this.field_a.field_b.add(var4);
      }

      this.field_c = 0.0F;
   }

   public final void a17(String var1) {
      this.field_b = var1;
   }

   public final void f() {
      this.field_d = 0.0F;
      this.field_c = 0.0F;
   }

   public final void g() {
      if(this.field_c < this.field_b - 1.0F) {
         this.field_c = this.field_b - 1.0F;
      }

   }

   public final void a12(class_935 var1) {
      if(!this.field_a) {
         if(this.field_d < 0.0F) {
            this.field_d += var1.a();
         } else {
            this.field_c += var1.a();
            float var2 = this.field_a * (this.field_a.a3() * super.field_a.field_y + 5.0F);
            float var3 = Math.min(1.0F, Math.max(0.01F, Math.abs(this.field_e - var2)) / (this.field_a.a3() * super.field_a.field_y));
            if(this.field_e > var2) {
               this.field_e -= var1.a() * 1000.0F * var3;
               if(this.field_e <= var2) {
                  this.field_e = var2;
                  return;
               }
            } else if(this.field_e < var2) {
               this.field_e += var1.a() * 1000.0F * var3;
               if(this.field_e >= var2) {
                  this.field_e = var2;
               }
            }

         }
      }
   }
}
