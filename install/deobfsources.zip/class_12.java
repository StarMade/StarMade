
public abstract class class_12 extends class_11 {

   final class_196 field_a;


   public class_12(class_371 var1, Object var2, Object var3) {
      super(var1);
      this.field_a = new class_196(var1, this, var2, var3);
      this.field_a.a143(this);
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.field_a && var2.field_a == 0) {
         if(var1.b19().equals("OK")) {
            System.err.println("OK");
            this.b();
         }

         if(var1.b19().equals("CANCEL") || var1.b19().equals("X")) {
            System.err.println("CANCEL");
            this.d();
         }
      }

   }

   public void handleKeyEvent() {}

   public abstract void b();
}
