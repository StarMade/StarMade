import org.schema.game.common.controller.CannotBeControlledException;
import org.schema.game.common.data.element.ElementKeyMap;

final class class_451 implements class_479 {

   // $FF: synthetic field
   private class_453 field_a;


   class_451(class_453 var1) {
      this.field_a = var1;
      super();
   }

   public final void a(class_47 var1, class_47 var2, short var3) {
      short var6;
      if(ElementKeyMap.getInfo(var6 = this.field_a.a6().a14().a18().a79().a60().a54()).getControlledBy().contains(Short.valueOf((short)1))) {
         class_800 var7;
         if((var7 = class_453.a71(this.field_a).a1().getSegmentBuffer().a9(class_453.a71(this.field_a).a(), false)) != null) {
            try {
               class_453.a71(this.field_a).a1().setCurrentBlockController(var7, var1);
            } catch (CannotBeControlledException var4) {
               this.field_a.a81(var4);
            }
         }

         if(class_943.field_P.b1() && ElementKeyMap.getInfo(var6).getControlling().size() > 0 && (var7 = class_453.a71(this.field_a).a1().getSegmentBuffer().a9(var1, false)) != null) {
            class_453.a72(this.field_a, var7);
         }

      } else {
         if(class_453.a73(this.field_a) != null && var1 != null) {
            class_453.a73(this.field_a).a12();
            if(class_453.a73(this.field_a).a9() != 0) {
               try {
                  class_453.a71(this.field_a).a1().setCurrentBlockController(class_453.a73(this.field_a), var1);
                  return;
               } catch (CannotBeControlledException var5) {
                  this.field_a.a81(var5);
                  return;
               }
            }

            if(ElementKeyMap.getInfo(var6).getControlledBy().size() > 0) {
               this.field_a.a6().a4().d1("Note:\nYou placed a controllable Block\nWithout having a conroller selected!\nE.g. if you place weapons, please\nselect/place the weapon computer\nfirst.");
               return;
            }
         } else if(class_453.a73(this.field_a) == null && ElementKeyMap.getInfo(var6).getControlledBy().size() > 0) {
            this.field_a.a6().a4().d1("Note:\nYou placed a controllable Block\nWithout having a conroller selected!\nE.g. if you place weapons, please\nselect/place the weapon computer\nfirst.");
         }

      }
   }
}
