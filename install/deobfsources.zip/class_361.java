
public interface class_361 {

   class_880 a();
}
