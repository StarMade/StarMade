
final class class_208 {

   // $FF: synthetic field
   private class_206 field_a;


   class_208(class_206 var1) {
      this.field_a = var1;
      super();
   }

   public final String toString() {
      if(this.field_a.a11().field_a == class_206.a86(this.field_a)) {
         return "*click on block*";
      } else {
         switch(class_206.a86(this.field_a)) {
         case 1:
            if(this.field_a.a11().field_a) {
               return "unset";
            }

            return "set";
         case 2:
            if(this.field_a.a11().field_b) {
               return "unset";
            }

            return "set";
         case 3:
         default:
            return "error";
         case 4:
            return this.field_a.a11().field_c?"unset":"set";
         }
      }
   }
}
