import java.util.ArrayList;
import java.util.Collections;

public final class class_26 extends ArrayList {

   private static final long serialVersionUID = 5564392963896845136L;


   public final boolean a(Comparable var1) {
      if(var1 == null) {
         throw new NullPointerException("tried to add null " + var1);
      } else if(this.size() == 0) {
         return super.add(var1);
      } else {
         int var2;
         if((var2 = Collections.binarySearch(this, var1)) >= 0) {
            super.add(var2 + 1, var1);
            return true;
         } else {
            super.add(-var2 - 1, var1);
            return true;
         }
      }
   }

   // $FF: synthetic method
   public final boolean add(Object var1) {
      return this.a((Comparable)var1);
   }
}
