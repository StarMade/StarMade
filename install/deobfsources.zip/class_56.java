
public final class class_56 extends class_58 {

   private static final long serialVersionUID = 7414765311357833461L;


   public class_56(Object var1, class_54 var2) {
      super(var1, var2);
   }
}
