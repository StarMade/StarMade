import com.bulletphysics.linearmath.Transform;
import javax.vecmath.Quat4f;
import javax.vecmath.Vector3f;
import org.schema.common.FastMath;
import org.schema.game.common.controller.SegmentController;
import org.schema.schine.graphicsengine.core.GlUtil;

public final class class_298 implements class_962 {

   private class_1432 field_b;
   private Vector3f field_a = new Vector3f();
   private Vector3f field_b = new Vector3f();
   private Vector3f field_c = new Vector3f();
   public boolean field_a;
   int field_a = 4;
   private class_1432 field_c;
   private final Transform field_b = new Transform();
   public final Transform field_a = new Transform();
   private final Transform field_c = new Transform();
   private final Transform field_d = new Transform();
   private float field_a = 0.7853982F;
   private int field_b = 0;
   private boolean field_b = true;
   public class_1432 field_a;
   private Quat4f field_a = new Quat4f();
   private Quat4f field_b = new Quat4f();
   private Quat4f field_c = new Quat4f();
   private Quat4f field_d = new Quat4f();
   private Quat4f field_e = new Quat4f(0.0F, 0.0F, 0.0F, 1.0F);
   private Quat4f field_f = new Quat4f();
   private Vector3f field_d = new Vector3f();


   public class_298(class_1432 var1, class_1432 var2) {
      this.field_b = var1;
      this.field_c = var2;
      this.field_a.setIdentity();
      this.field_c.setIdentity();
      this.field_b.set(var2.getWorldTransform());
   }

   private void a(Vector3f var1, Vector3f var2, Vector3f var3, Transform var4) {
      switch(this.field_a) {
      case 0:
         GlUtil.d(var1, var4);
         GlUtil.f(var2, var4);
         GlUtil.c(var3, var4);
         return;
      case 1:
         GlUtil.e(var1, var4);
         GlUtil.b(var2, var4);
         GlUtil.c(var3, var4);
         return;
      case 2:
         GlUtil.f(var1, var4);
         GlUtil.e(var2, var4);
         GlUtil.c(var3, var4);
         return;
      case 3:
         GlUtil.b(var1, var4);
         GlUtil.d(var2, var4);
         GlUtil.c(var3, var4);
      case 4:
         GlUtil.c(var1, var4);
         GlUtil.f(var2, var4);
         GlUtil.e(var3, var4);
         return;
      case 5:
         GlUtil.c(var1, var4);
         GlUtil.f(var2, var4);
         GlUtil.e(var3, var4);
         var1.negate();
         var3.negate();
         return;
      default:
      }
   }

   public final void a1(float var1, float var2, float var3, float var4, float var5, float var6) {
      this.field_d.set(this.field_b.getWorldTransform());
      this.field_b = 0;
      this.field_c.field_x = -var1 * var4;
      this.field_c.field_y = var2 * var5;
      this.field_c.field_z = var3 * var6;
      class_298 var11 = this;

      Vector3f var14;
      Vector3f var15;
      Vector3f var16;
      while(true) {
         if(var11.field_b) {
            var11.field_b = false;
            var11.field_c.set(((SegmentController)var11.field_a).getPhysicsDataContainer().getShapeChild().transform);
         }

         var11.field_b.getWorldTransform().set(var11.field_c);
         var3 = -0.7853982F;
         var4 = 1.5707964F;
         switch(var11.field_a) {
         case 0:
            var11.field_c.field_y = -var11.field_c.field_y;
            var3 = -1.5707964F;
            var4 = 2.3561945F;
            break;
         case 1:
            var11.field_c.field_y = -var11.field_c.field_y;
            var3 = -1.5707964F;
            var4 = 2.4561944F;
            break;
         case 2:
            var3 = 0.7853982F;
            var4 = 0.1F;
            break;
         case 3:
            var11.field_c.field_y = -var11.field_c.field_y;
            var3 = -3.0415928F;
            var4 = 4.026991F;
            break;
         case 4:
            var3 = -0.7853982F;
            var4 = 1.6707964F;
            break;
         case 5:
            var11.field_c.field_y = -var11.field_c.field_y;
            var3 = -1.5707964F;
            var4 = 2.4561944F;
         }

         var11.field_d.add(var11.field_c);
         if(var11.field_d.field_y > var3) {
            var11.field_d.field_y -= var11.field_c.field_y;
            var11.field_c.field_y = var3 - var11.field_d.field_y;
            var11.field_d.field_y = var3;
         }

         if(var11.field_d.field_y < -var4) {
            var11.field_d.field_y -= var11.field_c.field_y;
            var11.field_c.field_y = -(var4 - Math.abs(var11.field_d.field_y));
            var11.field_d.field_y = -var4;
         }

         var15 = GlUtil.c(new Vector3f(), var11.field_b.getWorldTransform());
         var16 = GlUtil.f(new Vector3f(), var11.field_b.getWorldTransform());
         var14 = GlUtil.e(new Vector3f(), var11.field_b.getWorldTransform());
         if(var11.field_c.field_y != 0.0F) {
            var11.field_a.cross(GlUtil.c(new Vector3f(), var11.field_b.getWorldTransform()), GlUtil.f(new Vector3f(), var11.field_b.getWorldTransform()));
            var11.field_b.set(var11.field_a);
            var11.field_b.normalize();
            switch(var11.field_a) {
            case 0:
               var11.field_b.set(GlUtil.c(new Vector3f(), var11.field_b.getWorldTransform()));
               var11.a3(var11.field_c.field_y, var11.field_b, var14, var16, var15);
               break;
            case 1:
               var11.field_b.set(GlUtil.c(new Vector3f(), var11.field_b.getWorldTransform()));
               var11.a3(var11.field_c.field_y, var11.field_b, var14, var16, var15);
               break;
            case 2:
               var11.a3(var11.field_c.field_y, var11.field_b, var15, var16, var14);
               break;
            case 3:
               var11.field_b.negate();
               var11.a3(var11.field_c.field_y, var11.field_b, var15, var16, var14);
               break;
            case 4:
               var11.a3(var11.field_c.field_y, var11.field_b, var15, var14, var16);
               break;
            case 5:
               var11.field_b.negate();
               var11.a3(var11.field_c.field_y, var11.field_b, var15, var14, var16);
            }
         }

         Vector3f var10 = new Vector3f();
         switch(var11.field_a) {
         case 0:
            var10.set(1.0F, 0.0F, 0.0F);
            break;
         case 1:
            var10.set(-1.0F, 0.0F, 0.0F);
            break;
         case 2:
            var10.set(0.0F, 1.0F, 0.0F);
            break;
         case 3:
            var10.set(0.0F, -1.0F, 0.0F);
            break;
         case 4:
            var10.set(0.0F, 0.0F, 1.0F);
            break;
         case 5:
            var10.set(0.0F, 0.0F, -1.0F);
         }

         if(var11.field_c.field_x != 0.0F) {
            var11.a3(var11.field_c.field_x, var10, var15, var16, var14);
         }

         if(var11.field_a != null) {
            GlUtil.a30(var15, var11.field_b.getWorldTransform());
            GlUtil.c3(var14, var11.field_b.getWorldTransform());
            GlUtil.d2(var16, var11.field_b.getWorldTransform());
            break;
         }

         Transform var17 = var11.field_c.getWorldTransform();
         Vector3f var9 = var14;
         Vector3f var8 = var16;
         Vector3f var7 = var15;
         var15 = new Vector3f();
         var16 = new Vector3f();
         var14 = new Vector3f();
         var11.a(var15, var16, var14, var17);
         var15 = new Vector3f(var15);
         var7.normalize();
         var9.normalize();
         if(var15.angle(var7) < var11.field_a) {
            GlUtil.a30(var7, var11.field_b.getWorldTransform());
            GlUtil.c3(var9, var11.field_b.getWorldTransform());
            GlUtil.d2(var8, var11.field_b.getWorldTransform());
            break;
         }

         var11.field_c.scale(0.5F);
         if(var11.field_b >= 10) {
            break;
         }

         ++var11.field_b;
         var11 = var11;
      }

      Transform var12;
      if(this.field_a) {
         (var12 = new Transform(this.field_c.getWorldTransform())).basis.sub(this.field_b.basis);
         var15 = new Vector3f();
         var16 = new Vector3f();
         var14 = new Vector3f();
         this.a(var15, var16, var14, var12);
         GlUtil.a30(var15, var12);
         GlUtil.d2(var16, var12);
         GlUtil.c3(var14, var12);
         this.field_b.getWorldTransform().basis.add(var12.basis);
         this.field_b.set(this.field_c.getWorldTransform());
      }

      if(this.field_a == null) {
         this.field_c.set(this.field_b.getWorldTransform());
      } else {
         this.field_c.set(this.field_b.getWorldTransform());
         if(this.field_a == 0 || this.field_a == 1) {
            Vector3f var13 = new Vector3f();
            var15 = new Vector3f();
            var16 = new Vector3f();
            this.a(var13, var15, var16, this.field_b.getWorldTransform());
            GlUtil.a30(var13, this.field_b.getWorldTransform());
            GlUtil.d2(var15, this.field_b.getWorldTransform());
            GlUtil.c3(var16, this.field_b.getWorldTransform());
         }

         (var12 = new Transform(((SegmentController)this.field_a).getWorldTransform())).basis.mul(this.field_b.getWorldTransform().basis);
         this.field_b.getWorldTransform().basis.set(var12.basis);
         this.field_b.set(this.field_a.getWorldTransform());
      }
   }

   private void a2(Vector3f var1) {
      this.field_f.set(var1.field_x, var1.field_y, var1.field_z, 0.0F);
      this.field_b.mul(this.field_d, this.field_f);
      this.field_a.mul(this.field_b, this.field_c);
      var1.set(this.field_a.field_x, this.field_a.field_y, this.field_a.field_z);
   }

   private void a3(float var1, Vector3f var2, Vector3f var3, Vector3f var4, Vector3f var5) {
      this.field_d.field_x = var2.field_x * FastMath.h(var1 / 2.0F);
      this.field_d.field_y = var2.field_y * FastMath.h(var1 / 2.0F);
      this.field_d.field_z = var2.field_z * FastMath.h(var1 / 2.0F);
      this.field_d.field_w = FastMath.d(var1 / 2.0F);
      this.field_d.normalize();
      this.field_c.conjugate(this.field_d);
      this.a2(var3);
      this.a2(var4);
      this.a2(var5);
      this.field_e.mul(this.field_d);
   }

   public final void a4(class_1432 var1) {
      if(var1 != null && var1 != this.field_a) {
         this.field_b.set(var1.getWorldTransform());
         this.field_c.set(((SegmentController)var1).getPhysicsDataContainer().getShapeChild().transform);
         this.field_b = true;
      }

      this.field_a = var1;
   }

   public final void a5(int var1) {
      if(var1 != this.field_a) {
         this.field_b.set(this.field_a.getWorldTransform());
         this.field_c.set(((SegmentController)this.field_a).getPhysicsDataContainer().getShapeChild().transform);
         this.field_b = true;
      }

      this.field_a = var1;
   }

   public final void a6() {}
}
