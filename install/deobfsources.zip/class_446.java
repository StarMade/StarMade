
public final class class_446 extends class_454 {

   private static final long serialVersionUID = 438885771406304916L;


   public class_446(class_983 var1, String var2, class_371 var3) {
      super(var1, var2, var3);
      this.field_b = true;
   }

   protected final boolean a() {
      if(super.field_a.a4().a5().field_a == null) {
         this.a8().a8().a2().a1(new class_389());
      }

      class_800 var1;
      return (var1 = super.field_a.a14().a18().a79().a60().a51().a40()) != null && var1.a7().a15() != null?var1.a7().a15() == super.field_a.a4().a5().field_a:false;
   }
}
