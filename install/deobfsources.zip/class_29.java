import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

final class class_29 extends ByteArrayOutputStream {

   private String field_a;
   private Logger field_a;
   private Level field_a;
   private PrintStream field_a;
   private String field_b;


   public class_29(PrintStream var1, Logger var2, Level var3, String var4) {
      this.field_b = var4;
      this.field_a = var2;
      this.field_a = var3;
      this.field_a = System.getProperty("line.separator");
      this.field_a = var1;
   }

   public final void close() {
      super.close();
      Handler[] var1;
      int var2 = (var1 = this.field_a.getHandlers()).length;

      for(int var3 = 0; var3 < var2; ++var3) {
         var1[var3].close();
      }

   }

   public final void flush() {
      synchronized(this) {
         super.flush();
         String var1 = this.toString();
         super.reset();
         if(var1.length() != 0 && !var1.equals(this.field_a)) {
            this.field_a.logp(this.field_a, "", "", "[" + this.field_b + "]" + var1);
            if(this.field_a != null) {
               this.field_a.append(var1);
               this.field_a.append("\n");
               this.field_a.flush();
            }

         }
      }
   }
}
