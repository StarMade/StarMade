
public final class class_57 extends class_58 {

   private static final long serialVersionUID = -5610119959656087076L;


   public class_57(Object var1, class_54 var2) {
      super(var1, var2);
   }
}
