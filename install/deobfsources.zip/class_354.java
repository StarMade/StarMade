import java.util.ArrayList;
import javax.vecmath.Vector3f;

public class class_354 implements class_923 {

   private class_1382 field_a;
   private int field_a;
   private Vector3f field_a = new Vector3f();
   private Vector3f field_b = new Vector3f();
   private Vector3f field_c = new Vector3f();
   private Vector3f field_d = new Vector3f();
   private Vector3f field_e = new Vector3f();
   private Vector3f field_f = new Vector3f();
   private ArrayList field_a = new ArrayList(16);
   private float field_a;
   private float field_b = 6.0F;
   // $FF: synthetic field
   private static boolean field_a = !eC.class.desiredAssertionStatus();


   public final void a() {}

   public class_354() {
      for(int var1 = 0; var1 < 16; ++var1) {
         this.field_a.add(new class_352((byte)0));
      }

   }

   public final void b() {
      if(!field_a && this.field_a == null) {
         throw new AssertionError();
      } else {
         this.field_a = 0;
         this.field_b.set(class_969.field_a.a83());
         this.field_a.set(class_967.a1().a83());
         this.field_c.sub(this.field_a, this.field_b);
         this.field_a = this.field_c.length();
         this.field_d.scale(this.field_a, class_967.a1().c10());
         this.field_d.add(this.field_a);
         this.field_e.sub(this.field_d, this.field_b);
         this.field_a = this.field_e.length();
         this.field_e.normalize();
         Vector3f var1 = this.field_b;
         this.a36(0.6F, 0.6F, 0.8F, 1.0F, var1, 16.0F).field_a = 3;
         var1 = this.field_b;
         this.a36(0.6F, 0.6F, 0.8F, 1.0F, var1, 16.0F).field_a = 2;
         this.a38(0.8F, 0.8F, 1.0F, 0.9F, this.field_b, 3.5F);
         this.field_a *= 2.0F;
         this.field_f.scale(this.field_a * 0.1F, this.field_e);
         this.field_f.add(this.field_b);
         this.a38(0.9F, 0.6F, 0.4F, 0.5F, this.field_f, 0.6F);
         this.field_f.scale(this.field_a * 0.15F, this.field_e);
         this.field_f.add(this.field_b);
         this.a37(0.8F, 0.5F, 0.6F, this.field_f, 1.7F);
         this.field_f.scale(this.field_a * 0.175F, this.field_e);
         this.field_f.add(this.field_b);
         this.a37(0.9F, 0.2F, 0.1F, this.field_f, 0.83F);
         this.field_f.scale(this.field_a * 0.285F, this.field_e);
         this.field_f.add(this.field_b);
         this.a37(0.7F, 0.7F, 0.4F, this.field_f, 1.6F);
         this.field_f.scale(this.field_a * 0.2755F, this.field_e);
         this.field_f.add(this.field_b);
         this.a38(0.9F, 0.9F, 0.2F, 0.5F, this.field_f, 0.8F);
         this.field_f.scale(this.field_a * 0.4775F, this.field_e);
         this.field_f.add(this.field_b);
         this.a38(0.93F, 0.82F, 0.73F, 0.5F, this.field_f, 1.0F);
         this.field_f.scale(this.field_a * 0.49F, this.field_e);
         this.field_f.add(this.field_b);
         this.a37(0.7F, 0.6F, 0.5F, this.field_f, 1.4F);
         this.field_f.scale(this.field_a * 0.65F, this.field_e);
         this.field_f.add(this.field_b);
         this.a38(0.7F, 0.8F, 0.3F, 0.5F, this.field_f, 1.8F);
         this.field_f.scale(this.field_a * 0.63F, this.field_e);
         this.field_f.add(this.field_b);
         this.a38(0.4F, 0.3F, 0.2F, 0.5F, this.field_f, 1.4F);
         this.field_f.scale(this.field_a * 0.8F, this.field_e);
         this.field_f.add(this.field_b);
         this.a37(0.7F, 0.5F, 0.5F, this.field_f, 1.4F);
         this.field_f.scale(this.field_a * 0.7825F, this.field_e);
         this.field_f.add(this.field_b);
         this.a38(0.8F, 0.5F, 0.1F, 0.5F, this.field_f, 0.6F);
         this.field_f.scale(this.field_a, this.field_e);
         this.field_f.add(this.field_b);
         this.a37(0.5F, 0.5F, 0.7F, this.field_f, 1.7F);
         this.field_f.scale(this.field_a * 0.975F, this.field_e);
         this.field_f.add(this.field_b);
         this.a38(0.4F, 0.1F, 0.9F, 0.5F, this.field_f, 2.0F);
         this.field_a.field_a = 1;
         this.field_a.b20(false);
         class_1382.a171(this.field_a, this.field_a, class_967.a1());
      }
   }

   private class_352 a36(float var1, float var2, float var3, float var4, Vector3f var5, float var6) {
      class_352 var7;
      (var7 = (class_352)this.field_a.get(this.field_a++)).field_a.set(var5);
      var7.field_a = var6 * this.field_b;
      var7.field_a.set(var1, var2, var3, var4);
      return var7;
   }

   private void a37(float var1, float var2, float var3, Vector3f var4, float var5) {
      this.a36(var1, var2, var3, 0.5F, var4, var5).field_a = 0;
   }

   private void a38(float var1, float var2, float var3, float var4, Vector3f var5, float var6) {
      this.a36(var1, var2, var3, var4, var5, var6).field_a = 1;
   }

   public final void c() {
      this.field_a = class_967.a2().a5("lens_flare-4x1-c-");
      if(!field_a && this.field_a == null) {
         throw new AssertionError();
      }
   }

   public static void d() {}

}
