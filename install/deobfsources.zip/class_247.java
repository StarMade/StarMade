import com.bulletphysics.collision.shapes.BoxShape;
import com.bulletphysics.linearmath.Transform;
import java.util.ArrayList;
import javax.vecmath.Vector3f;
import org.schema.game.common.controller.elements.lift.LiftUnit;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.graphicsengine.forms.Mesh;

public final class class_247 implements class_923 {

   public final ArrayList field_a = new ArrayList();
   private boolean field_a;
   private Mesh field_a;
   private Transform field_a = new Transform();
   private Vector3f field_a = new Vector3f();
   private class_1395 field_a;


   public final void a() {}

   public final void b() {
      if(!this.field_a) {
         this.c();
      }

      for(int var1 = 0; var1 < this.field_a.size(); ++var1) {
         if(!((LiftUnit)this.field_a.get(var1)).isActive()) {
            this.field_a.remove(var1);
            --var1;
         } else {
            LiftUnit var2 = (LiftUnit)this.field_a.get(var1);
            class_1379.field_z.c();
            this.field_a.a2();
            if(var2.getBody() != null) {
               var2.getBody().getWorldTransform(this.field_a);
               GlUtil.d1();
               GlUtil.b3(this.field_a);
               ((BoxShape)var2.getBody().getCollisionShape()).getHalfExtentsWithoutMargin(this.field_a);
               GlUtil.b5(this.field_a.field_x * 2.0F, this.field_a.field_y * 2.0F, this.field_a.field_z * 2.0F);
               this.field_a.b();
               GlUtil.c2();
            }

            this.field_a.c();
            class_1376 var10000 = class_1379.field_z;
            class_1376.e();
         }
      }

   }

   public final void c() {
      this.field_a = (Mesh)class_967.a2().a4("Box").a156().get(0);
      this.field_a = new class_1395();
      this.field_a.f();
      this.field_a.c1(new float[]{1.3F, 1.3F, 1.3F, 1.0F});
      this.field_a = true;
   }
}
