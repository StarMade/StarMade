import org.schema.schine.network.client.ClientState;

final class class_106 extends class_972 {

   private class_744 field_a;


   public class_106(class_116 var1, class_744 var2, ClientState var3) {
      super(new class_104(var3), new class_104(var3), var3);
      this.field_a = var2;
      this.a12((class_935)null);
      super.field_a = var2;
      class_116.a30(var1).put(var2, this);
   }

   public final boolean equals(Object var1) {
      return this.field_a.equals(((class_106)var1).field_a);
   }

   public final int hashCode() {
      return this.field_a.getId();
   }

   public final void a12(class_935 var1) {
      ((class_104)super.field_a).a15(this.field_a.getName(), String.valueOf(this.field_a.f2()), String.valueOf(this.field_a.e()), String.valueOf(this.field_a.g1()), String.valueOf(this.field_a.h1()));
      ((class_104)super.field_b).a15(this.field_a.getName(), String.valueOf(this.field_a.f2()), String.valueOf(this.field_a.e()), String.valueOf(this.field_a.g1()), String.valueOf(this.field_a.h1()));
   }
}
