import javax.vecmath.Vector3f;
import org.schema.schine.network.client.ClientState;

public final class class_115 extends class_964 {

   private class_970 field_a;
   private class_970 field_b;
   private class_970 field_c;
   private class_970 field_d;
   private boolean field_a;
   private class_970 field_e;


   public class_115(ClientState var1) {
      super(var1);
   }

   public final void a2() {}

   public final void b() {
      if(this.field_a) {
         int var1 = ((class_371)this.a24()).a14().field_a.field_a;
         if(this.a28().a52().field_b) {
            this.field_a.b();
         }

         if(this.a28().a51().field_b) {
            if(var1 == 0) {
               this.field_b.b();
            }

            if(var1 == 1) {
               this.field_c.b();
            }

            if(var1 == 2) {
               this.field_d.b();
            }
         }

      } else {
         this.field_e.b();
      }
   }

   public final float a3() {
      return 0.0F;
   }

   private class_443 a28() {
      return ((class_371)this.a24()).a14().field_a.field_a.field_a;
   }

   public final float b1() {
      return 0.0F;
   }

   public final void c() {
      this.field_e = new class_970(class_967.a2().a5("help-gui-"), this.a24());
      this.field_e.h2(9);
      this.field_e.c();
      Vector3f var10000 = this.field_e.a83();
      var10000.field_y -= 64.0F;
      this.field_a = new class_970(class_967.a2().a5("help-gamecharacter-gui-"), this.a24());
      this.field_a.h2(17);
      this.field_b = new class_970(class_967.a2().a5("help-shipcommon-gui-"), this.a24());
      this.field_b.h2(17);
      this.field_c = new class_970(class_967.a2().a5("help-shipbuild-gui-"), this.a24());
      this.field_c.h2(17);
      this.field_d = new class_970(class_967.a2().a5("help-shipflight-gui-"), this.a24());
      this.field_d.h2(17);
   }

   public final void a29(boolean var1) {
      this.field_a = var1;
   }
}
