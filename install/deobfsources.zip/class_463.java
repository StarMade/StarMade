
public final class class_463 extends class_14 {

   private class_1416 field_a;


   public class_463(class_371 var1, short var2, String var3, Object var4, class_1416 var5) {
      super(var1, 5, var3, var4, "1");
      this.field_a = var5;
      this.a10(new class_465(var2));
   }

   public final String[] getCommandPrefixes() {
      return null;
   }

   public final String handleAutoComplete(String var1, class_1077 var2, String var3) {
      return var1;
   }

   public final boolean a1() {
      return super.field_a.b().indexOf(this) != super.field_a.b().size() - 1;
   }

   public final void a2() {
      super.field_a.a14().field_a.field_a.field_a.e2(false);
   }

   public final void onFailedTextCheck(String var1) {
      this.a9(var1);
   }

   public final boolean a7(String var1) {
      int var2 = Integer.parseInt(var1);
      var2 = Math.min(((class_185)this.field_a).a68(false), var2);
      this.field_a.a5(true);
      super.field_a.setDragging(this.field_a);
      this.field_a.c((int)super.field_a.f5().field_x + 32);
      this.field_a.d((int)super.field_a.f5().field_y + 32);
      this.field_a.a6(System.currentTimeMillis());
      ((class_185)this.field_a).b13(var2);
      return true;
   }
}
