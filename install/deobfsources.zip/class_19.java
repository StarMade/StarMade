import com.bulletphysics.linearmath.Transform;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Random;
import javax.vecmath.Vector3f;
import org.schema.common.util.ByteUtil;
import org.schema.game.common.controller.CannotImmediateRequestOnClientException;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.data.element.Element;
import org.schema.game.common.data.world.Segment;
import org.schema.game.common.data.world.SegmentData;
import org.schema.schine.network.objects.NetworkObject;
import org.schema.schine.network.objects.remote.RemoteVector3i;
import org.schema.schine.network.objects.remote.Streamable;

public class class_19 extends class_753 {

   private class_47 field_a = new class_47();
   private class_47 field_b = new class_47();
   private class_47 field_c = new class_47();
   private long field_b;
   private static Random field_a = new Random();
   private final ObjectOpenHashSet field_a = new ObjectOpenHashSet();
   private final ObjectOpenHashSet field_b = new ObjectOpenHashSet();
   private final ObjectOpenHashSet field_c = new ObjectOpenHashSet();
   private final ObjectOpenHashSet field_d = new ObjectOpenHashSet();
   private final ArrayList field_b = new ArrayList();
   private class_745 field_a;
   public static class_675 field_a;
   public static int field_a;
   private Vector3f field_a = new Vector3f();
   private class_990 field_a = new class_990();
   private ObjectOpenHashSet field_e = new ObjectOpenHashSet();
   private int field_b;
   private long field_c;
   private static final class_16 field_a;
   private class_47 field_d = new class_47();
   private class_47 field_e = new class_47();
   private int field_c;
   private Vector3f field_b = new Vector3f();
   private Vector3f field_c = new Vector3f();
   private ArrayList field_c = new ArrayList();
   private class_661[] field_a = new class_661[32];
   private class_661[] field_b = new class_661[32];
   private int field_d = 0;
   private int field_e = 0;
   private boolean field_a;
   private Vector3f field_d = new Vector3f();
   private final Comparator field_a = new class_22(this);
   private boolean field_b;
   private boolean field_c;
   private long field_d = -1L;
   private boolean field_d;
   // $FF: synthetic field
   private static boolean field_e = !Q.class.desiredAssertionStatus();


   public class_19(SegmentController var1) {
      super(var1);
      if(field_a == null) {
         System.err.println("NEW DUMMY SEGMENT");
         (field_a = new class_675(var1)).a22(new SegmentData(false));
      }

   }

   private void g() {
      class_19 var1 = this;
      long var2 = System.currentTimeMillis();
      if(!this.field_c.isEmpty()) {
         ObjectOpenHashSet var4 = this.field_c;
         synchronized(this.field_c) {
            ObjectIterator var5 = var1.field_c.iterator();

            while(var5.hasNext()) {
               class_790 var6 = (class_790)var5.next();
               var5.remove();
               ArrayList var7;
               if(var6.field_a) {
                  var7 = var1.field_b;
                  synchronized(var1.field_b) {
                     for(int var8 = 0; var8 < var1.field_b.size(); ++var8) {
                        Segment var9;
                        if((var9 = (Segment)var1.field_b.get(var8)) != null && var9.field_a != null) {
                           if(var9.field_a.equals(var6.field_a)) {
                              if(!var9.g()) {
                                 System.err.println("[CLIENT][PROVIDER] Segment was not empty but received signature says so! -> setting empty on client (reqrequest though missile hit?)");
                                 var1.field_a.getSegmentProvider().a20(var9.a16());
                                 var9.b2(0);
                              }

                              ((class_675)var9).a46(var6.field_a);
                              var1.f((class_675)var9);
                           }
                        } else {
                           var1.field_b.remove(var8);
                           --var8;
                        }
                     }
                  }
               }

               Segment var18;
               if(var1.a7(var6)) {
                  var7 = null;
                  boolean var23 = false;
                  ArrayList var20 = var1.field_b;
                  synchronized(var1.field_b) {
                     for(int var10 = 0; var10 < var1.field_b.size(); ++var10) {
                        if((var18 = (Segment)var1.field_b.get(var10)) != null && var18.field_a != null) {
                           if(var18.field_a.equals(var6.field_a)) {
                              class_675 var22 = (class_675)var18;
                              class_19 var19 = var1;
                              if(var1.field_a.getSegmentBuffer().a3(var22.field_a)) {
                                 ArrayList var24 = var1.field_b;
                                 synchronized(var1.field_b) {
                                    var19.field_b.remove(var22);
                                 }

                                 Collection var25 = var1.field_a;
                                 synchronized(var1.field_a) {
                                    var19.field_a.remove(var22.field_a);
                                 }
                              } else {
                                 field_a.a(new S(var1, var22));
                              }

                              var23 = true;
                              break;
                           }
                        } else {
                           var1.field_b.remove(var10);
                           --var10;
                        }
                     }
                  }

                  if(!var23) {
                     System.err.println("[WARNING] the request could not be found: " + var6.field_a + " " + var1.field_a);
                  }
               } else {
                  if((var18 = var1.field_a.getSegmentBuffer().a5(var6.field_a)) != null && !field_e && !var6.field_a.equals(var18.field_a)) {
                     throw new AssertionError();
                  }

                  ObjectOpenHashSet var21 = var1.field_b;
                  synchronized(var1.field_b) {
                     var1.field_b.add(new class_47(var6.field_a));
                  }
               }
            }
         }
      }

      long var17;
      if((var17 = System.currentTimeMillis() - var2) > 20L) {
         System.err.println("[CLIENT][SEGMENTPROVIDER] WARNING: checkReceivedSignatures of " + var1.field_a + " took: " + var17);
      }

      this.j();
   }

   public final void a() {
      --field_a;
   }

   private void h() {
      long var1 = System.currentTimeMillis();
      if(this.e()) {
         if(!this.field_b.isEmpty()) {
            ObjectOpenHashSet var3 = this.field_b;
            synchronized(this.field_b) {
               ObjectIterator var4 = this.field_b.iterator();

               while(var4.hasNext()) {
                  class_47 var5 = (class_47)var4.next();
                  var4.remove();
                  this.field_a.a47().segmentRequestBuffer.add((Streamable)(new RemoteVector3i(new class_47(var5), false)));
               }
            }
         }
      } else {
         System.err.println("WAITING FOR PIPE!! " + super.field_a);
      }

      long var7;
      if((var7 = System.currentTimeMillis() - var1) > 5L) {
         System.err.println("[CLIENT][SEGMENTPROVIDER] WARNING: doNTSegmentRequests of " + super.field_a + " took: " + var7);
      }

   }

   private void i() {
      long var1 = System.currentTimeMillis();
      int var3 = this.field_a.size();
      if(this.e()) {
         if(!this.field_a.isEmpty()) {
            ObjectOpenHashSet var4 = this.field_a;
            synchronized(this.field_a) {
               ObjectIterator var5 = this.field_a.iterator();

               while(var5.hasNext()) {
                  class_47 var6 = (class_47)var5.next();
                  var5.remove();
                  if(!field_e && var6 == null) {
                     throw new AssertionError();
                  }

                  if(!field_e && super.field_a == null) {
                     throw new AssertionError();
                  }

                  if(!field_e && (class_51)super.field_a.getState().getController() == null) {
                     throw new AssertionError();
                  }

                  if(!field_e && !this.a21(var6)) {
                     throw new AssertionError();
                  }

                  this.field_a.a47().signatureRequestBuffer.add((Streamable)(new RemoteVector3i(new class_47(var6), false)));
               }
            }
         }
      } else {
         System.err.println("WAITING FOR PIPE!! " + super.field_a);
      }

      long var8;
      if((var8 = System.currentTimeMillis() - var1) > 5L) {
         System.err.println("[CLIENT][SEGMENTPROVIDER] WARNING: doNTSegmentSinaturesRequests of " + super.field_a + " took: " + var8 + "; requests: " + var3);
      }

   }

   protected final class_675 a1(class_47 var1, boolean var2) {
      if(!field_e && var2) {
         throw new AssertionError();
      } else {
         return super.a1(var1, var2);
      }
   }

   protected final void a2(class_675 var1) {
      ((class_371)var1.a15().getState()).a26().a(var1);
   }

   private float a3(class_47 var1) {
      Transform var2 = super.field_a.getWorldTransformClient();
      this.field_b.set((float)var1.field_a + var2.origin.field_x, (float)var1.field_b + var2.origin.field_y, (float)var1.field_c + var2.origin.field_z);
      this.field_b.sub(class_967.a1().a83());
      return this.field_b.lengthSquared();
   }

   public final ObjectOpenHashSet a4() {
      return this.field_d;
   }

   public final ObjectOpenHashSet b() {
      return this.field_c;
   }

   public final ArrayList a5() {
      return this.field_b;
   }

   private void f(class_675 var1) {
      if(!field_e && !var1.g() && var1.a16() == null) {
         throw new AssertionError(" SEGMENT NULL: " + var1.b1() + "; " + var1.field_a + " " + var1.a15());
      } else if(!field_e && var1 == null) {
         throw new AssertionError();
      } else {
         if(!super.field_a.contains(var1)) {
            super.field_a.add(var1);
         }

      }
   }

   private void j() {
      long var1 = System.currentTimeMillis();
      Segment var5 = null;
      if(!this.field_d.isEmpty()) {
         ObjectOpenHashSet var3 = this.field_d;
         synchronized(this.field_d) {
            ObjectIterator var4 = this.field_d.iterator();

            while(var4.hasNext()) {
               var5 = (Segment)var4.next();
               var4.remove();
               if(!field_e && var5 == null) {
                  throw new AssertionError();
               }

               this.f((class_675)var5);
            }
         }
      }

      long var7;
      if((var7 = System.currentTimeMillis() - var1) > 5L) {
         System.err.println("[CLIENT][SEGMENTPROVIDER] WARNING: handleReceivedSegments of " + super.field_a + " took: " + var7);
      }

   }

   private class_667 a6(class_661 var1) {
      if(this.a3(var1.field_a) >= class_967.field_a.a() * class_967.field_a.a() * class_967.field_a.a()) {
         return class_667.field_d;
      } else if(super.field_a.getSegmentBuffer().a5(var1.field_a) != var1) {
         return class_667.field_e;
      } else {
         for(int var2 = 0; var2 < 6; ++var2) {
            if((var1.field_a & Element.SIDE_FLAG[var2]) != Element.SIDE_FLAG[var2]) {
               this.field_d.b1(var1.field_a);
               super.field_a.getNeighborSegmentPos(this.field_d, var2, this.field_e);
               if(!this.a21(this.field_e)) {
                  var1.field_a += Element.SIDE_FLAG[var2];
               } else if(super.field_a.getSegmentBuffer().a3(this.field_e)) {
                  var1.field_a += Element.SIDE_FLAG[var2];
                  ++this.field_c;
               } else if(!this.field_a.contains(this.field_e) && !this.field_b.contains(this.field_e) && !this.field_a.contains(this.field_e) && this.a3(this.field_e) < class_967.field_a.a() * class_967.field_a.a()) {
                  class_47 var3 = new class_47(this.field_e);
                  this.field_e.add(var3);
                  var1.field_a += Element.SIDE_FLAG[var2];
                  ++this.field_c;
               }
            }

            ++this.field_b;
         }

         if(!field_e && var1.field_a >= 64) {
            throw new AssertionError(var1.field_a + "; " + var1);
         } else if(var1.field_a == 63) {
            return class_667.field_c;
         } else {
            return class_667.field_b;
         }
      }
   }

   public final void b1() {
      ArrayList var1 = this.field_b;
      synchronized(this.field_b) {
         for(int var2 = 0; var2 < this.field_b.size(); ++var2) {
            try {
               Segment var3;
               if((var3 = (Segment)this.field_b.get(var2)) == null) {
                  System.err.println("[CLIENT-SEGMENT-PROVIDER] ERROR-REQUESTED SEG: NULL: " + this.field_d);
                  this.field_b.remove(var2);
                  --var2;
               } else {
                  class_675 var8 = (class_675)var3;
                  if(System.currentTimeMillis() - var8.b8() > 50000L) {
                     System.err.println("[CLIENT-SEGMENT-PROVIDER] REQUEST TIMEOUT FOR " + var8 + " REREQUESTING SIGNATURE (" + super.field_a + ")");
                     if(((class_371)super.field_a.getState()).a7().containsKey(var8.a15().getId())) {
                        var8.b9(System.currentTimeMillis());
                        ObjectOpenHashSet var4 = this.field_a;
                        synchronized(this.field_a) {
                           this.field_a.add(new class_47(var8.field_a));
                           this.field_b.remove(var2);
                           --var2;
                        }
                     } else {
                        System.err.println("REQUEST IN ANOTHER SECTOR. DISCARDING " + var8);
                        this.field_b.remove(var2);
                        --var2;
                     }
                  }
               }
            } catch (Exception var6) {
               System.err.println("[CLIENTSEGEMENTPROVIDER] CATCHED EXCEPTION " + var6.getClass() + ": " + var6.getMessage() + " (" + super.field_a + ")");
            }
         }

      }
   }

   public final void c() {
      ++field_a;
   }

   private boolean a7(class_790 var1) {
      try {
         long var2;
         return (var2 = this.field_a.a5(var1.field_a.field_a, var1.field_a.field_b, var1.field_a.field_c)) >= 0L && var2 >= var1.field_a;
      } catch (FileNotFoundException var4) {
         return false;
      }
   }

   public final void a8(Segment var1) {
      ArrayList var2 = this.field_b;
      synchronized(this.field_b) {
         this.field_b.remove(var1);
      }
   }

   final int a9(class_675 var1) {
      return this.field_a.a8(var1.field_a.field_a, var1.field_a.field_b, var1.field_a.field_c, var1);
   }

   protected final boolean a10() {
      return this.field_b.size() < 200 && this.field_a.size() < 200;
   }

   protected final class_47 a11() {
      ArrayList var1 = (ArrayList)this.field_a;
      this.field_d.set(class_967.a1().a83());
      int var2 = -1;

      for(int var3 = 0; var3 < var1.size(); ++var3) {
         class_47 var4 = (class_47)var1.get(var3);
         if(var2 < 0 || this.field_a.compare(var1.get(var2), var4) > 0) {
            var2 = var3;
         }
      }

      return (class_47)var1.remove(var2);
   }

   public final Segment a12(int var1, int var2, int var3) {
      if(!field_e) {
         throw new AssertionError();
      } else {
         throw new CannotImmediateRequestOnClientException(new class_47(var1, var2, var3));
      }
   }

   public final boolean b2() {
      if(!((class_371)super.field_a.getState()).a7().containsKey(super.field_a.getId())) {
         return false;
      } else if(System.currentTimeMillis() - this.field_c > 1000L) {
         this.d();
         this.field_c = System.currentTimeMillis();
         return true;
      } else {
         NetworkObject var1;
         if((var1 = (NetworkObject)super.field_a.getState().getLocalAndRemoteObjectContainer().getRemoteObjects().get(super.field_a.getId())) != null && !var1.newObject && class_967.a1() != null && super.field_a.getLocalCamPos().field_z != Float.POSITIVE_INFINITY) {
            long var2 = System.currentTimeMillis();
            this.field_a.set(super.field_a.getLocalCamPos());
            this.field_a.field_a.set((float)(super.field_a.getMinPos().field_a << 4), (float)(super.field_a.getMinPos().field_b << 4), (float)(super.field_a.getMinPos().field_c << 4));
            this.field_a.field_b.set((float)(super.field_a.getMaxPos().field_a << 4), (float)(super.field_a.getMaxPos().field_b << 4), (float)(super.field_a.getMaxPos().field_c << 4));
            int var11 = ByteUtil.b((int)this.field_a.field_x);
            int var4 = ByteUtil.b((int)this.field_a.field_y);
            int var5 = ByteUtil.b((int)this.field_a.field_z);
            this.field_a.b(var11, var4, var5);
            this.field_b = 0;
            this.field_c = 0;
            if(this.field_a.a7(this.field_a)) {
               this.field_b.b(var11 << 4, var4 << 4, var5 << 4);
               if(!super.field_a.getSegmentBuffer().a3(this.field_b) && !this.field_a.contains(this.field_b) && !this.field_b.contains(this.field_b) && !this.field_a.contains(this.field_b)) {
                  if(this.a21(this.field_b)) {
                     this.field_e.add(new class_47(this.field_b));
                  }

                  ++this.field_c;
               }

               ++this.field_b;
            } else {
               Vector3f var6 = this.field_a.a4(this.field_a, new Vector3f());
               class_990 var7;
               (var7 = new class_990()).field_a.field_x = var6.field_x - 16.0F;
               var7.field_a.field_y = var6.field_y - 16.0F;
               var7.field_a.field_z = var6.field_z - 16.0F;
               var7.field_b.field_x = var6.field_x + 16.0F;
               var7.field_b.field_y = var6.field_y + 16.0F;
               var7.field_b.field_z = var6.field_z + 16.0F;
               class_990 var8;
               if((var8 = var7.a5(this.field_a, new class_990())) == null) {
                  return false;
               }

               var8.field_a.field_x = (float)(ByteUtil.a((int)var8.field_a.field_x) << 4);
               var8.field_a.field_y = (float)(ByteUtil.a((int)var8.field_a.field_y) << 4);
               var8.field_a.field_z = (float)(ByteUtil.a((int)var8.field_a.field_z) << 4);
               var8.field_b.field_x = (float)(ByteUtil.a((int)var8.field_b.field_x) << 4);
               var8.field_b.field_y = (float)(ByteUtil.a((int)var8.field_b.field_y) << 4);
               var8.field_b.field_z = (float)(ByteUtil.a((int)var8.field_b.field_z) << 4);

               try {
                  for(int var9 = (int)var8.field_a.field_x; (float)var9 <= var8.field_b.field_x; var9 += 16) {
                     for(var11 = (int)var8.field_a.field_y; (float)var11 <= var8.field_b.field_y; var11 += 16) {
                        for(var4 = (int)var8.field_a.field_z; (float)var4 <= var8.field_b.field_z; var4 += 16) {
                           this.field_b.b(var9, var11, var4);
                           if(!super.field_a.getSegmentBuffer().a3(this.field_b) && !this.field_a.contains(this.field_b) && !this.field_b.contains(this.field_b) && !this.field_a.contains(this.field_b) && !this.field_b.contains(this.field_b)) {
                              if(this.a21(this.field_b)) {
                                 this.field_e.add(new class_47(this.field_b));
                              }

                              ++this.field_c;
                           }

                           ++this.field_b;
                        }
                     }
                  }
               } catch (ArrayIndexOutOfBoundsException var10) {
                  var10.printStackTrace();
               }
            }

            long var13 = System.currentTimeMillis();
            int var14;
            class_661 var16;
            if(this.field_a) {
               for(var14 = 0; var14 < this.field_e; ++var14) {
                  (var16 = this.field_b[var14]).field_a = this.a6(var16);
               }
            } else {
               for(var14 = 0; var14 < this.field_d; ++var14) {
                  (var16 = this.field_a[var14]).field_a = this.a6(var16);
               }
            }

            long var15 = System.currentTimeMillis();
            var11 = this.field_e.size();
            this.a22(this.field_e);
            if(!this.field_a.equals(this.field_c) || System.currentTimeMillis() - this.field_b > 700L) {
               this.field_c.b1(this.field_a);
               this.field_b = System.currentTimeMillis();
            }

            var4 = (int)(System.currentTimeMillis() - var2);
            int var12 = (int)(System.currentTimeMillis() - var15);
            int var3 = (int)(System.currentTimeMillis() - var13) - var12;
            if(var4 > 20) {
               System.err.println("[CLIENTPROVIDER] WARNING: request time total > 10: " + var4 + "; RETtime " + var3 + "; enqTime " + var12 + " ;ITERATIONS: " + this.field_c + " / " + this.field_b + "; Ret REQ size: " + this.field_c.size());
            }

            return var11 > 0;
         } else {
            return false;
         }
      }
   }

   private boolean d() {
      boolean var1 = false;
      NetworkObject var2;
      if((var2 = (NetworkObject)super.field_a.getState().getLocalAndRemoteObjectContainer().getRemoteObjects().get(super.field_a.getId())) != null && !var2.newObject && class_967.a1() != null && super.field_a.getLocalCamPos().field_z != Float.POSITIVE_INFINITY) {
         long var3 = System.currentTimeMillis();
         synchronized(super.field_a.getLocalCamPos()) {
            this.field_a.set(super.field_a.getLocalCamPos());
         }

         this.field_a.field_a.set((float)((super.field_a.getMinPos().field_a << 4) - 8), (float)((super.field_a.getMinPos().field_b << 4) - 8), (float)((super.field_a.getMinPos().field_c << 4) - 8));
         this.field_a.field_b.set((float)((super.field_a.getMaxPos().field_a << 4) + 8), (float)((super.field_a.getMaxPos().field_b << 4) + 8), (float)((super.field_a.getMaxPos().field_c << 4) + 8));
         Vector3f var5 = null;
         if(!this.field_a.a7(this.field_a)) {
            (var5 = this.field_a.a4(this.field_a, new Vector3f())).sub(this.field_a);
            if(var5.length() > class_967.field_a.a() * class_967.field_a.a()) {
               return false;
            }
         }

         int var12 = ByteUtil.b((int)this.field_a.field_x);
         int var6 = ByteUtil.b((int)this.field_a.field_y);
         int var7 = ByteUtil.b((int)this.field_a.field_z);
         int var8 = 0;
         int var9 = 0;
         this.field_a.b(var12, var6, var7);
         if(!this.field_a.equals(this.field_c) || System.currentTimeMillis() - this.field_b > 700L) {
            this.field_c.b1(this.field_a);
            class_990 var13;
            (var13 = new class_990()).field_a.field_x = -80.0F + this.field_a.field_x;
            var13.field_a.field_y = -80.0F + this.field_a.field_y;
            var13.field_a.field_z = -80.0F + this.field_a.field_z;
            var13.field_b.field_x = 80.0F + this.field_a.field_x;
            var13.field_b.field_y = 80.0F + this.field_a.field_y;
            var13.field_b.field_z = 80.0F + this.field_a.field_z;
            if((var13 = var13.a5(this.field_a, new class_990())) == null) {
               if(var5 == null) {
                  return false;
               }

               var5.add(this.field_a);
               super.field_a.getClientTransformInverse().transform(var5);
               var13 = new class_990();
               class_47 var14 = super.field_a.getMaxPos();
               class_47 var16 = super.field_a.getMinPos();
               int var10000;
               if(Math.abs(var14.field_a - var16.field_a) > 0) {
                  field_a.nextInt(Math.abs(var14.field_a - var16.field_a));
                  var10000 = var16.field_a;
               }

               if(Math.abs(var14.field_a - var16.field_a) > 0) {
                  field_a.nextInt(Math.abs(var14.field_b - var16.field_b));
                  var10000 = var16.field_b;
               }

               if(Math.abs(var14.field_a - var16.field_a) > 0) {
                  field_a.nextInt(Math.abs(var14.field_c - var16.field_c));
                  var10000 = var16.field_c;
               }

               var13.field_a.set(0.0F, 0.0F, 0.0F);
               var13.field_b.set(0.0F, 0.0F, 0.0F);
            }

            var13.field_a.field_x = (float)(ByteUtil.a((int)var13.field_a.field_x) << 4);
            var13.field_a.field_y = (float)(ByteUtil.a((int)var13.field_a.field_y) << 4);
            var13.field_a.field_z = (float)(ByteUtil.a((int)var13.field_a.field_z) << 4);
            var13.field_b.field_x = (float)(ByteUtil.a((int)var13.field_b.field_x) << 4);
            var13.field_b.field_y = (float)(ByteUtil.a((int)var13.field_b.field_y) << 4);
            var13.field_b.field_z = (float)(ByteUtil.a((int)var13.field_b.field_z) << 4);

            try {
               for(int var15 = (int)var13.field_a.field_x; (float)var15 <= var13.field_b.field_x; var15 += 16) {
                  for(var6 = (int)var13.field_a.field_y; (float)var6 <= var13.field_b.field_y; var6 += 16) {
                     for(var7 = (int)var13.field_a.field_z; (float)var7 <= var13.field_b.field_z; var7 += 16) {
                        this.field_b.b(var15, var6, var7);
                        if(!super.field_a.getSegmentBuffer().a3(this.field_b) && !this.field_a.contains(this.field_b) && !this.field_b.contains(this.field_b) && !this.field_a.contains(this.field_b)) {
                           var1 = true;
                           if(this.a21(this.field_b)) {
                              this.field_e.add(new class_47(this.field_b));
                           }

                           ++var9;
                        }
                     }
                  }

                  ++var8;
               }
            } catch (ArrayIndexOutOfBoundsException var11) {
               var11.printStackTrace();
            }

            this.a22(this.field_e);
            this.field_b = System.currentTimeMillis();
         }

         if((var12 = (int)(System.currentTimeMillis() - var3)) > 20) {
            System.err.println("[CLIENTPROVIDER] WARNING: WHOLE request time > 10: " + var12 + "; ITERATIONS: " + var9 + " / " + var8);
         }

         return var1;
      } else {
         return false;
      }
   }

   public final void b3(class_675 var1) {
      if(!field_e) {
         throw new AssertionError("no blocked request in client please!");
      } else {
         throw new CannotImmediateRequestOnClientException(var1.field_a);
      }
   }

   public final void c1(class_675 var1) {
      if(!field_e && var1 == null) {
         throw new AssertionError();
      } else {
         boolean var2 = false;
         ObjectOpenHashSet var3 = this.field_d;
         synchronized(this.field_d) {
            var2 = this.field_d.contains(var1);
         }

         boolean var9 = false;
         ArrayList var4 = this.field_b;
         synchronized(this.field_b) {
            var9 = this.field_b.contains(var1);
         }

         if(!var2 && !var9) {
            var1.b9(System.currentTimeMillis());
            var4 = this.field_b;
            synchronized(this.field_b) {
               this.field_b.add(var1);
            }

            ObjectOpenHashSet var10 = this.field_a;
            synchronized(this.field_a) {
               if(!this.field_a.contains(var1.field_a)) {
                  this.field_a.add(new class_47(var1.field_a));
               }

            }
         }
      }
   }

   public final void a13(class_661 var1) {
      this.field_c.add(var1);
   }

   public final void a14(class_745 var1) {
      this.field_a = var1;
   }

   protected final Collection a15() {
      return new class_751();
   }

   private boolean e() {
      if(!this.field_c) {
         this.field_c = this.field_a != null && this.field_a.a1();
      }

      return this.field_c;
   }

   public final void d1() {
      super.d1();
      if(this.e()) {
         class_19 var1 = this;
         long var2 = System.currentTimeMillis();
         int var4;
         if((var4 = this.field_c.size()) > 0) {
            int var5;
            if(this.field_a) {
               this.field_d = 0;

               for(var5 = 0; var5 < var1.field_c.size(); ++var5) {
                  if(((class_661)var1.field_c.get(var5)).field_a.field_a == 0) {
                     var1.field_c.remove(var5);
                     --var5;
                  } else if(var1.field_d < var1.field_a.length) {
                     var1.field_a[var1.field_d] = (class_661)var1.field_c.get(var5);
                     ++var1.field_d;
                  }
               }

               var1.field_a = false;
            } else {
               this.field_e = 0;

               for(var5 = 0; var5 < var1.field_c.size(); ++var5) {
                  if(((class_661)var1.field_c.get(var5)).field_a.field_a == 0) {
                     var1.field_c.remove(var5);
                     --var5;
                  } else if(var1.field_e < var1.field_b.length) {
                     var1.field_b[var1.field_e] = (class_661)var1.field_c.get(var5);
                     ++var1.field_e;
                  }
               }

               var1.field_a = true;
            }
         }

         long var7;
         if((var7 = System.currentTimeMillis() - var2) > 20L) {
            System.err.println("[CLIENT][SEGMENTPROVIDER] WARNING: cleanReturnedRequests of " + var1.field_a + " of size " + var4 + ", took " + var7 + " ms");
         }

         this.i();
         this.h();
         this.g();
         if(!this.field_b && this.e()) {
            this.field_a.c1();
            this.field_b = true;
         }

         if(!this.field_d && this.e()) {
            this.field_a.d();
            this.field_d = true;
         }

         if(class_943.field_Q.a4().equals("ALL_INFO")) {
            class_371.field_d += this.field_a.size();
            class_371.field_e += this.field_b.size();
            class_371.field_f += this.field_c.size();
         }

         if(this.field_a.isEmpty() && this.field_b.isEmpty() && this.field_c.isEmpty() && this.field_d.isEmpty()) {
            if(this.field_d < 0L) {
               this.field_d = System.currentTimeMillis();
               return;
            }

            if(System.currentTimeMillis() - this.field_d > 8000L) {
               this.field_d = -1L;
               return;
            }
         } else if(this.field_d > 0L) {
            this.field_d = -1L;
         }
      }

   }

   public final class_745 a16() {
      return this.field_a;
   }

   public final ObjectOpenHashSet c2() {
      return this.field_b;
   }

   // $FF: synthetic method
   static float a17(class_19 var0, class_47 var1) {
      Transform var2 = var0.field_a.getWorldTransformClient();
      var0.field_c.set((float)var1.field_a, (float)var1.field_b, (float)var1.field_c);
      var2.transform(var0.field_c);
      var0.field_c.sub(var0.field_d);
      return var0.field_c.lengthSquared();
   }

   static {
      (field_a = new class_16()).start();
   }
}
