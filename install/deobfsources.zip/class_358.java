import com.bulletphysics.linearmath.Transform;

public final class class_358 {

   Transform field_a;
   boolean field_a;


   public class_358(Transform var1, boolean var2) {
      this.field_a = var1;
      this.field_a = var2;
   }
}
