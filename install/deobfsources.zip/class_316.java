
public abstract class class_316 extends class_14 {

   protected short field_a;
   protected final Object field_a;


   public class_316(class_371 var1, short var2, String var3, Object var4, int var5) {
      super(var1, 5, var3, var4, String.valueOf(var5));
      this.field_a = var4;
      this.field_a = var2;
   }

   public class_316(class_371 var1, String var2, Object var3) {
      super(var1, 10, var2, var3, "0");
      this.field_a = var3;
      this.field_a = -2;
   }

   public String[] getCommandPrefixes() {
      return null;
   }

   public String handleAutoComplete(String var1, class_1077 var2, String var3) {
      return var1;
   }

   public final boolean a1() {
      return super.field_a.b().indexOf(this) != super.field_a.b().size() - 1;
   }

   public final void a2() {
      super.field_a.a14().field_a.field_a.field_a.e2(false);
   }

   public void onFailedTextCheck(String var1) {
      this.a9(var1);
   }
}
