
final class class_432 extends class_422 {

   // $FF: synthetic field
   private class_431 field_a;


   class_432(class_431 var1, class_371 var2, class_801 var3) {
      this.field_a = var1;
      super(var2, var3);
   }

   public final void a2() {
      this.field_a.a13(400);
      this.field_a.e2(false);
   }
}
