
public class class_300 extends class_403 {

   int field_a;
   private static final long serialVersionUID = -2062138621427988662L;


   public class_300(class_983 var1, class_371 var2, String var3, int var4) {
      super(var1, var3, var2);
      this.field_a = var4;
   }
}
