import java.util.Iterator;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import org.schema.game.common.data.element.ElementCollection;
import org.schema.schine.network.objects.remote.RemoteArray;
import org.schema.schine.network.objects.remote.RemoteIntegerArray;
import org.schema.schine.network.objects.remote.RemoteString;
import org.schema.schine.network.objects.remote.Streamable;

public final class class_359 implements class_74 {

   private String field_a;
   private String field_b;
   public ConcurrentHashMap field_a = new ConcurrentHashMap();
   public ConcurrentHashMap field_b = new ConcurrentHashMap();
   private class_744 field_a;


   public class_359(class_744 var1, String var2) {
      this.field_b = var1.getUniqueIdentifier();
      this.field_a = var1;
      this.field_a = var2;
   }

   public final boolean equals(Object var1) {
      return this.field_a.equals(((class_359)var1).field_a) && this.field_b.equals(((class_359)var1).field_b);
   }

   public final void fromTagStructure(class_79 var1) {}

   public final class_47 a17(int var1) {
      return (class_47)this.field_a.get(Integer.valueOf(var1));
   }

   public final String getUniqueIdentifier() {
      return null;
   }

   public final boolean a18(int var1) {
      return this.field_a.containsKey(Integer.valueOf(var1));
   }

   public final int hashCode() {
      return this.field_a.hashCode() + this.field_b.hashCode();
   }

   public final boolean a19(class_47 var1) {
      return this.field_a.containsValue(var1);
   }

   public final boolean isVolatile() {
      return false;
   }

   public final boolean a20(int var1, class_47 var2, boolean var3) {
      System.err.println("[SHIP][KEYCONFIG] ASSIGNED Key " + var1 + " to " + var2 + " on " + this.field_a + " on " + this.field_a.getState());
      class_47 var4 = (class_47)this.field_a.get(Integer.valueOf(var1));
      if(var2.equals(var4)) {
         return false;
      } else {
         if(var4 != null) {
            this.field_b.remove(var4);
         }

         Integer var5;
         if((var5 = (Integer)this.field_b.get(var2)) != null) {
            this.field_a.remove(var5);
         }

         this.field_a.put(Integer.valueOf(var1), var2);
         this.field_b.put(var2, Integer.valueOf(var1));
         if(var3) {
            this.a24(var1, var2, true);
         }

         return true;
      }
   }

   public final void a21(class_371 var1, class_858 var2) {
      class_743 var9 = var1.a25();
      int var3 = 0;
      if(var9 == null) {
         System.err.println("[ShipKeyConfig] WARNING: no ship for state but tried to update assignments");
      } else {
         class_47 var10000 = new class_47(8, 8, 8);
         class_47 var4 = null;
         long var5 = ElementCollection.getIndex(var10000);
         Iterator var10 = var9.getControlElementMap().getControllingMap().keySet().iterator();

         while(var10.hasNext()) {
            long var7;
            if((var7 = ((Long)var10.next()).longValue()) != var5) {
               var4 = ElementCollection.getPosFromIndex(var7, new class_47());
               if(var2.field_a.contains(var4)) {
                  this.a20(var3, var4, true);
               }

               if(var3 > 9) {
                  break;
               }

               ++var3;
            }
         }

      }
   }

   public final class_47 a22(int var1, boolean var2) {
      class_47 var3;
      if((var3 = (class_47)this.field_a.get(Integer.valueOf(var1))) != null) {
         this.field_b.remove(var3);
         this.field_a.remove(Integer.valueOf(var1));
         if(var2) {
            this.a24(var1, var3, false);
         }

         return var3;
      } else {
         return null;
      }
   }

   public final int a23(class_47 var1) {
      Integer var2;
      if((var2 = (Integer)this.field_b.get(var1)) != null) {
         this.field_b.remove(var1);
         this.field_a.remove(var2);
         this.a24(var2.intValue(), var1, false);
         return var2.intValue();
      } else {
         return -1;
      }
   }

   private void a24(int var1, class_47 var2, boolean var3) {
      synchronized(this.field_a.a117()) {
         RemoteIntegerArray var5;
         (var5 = new RemoteIntegerArray(4, this.field_a.a117())).set(0, Integer.valueOf(var3?var1:-var1 - 1));
         var5.set(1, Integer.valueOf(var2.field_a));
         var5.set(2, Integer.valueOf(var2.field_b));
         var5.set(3, Integer.valueOf(var2.field_c));
         this.field_a.a117().controllerKeyNameBuffer.add((Streamable)(new RemoteString(this.field_a, this.field_a.a117())));
         this.field_a.a117().controllerKeyBuffer.add((RemoteArray)var5);
      }
   }

   public final void a13() {
      synchronized(this.field_a.a117()) {
         Iterator var2 = this.field_a.entrySet().iterator();

         while(var2.hasNext()) {
            Entry var3 = (Entry)var2.next();
            this.a24(((Integer)var3.getKey()).intValue(), (class_47)var3.getValue(), true);
         }

      }
   }

   public final String toString() {
      return "ShipKeyConfiguration [shipIdentifier=" + this.field_a + ", playerIdentifier=" + this.field_b + ", keyControllerMap=" + this.field_a + ", controllerKeyMap=" + this.field_b + "]";
   }

   public final class_79 toTagStructure() {
      return null;
   }
}
