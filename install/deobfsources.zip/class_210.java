
final class class_210 implements class_1410 {

   // $FF: synthetic field
   private class_206 field_a;


   class_210(class_206 var1) {
      this.field_a = var1;
      super();
   }

   public final boolean a1() {
      return false;
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.a()) {
         if(this.field_a.a11().field_a == 0) {
            switch(class_206.a86(this.field_a)) {
            case 1:
               if(this.field_a.a11().field_a) {
                  this.field_a.a11().field_a = false;
                  return;
               }

               this.field_a.a11().field_a = class_206.a86(this.field_a);
               return;
            case 2:
               if(this.field_a.a11().field_b) {
                  this.field_a.a11().field_b = false;
                  return;
               }

               this.field_a.a11().field_a = class_206.a86(this.field_a);
               return;
            case 4:
               if(this.field_a.a11().field_c) {
                  this.field_a.a11().field_c = false;
                  return;
               }

               this.field_a.a11().field_a = class_206.a86(this.field_a);
            case 3:
            default:
               return;
            }
         }

         this.field_a.a11().field_a = 0;
      }

   }
}
