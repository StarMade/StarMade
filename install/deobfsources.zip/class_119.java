
final class class_119 implements class_1410 {

   // $FF: synthetic field
   private static boolean field_a = !fg.class.desiredAssertionStatus();
   // $FF: synthetic field
   private class_113 field_a;


   private class_119(class_113 var1) {
      this.field_a = var1;
      super();
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var2.field_a && var2.field_a == 0) {
         if(var1.b19().equals("INVENTORY")) {
            if(!class_113.a25(this.field_a)) {
               class_113.a26(this.field_a);
               return;
            }
         } else if(var1.b19().equals("WEAPON")) {
            if(!class_113.b4(this.field_a)) {
               class_113.b5(this.field_a);
               return;
            }
         } else if(var1.b19().equals("FACTION")) {
            if(!class_113.c2(this.field_a)) {
               class_113.c3(this.field_a);
               return;
            }
         } else if(var1.b19().equals("CATALOG")) {
            if(!class_113.d2(this.field_a)) {
               class_113.d3(this.field_a);
               return;
            }
         } else if(var1.b19().equals("AI")) {
            if(!class_113.e2(this.field_a)) {
               class_113.e3(this.field_a);
               return;
            }
         } else if(var1.b19().equals("SHOP")) {
            if(!class_113.f2(this.field_a)) {
               class_113.f3(this.field_a);
               return;
            }
         } else if(var1.b19().equals("NAVIGATION")) {
            if(!class_113.g1(this.field_a)) {
               class_113.g2(this.field_a);
               return;
            }
         } else {
            if(var1.b19().equals("X")) {
               class_113.h(this.field_a);
               return;
            }

            if(!field_a) {
               throw new AssertionError("not known command: " + var1.b19());
            }
         }
      }

   }

   public final boolean a1() {
      return !this.field_a.a20().b().isEmpty();
   }

   // $FF: synthetic method
   class_119(class_113 var1, byte var2) {
      this(var1);
   }

}
