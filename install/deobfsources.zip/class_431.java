import com.bulletphysics.collision.dispatch.CollisionWorld;
import com.bulletphysics.linearmath.Transform;
import java.util.Observer;
import javax.vecmath.Vector3f;
import org.lwjgl.input.Keyboard;
import org.schema.game.common.controller.CannotBeControlledException;
import org.schema.game.common.controller.CannotImmediateRequestOnClientException;
import org.schema.game.common.controller.EditableSendableSegmentController;
import org.schema.game.common.controller.SegmentController;
import org.schema.game.common.controller.elements.LiftContainerInterface;
import org.schema.game.common.controller.elements.ManagerContainer;
import org.schema.game.common.controller.elements.PowerAddOn;
import org.schema.game.common.controller.elements.PowerManagerInterface;
import org.schema.game.common.controller.elements.ShieldContainerInterface;
import org.schema.game.common.controller.elements.lift.LiftCollectionManager;
import org.schema.game.common.controller.elements.shield.ShieldCollectionManager;
import org.schema.game.common.data.element.ElementKeyMap;
import org.schema.game.common.data.physics.CubeRayCastResult;
import org.schema.game.common.data.physics.PhysicsExt;
import org.schema.game.network.objects.NetworkSegmentController;
import org.schema.schine.graphicsengine.camera.Camera;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.graphicsengine.shader.ErrorDialogException;
import org.schema.schine.network.objects.remote.RemoteVector4i;
import org.schema.schine.network.objects.remote.Streamable;

public final class class_431 extends class_485 {

   private Camera field_a;
   String field_a;
   private String field_b = "To create a new ship, please enter the name of your choice.\nthe name cannot be changed later (yet)";
   public class_800 field_a;
   private String field_c;
   private String field_d;
   private final class_433 field_a = new class_433();
   private boolean field_d;


   public class_431(class_371 var1) {
      super(var1);
   }

   private void f2(boolean var1) {
      CollisionWorld.ClosestRayResultCallback var2;
      if((var2 = this.a47()) != null && var2.hasHit() && var2 instanceof CubeRayCastResult) {
         CubeRayCastResult var5;
         if((var5 = (CubeRayCastResult)var2).getSegment() != null && var5.getSegment().a15() instanceof EditableSendableSegmentController) {
            var5.getSegment().a15().getControlElementMap().setObs(this);
            Vector3f var3 = new Vector3f(this.a6().a3().a136().origin);
            Vector3f var4 = new Vector3f(class_967.a1().c10());
            if(var1) {
               this.a6().a14().field_a.field_a.field_a.a48((EditableSendableSegmentController)var5.getSegment().a15(), var3, var4, new class_417(this), new class_709(), this.field_a, 6.0F);
               return;
            }

            this.a6().a14().field_a.field_a.field_a.a49((EditableSendableSegmentController)var5.getSegment().a15(), var3, var4, 6.0F, this.field_a);
         }

      } else {
         System.err.println("[PLAYEREXTERNALCONTROLLER] CUBE RESULT NOT AVAILABLE");
      }
   }

   private CollisionWorld.ClosestRayResultCallback a47() {
      Vector3f var1 = new Vector3f(this.a6().a3().a136().origin);
      Vector3f var2 = new Vector3f(this.a6().a3().a136().origin);
      Vector3f var3;
      (var3 = new Vector3f(class_967.a1().c10())).scale(6.0F);
      var2.add(var3);
      CubeRayCastResult var4;
      (var4 = new CubeRayCastResult(var1, var2, Boolean.valueOf(false), (SegmentController)null)).setIgnoereNotPhysical(true);
      var4.setRespectShields(false);
      var4.onlyCubeMeshes = true;
      return ((PhysicsExt)this.a6().a19()).testRayCollisionPoint(var1, var2, var4, false);
   }

   public final class_800 a40() {
      return this.field_a;
   }

   public final void handleKeyEvent() {
      super.handleKeyEvent();
      if(Keyboard.getEventKeyState()) {
         class_24 var10000 = this.a6().a14();
         Vector3f var4 = null;
         class_443 var16 = var10000.field_a.field_a.field_a;
         Keyboard.getEventKey();
         if(var16.a1()) {
            return;
         }

         CollisionWorld.ClosestRayResultCallback var2;
         class_431 var11;
         CubeRayCastResult var23;
         class_47 var22;
         if(Keyboard.getEventKey() == class_367.field_w.a5()) {
            class_800 var1 = this.a6().a3().a137(true);
            if(var1 != null && this.a6().a4().b5(var1.a7().a15())) {
               if(var1.a9() == 56) {
                  if(!this.a6().a3().getGravity().a()) {
                     this.a6().a3().scheduleGravity(new Vector3f(0.0F, -9.89F, 0.0F), var1.a7().a15());
                     this.a6().a4().c1("You entered the\nGravity of \n" + var1.a7().a15().toNiceString());
                     System.err.println("[CLIENT][ACTIVATE] Enter gravity of " + var1.a7().a15().getId());
                  } else if(this.a6().a3().getGravity().field_a == var1.a7().a15()) {
                     this.a6().a3().scheduleGravity(new Vector3f(0.0F, 0.0F, 0.0F), (class_801)null);
                     this.a6().a4().c1("You exited the\nGravity of \n" + var1.a7().a15().toNiceString());
                     System.err.println("[CLIENT][ACTIVATE] Exit gravity of " + var1.a7().a15().getId());
                  }
               } else if(var1.a9() == 94) {
                  Transform var3 = new Transform();
                  var1.a8(var3);
                  (var4 = GlUtil.f(new Vector3f(), var3)).scale(1.5F);
                  var3.origin.add(var4);
                  this.a6().a4().a24(var3.origin);
                  this.a6().a4().d1("Spawning Point Set");
               } else if(var1.a9() == 121) {
                  this.a6().a4().c1("Acitvated ships AI Element\n" + var1.a7().a15().toNiceString());
                  this.a6().a14().field_a.field_a.a16(var1);
               } else if(var1.a9() == 291) {
                  if(this.a6().a20().h1() != 0) {
                     if(this.a6().a45().a146(this.a6().a20().h1()) != null) {
                        this.a6().a4().c1("Acitvated faction block\n" + var1.a7().a15().toNiceString());
                        this.e2(true);
                        (new class_432(this, this.a6(), var1.a7().a15())).c1();
                     } else {
                        this.a6().a4().c1("Cannot activate:\ninvalid faction ID\non you" + var1.a7().a15().toNiceString());
                     }
                  } else {
                     this.a6().a4().c1("You have to be in a faction\nto activate this block" + var1.a7().a15().toNiceString());
                  }
               } else {
                  SegmentController var15;
                  if(var1.a9() == 113) {
                     System.err.println("CHECKING FOR LIFT");
                     if((var15 = var1.a7().a15()) instanceof class_802 && ((class_802)var15).a() instanceof LiftContainerInterface) {
                        LiftContainerInterface var19;
                        LiftCollectionManager var5 = (var19 = (LiftContainerInterface)((class_802)var15).a()).getLiftManager();
                        class_47 var6 = var1.a2(new class_47());
                        var5.activate(var6, true);
                        var19.handleClientRemoteLift(var6);
                     }
                  } else if(var1.a9() == 2) {
                     if((var15 = var1.a7().a15()) instanceof class_802 && ((class_802)var15).a() instanceof PowerManagerInterface) {
                        PowerAddOn var21 = ((PowerManagerInterface)((class_802)var15).a()).getPowerAddOn();
                        if(this.field_c != null) {
                           this.a6().a4().a2(this.field_c);
                        }

                        this.field_c = "POWER INFO\n\nLoad: " + (int)var21.getPower() + "/" + (int)var21.getMaxPower() + "\nRecharge Rate (e/sec): " + (int)var21.getRecharge();
                        this.a6().a4().d1(this.field_c);
                     }
                  } else if(var1.a9() == 3) {
                     if((var15 = var1.a7().a15()) instanceof class_802 && ((class_802)var15).a() instanceof ShieldContainerInterface) {
                        ShieldCollectionManager var26 = ((ShieldContainerInterface)((class_802)var15).a()).getShieldManager();
                        if(this.field_d != null) {
                           this.a6().a4().a2(this.field_d);
                        }

                        this.field_d = "SHIELD INFO\n\nLoad: " + (int)var26.getShields() + "/" + (int)var26.getShieldCapabilityHP() + "\nRecharge Rate (e/sec): " + (int)var26.getShieldRechargeRate() + "\nPower Usage (e/sec): " + (int)(var26.getShieldRechargeRate() * 500L);
                        this.a6().a4().d1(this.field_d);
                     }
                  } else if(var1.a9() != 120 && var1.a9() != 114 && !ElementKeyMap.getFactorykeyset().contains(Short.valueOf(var1.a9()))) {
                     short var17 = var1.a9();
                     boolean var20 = false;
                     if(!ElementKeyMap.getInfo(var17).isEnterable()) {
                        System.err.println("[EXTERNALPLAYER] ACTIVATE BLOCK (std) " + var1);
                        class_47 var18 = var1.a2(new class_47());
                        class_45 var25 = new class_45(var18.field_a, var18.field_b, var18.field_c, var1.a10()?0:1);
                        ((NetworkSegmentController)var1.a7().a15().getNetworkObject()).blockActivationBuffer.add((Streamable)(new RemoteVector4i(var25, var1.a7().a15().getNetworkObject())));
                     } else {
                        boolean var14;
                        if(var1 != null && !this.a6().a4().b5(var1.a7().a15())) {
                           var14 = false;
                        } else if(!(var1.a7().a15() instanceof class_365)) {
                           this.a6().a4().b1("ERROR\n \nCannot enter here.\nOnly ships can be entered\nat the moment!");
                           var14 = false;
                        } else if(ElementKeyMap.getInfo(var1.a9()).isEnterable()) {
                           label192: {
                              var10000 = this.a6().a14();
                              var4 = null;
                              class_443 var27 = var10000.field_a.field_a.field_a;
                              if(var1.a7().a15() instanceof class_743) {
                                 if(var1.a9() == 1 && !((class_743)var1.a7().a15()).a78().isEmpty()) {
                                    this.a6().a4().b1("ERROR\n \nCannot enter here.\nThere is already someone in this ship\nyou can still enter\ncomputers, etc. though");
                                    var14 = false;
                                    break label192;
                                 }

                                 var27.a51().a16(var1);
                              } else if(var1.a7().a15() instanceof class_780) {
                                 var27.a53().a16(var1);
                              } else if(var1.a7().a15() instanceof class_848) {
                                 var27.a53().a16(var1);
                              } else {
                                 if(!(var1.a7().a15() instanceof class_864)) {
                                    throw new ErrorDialogException("Cannot enter " + var1.a7().a15());
                                 }

                                 var27.a53().a16(var1);
                              }

                              this.a6().a4().a14(this.a6().a3(), (class_365)var1.a7().a15(), new class_47(), var1.a2(new class_47()), true);
                              var14 = true;
                           }
                        } else {
                           this.a6().a4().b1("ERROR\n \nCannot enter ship here.\nMust enter at core or\nanother controller!");
                           var14 = false;
                        }

                        if(!var14) {
                           this.a6().a4().b1("Cannot activate this block");
                        }
                     }
                  } else if((var15 = var1.a7().a15()) instanceof class_802 && ((class_802)var15).a() instanceof class_647) {
                     var22 = var1.a2(new class_47());
                     ManagerContainer var24;
                     class_635 var28 = (var24 = ((class_802)var15).a()).getInventory(var22);
                     System.err.println("CHECK FOR INVENTORY: " + var22 + " -> " + var28);
                     if(var28 == null) {
                        System.err.println("Inventory NULL: " + var24.printInventories());
                     } else {
                        this.a6().a4().c1("Opened\n" + ElementKeyMap.getInfo(var1.a9()).getName() + "\nLocation: " + var28.a44() + "\nof " + var15.toNiceString());
                     }

                     this.a6().a14().field_a.field_a.a63(var28);
                  } else {
                     this.a6().a4().b1("Error: Chest/Recycler Element\ndoes only work on\nships & space stations (yet)");
                  }
               }
            }
         } else if(Keyboard.getEventKey() == class_367.field_z.a5()) {
            var11 = this;
            if((var2 = this.a47()) != null && var2.hasHit() && var2 instanceof CubeRayCastResult) {
               if((var23 = (CubeRayCastResult)var2).getSegment() != null && var23.getSegment().a15() instanceof EditableSendableSegmentController) {
                  var22 = var23.getSegment().a14(var23.cubePos, new class_47());
                  if(this.field_a != null && this.field_a.a2(new class_47()).equals(var22)) {
                     this.field_a = null;
                  } else {
                     try {
                        var11.field_a = var23.getSegment().a15().getSegmentBuffer().a9(var22, true);
                        System.err.println("External Selected " + var11.field_a);
                     } catch (CannotImmediateRequestOnClientException var9) {
                        var9.printStackTrace();
                     }
                  }
               } else {
                  this.field_a = null;
               }
            } else {
               this.field_a = null;
            }
         }

         if(Keyboard.getEventKey() == class_367.field_A.a5()) {
            var11 = this;
            if(this.field_a != null && (var2 = this.a47()) != null && var2.hasHit() && var2 instanceof CubeRayCastResult && (var23 = (CubeRayCastResult)var2).getSegment() != null && var23.getSegment().a15() instanceof EditableSendableSegmentController && this.a6().a4().a31((EditableSendableSegmentController)var23.getSegment().a15())) {
               var22 = var23.getSegment().a14(var23.cubePos, new class_47());

               try {
                  var11.field_a.a7().a15().setCurrentBlockController(var11.field_a, var22);
                  return;
               } catch (CannotBeControlledException var10) {
                  this.a81(var10);
               }
            }

            return;
         }

         if(Keyboard.isKeyDown(42)) {
            var10000 = this.a6().a14();
            var4 = null;
            var10000.field_a.field_a.field_a.b();
            return;
         }

         if(Keyboard.getEventKey() == class_367.field_x.a5()) {
            if(this.a6().a3().a137(false) != null) {
               this.a6().a4().b1("ERROR\n \nCannot spawn ship here.\nNo space!");
               return;
            }

            class_418 var13;
            (var13 = new class_418(this, this.a6(), "New Ship", this.field_b, this.a6().getPlayerName() + "_" + System.currentTimeMillis())).a10(new class_419());
            synchronized(this.a6().b()) {
               this.a6().b().add(var13);
               this.e2(true);
               return;
            }
         }

         if(Keyboard.getEventKey() == class_367.field_y.a5()) {
            if(this.a6().a20().b4() < 1000000) {
               this.a6().a4().b1("You don\'t have enough money\nfor a Space Station \n(1000000)");
               return;
            }

            if(this.a6().a3().a137(false) != null) {
               this.a6().a4().b1("ERROR\n \nCannot spawn station here.\nNo space!");
               return;
            }

            class_420 var12;
            (var12 = new class_420(this, this.a6(), "New Space Station", this.field_b, this.a6().getPlayerName() + "_" + System.currentTimeMillis())).a10(new class_421());
            synchronized(this.a6().b()) {
               this.a6().b().add(var12);
               this.e2(true);
               return;
            }
         }
      }

   }

   public final void a12(class_941 var1) {
      if(!super.field_a && !this.e1() && !var1.field_a) {
         if(var1.field_a == 0) {
            this.f2(!class_943.field_a.b1());
         } else if(var1.field_a == 1) {
            this.f2(class_943.field_a.b1());
         }
      }

      super.a12(var1);
   }

   public final void a9(String var1) {
      this.setChanged();
      this.notifyObservers(var1);
   }

   public final void b2(boolean var1) {
      if(var1) {
         if(this.a6().a3() == null) {
            this.c2(false);
            return;
         }

         this.field_a.field_a = false;
         this.field_a.field_b = false;
         this.field_a.field_c = false;
         class_459 var2;
         (var2 = this.a6().a14().field_a.field_a.field_a.a50()).field_a.field_a = 1;
         var2.field_b.field_a = 1;
         var2.field_c.field_a = 1;
         if(this.field_a == null) {
            this.field_a = new class_195(this.a6(), this.a6().a3());
         }

         if(((class_195)this.field_a).a80() != this.a6().a3()) {
            ((class_195)this.field_a).a82(this.a6().a3());
         }

         class_967.a9(this.field_a);
      }

      super.b2(var1);
   }

   public final synchronized void addObserver(Observer var1) {
      super.addObserver(var1);
   }

   public final void a15(class_935 var1) {
      class_1008.field_a = true;
      if(this.field_a != null) {
         this.field_a.a12();
         if(this.field_a.a9() == 0) {
            this.field_a = null;
         }
      }

      if(this.field_d) {
         this.field_d = false;
      }

      if(this.a6().a3() == null) {
         this.c2(false);
         this.a6().a14().field_a.field_a.c2(true);
      }

   }

   public final void b() {
      this.field_d = true;
   }
}
