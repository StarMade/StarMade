
final class class_20 {

   class_744 field_a;
   long field_a;


   public class_20(class_744 var1, long var2) {
      this.field_a = var1;
      this.field_a = var2;
   }
}
