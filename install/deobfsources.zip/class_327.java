import java.io.IOException;
import org.schema.schine.graphicsengine.core.ResourceException;

final class class_327 extends class_73 {

   public final void a(class_66 var1) {
      try {
         System.err.println("Loading marble seamless");
         class_333.field_b = class_967.a3().a6("data/./textures/marble-seamless-texture.png", true);
         System.err.println("Loading marble seamless DONE");
      } catch (IOException var2) {
         var2.printStackTrace();
         throw new ResourceException("data/./textures/marble-seamless-texture.png");
      }
   }
}
