import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.schema.game.client.view.SegmentDrawer;
import org.schema.game.client.view.cubes.CubeMeshBufferContainer;
import org.schema.game.common.data.world.SegmentData;

public final class class_215 extends Thread {

   private class_386 field_a;
   private class_661 field_a;
   private class_661 field_b;
   private class_213 field_a;
   // $FF: synthetic field
   private static boolean field_a = !SegmentDrawer.class.desiredAssertionStatus();
   // $FF: synthetic field
   private SegmentDrawer field_a;


   public class_215(SegmentDrawer var1, class_213 var2) {
      this.field_a = var1;
      super("LightUpdate" + SegmentDrawer.field_a++);
      this.setPriority(4);
      this.field_a = new class_386();
      this.field_a = var2;
   }

   public final void a(class_661 var1) {
      synchronized(this) {
         this.field_a = var1;
         this.notify();
      }
   }

   private void a1(class_661 var1, CubeMeshBufferContainer var2, class_400 var3) {
      while(true) {
         try {
            if(!var1.g() && var1.a16() != null) {
               SegmentData var4;
               synchronized(var4 = var1.a16()) {
                  if(var4.getSize() > 0) {
                     if(!field_a && var4 == null) {
                        throw new AssertionError();
                     }

                     this.field_a.a7(var2);
                  }

                  if(!field_a && var4 == null) {
                     throw new AssertionError();
                  }

                  this.field_a.a1(var4, var2);
                  SegmentDrawer var10000 = this.field_a;
                  SegmentDrawer.a64(var3, var4, var2);
                  return;
               }
            }

            return;
         } catch (Exception var10) {
            var10.printStackTrace();
            System.err.println("[CLIENT] Exception: " + var10.getClass().getSimpleName() + " in computing Lighting. retrying");
         }
      }
   }

   public final void run() {
      try {
         while(!class_927.a1()) {
            synchronized(this) {
               while(this.field_a == null && this.field_b == null) {
                  this.wait();
               }

               this.field_b = this.field_a;
               this.field_a = null;
            }

            class_661 var2 = this.field_b;
            class_215 var1 = this;
            if(!field_a && var2.b5() != null) {
               throw new AssertionError();
            }

            Object var3 = var2.field_a;
            synchronized(var2.field_a) {
               class_400 var4 = SegmentDrawer.field_a.a3(var2);
               var2.a33(var4);
               CubeMeshBufferContainer var5 = var2.a31();
               var1.a1(var2, var5, var4);
               ObjectArrayList var12 = var1.field_a.field_a;
               synchronized(var1.field_a.field_a) {
                  int var13;
                  if((var13 = var1.field_a.field_a.indexOf(var2)) >= 0) {
                     if(!field_a && var2.getId() == ((class_661)var1.field_a.field_a.get(var13)).getId()) {
                        throw new AssertionError();
                     }

                     synchronized(SegmentDrawer.a65(var1.field_a)) {
                        SegmentDrawer.a65(var1.field_a).add(var1.field_a.field_a.get(var13));
                     }

                     var1.field_a.field_a.remove(var13);
                  }

                  var1.field_a.field_a.add(var2);
               }
            }

            ++this.field_a.field_a;
            Thread.sleep(3L);
            this.field_a.a(this, this.field_b, true);
            this.field_b = null;
         }

      } catch (InterruptedException var11) {
         var11.printStackTrace();
      }
   }

}
