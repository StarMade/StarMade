import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;
import org.schema.game.common.data.UploadInProgressException;
import org.schema.game.common.updater.FileUtil;
import org.schema.schine.network.objects.remote.RemoteStringArray;

public final class class_10 implements Observer {

   private class_371 field_a;
   private final ArrayList field_a = new ArrayList();
   private final ArrayList field_b = new ArrayList();
   private final ArrayList field_c = new ArrayList();
   private final ArrayList field_d = new ArrayList();
   private final Map field_a = new HashMap();
   private String field_a = "defaultMale";
   private boolean field_a = false;
   private boolean field_b = false;
   private class_9 field_a;


   public class_10(class_371 var1) {
      this.field_a = var1;
      var1.addObserver(this);
   }

   public final void a() {
      if(!this.field_c.isEmpty()) {
         ArrayList var1 = this.field_c;
         synchronized(this.field_c) {
            while(!this.field_c.isEmpty()) {
               class_744 var2 = (class_744)this.field_c.remove(0);
               this.field_a.put(var2, new class_9(var2));
               this.field_a = true;
            }
         }
      }

      if(this.field_a != null) {
         this.a1(this.field_a);
      } else {
         class_10 var12 = this;
         class_9 var4;
         File var5;
         if(!this.field_a.isEmpty()) {
            ArrayList var13 = this.field_a;
            synchronized(this.field_a) {
               while(!var12.field_a.isEmpty()) {
                  class_20 var3;
                  if(!(var3 = (class_20)var12.field_a.remove(0)).field_a.a7()) {
                     var4 = new class_9(var3.field_a);
                     var12.field_a.put(var3.field_a, var4);
                     if((var5 = new File(var4.field_a.a131().field_a + var4.field_a.getName() + ".png")).exists()) {
                        var4.field_a = var5.lastModified();
                     }

                     var4.field_b = var3.field_a;
                     var12.field_a = true;
                  }
               }
            }
         }

         boolean var14 = true;
         if(var12.field_a) {
            Iterator var16 = var12.field_a.values().iterator();

            while(var16.hasNext()) {
               var4 = (class_9)var16.next();
               if(var12.field_b || var4.field_a.a7()) {
                  if(var12.field_a != null) {
                     break;
                  }

                  var5 = null;
                  if(!var4.field_b) {
                     if(var4.field_b < 0L) {
                        if(!var4.field_a) {
                           if((var5 = new File(var12.field_a.a20().a131().field_a + var4.field_a.getName() + ".png")).exists()) {
                              var4.field_a = var5.lastModified();
                           }

                           var12.field_a.a4().a29().b(var4.field_a.getName());
                           var4.field_a = true;
                        } else {
                           ArrayList var17 = var12.field_d;
                           synchronized(var12.field_d) {
                              for(int var6 = 0; var6 < var12.field_d.size(); ++var6) {
                                 String[] var15;
                                 if((var15 = (String[])var12.field_d.get(var6))[0].equals(var4.field_a.getName())) {
                                    var4.field_b = Long.parseLong(var15[1]);
                                 }
                              }
                           }
                        }
                     } else if(var4.field_a.a7()) {
                        if(!var12.field_a.equals("defaultMale")) {
                           var5 = new File(var12.field_a);
                           var4.field_a = var5.lastModified();
                        }

                        if(var4.field_a > var4.field_b) {
                           if(var12.field_a.equals("defaultMale")) {
                              var12.field_a.a20().a131().a3(var12.field_a);
                           } else {
                              try {
                                 (new File(var12.field_a)).setLastModified(System.currentTimeMillis());
                                 var12.field_a.a20().a131().b1(var12.field_a);
                              } catch (IOException var7) {
                                 var7.printStackTrace();
                              } catch (UploadInProgressException var8) {
                                 var8.printStackTrace();
                              }
                           }

                           var4.field_b = true;
                           var4.field_a.a131().f();
                        } else {
                           var4.field_b = true;
                           var4.field_a.a131().a3(var12.field_a);
                           var4.field_a.a131().f();
                        }

                        var12.field_b = true;
                     } else if(var4.field_a.a131().a2().length() != 0) {
                        if(!var4.field_a.a131().a2().equals("defaultMale") && var4.field_a < var4.field_b) {
                           var12.field_a = var4;
                        } else {
                           var4.field_b = true;
                           var4.field_a.a131().f();
                        }
                     }

                     var14 = false;
                  }
               }
            }
         }

         var12.field_a = var14;
      }
   }

   private void a1(class_9 var1) {
      File var5;
      if(!var1.field_c) {
         StringBuilder var10000 = new StringBuilder();
         var5 = null;
         String var9 = var10000.append(var1.field_a.getName()).append(".png").toString();
         System.err.println("[CLIENT] REQUESTING FILE FOR DOWNLOAD: " + var9);
         var1.field_c = true;
         this.field_a.a4().a29().a3(var9);
      } else {
         if(!this.field_b.isEmpty()) {
            ArrayList var2 = this.field_b;
            synchronized(this.field_b) {
               System.err.println("RECEIVED FILES: " + this.field_b);
               var5 = null;
               class_744 var3 = var1.field_a;
               int var4 = 0;

               while(var4 < this.field_b.size()) {
                  if(!(var5 = (File)this.field_b.get(var4)).getName().equals(var3.getName() + ".png")) {
                     ++var4;
                  } else {
                     String var6 = var3.a131().field_a;
                     File var10;
                     (var10 = new File(var6 + var3.getName() + ".png")).delete();

                     try {
                        var10.createNewFile();
                        FileUtil.b(var5, var10);
                        var5.delete();
                        var10.setLastModified(var1.field_b);
                     } catch (IOException var7) {
                        var7.printStackTrace();
                     }

                     this.field_b.remove(var4);
                     var1.field_b = true;
                     var3.a131().f();
                     break;
                  }
               }
            }

            this.field_a = null;
         }

      }
   }

   public final void update(Observable var1, Object var2) {
      if(var2 instanceof class_744 && this.field_a.getLocalAndRemoteObjectContainer().getLocalObjects().containsKey(((class_744)var2).getId())) {
         ArrayList var4 = this.field_c;
         synchronized(this.field_c) {
            System.err.println("[CLIENT][TEXTURE][SYNCHRONIZER] ADDED TO UPDATE QUEUE: " + var2 + " for " + this.field_a.a20());
            this.field_c.add((class_744)var2);
         }
      }
   }

   public final void a2(RemoteStringArray var1) {
      ArrayList var2 = this.field_d;
      synchronized(this.field_d) {
         this.field_d.add(new String[]{(String)var1.get(0).get(), (String)var1.get(1).get()});
      }
   }

   public final void a3(File var1) {
      ArrayList var2 = this.field_b;
      synchronized(this.field_b) {
         this.field_b.add(var1);
      }
   }

   public final void a4(class_744 var1, long var2) {
      ArrayList var4 = this.field_a;
      synchronized(this.field_a) {
         this.field_a.add(new class_20(var1, var2));
      }
   }

   public final void a5(String var1) {
      this.field_a = var1;
   }
}
