import it.unimi.dsi.fastutil.floats.FloatArrayList;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.schema.game.client.view.cubes.CubeMeshBufferContainer;
import org.schema.game.client.view.cubes.CubeOptOptMesh;
import org.schema.game.common.data.element.ElementKeyMap;
import org.schema.game.common.data.world.SegmentData;

public final class class_400 {

   private int field_b;
   private int field_c;
   private int field_d;
   public class_661 field_a;
   private static IntOpenHashSet field_a = new IntOpenHashSet();
   public CubeOptOptMesh field_a;
   public boolean field_a;
   public static int field_a;


   public class_400() {
      new FloatArrayList();
   }

   public final void a(SegmentData var1, CubeMeshBufferContainer var2) {
      var2.field_a.rewind();
      var2.field_a.limit(var2.field_a.capacity());
      this.field_c = 0;
      this.field_b = 0;

      int var3;
      int var4;
      int var6;
      for(var3 = 0; var3 < 4096; ++var3) {
         var4 = var3 * 3;
         short var5;
         if(((var5 = var1.getType(var4)) != 122 || var1.isActive(var4)) && var5 != 0) {
            ++this.field_c;
            if(ElementKeyMap.getInfo(var5).isBlended()) {
               var2.field_a.put(this.field_b, var3);
               var2.field_b.put(this.field_b, var5);
               ++this.field_b;
            } else {
               for(var6 = 0; var6 < 6; ++var6) {
                  CubeMeshBufferContainer.a8(var2, var3, var4, var1, class_1384.field_a[var6], var6, var5);
               }
            }
         }
      }

      var2.field_a.position();

      for(var3 = 0; var3 < this.field_b; ++var3) {
         int var7 = (var4 = var2.field_a.get(var3)) * 3;

         for(var6 = 0; var6 < 6; ++var6) {
            CubeMeshBufferContainer.a8(var2, var4, var7, var1, class_1384.field_a[var6], var6, var2.field_b.get(var3));
         }
      }

      this.field_d = var2.field_a.position();
      int var10000 = this.field_d;
      var10000 = CubeMeshBufferContainer.field_a;
   }

   public final int a1() {
      return this.field_b;
   }

   public final void a2(CubeMeshBufferContainer var1) {
      if(this.field_a == null) {
         this.field_a = new CubeOptOptMesh();
      }

      this.field_a.a181(var1.field_a);
   }

   public final void a3() {
      this.field_a.b();
      ++field_a;
   }

   public static void b() {
      field_a.clear();
   }

   static {
      new Object2ObjectOpenHashMap();
   }
}
