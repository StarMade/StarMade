import org.schema.schine.network.client.ClientState;
import org.schema.schine.network.objects.Sendable;

final class class_240 extends class_972 {

   private Sendable field_a;


   public class_240(class_242 var1, Sendable var2, ClientState var3) {
      super(new class_190(var3), new class_190(var3), var3);
      this.field_a = var2;
      this.a12((class_935)null);
      super.field_a = var2;
      class_242.a107(var1).put(var2, this);
   }

   public final boolean equals(Object var1) {
      return this.field_a.equals(((class_240)var1).field_a);
   }

   public final int hashCode() {
      return this.field_a.getId();
   }

   public final void a12(class_935 var1) {
      ((class_190)super.field_a).a15(String.valueOf(this.field_a.getId()), this.field_a.toString(), this.a16(), "", "");
      ((class_190)super.field_b).a15(String.valueOf(this.field_a.getId()), this.field_a.toString(), this.a16(), "", "");
   }

   private String a16() {
      return this.field_a instanceof class_801?String.valueOf(((class_801)this.field_a).getSectorId()):"-";
   }
}
