import java.util.ArrayList;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public final class class_82 extends class_932 implements class_1410 {

   private class_940 field_a;
   private class_970 field_a;
   private class_970 field_b;
   private class_461 field_a;
   private boolean field_a;


   public class_82(ClientState var1, class_461 var2) {
      super(var1);
      super.field_g = true;
      this.a143(this);
      this.field_a = var2;
      this.field_a = new class_970(class_967.a2().a5("tools-16x16-gui-"), this.a24());
      this.field_b = new class_970(class_967.a2().a5("tools-16x16-gui-"), this.a24());
      this.field_a = new class_940(30, 30, class_28.e(), this.a24());
   }

   public final void a1(class_964 var1, class_941 var2) {
      if(var2.field_a && var2.field_a == 0) {
         System.err.println("XCALLBACk");
      }

   }

   public final void a2() {}

   protected final void d() {}

   public final void b() {
      if(!this.field_a) {
         this.c();
      }

      GlUtil.d1();
      this.r();
      this.field_a.b();
      this.field_a.b();
      this.field_b.b();
      GlUtil.c2();
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final float b1() {
      return this.field_a.b1() + this.field_a.b1() + this.field_b.b1();
   }

   public final boolean a4() {
      return false;
   }

   public final void c() {
      this.field_a.field_b = new ArrayList();
      this.field_a.field_b.add(this.field_a.toString());
      this.field_a.c();
      this.field_a.field_g = true;
      this.field_b.field_g = true;
      this.field_a.a143(new class_203(this));
      this.field_b.a143(new class_204(this));
      this.field_a.a_2(21);
      this.field_b.a_2(20);
      this.field_a.a83().field_x = this.field_a.b1();
      this.field_b.a83().field_x = this.field_a.b1() + this.field_a.b1();
      this.field_a = true;
   }

   // $FF: synthetic method
   static class_461 a5(class_82 var0) {
      return var0.field_a;
   }

   // $FF: synthetic method
   static void a6(class_82 var0) {
      var0.field_a.field_b.set(0, var0.field_a.toString());
   }
}
