import java.util.Collection;
import org.schema.schine.network.client.ClientState;

final class class_280 extends class_160 {

   class_280(ClientState var1) {
      super(var1, false);
   }

   public final Collection a50() {
      return ((class_371)this.a24()).a20().a112().field_a;
   }
}
