
public class class_3 extends class_11 {

   private static class_853 field_a;
   private Object field_a;
   private Object field_b;
   private Object field_c;
   private Object field_d;
   // $FF: synthetic field
   private static boolean field_b = !G.class.desiredAssertionStatus();


   public class_3(class_371 var1) {
      super(var1);
      if(field_a == null) {
         field_a = new class_853(var1, this);
      }

      this.b();
   }

   public final void a(class_964 var1, class_941 var2) {
      if(var1.b19() != null && !var1.l1() && var1.a_()) {
         class_967.b("0022_action - buttons push small");
      }

      if(var2.field_a && var2.field_a == 0) {
         if(var1.b19().equals("OK")) {
            class_967.b("0022_menu_ui - enter");
            this.d();
            super.field_a.a14().field_a.c2(false);
            super.field_a.a14().field_a.d2(true);
            super.field_a.a14().field_a.a13(200);
            if(this.field_a != class_943.field_b.a4()) {
               System.err.println("ScreenSetting Changed");
               class_927.b3();
            }

            if(this.field_b != class_943.field_d.a4()) {
               System.err.println("ScreenSetting Changed");
               class_927.b3();
            }

            if(this.field_c != class_943.field_c.a4()) {
               System.err.println("ScreenSetting Changed");
               class_927.b3();
            }

            if(this.field_d != class_943.field_e.a4()) {
               System.err.println("VIS distance Changed");
               class_967.field_a.a1();
            }

            this.b();
            return;
         }

         if(var1.b19().equals("CANCEL")) {
            class_967.b("0022_menu_ui - back");
            this.d();
            super.field_a.a14().field_a.c2(false);
            super.field_a.a14().field_a.d2(true);
            super.field_a.a14().field_a.a13(200);
            return;
         }

         if(var1.b19().equals("X")) {
            class_967.b("0022_menu_ui - back");
            this.d();
            super.field_a.a14().field_a.c2(false);
            super.field_a.a14().field_a.d2(true);
            super.field_a.a14().field_a.a13(200);
            return;
         }

         if(!field_b) {
            throw new AssertionError("not known command: \'" + var1.b19() + "\'");
         }
      }

   }

   public void handleKeyEvent() {}

   public final boolean a1() {
      return false;
   }

   public final void a2() {}

   private void b() {
      this.field_a = class_943.field_b.a4();
      this.field_b = class_943.field_d.a4();
      this.field_c = class_943.field_c.a4();
      this.field_d = class_943.field_e.a4();
   }

}
