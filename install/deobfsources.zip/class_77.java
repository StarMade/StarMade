import com.bulletphysics.collision.dispatch.CollisionObject;
import com.bulletphysics.dynamics.RigidBody;
import com.bulletphysics.util.ObjectArrayList;
import java.io.File;
import java.util.Iterator;
import javax.vecmath.Vector3f;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.objects.Sendable;
import paulscode.sound.SoundSystem;
import paulscode.sound.SoundSystemConfig;
import paulscode.sound.codecs.CodecJOrbis;
import paulscode.sound.codecs.CodecWav;
import paulscode.sound.libraries.LibraryLWJGLOpenAL;

public final class class_77 {

   private static SoundSystem field_a;
   private class_61 field_a = new class_61();
   private class_61 field_b = new class_61();
   private int field_a;
   private static boolean field_a = false;
   private final ObjectArrayList field_a = new ObjectArrayList();
   private final Vector3f field_a = new Vector3f();


   public class_77() {
      new class_61();
      this.field_a = 0;
   }

   public final void a() {
      this.field_b.field_a = false;
      if(!field_a && class_943.field_g.b1()) {
         try {
            float var1 = a1();
            float var2 = (float)((Integer)class_943.field_i.a4()).intValue() / 10.0F;
            a2(0.0F);
            a2(0.0F);
            SoundSystemConfig.addLibrary(LibraryLWJGLOpenAL.class);
            SoundSystemConfig.setCodec("ogg", CodecJOrbis.class);
            SoundSystemConfig.setCodec("wav", CodecWav.class);
            field_a = new SoundSystem();
            a2(var1);
            a2(var2);
         } catch (Throwable var3) {
            var3.printStackTrace();
            System.err.println("error linking with the LibraryJavaSound plug-in");
         }

         field_a = true;
      }

   }

   private static float a1() {
      return (float)((Integer)class_943.field_i.a4()).intValue() / 10.0F;
   }

   private static void a2(float var0) {
      class_943.field_i.a8(Integer.valueOf((int)(var0 * 10.0F)));
   }

   public static void b() {
      if(field_a) {
         System.err.println("[AUDIO] Cleaning up sound system");
         field_a.cleanup();
      }

   }

   public final void a3(String var1, File var2) {
      this.field_a.a(var1, var2);
   }

   public final void a4(class_1432 var1) {
      if(field_a && a1() != 0.0F) {
         if(var1 != null) {
            field_a.setListenerPosition(var1.getWorldTransform().origin.field_x, var1.getWorldTransform().origin.field_y, var1.getWorldTransform().origin.field_z);
            Vector3f var2 = GlUtil.c(new Vector3f(), var1.getWorldTransform());
            Vector3f var3 = GlUtil.f(new Vector3f(), var1.getWorldTransform());
            field_a.setListenerOrientation(var2.field_x, var2.field_y, var2.field_z, var3.field_x, var3.field_y, var3.field_z);
            CollisionObject var4;
            if(var1 instanceof class_1419 && (var4 = ((class_1419)var1).getPhysicsDataContainer().getObject()) != null && var4 instanceof RigidBody) {
               ((RigidBody)var4).getLinearVelocity(this.field_a);
               field_a.setListenerVelocity(this.field_a.field_x, this.field_a.field_y, this.field_a.field_z);
            }

         }
      }
   }

   public final void c() {
      if(field_a && a1() != 0.0F) {
         Iterator var1 = this.field_a.iterator();

         while(var1.hasNext()) {
            class_76 var2 = (class_76)var1.next();
            this.b1(var2, var2.b(), var2.b1(), 1.0F);
         }

      }
   }

   private void b1(class_76 var1, String var2, float var3, float var4) {
      if(field_a && a1() != 0.0F) {
         class_60 var5;
         if((var5 = this.field_a.a1(var2)) != null && var3 > 0.0F) {
            this.field_a = (this.field_a + 1) % 256;
            var2 = ((class_74)var1).getUniqueIdentifier();
            float var6 = 16.0F;
            if(var3 > 1.0F) {
               var6 = 16.0F * var3;
            }

            field_a.newSource(var3 > 1.0F, var2, var5.field_a, var5.field_a, true, var1.getWorldTransformClient().origin.field_x, var1.getWorldTransformClient().origin.field_y, var1.getWorldTransformClient().origin.field_z, 2, var6);
            field_a.setPitch(var2, var4);
            if(var3 > 1.0F) {
               var3 = 1.0F;
            }

            field_a.setVolume(var2, var3 * a1());
            field_a.play(var2);
         } else {
            System.err.println("[SOUND] WARNING: sound not found: " + var2);
         }
      }
   }

   public final void a5(class_76 var1, String var2, float var3, float var4) {
      if(field_a && a1() != 0.0F) {
         field_a.stop(var1.getUniqueIdentifier());
         this.b1(var1, var2, var3, var4);
         if(!this.field_a.contains(var1)) {
            this.field_a.add(var1);
         }

      }
   }

   public final void d() {
      Iterator var1 = this.field_a.iterator();

      while(var1.hasNext()) {
         class_76 var2 = (class_76)var1.next();
         field_a.setPosition(var2.getUniqueIdentifier(), var2.getWorldTransformClient().origin.field_x, var2.getWorldTransformClient().origin.field_y, var2.getWorldTransformClient().origin.field_z);
         CollisionObject var3;
         if((var3 = var2.getPhysicsDataContainer().getObject()) != null && var3 instanceof RigidBody) {
            ((RigidBody)var3).getLinearVelocity(this.field_a);
            field_a.setVelocity(var2.getUniqueIdentifier(), this.field_a.field_x, this.field_a.field_y, this.field_a.field_z);
         }
      }

   }

   public final void a6(String var1) {
      class_60 var2;
      if((var2 = this.field_a.a1(var1)) != null) {
         field_a.backgroundMusic("bm", var2.field_a, var2.field_a, true);
         field_a.setVolume("bm", 0.18F);
      }

   }

   public final void a7(String var1, float var2, float var3, float var4, float var5) {
      if(field_a && a1() != 0.0F) {
         class_60 var6;
         if((var6 = this.field_a.a1(var1)) != null && var5 > 0.0F) {
            this.field_a = (this.field_a + 1) % 256;
            var1 = "sound_" + this.field_a;
            float var7 = 16.0F;
            if(var5 > 1.0F) {
               var7 = 16.0F * var5;
            }

            field_a.newSource(var5 > 1.0F, var1, var6.field_a, var6.field_a, false, var2, var3, var4, 2, var7);
            field_a.setPitch(var1, 1.0F);
            if(var5 > 1.0F) {
               var5 = 1.0F;
            }

            field_a.setVolume(var1, var5 * a1());
            field_a.play(var1);
         } else {
            System.err.println("[SOUND] WARNING: sound not found: " + var1);
         }
      }
   }

   public final void b2(String var1) {
      if(field_a && a1() != 0.0F) {
         class_60 var3;
         if((var3 = this.field_a.a1(var1)) != null) {
            this.field_a = (this.field_a + 1) % 256;
            String var2 = "sound_" + this.field_a;
            field_a.newSource(false, var2, var3.field_a, var3.field_a, false, 0.0F, 0.0F, 0.0F, 0, 0.0F);
            field_a.setPitch(var2, 1.0F);
            field_a.setVolume(var2, 0.25F * a1());
            field_a.play(var2);
         }

      }
   }

   public final ObjectArrayList a8() {
      return this.field_a;
   }

   public static boolean a9() {
      return field_a;
   }

   public final void a10(Sendable var1) {
      if(field_a && a1() != 0.0F) {
         field_a.stop(((class_74)var1).getUniqueIdentifier());
         this.field_a.remove(var1);
      }
   }

   public static void e() {
      if(field_a && a1() != 0.0F) {
         field_a.stop("bm");
      }
   }

   public final void a11(class_76 var1) {
      this.a5(var1, var1.a(), 1.0F, var1.b1());
   }

   public final void b3(class_76 var1) {
      this.a5(var1, var1.b(), var1.b1(), 1.0F);
   }

}
