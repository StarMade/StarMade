import java.io.DataOutputStream;

public interface class_347 extends class_74, class_953 {

   void a2(DataOutputStream var1);

   int a3();

   void a4(byte var1);

   boolean a5(int var1, class_47 var2);

   class_251 a6(class_47 var1);

   boolean a7();
}
