import java.util.HashMap;
import org.schema.schine.ai.stateMachines.FSMException;

public final class class_460 extends class_985 {

   public class_743 field_a;


   public class_460(class_991 var1) {
      super(var1, true);
      this.b2(false);
   }

   public final void a() {
      super.field_a.a2().a1(new class_395());
   }

   public final void b() {
      try {
         super.field_a.a2().a1(new class_393());
      } catch (FSMException var1) {
         var1.printStackTrace();
      }
   }

   public final void c() {
      try {
         super.field_a.a2().a1(new class_375());
      } catch (FSMException var1) {
         var1.printStackTrace();
      }
   }

   public final class_371 a1() {
      return (class_371)super.a6();
   }

   public static boolean a2() {
      return false;
   }

   public final void d() {
      try {
         super.field_a.a2().a1(new class_385());
      } catch (FSMException var1) {
         var1.printStackTrace();
      }
   }

   public final void e() {
      try {
         super.field_a.a2().a1(new class_383());
      } catch (FSMException var1) {
         var1.printStackTrace();
      }
   }

   public final void a3(boolean var1) {
      if(!(super.field_a.a2().a() instanceof class_405) && !var1) {
         try {
            super.field_a.a2().a1(new class_381());
            return;
         } catch (FSMException var2) {
            ;
         }
      }

   }

   public final void f() {
      if(super.field_a.a2().a() instanceof class_454) {
         ((class_454)super.field_a.a2().a()).a2();
      }

   }

   protected final void a4(HashMap var1) {
      var1.put("basic_tutorial", new class_462(super.field_a, this));
   }

   protected final String a5() {
      return "basic_tutorial";
   }
}
