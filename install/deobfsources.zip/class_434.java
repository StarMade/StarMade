import java.util.Iterator;
import javax.vecmath.Vector3f;
import org.lwjgl.input.Keyboard;
import org.schema.schine.graphicsengine.camera.Camera;

public final class class_434 extends class_15 {

   private Camera field_a;
   private float field_a = 0.0F;
   private float field_b = 0.0F;
   private class_801 field_a;
   private boolean field_d = false;
   private boolean field_e;


   public class_434(class_371 var1) {
      super(var1);
      new Vector3f();
      this.field_e = true;
      new class_47();
   }

   private class_800 a40() {
      return this.a6().a14().field_a.field_a.field_a.a53().a40();
   }

   public final void handleKeyEvent() {
      if(Keyboard.getEventKeyState() && Keyboard.getEventKey() >= 2 && Keyboard.getEventKey() <= 11 && !Keyboard.isKeyDown(29)) {
         int var2 = Keyboard.getEventKey() - 2;
         this.a6().a20().d6(var2);
         this.field_e = true;
      }

   }

   public final void a12(class_941 var1) {}

   public final void b2(boolean var1) {
      class_447 var2 = this.a6().a14().field_a.field_a.field_a.a53();
      if(this.a6().a20() != null) {
         this.a6().a20().a55((class_801)null);
      }

      if(var1) {
         System.err.println("[CLIENT][SEGMENTEXTERNALCONTROLLER] ENTERED: " + this.a40());
         this.field_a = new class_191(var2, class_967.a1(), this.a40());
         this.field_a.a(0.0F);
         class_47 var3 = new class_47();
         if(!this.a6().a14().field_a.field_a.field_a.a53().a40().a2(var3).equals(class_743.field_a)) {
            ((class_191)this.field_a).field_b = true;
         } else {
            ((class_191)this.field_a).field_b = false;
         }

         class_47 var4;
         (var4 = var2.a40().a2(new class_47())).c1(class_743.field_a);
         ((class_201)this.field_a.a184()).a85().b1(var4);
         ((class_201)this.field_a.a184()).a2();
         class_967.a9(this.field_a);
      } else {
         this.field_a = null;
      }

      super.b2(var1);
   }

   private class_801 a43() {
      if(this.a6().a23() != null && this.a6().a23().a26() != null) {
         class_1381 var1 = this.a6().a23().a26();
         Vector3f var2 = new Vector3f();
         float var3 = 0.0F;
         float var4 = -1.0F;
         class_801 var5 = null;
         Vector3f var6 = var1.a1(new Vector3f());
         Iterator var7 = this.a6().a7().values().iterator();

         while(var7.hasNext()) {
            class_801 var8;
            if((var8 = (class_801)var7.next()) != this.a6().a6()) {
               var2.set(var8.getWorldTransform().origin);
               if(this.a6().a6() != null) {
                  var2.sub(this.a6().a6().getWorldTransform().origin);
               } else {
                  var2.sub(class_967.a1().a83());
               }

               Vector3f var9 = var1.a2(var8.getWorldTransform().origin, new Vector3f(), true);
               Vector3f var10 = new Vector3f();
               Vector3f var11 = new Vector3f();
               var10.sub(var9, var6);
               var11.sub(this.a40().a7().a15().getWorldTransform().origin, var8.getWorldTransform().origin);
               if(var10.length() < 90.0F && (var5 == null || var10.length() < var3 && var11.length() < var4)) {
                  var5 = var8;
                  var3 = var10.length();
                  var4 = var11.length();
               }
            }
         }

         return var5;
      } else {
         return null;
      }
   }

   public final void a15(class_935 var1) {
      super.a15(var1);
      class_434 var2 = this;
      if(this.field_e) {
         try {
            class_359 var3;
            if((var3 = var2.a6().a20().a118(var2.a40().a7().a15())) != null) {
               class_47 var6 = var3.a17(var2.a6().a20().d());
               class_800 var7;
               if((var7 = var2.a40().a7().a15().getSegmentBuffer().a9(var6, true)) != null) {
                  var2.field_d = var7.a9() == 54;
               }

               var2.field_e = false;
            }
         } catch (Exception var4) {
            ;
         }
      }

      class_1008.field_a = true;
      if(this.field_d) {
         if(this.a6().a20().a110() != null) {
            this.field_b += var1.a();
         }

         if(this.field_b <= 0.0F || this.field_b >= 3.0F) {
            this.field_b = 0.0F;
            class_801 var5 = this.a43();
            if(this.field_a != var5) {
               this.field_a = var5;
               this.field_a = 0.0F;
               this.a6().a20().a55((class_801)null);
               return;
            }

            if(this.field_a != null) {
               this.field_a += var1.a();
               if(this.field_a > 5.0F) {
                  this.a6().a20().a55(this.field_a);
               }
            }

            return;
         }

         if(this.a43() == this.a6().a20().a110()) {
            this.field_b = 0.0F;
            return;
         }
      } else {
         this.a6().a20().a55((class_801)null);
         this.field_a = 0.0F;
         this.field_b = 0.0F;
      }

   }
}
