import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;
import org.schema.schine.network.objects.remote.RemoteInteger;
import org.schema.schine.network.objects.remote.Streamable;

public final class class_159 extends class_964 implements Observer {

   private class_970 field_a = new class_970(class_967.a2().a5("inventory-gui-"), (class_371)super.a24());
   private class_970 field_b = new class_970(class_967.a2().a5("sell-item-dropzone-gui-"), (class_371)super.a24());
   private class_163 field_a;
   private class_187 field_a;
   private boolean field_a;
   private class_194 field_a;
   private class_928 field_a;


   public class_159(ClientState var1) {
      super(var1);
      this.field_b.field_g = true;
      this.field_a = new class_163((class_371)super.a24());
      this.field_a = new class_187((class_371)super.a24());
      this.a49().addObserver(this);
   }

   public final void a9(class_964 var1) {
      this.field_a.a9(var1);
   }

   public final void a2() {}

   public final void b2(class_964 var1) {
      this.field_a.b2(var1);
   }

   public final void b() {
      if(this.field_a) {
         this.field_a.b2(this.field_a);
         this.field_a.b2(this.field_a);
         this.field_a.b2(this.field_a);
         if(this.a49().field_a == null) {
            System.err.println("!!!!!!!!!!!!!!!!!!! NO SECOND INVENTORY");
            this.field_a.a9(this.field_a);
         } else {
            this.field_a.a54(this.a49().field_a);
            this.field_a.a9(this.field_a);
            if(this.a49().field_a instanceof class_639) {
               this.field_a.a9(this.field_a);
            }
         }

         this.field_a = false;
      }

      GlUtil.d1();
      this.r();
      if(((class_371)super.a24()).getDragging() != null && ((class_371)super.a24()).d2()) {
         this.field_b.a165(-47.0F, 100.0F, 0.0F);
         this.field_b.b();
      } else {
         this.field_b.b20(false);
      }

      this.l();
      class_159 var1 = this;
      class_1416 var2;
      if((super.field_b.field_x < 208.0F || super.field_b.field_y < 24.0F || super.field_b.field_x > 816.0F || super.field_b.field_y > 512.0F) && !((class_371)super.a24()).a27().a92().a18().a22().a_() && (var2 = ((class_371)super.a24()).getDragging()) != null && var2 instanceof class_185) {
         Iterator var3;
         class_941 var4;
         class_185 var7;
         if(this.field_b.a_()) {
            var3 = ((class_371)super.a24()).getMouseEvents().iterator();

            while(var3.hasNext()) {
               var4 = (class_941)var3.next();
               if(var2.a2(var4)) {
                  var7 = (class_185)((class_371)super.a24()).getDragging();
                  class_739 var6;
                  if((var6 = ((class_371)super.a24()).a5()) != null) {
                     ((class_371)super.a24()).a14().field_a.field_a.field_a.a34(var7.a70(), var7.a68(true), var6);
                  } else {
                     ((class_371)super.a24()).a4().b1("ERROR: not in shop dist");
                  }

                  var2.a5(false);
                  ((class_371)super.a24()).setDragging((class_1416)null);
                  break;
               }
            }
         } else {
            ((class_185)var2).f();
            var3 = ((class_371)super.a24()).getMouseEvents().iterator();

            while(var3.hasNext()) {
               var4 = (class_941)var3.next();
               if(var2.a2(var4)) {
                  System.err.println("CHECKING " + var1 + " " + var1.hashCode() + " MOUSE NO MORE GRABBED");
                  boolean var8 = false;
                  if(var2 instanceof class_185 && var2 != var1) {
                     if(System.currentTimeMillis() - var2.a4() > 50L) {
                        System.err.println("NOW DROPPING " + var2);
                        var7 = (class_185)var2;
                        System.err.println("[INVENTORYGUI] ITEM " + var7.a70() + " #" + var7.a68(true) + " thrown into trash");
                        ((class_371)var1.a24()).a20().a117().dropOrPickupSlots.add((Streamable)(new RemoteInteger(Integer.valueOf(var7.c5()), ((class_371)var1.a24()).a20().a117())));
                     } else {
                        System.err.println("NO DROP: time dragged to short");
                     }

                     var8 = true;
                  }

                  if(!(var2 instanceof class_185)) {
                     System.err.println("NO DROP: not a target: " + var1);
                  }

                  if(var2 == var1 && var2.b()) {
                     var2.a5(false);
                     ((class_371)var1.a24()).setDragging((class_1416)null);
                  }

                  if(var8) {
                     ((class_371)var1.a24()).setDragging((class_1416)null);
                  }
               }
            }
         }
      }

      this.field_a.b();
      GlUtil.c2();
   }

   public final void a48(class_185 var1) {
      class_163 var2 = this.field_a;
      this.field_a.field_a.a48(var1);
      var2.field_b.a48(var1);
      this.field_a.field_a.a48(var1);
   }

   public final void e() {
      GlUtil.d1();
      this.field_a.r();
      class_163 var1 = this.field_a;
      this.field_a.field_a.e();
      var1.field_b.e();
      this.field_a.field_a.e();
      GlUtil.c2();
   }

   public final float a3() {
      return this.field_a.a3();
   }

   public final class_469 a49() {
      return ((class_371)super.a24()).a14().field_a.field_a.field_a;
   }

   public final float b1() {
      return this.field_a.b1();
   }

   public final void c() {
      this.field_a = new class_928((class_371)super.a24(), 100, 20, "Drop Credits", new class_189(this));
      this.field_b.c();
      this.field_a.c();
      super.a9(this.field_a);
      this.field_a.c();
      this.field_a.c();
      this.field_a = new class_194(class_967.a2().a5("buttons-8x8-gui-"), (class_371)super.a24(), class_319.field_c, "CONVERT", this.a49());
      this.field_a.b29(0.35F, 0.35F, 0.35F);
      this.field_a.a165(500.0F, 264.0F, 0.0F);
      this.field_a.a9(this.field_a);
      this.field_a.a9(this.field_a);
      this.field_a.a165(680.0F, 70.0F, 0.0F);
      this.field_a.b14(7, 1);
      this.field_a.a165(260.0F, 96.0F, 0.0F);
      this.field_a.a165(260.0F, 96.0F, 0.0F);
   }

   public final void update(Observable var1, Object var2) {
      this.field_a = true;
   }
}
