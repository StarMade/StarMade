import com.bulletphysics.linearmath.Transform;
import javax.vecmath.Vector3f;
import org.schema.schine.graphicsengine.core.GlUtil;

public final class class_291 implements class_923 {

   private class_1359 field_a;
   class_226 field_a;
   private boolean field_a = true;
   class_802 field_a;
   Vector3f field_a = new Vector3f();
   class_47 field_a = new class_47();


   public class_291(class_802 var1) {
      this.field_a = var1;
      this.field_a = new class_226();
      this.field_a = new class_1359(this.field_a, 8.0F);
   }

   public final void a() {}

   public final void b() {
      if(this.field_a) {
         this.c();
      }

      GlUtil.d1();
      GlUtil.b3(this.field_a.a1().getWorldTransformClient());
      this.field_a.field_a.set(this.field_a.a1().getWorldTransformClient());
      this.field_a.b();
      GlUtil.c2();
   }

   public final void c() {
      if(this.field_a.field_a == null) {
         this.field_a.field_a = new Transform();
      }

      this.field_a.c();
      this.field_a = false;
   }

   public final boolean a5() {
      return this.field_a.b1() > 0;
   }
}
