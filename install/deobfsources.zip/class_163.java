import org.schema.schine.graphicsengine.core.GlUtil;
import org.schema.schine.network.client.ClientState;

public final class class_163 extends class_964 {

   private class_966 field_a;
   private class_966 field_b;
   private boolean field_a;
   private class_970 field_a;
   private class_970 field_b;
   class_161 field_a;
   class_161 field_b;


   public class_163(ClientState var1) {
      super(var1);
      this.field_a = new class_966(536.0F, 171.0F, var1);
      this.field_b = new class_966(536.0F, 171.0F, var1);
      this.field_b.a83().field_y = 189.0F;
      this.a9(this.field_a);
      this.a9(this.field_b);
   }

   public final void a2() {}

   public final void b() {
      if(!this.field_a) {
         this.c();
      }

      GlUtil.d1();
      this.r();
      this.field_a.b();
      this.field_b.b();
      GlUtil.c2();
   }

   public final float a3() {
      return 360.0F;
   }

   public final float b1() {
      return 536.0F;
   }

   public final boolean a_() {
      return super.a_() && (this.a158() == null || ((class_964)this.a158()).a_());
   }

   public final void c() {
      this.field_a = new class_183(this.a24(), this.field_a);
      this.field_b = new class_183(this.a24(), this.field_b);
      this.field_a.c6(this.field_a);
      this.field_b.c6(this.field_b);
      this.field_a = new class_161((class_371)this.a24());
      this.field_b = new class_161((class_371)this.a24());
      class_635 var1 = ((class_371)this.a24()).a20().getInventory((class_47)null);
      this.field_a.a54(var1);
      this.a54(((class_371)this.a24()).a20().getInventory((class_47)null));
      this.field_a.a9(this.field_a);
      this.field_b.a9(this.field_b);
      this.field_a.c();
      this.field_b.c();
      this.field_a = true;
   }

   public final void a54(class_635 var1) {
      this.field_b.a54(var1);
   }
}
