import javax.vecmath.Vector4f;
import org.schema.schine.network.client.ClientState;

public class class_86 extends class_196 {

   private final class_777 field_a;
   private final class_777 field_b;
   private final class_344 field_a;
   // $FF: synthetic field
   private static boolean field_b = !gX.class.desiredAssertionStatus();


   public class_86(ClientState var1, class_777 var2, class_777 var3, class_344 var4) {
      super(var1, var4, "Relationship to " + var3.a(), "");
      this.field_a = var2;
      this.field_b = var3;
      this.field_a = var4;
   }

   public final void c() {
      super.c();
      class_940 var1 = new class_940(100, 10, this.a24());
      class_631 var2 = ((class_371)this.a24()).a45().a149(this.field_a.a3(), this.field_b.a3());
      class_928 var3 = new class_928(this.a24(), 100, 25, new Vector4f(0.7F, 0.0F, 0.0F, 1.0F), new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), class_28.h(), "Declare War", this.field_a);
      class_928 var4 = new class_928(this.a24(), 100, 25, new Vector4f(0.7F, 0.0F, 0.7F, 1.0F), new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), class_28.h(), "Offer Peace", this.field_a);
      class_928 var5 = new class_928(this.a24(), 100, 25, new Vector4f(0.0F, 0.0F, 0.7F, 1.0F), new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), class_28.h(), "Offer Alliance", this.field_a);
      var4.a83().field_y = 15.0F;
      var3.a83().field_y = 45.0F;
      var5.a83().field_y = 75.0F;
      class_928 var6 = new class_928(this.a24(), 100, 25, new Vector4f(0.7F, 0.0F, 0.7F, 1.0F), new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), class_28.h(), "Revoke Peace Offer", this.field_a);
      class_928 var7 = new class_928(this.a24(), 100, 25, new Vector4f(0.0F, 0.0F, 0.7F, 1.0F), new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), class_28.h(), "Revoke Alliance Offer", this.field_a);
      var6.a83().field_y = 45.0F;
      var7.a83().field_y = 75.0F;
      switch(class_88.field_a[var2.ordinal()]) {
      case 1:
         var1.a137("You are on war with " + this.field_b.a());
         this.field_a.a9(var4);
         this.field_a.a9(var5);
         break;
      case 2:
         var1.a137("You are allied to " + this.field_b.a());
         this.field_a.a9(var3);
         this.field_a.a9(var4);
         break;
      case 3:
         var1.a137("You are on peace with " + this.field_b.a());
         this.field_a.a9(var3);
         this.field_a.a9(var5);
         break;
      default:
         if(!field_b) {
            throw new AssertionError();
         }
      }

      this.field_a.a9(var1);
      var3.field_a = "WAR";
      var4.field_a = "PEACE";
      var5.field_a = "ALLY";
   }

}
