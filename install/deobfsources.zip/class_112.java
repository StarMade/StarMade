
public final class class_112 extends class_11 implements class_1410 {

   class_777 field_a;
   private class_117 field_a;
   class_762 field_a;


   public class_112(class_371 var1, class_777 var2, class_762 var3) {
      super(var1);
      this.field_a = var2;
      this.field_a = new class_117(this, var1, this, "Settings for " + var3.field_a, "", var2);
      this.field_a = var3;
   }

   public final void handleKeyEvent() {}

   public final void a(class_964 var1, class_941 var2) {
      if(var2.field_a && var2.field_a == 0) {
         if(var1.b19().equals("CANCEL") || var1.b19().equals("X")) {
            System.err.println("CANCEL");
            this.d();
         }

         if(var1 instanceof class_105) {
            int var4 = ((Integer)var1.b19()).intValue();
            class_762 var5;
            if((var5 = (class_762)this.field_a.a154().get(super.field_a.a20().getName())) == null) {
               super.field_a.a4().b1("You are not in this faction");
               return;
            }

            try {
               if(var5.field_a.equals(this.field_a.field_a) && var5.field_a == 4) {
                  this.d();
                  class_118 var10000 = new class_118(this, super.field_a, "Confirm", "You are admin of this faction.\nDo you really want to change your role", var5, var4);
                  var1 = null;
                  var10000.c1();
                  return;
               }

               if(!var5.d7(this.field_a)) {
                  super.field_a.a4().b1("You cannot change role:\npermission denied!");
               } else if(var5.field_a < this.field_a.field_a) {
                  super.field_a.a4().b1("You cannot change\nroles of higher ranked\nplayers");
               } else {
                  this.field_a.b31(super.field_a.a20().getName(), this.field_a.field_a, (byte)var4, super.field_a.a12());
               }

               this.d();
               return;
            } catch (Exception var3) {
               var1 = null;
               var3.printStackTrace();
            }
         }
      }

   }

   public final boolean a1() {
      return false;
   }

   public final class_964 a3() {
      return this.field_a;
   }

   public final void a2() {}

   // $FF: synthetic method
   static class_777 a20(class_112 var0) {
      return var0.field_a;
   }

   // $FF: synthetic method
   static class_762 a21(class_112 var0) {
      return var0.field_a;
   }
}
