import org.schema.game.common.controller.CannotBeControlledException;

public abstract class class_485 extends class_15 {

   public class_485(class_371 var1) {
      super(var1);
   }

   public final void a81(CannotBeControlledException var1) {
      if(var1 != null && var1.field_a != null && var1.field_a.controlledBy != null && var1.field_a.controlledBy.size() > 0) {
         this.a6().a4().b1(var1.field_a.getName() + " cannot be\nconnected to selected block:\n" + var1.field_b.getName());
      }

   }

   public abstract void b();
}
