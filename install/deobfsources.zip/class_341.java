
public class class_341 {

   public class_47 field_a;
   public byte field_a;


   public class_341() {}

   public class_341(class_341 var1) {
      this(var1.field_a, new class_47(var1.field_a));
   }

   public class_341(byte var1, class_47 var2) {
      this.field_a = var1;
      this.field_a = var2;
   }

   public boolean equals(Object var1) {
      return this.field_a == ((class_341)var1).field_a && this.field_a.equals(((class_341)var1).field_a);
   }

   public int hashCode() {
      return this.field_a * 90000 + this.field_a.hashCode();
   }
}
