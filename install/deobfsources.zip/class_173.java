import java.util.HashMap;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import org.schema.schine.network.client.ClientState;

public abstract class class_173 extends class_964 implements Observer, class_1410 {

   private class_966 field_a;
   private class_963 field_a;
   private int field_a = 400;
   private int field_b = 380;
   private class_1410 field_b;
   private int field_c;
   private boolean field_a = true;
   private boolean field_b;


   public class_173(ClientState var1, class_1410 var2) {
      super(var1);
      this.field_b = var2;
      this.field_b = true;
      ((class_371)super.a24()).a12().a51().addObserver(this);
   }

   public final class_371 a20() {
      return (class_371)super.a24();
   }

   public final void a2() {}

   public final void b() {
      if(this.a57() != this.field_c) {
         this.field_a = true;
      }

      if(this.field_a) {
         this.e();
         this.field_a = false;
      }

      this.k();
   }

   public final void c() {
      this.field_a = new class_966((float)this.field_a, (float)this.field_b, (class_371)super.a24());
      this.field_a = new class_963((class_371)super.a24());
      this.field_a.a143(this);
      this.e();
      this.field_a.c6(this.field_a);
      this.a9(this.field_a);
   }

   private void e() {
      class_769 var1 = ((class_371)super.a24()).a12().a51();
      int var2 = this.a57();
      this.field_a.clear();
      class_777 var6;
      if((var6 = var1.a146(var2)) != null) {
         HashMap var3 = var6.a154();
         int var4 = 0;
         Iterator var7 = var3.values().iterator();

         while(var7.hasNext()) {
            class_762 var5 = (class_762)var7.next();
            class_171 var8;
            (var8 = new class_171(this, (class_371)super.a24(), var6, var5, var4++)).c();
            this.field_a.a144(var8);
         }
      }

      this.field_c = var2;
   }

   public abstract int a57();

   public final float a3() {
      return (float)this.field_b;
   }

   public final float b1() {
      return (float)this.field_a;
   }

   public void update(Observable var1, Object var2) {
      this.field_a = true;
   }

   // $FF: synthetic method
   static class_1410 a58(class_173 var0) {
      return var0.field_b;
   }

   // $FF: synthetic method
   static boolean a59(class_173 var0) {
      return var0.field_b;
   }
}
