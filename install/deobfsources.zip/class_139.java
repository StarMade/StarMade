import java.util.Comparator;
import java.util.Locale;

final class class_139 implements Comparator {

   // $FF: synthetic method
   public final int compare(Object var1, Object var2) {
      class_972 var10000 = (class_972)var1;
      class_972 var3 = (class_972)var2;
      return ((class_248)var10000).a108().field_b.toLowerCase(Locale.ENGLISH).compareTo(((class_248)var3).a108().field_b.toLowerCase(Locale.ENGLISH));
   }
}
