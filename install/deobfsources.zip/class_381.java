
public final class class_381 extends class_956 {

   private static final long serialVersionUID = -5677566600649358934L;


}
